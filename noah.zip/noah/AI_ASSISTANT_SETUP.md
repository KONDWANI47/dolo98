# NCA AI Assistant - Setup Guide

## Overview

The NCA AI Assistant has been successfully integrated into your School Management System. This powerful AI assistant helps teachers and administrators with:

- **Teachers**: Student queries, lesson plans, exam generation, homework creation, attendance analysis, performance reports
- **Administrators**: School-wide analytics, financial reports, fee management, teacher information, comprehensive reports

## Prerequisites

1. **Groq API Key** (recommended - free tier available)
   - Get your API key from: https://console.groq.com/keys
   - Sign up for a free Groq account
   - Click "Create API Key"
   - Copy the API key (starts with `gsk-`)
   - Recommended model: `qwen/qwen3.8-27b` or `openai/gpt-oss-20b` (free tier)

   **Alternative Providers:**
   - **OpenAI**: Get key from https://platform.openai.com/api-keys (key starts with `sk-`)
   - **Gemini**: Get key from https://aistudio.google.com/app/apikey (key starts with `AIzaSy`)

2. **Google Custom Search API Key** (optional, for web search)
   - Get from: https://developers.google.com/custom-search/v1/overview
   - Create a Custom Search Engine at: https://programmablesearchengine.google.com/
   - Enable the API in Google Cloud Console

## Installation Steps

### 1. Configure Environment Variables

Edit the `.env` file in your project root:

```bash
# AI Configuration
# Groq (recommended - free tier, very fast)
AI_PROVIDER=groq
AI_MODEL=qwen/qwen3.8-27b
AI_API_KEY=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


# Google Custom Search API (optional, for web search)
GOOGLE_SEARCH_API_KEY=your_google_search_api_key_here
GOOGLE_SEARCH_ENGINE_ID=your_search_engine_id_here
```

**Important**: Replace the placeholder values with your actual API keys. The system supports NVIDIA, Gemini, and OpenAI providers.

### 2. File Structure

The AI assistant consists of the following files:

```
noah/
├── api/
│   ├── ai_service.php          # AI provider abstraction layer
│   ├── ai_tools.php             # Secure database tool system
│   ├── ai.php                   # Main AI chat API endpoint
│   └── web_search.php           # Web search service
├── css/
│   └── ai-chat.css              # Chat interface styles
├── script/
│   └── ai-chat.js               # Chat interface JavaScript
├── dashboard/
│   └── teacher.html             # Teacher portal (updated)
└── admin/
    └── admin.html               # Admin portal (updated)
```

### 3. Database Tables

The following tables are automatically created on first use:

- `ai_conversations` - Stores chat history
- `ai_usage_log` - Tracks AI API usage for monitoring

No manual database setup is required.

## Features

### Teacher Capabilities

1. **Student Queries**
   - "Show me my students"
   - "Who are the students in Form 2A?"
   - "Which students have attendance below 75%?"

2. **Results & Performance**
   - "Show me John Banda's performance this term"
   - "Who scored below 50% in mathematics?"
   - "What is the average mark for my class?"

3. **Lesson Plans**
   - "Create a mathematics lesson plan for Form 2 about fractions"
   - "Generate a lesson plan for my class"

4. **Examinations**
   - "Create a Form 3 mathematics examination"
   - "Generate 20 multiple-choice questions about photosynthesis"

5. **Homework**
   - "Create homework for my class"
   - "Generate homework about algebra"

6. **Reports**
   - "Analyze my class performance"
   - "Identify students who need academic support"

### Administrator Capabilities

1. **School-wide Analytics**
   - "How many students are enrolled?"
   - "Show me students with outstanding fees"
   - "How much money is outstanding?"

2. **Financial Reports**
   - "Generate a financial summary"
   - "Show fee payments for this term"

3. **Attendance**
   - "How many students are absent today?"
   - "Show me teacher attendance"
   - "Generate an attendance report"

4. **Performance Analysis**
   - "Which classes have the highest failure rate?"
   - "Compare examination results between terms"
   - "Show me the top-performing students"

5. **Comprehensive Reports**
   - "Generate a school performance report"
   - "Create an enrollment report"
   - "Create a fee collection report"

## Security Features

### 1. SQL Injection Prevention
- All database queries use prepared statements
- No direct SQL execution from user input
- Parameterized queries throughout

### 2. Role-Based Access Control
- Teachers can only access their assigned class data
- Administrators have school-wide access
- Permission checks on every database operation

### 3. API Key Security
- API keys stored in environment variables (not in code)
- Never exposed to frontend
- Backend-only API calls

### 4. Audit Logging
- All AI usage logged to `ai_usage_log` table
- Tracks user ID, role, timestamps, token usage
- Activity logging for important actions

### 5. Input Validation
- All user inputs validated and sanitized
- File upload restrictions (PDF, DOCX, XLSX, CSV, TXT only)
- Maximum file size limits

### 6. Confirmation Workflows
- Destructive actions require user confirmation
- Clear warning messages before important operations
- Cancel option always available

## Usage

### For Teachers

1. Log in to the Teacher Portal
2. Click the floating AI button (bottom-right corner)
3. Ask questions in natural language
4. The AI will use available tools to answer
5. View suggestions for common tasks

### For Administrators

1. Log in to the Admin Portal
2. Click the floating AI button (bottom-right corner)
3. Ask questions in natural language
4. Access school-wide data and analytics
5. Generate comprehensive reports

## Cost Estimation

### Groq API Costs (qwen/qwen3.8-27b)

- **Free tier limits** (varies by account):
  - 32 API calls per day (some accounts)
  - 8,000 tokens per minute (TPM)
  - Valid until: April 1, 2027 (for some accounts)
- **Paid tier**: $0.0001 per 1K tokens (very affordable)
- **Estimated cost per conversation**: $0.0001 - $0.001 (after free tier)
- **Estimated monthly cost (100 conversations)**: $0.01 - $0.10 (after free tier)

**Note**: Free tier limits vary by account. Check your specific limits at https://console.groq.com/settings/billing

### Gemini API Costs (gemini-1.5-flash)

- **Input tokens**: Free (up to certain limits)
- **Output tokens**: Free (up to certain limits)
- **Paid tier**: $0.075 per 1M input tokens, $0.30 per 1M output tokens
- **Estimated cost per conversation**: $0.001 - $0.005 (after free tier)
- **Estimated monthly cost (100 conversations)**: $0.10 - $0.50 (after free tier)

### Cost Optimization Tips

1. Use Groq's free tier for most queries
2. Clear chat history regularly to reduce token usage
3. Keep messages shorter to avoid hitting token limits
4. Implement caching for repeated queries
5. Monitor usage via `ai_usage_log` table

## Troubleshooting

### AI Not Responding

1. Check `.env` file has valid `AI_API_KEY` (must start with `gsk-` for Groq)
2. Verify API key is from Groq Console (https://console.groq.com/keys)
3. Check PHP error logs for API errors
4. Ensure internet connection is available
5. Verify the model name is correct (e.g., `qwen/qwen3.8-27b`)

### Rate Limit Errors

If you see "Request too large" or "tokens per minute limit" errors:
1. Wait 1-2 minutes for the rate limit to reset
2. Clear the chat history (click trash icon)
3. Keep messages shorter
4. Consider upgrading to Groq Dev Tier for higher limits

### Permission Errors

1. Verify user role is correctly set in localStorage
2. Check teacher has assigned class in database
3. Ensure user is logged in properly

### Chat Interface Not Showing

1. Check browser console for JavaScript errors
2. Verify CSS and JS files are loaded
3. Clear browser cache
4. Check Content Security Policy settings

## Web Search Setup (Optional)

To enable web search capability:

1. Go to Google Cloud Console
2. Enable Custom Search JSON API
3. Create a Custom Search Engine
4. Get Search Engine ID from: https://programmablesearchengine.google.com/
5. Add credentials to `.env`:
   ```
   GOOGLE_SEARCH_API_KEY=your_key_here
   GOOGLE_SEARCH_ENGINE_ID=your_engine_id_here
   ```

## Monitoring

### View AI Usage

Run this SQL query to monitor usage:

```sql
SELECT user_role, COUNT(*) as requests,
       SUM(total_tokens) as total_tokens,
       SUM(prompt_tokens) as prompt_tokens,
       SUM(completion_tokens) as completion_tokens,
       DATE(created_at) as date
FROM ai_usage_log
GROUP BY user_role, DATE(created_at)
ORDER BY date DESC;
```

### View Conversations

```sql
SELECT user_role, user_message, ai_response, created_at
FROM ai_conversations
ORDER BY created_at DESC
LIMIT 50;
```

## Future Enhancements

Potential improvements for the AI assistant:

1. **Voice Input/Output** - Speech-to-text and text-to-speech
2. **Advanced Document Analysis** - Full PDF/DOCX parsing
3. **Image Analysis** - Analyze uploaded images
4. **Multi-language Support** - Support Chichewa and other languages
5. **Caching Layer** - Cache common queries
6. **Rate Limiting** - Prevent API abuse
7. **Custom Prompts** - Allow schools to customize AI behavior

## Support

For issues or questions:

1. Check this documentation first
2. Review error logs in PHP error log
3. Verify API credentials are valid (must start with `AIzaSy`)
4. Test API keys directly with Google AI Studio: https://aistudio.google.com/

## License

This AI assistant integration is part of the Noah Christian Academy School Management System.

---

**Version**: 1.0.0
**Last Updated**: 2026-10-06
**Compatible with**: PHP 7.4+, MySQL 5.7+
