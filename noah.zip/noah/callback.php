<?php
/**
 * Google OAuth callback for Noah Christian Academy.
 * Requires Composer dependencies from composer.json.
 */
error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once __DIR__ . '/api/db.php';

if (!is_file(__DIR__ . '/vendor/autoload.php')) {
    http_response_code(503);
    exit('Google login is not installed yet. Run "composer install" in the website root.');
}
require_once __DIR__ . '/vendor/autoload.php';
$dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
$dotenv->safeLoad();

// Helper functions needed for OAuth callback
function ensureEmailAuthSchema() {
    static $done = false;
    if ($done) return;
    $done = true;
    try {
        $conn = getDB();
        foreach (['admins','teachers','parents'] as $table) {
            $checks = [
                'email_verified' => "TINYINT(1) NOT NULL DEFAULT 1",
                'email_verification_token' => "VARCHAR(128) DEFAULT NULL",
                'email_verification_expires' => "DATETIME DEFAULT NULL"
            ];
            foreach ($checks as $column => $definition) {
                $safeTable = preg_replace('/[^a-z_]/i', '', $table);
                $safeColumn = preg_replace('/[^a-z_]/i', '', $column);
                $result = $conn->query("SHOW COLUMNS FROM `$safeTable` LIKE '$safeColumn'");
                if ($result && $result->num_rows === 0) {
                    $conn->query("ALTER TABLE `$safeTable` ADD COLUMN `$safeColumn` $definition");
                }
            }
        }
    } catch (Throwable $e) {}
}

function ensureOAuthTokenSchema() {
    try {
        $conn = getDB();
        $conn->query("CREATE TABLE IF NOT EXISTS oauth_login_tokens (
            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            token_hash CHAR(64) NOT NULL UNIQUE,
            user_type VARCHAR(20) NOT NULL,
            user_id INT NOT NULL,
            expires_at DATETIME NOT NULL,
            used_at DATETIME DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_oauth_user (user_type, user_id),
            INDEX idx_oauth_expires (expires_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Throwable $e) {}
}

function createOAuthLoginToken($userType, $userId) {
    ensureOAuthTokenSchema();
    $raw = bin2hex(random_bytes(32));
    $hash = hash('sha256', $raw);
    $expires = date('Y-m-d H:i:s', strtotime('+5 minutes'));
    dbInsert(
        "INSERT INTO oauth_login_tokens (token_hash, user_type, user_id, expires_at) VALUES (?, ?, ?, ?)",
        [$hash, $userType, $userId, $expires],
        'ssis'
    );
    return $raw;
}


$code = $_GET['code'] ?? '';
$stateRaw = $_GET['state'] ?? '';
if ($code === '' || $stateRaw === '') {
    http_response_code(400);
    exit('Google authentication was cancelled or returned an invalid response.');
}

$state = json_decode(base64_decode($stateRaw), true);
$role = strtolower($state['role'] ?? '');
if (!in_array($role, ['admin','teacher','parent'], true)) {
    http_response_code(400);
    exit('Invalid OAuth role.');
}

$client = new Google\Client();
$client->setClientId($_ENV['GOOGLE_CLIENT_ID'] ?? '');
$client->setClientSecret($_ENV['GOOGLE_CLIENT_SECRET'] ?? '');
$basePath = dirname($_SERVER['SCRIPT_NAME'] ?? '/noah');
$client->setRedirectUri($_ENV['GOOGLE_REDIRECT_URI'] ?? ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https://' : 'http://') . ($_SERVER['HTTP_HOST'] ?? 'localhost') . $basePath . '/callback.php'));

try {
    $token = $client->fetchAccessTokenWithAuthCode($code);
    if (!empty($token['error'])) throw new RuntimeException($token['error']);
    $client->setAccessToken($token);

    // Fetch user info using Guzzle HTTP client instead of Google\Service\Oauth2
    $httpClient = new GuzzleHttp\Client();
    $response = $httpClient->get('https://www.googleapis.com/oauth2/v2/userinfo', [
        'headers' => [
            'Authorization' => 'Bearer ' . $token['access_token']
        ]
    ]);
    $profile = json_decode($response->getBody()->getContents(), true);
    $email = strtolower(trim($profile['email'] ?? ''));
    $firstName = trim($profile['given_name'] ?? '');
    $lastName = trim($profile['family_name'] ?? '');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) throw new RuntimeException('Google did not return a valid email address.');

    ensureEmailAuthSchema();
    ensureOAuthTokenSchema();

    $table = $role === 'admin' ? 'admins' : ($role === 'teacher' ? 'teachers' : 'parents');
    $existing = dbFetchOne("SELECT * FROM `$table` WHERE LOWER(email)=LOWER(?) LIMIT 1", [$email], 's');

    if ($role === 'admin') {
        if ($existing) {
            $id = (int)$existing['id'];
            dbExecute("UPDATE `$table` SET email_verified=1 WHERE id=?", [$id], 'i');
        } else {
            $baseUser = strtolower(preg_replace('/[^a-z0-9]+/i', '.', strstr($email, '@', true) ?: $email));
            $username = trim($baseUser, '.') ?: ('admin.' . random_int(1000,9999));
            $n = 1;
            while (dbFetchOne("SELECT id FROM `$table` WHERE username=?", [$username], 's')) {
                $username = $baseUser . '.' . $n++;
            }
            $randomPassword = password_hash(bin2hex(random_bytes(24)), PASSWORD_DEFAULT);
            $id = dbInsert("INSERT INTO admins (first_name,last_name,username,email,password,role,status,email_verified) VALUES (?,?,?,?,?,'Admin','Active',1)",
                [$firstName ?: 'Google', $lastName ?: 'User', $username, $email, $randomPassword], 'sssss');
            addActivityLog('Admin Google Account Created', "$email created an admin account using Google");
        }
    } else {
        if ($existing) {
            $id = (int)$existing['id'];
            dbExecute("UPDATE `$table` SET email_verified=1, approved=1 WHERE id=?", [$id], 'i');
        } else {
            $baseUser = strtolower(preg_replace('/[^a-z0-9]+/i', '.', strstr($email, '@', true) ?: $email));
            $username = trim($baseUser, '.') ?: ($role . '.' . random_int(1000,9999));
            $n = 1;
            while (dbFetchOne("SELECT id FROM `$table` WHERE username=?", [$username], 's')) {
                $username = $baseUser . '.' . $n++;
            }
            $randomPassword = password_hash(bin2hex(random_bytes(24)), PASSWORD_DEFAULT);
            if ($role === 'teacher') {
                $id = dbInsert("INSERT INTO teachers (first_name,last_name,username,email,password,approved,email_verified) VALUES (?,?,?,?,?,1,1)",
                    [$firstName ?: 'Google', $lastName ?: 'User', $username, $email, $randomPassword], 'sssss');
            } else {
                $id = dbInsert("INSERT INTO parents (first_name,last_name,username,email,password,approved,is_active,email_verified) VALUES (?,?,?,?,?,1,1,1)",
                    [$firstName ?: 'Google', $lastName ?: 'User', $username, $email, $randomPassword], 'sssss');
            }
            addActivityLog(ucfirst($role).' Google Account Created', "$email created an account using Google");
        }
    }

    $oneTimeToken = createOAuthLoginToken($role, $id);
    $target = $role === 'admin' ? 'admin/admin.html' : ('dashboard/' . $role . '.html');
    $base = rtrim($_ENV['APP_URL'] ?? '', '/');
    if ($base === '') {
        $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $base = $scheme . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost');
    }
    header('Location: ' . $base . '/' . $target . '?oauth_token=' . rawurlencode($oneTimeToken));
    exit;
} catch (Throwable $e) {
    http_response_code(400);
    echo 'Google login failed: ' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8');
}
?>
