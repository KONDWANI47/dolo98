<?php
/**
 * Teacher API Handler - Noah Christian Academy
 * Handles teacher-specific operations: assessments, students, attendance, announcements
 */

require_once __DIR__ . '/db.php';

// Safety net: always return JSON even on fatal errors
ob_start();
register_shutdown_function(function() {
    $error = error_get_last();
    if ($error && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        while (ob_get_level()) { ob_end_clean(); }
        http_response_code(500);
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Server error: ' . $error['message']]);
    }
});

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$method = $_SERVER['REQUEST_METHOD'];
$action = $_REQUEST['action'] ?? '';

switch ($action) {
    // GET actions
    case 'my_students':
        handleGetMyStudents();
        break;
    case 'my_assessments':
        handleGetMyAssessments();
        break;
    case 'student_progress':
        handleGetStudentProgress();
        break;
    case 'announcements':
        handleGetAnnouncements();
        break;
    case 'class_attendance':
        handleGetClassAttendance();
        break;
    case 'teacher_profile':
        handleGetProfile();
        break;
    case 'login_history':
        handleGetLoginHistory();
        break;
    case 'get_authorized_ips':
        handleGetAuthorizedIps();
        break;
    case 'get_authorized_emails':
        handleGetAuthorizedEmails();
        break;
    // POST actions
    case 'save_assessment':
        handleSaveAssessment();
        break;
    case 'delete_assessment':
        handleDeleteAssessment();
        break;
    case 'save_attendance':
        handleSaveAttendance();
        break;
    case 'bulk_attendance':
        handleBulkAttendance();
        break;
    case 'update_profile':
        handleUpdateProfile();
        break;
    case 'change_password':
        handleChangePassword();
        break;
    // Exam management
    case 'my_exams':
        handleGetMyExams();
        break;
    case 'upload_exam':
        handleUploadExam();
        break;
    case 'delete_exam':
        handleDeleteExam();
        break;
    // School reports
    case 'my_reports':
        handleGetMyReports();
        break;
    case 'save_report':
        handleSaveReport();
        break;
    case 'sign_report':
        handleSignReport();
        break;
    case 'delete_report':
        handleDeleteReport();
        break;
    case 'upload_file_to_admin':
        handleUploadFileToAdmin();
        break;
    case 'my_sent_files':
        handleGetMySentFiles();
        break;
    // Complaints
    case 'class_complaints':
        handleGetClassComplaints();
        break;
    case 'respond_complaint':
        handleRespondComplaint();
        break;
    case 'edit_complaint':
        handleEditComplaint();
        break;
    case 'delete_complaint':
        handleDeleteComplaint();
        break;
    case 'reject_complaint':
        handleRejectComplaint();
        break;
    case 'add_authorized_ip':
        handleAddAuthorizedIp();
        break;
    case 'revoke_authorized_ip':
        handleRevokeAuthorizedIp();
        break;
    case 'add_authorized_email':
        handleAddAuthorizedEmail();
        break;
    case 'revoke_authorized_email':
        handleRevokeAuthorizedEmail();
        break;
    // Resource management
    case 'my_resources':
        handleGetMyResources();
        break;
    case 'shared_resources':
        handleGetSharedResources();
        break;
    case 'save_resource':
        handleSaveResource();
        break;
    case 'delete_resource':
        handleDeleteResource();
        break;
    // Lesson Plans
    case 'my_lesson_plans':
        handleGetMyLessonPlans();
        break;
    case 'get_lesson_plan':
        handleGetLessonPlan();
        break;
    case 'save_lesson_plan':
        handleSaveLessonPlan();
        break;
    case 'delete_lesson_plan':
        handleDeleteLessonPlan();
        break;
    // Simple lesson plan (template-based)
    case 'lesson_plan':
        handleSimpleLessonPlan();
        break;
    default:
        respondError('Unknown action: ' . $action, 404);
}

function handleGetMyStudents() {
    $teacherId = (int)($_REQUEST['teacher_id'] ?? 0);
    if (!$teacherId) respondError('Teacher ID required');
    
    $teacher = dbFetchOne("SELECT * FROM teachers WHERE id = ?", [$teacherId], 'i');
    if (!$teacher) respondError('Teacher not found');
    
    $className = $teacher['class_assigned'];
    if (empty($className)) {
        respondSuccess(['items' => [], 'total' => 0, 'className' => '']);
    }
    
    $students = dbFetchAll(
        "SELECT * FROM students WHERE grade = ? AND status = 'Active' ORDER BY first_name",
        [$className], 's'
    );
    
    $rows = array_map(function($r) {
        return [
            'id' => $r['id'],
            'firstName' => $r['first_name'],
            'lastName' => $r['last_name'],
            'gender' => $r['gender'],
            'grade' => $r['grade'],
            'parent' => $r['parent_name'],
            'phone' => $r['phone'],
            'status' => $r['status']
        ];
    }, $students);
    
    respondSuccess(['items' => $rows, 'total' => count($rows), 'className' => $className]);
}

function handleGetMyAssessments() {
    $teacherId = (int)($_REQUEST['teacher_id'] ?? 0);
    if (!$teacherId) respondError('Teacher ID required');
    
    $rows = dbFetchAll(
        "SELECT * FROM assessments WHERE teacher_id = ? ORDER BY created_at DESC LIMIT 200",
        [$teacherId], 'i'
    );
    
    $assessments = array_map(function($r) {
        return [
            'id' => $r['id'],
            'teacherId' => $r['teacher_id'],
            'studentId' => $r['student_id'],
            'studentName' => $r['student_name'],
            'className' => $r['class_name'],
            'subject' => $r['subject'],
            'type' => $r['type'],
            'score' => $r['score'],
            'date' => $r['date'],
            'remarks' => $r['remarks'],
            'createdAt' => $r['created_at']
        ];
    }, $rows);
    
    respondSuccess(['items' => $assessments, 'total' => count($assessments)]);
}

function handleGetStudentProgress() {
    $teacherId = (int)($_REQUEST['teacher_id'] ?? 0);
    $studentId = (int)($_REQUEST['student_id'] ?? 0);
    if (!$teacherId || !$studentId) respondError('Teacher ID and Student ID required');
    
    $assessments = dbFetchAll(
        "SELECT * FROM assessments WHERE teacher_id = ? AND student_id = ? ORDER BY date DESC",
        [$teacherId, $studentId], 'ii'
    );
    
    $student = dbFetchOne("SELECT * FROM students WHERE id = ?", [$studentId], 'i');
    if (!$student) respondError('Student not found');
    
    $avgScore = 0;
    $subjectBreakdown = [];
    if (count($assessments) > 0) {
        $total = 0;
        foreach ($assessments as $a) {
            $total += $a['score'];
            $subj = $a['subject'];
            if (!isset($subjectBreakdown[$subj])) {
                $subjectBreakdown[$subj] = ['count' => 0, 'total' => 0];
            }
            $subjectBreakdown[$subj]['count']++;
            $subjectBreakdown[$subj]['total'] += $a['score'];
        }
        $avgScore = round($total / count($assessments));
    }
    
    $data = [
        'student' => [
            'id' => $student['id'],
            'firstName' => $student['first_name'],
            'lastName' => $student['last_name'],
            'gender' => $student['gender'],
            'grade' => $student['grade'],
        ],
        'assessments' => array_map(function($a) {
            return [
                'id' => $a['id'],
                'subject' => $a['subject'],
                'type' => $a['type'],
                'score' => $a['score'],
                'date' => $a['date'],
                'remarks' => $a['remarks']
            ];
        }, $assessments),
        'averageScore' => $avgScore,
        'totalAssessments' => count($assessments),
        'subjectBreakdown' => $subjectBreakdown
    ];
    
    respondSuccess($data);
}

function handleGetAnnouncements() {
    $rows = dbFetchAll(
        "SELECT * FROM announcements WHERE status = 'Published' AND (target_audience = 'all' OR target_audience = 'teachers') ORDER BY pinned DESC, created_at DESC LIMIT 50"
    );
    
    $announcements = array_map(function($r) {
        return [
            'id' => $r['id'],
            'title' => $r['title'],
            'content' => $r['content'],
            'priority' => $r['priority'],
            'targetAudience' => $r['target_audience'],
            'status' => $r['status'],
            'createdBy' => $r['created_by'],
            'pinned' => (bool)$r['pinned'],
            'createdAt' => $r['created_at']
        ];
    }, $rows);
    
    respondSuccess(['items' => $announcements, 'total' => count($announcements)]);
}

function handleGetClassAttendance() {
    $teacherId = (int)($_REQUEST['teacher_id'] ?? 0);
    if (!$teacherId) respondError('Teacher ID required');
    
    $teacher = dbFetchOne("SELECT * FROM teachers WHERE id = ?", [$teacherId], 'i');
    if (!$teacher) respondError('Teacher not found');
    
    $className = $teacher['class_assigned'];
    if (empty($className)) respondSuccess(['items' => [], 'total' => 0]);
    
    $rows = dbFetchAll(
        "SELECT * FROM attendance WHERE class_name = ? ORDER BY date DESC LIMIT 200",
        [$className], 's'
    );
    
    $attendance = array_map(function($r) {
        return [
            'id' => $r['id'],
            'studentId' => $r['student_id'],
            'studentName' => $r['student_name'],
            'studentClass' => $r['class_name'],
            'date' => $r['date'],
            'status' => $r['status'],
            'remarks' => $r['remarks']
        ];
    }, $rows);
    
    respondSuccess(['items' => $attendance, 'total' => count($attendance)]);
}

function handleGetProfile() {
    $teacherId = (int)($_REQUEST['teacher_id'] ?? 0);
    if (!$teacherId) respondError('Teacher ID required');
    
    $teacher = dbFetchOne("SELECT * FROM teachers WHERE id = ?", [$teacherId], 'i');
    if (!$teacher) respondError('Teacher not found');
    
    respondSuccess([
        'id' => $teacher['id'],
        'firstName' => $teacher['first_name'],
        'lastName' => $teacher['last_name'],
        'username' => $teacher['username'],
        'email' => $teacher['email'],
        'phone' => $teacher['phone'],
        'subject' => $teacher['subject'],
        'qualification' => $teacher['qualification'],
        'class' => $teacher['class_assigned'],
        'approved' => (bool)$teacher['approved'],
        'dateOfEmployment' => $teacher['date_of_employment'] ?? '',
        'nationalId' => $teacher['national_id'] ?? '',
        'residentialAddress' => $teacher['residential_address'] ?? '',
        'nextOfKin' => $teacher['next_of_kin'] ?? '',
        'nextOfKinRelationship' => $teacher['next_of_kin_relationship'] ?? '',
        'nextOfKinPhone' => $teacher['next_of_kin_phone'] ?? ''
    ]);
}

function handleDeleteAssessment() {
    $body = getJsonBody();
    $id = (int)($body['id'] ?? 0);
    $teacherId = (int)($body['teacherId'] ?? 0);
    if (!$id || !$teacherId) respondError('Assessment ID and Teacher ID required');

    // Ensure the assessment belongs to this teacher
    $a = dbFetchOne("SELECT id FROM assessments WHERE id = ? AND teacher_id = ?", [$id, $teacherId], 'ii');
    if (!$a) respondError('Assessment not found or access denied');

    dbExecute("DELETE FROM assessments WHERE id = ?", [$id], 'i');
    addActivityLog('Assessment Deleted', "Assessment #$id deleted");
    respondSuccess([], 'Assessment deleted successfully');
}

function handleSaveAssessment() {
    $body = getJsonBody();
    if (!$body) respondError('Invalid request body');
    
    $editId = $body['id'] ?? null;
    $data = [
        'teacher_id' => (int)($body['teacherId'] ?? $body['teacher_id'] ?? 0),
        'student_id' => (int)($body['studentId'] ?? $body['student_id'] ?? 0),
        'student_name' => $body['studentName'] ?? $body['student_name'] ?? '',
        'class_name' => $body['className'] ?? $body['class_name'] ?? '',
        'subject' => $body['subject'] ?? '',
        'type' => $body['type'] ?? 'Quiz',
        'score' => (int)($body['score'] ?? 0),
        'date' => $body['date'] ?? date('Y-m-d'),
        'remarks' => $body['remarks'] ?? ''
    ];
    
    if (!$data['teacher_id'] || !$data['student_id']) respondError('Teacher ID and Student ID required');
    if (empty($data['subject'])) respondError('Subject is required');
    if ($data['score'] < 0 || $data['score'] > 100) respondError('Score must be between 0 and 100');

    // Try to find registration_id from student
    $regId = (int)($body['registrationId'] ?? $body['registration_id'] ?? 0);
    if (!$regId && $data['student_id']) {
        $reg = dbFetchOne(
            "SELECT id FROM registrations WHERE student_id = ? OR student_name = ? ORDER BY id DESC LIMIT 1",
            [$data['student_id'], $data['student_name']],
            'is'
        );
        if ($reg) $regId = (int)$reg['id'];
    }

    // Ensure registration_id column is nullable (auto-fix)
    static $assessmentsFixed = false;
    if (!$assessmentsFixed) {
        $conn = getDB();
        // Find and drop any FK on registration_id
        $fkRows = $conn->query("SELECT CONSTRAINT_NAME FROM information_schema.KEY_COLUMN_USAGE WHERE TABLE_SCHEMA='noh_academy' AND TABLE_NAME='assessments' AND COLUMN_NAME='registration_id' AND REFERENCED_TABLE_NAME='registrations'");
        if ($fkRows) {
            while ($fk = $fkRows->fetch_assoc()) {
                try { $conn->query("ALTER TABLE assessments DROP FOREIGN KEY `" . $fk['CONSTRAINT_NAME'] . "`"); } catch (\Exception $e) {}
            }
        }
        try { $conn->query("ALTER TABLE assessments MODIFY COLUMN registration_id INT DEFAULT NULL"); } catch (\Exception $e) {}
        $assessmentsFixed = true;
    }

    $regVal = $regId ?: null;

    if ($editId) {
        $affected = dbExecute(
            "UPDATE assessments SET teacher_id=?, student_id=?, registration_id=?, student_name=?, class_name=?, subject=?, type=?, score=?, date=?, remarks=? WHERE id=?",
            [$data['teacher_id'], $data['student_id'], $regVal, $data['student_name'], $data['class_name'], $data['subject'], $data['type'], $data['score'], $data['date'], $data['remarks'], (int)$editId],
            'iiissssisii'
        );
        addActivityLog('Assessment Updated', "Assessment #$editId updated");
        respondSuccess([], 'Assessment updated successfully');
    } else {
        $id = dbInsert(
            "INSERT INTO assessments (teacher_id, student_id, registration_id, student_name, class_name, subject, type, score, date, remarks) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            [$data['teacher_id'], $data['student_id'], $regVal, $data['student_name'], $data['class_name'], $data['subject'], $data['type'], $data['score'], $data['date'], $data['remarks']],
            'iiisssisss'
        );
        if ($id) {
            addActivityLog('Assessment Created', "Assessment for {$data['student_name']} - {$data['subject']}: {$data['score']}%");
            respondSuccess(['id' => $id], 'Assessment saved successfully');
            return;
        }
        respondError('Failed to save assessment. Please ensure the assessments table exists and student data is valid.');
    }
}

function handleSaveAttendance() {
    $body = getJsonBody();
    if (!$body) respondError('Invalid request body');
    
    $editId = $body['id'] ?? null;
    $data = [
        'student_id' => $body['studentId'] ?? $body['student_id'] ?? 0,
        'student_name' => $body['studentName'] ?? $body['student_name'] ?? '',
        'class_name' => $body['studentClass'] ?? $body['class_name'] ?? '',
        'date' => $body['date'] ?? date('Y-m-d'),
        'status' => $body['status'] ?? 'Present',
        'remarks' => $body['remarks'] ?? ''
    ];
    
    if (!$data['student_id']) respondError('Student ID required');

    // Look up registration_id from student
    $attRegId = 0;
    if ($data['student_id']) {
        $attReg = dbFetchOne(
            "SELECT id FROM registrations WHERE student_id = ? OR student_name = ? ORDER BY id DESC LIMIT 1",
            [(int)$data['student_id'], $data['student_name']],
            'is'
        );
        if ($attReg) $attRegId = (int)$attReg['id'];
    }

    // Ensure attendance.registration_id column is nullable (auto-fix)
    static $attendanceFixed = false;
    if (!$attendanceFixed) {
        $conn = getDB();
        $fkRows = $conn->query("SELECT CONSTRAINT_NAME FROM information_schema.KEY_COLUMN_USAGE WHERE TABLE_SCHEMA='noh_academy' AND TABLE_NAME='attendance' AND COLUMN_NAME='registration_id' AND REFERENCED_TABLE_NAME='registrations'");
        if ($fkRows) {
            while ($fk = $fkRows->fetch_assoc()) {
                try { $conn->query("ALTER TABLE attendance DROP FOREIGN KEY `" . $fk['CONSTRAINT_NAME'] . "`"); } catch (\Exception $e) {}
            }
        }
        try { $conn->query("ALTER TABLE attendance MODIFY COLUMN registration_id INT DEFAULT NULL"); } catch (\Exception $e) {}
        $attendanceFixed = true;
    }

    $attRegVal = $attRegId ?: null;

    if ($editId) {
        dbExecute(
            "UPDATE attendance SET student_id=?, registration_id=?, student_name=?, class_name=?, date=?, status=?, remarks=? WHERE id=?",
            [$data['student_id'], $attRegVal, $data['student_name'], $data['class_name'], $data['date'], $data['status'], $data['remarks'], $editId],
            'iissssi'
        );
        respondSuccess([], 'Attendance updated');
    } else {
        $id = dbInsert(
            "INSERT INTO attendance (student_id, registration_id, student_name, class_name, date, status, remarks) VALUES (?, ?, ?, ?, ?, ?, ?)",
            [$data['student_id'], $attRegVal, $data['student_name'], $data['class_name'], $data['date'], $data['status'], $data['remarks']],
            'iisssss'
        );
        if ($id) {
            respondSuccess(['id' => $id], 'Attendance marked');
            return;
        }
        respondError('Failed to save attendance');
    }
}

function handleBulkAttendance() {
    $body = getJsonBody();
    if (!$body) respondError('Invalid request body');
    
    $records = $body['records'] ?? [];
    $date = $body['date'] ?? date('Y-m-d');
    
    if (empty($records)) respondError('No attendance records provided');
    
    $count = 0;
    foreach ($records as $r) {
        $studentId = $r['studentId'] ?? $r['student_id'] ?? 0;
        $status = $r['status'] ?? 'Present';
        $studentName = $r['studentName'] ?? $r['student_name'] ?? '';
        $className = $r['className'] ?? $r['class_name'] ?? '';
        
        if ($studentId) {
            // Look up registration_id
            $bulkRegId = 0;
            $bulkReg = dbFetchOne(
                "SELECT id FROM registrations WHERE student_id = ? OR student_name = ? ORDER BY id DESC LIMIT 1",
                [(int)$studentId, $studentName],
                'is'
            );
            if ($bulkReg) $bulkRegId = (int)$bulkReg['id'];
            $bulkRegVal = $bulkRegId ?: null;

            // Ensure attendance.registration_id is nullable (same fix)
            static $bulkAttFixed = false;
            if (!$bulkAttFixed) {
                $conn = getDB();
                $fkRows = $conn->query("SELECT CONSTRAINT_NAME FROM information_schema.KEY_COLUMN_USAGE WHERE TABLE_SCHEMA='noh_academy' AND TABLE_NAME='attendance' AND COLUMN_NAME='registration_id' AND REFERENCED_TABLE_NAME='registrations'");
                if ($fkRows) {
                    while ($fk = $fkRows->fetch_assoc()) {
                        try { $conn->query("ALTER TABLE attendance DROP FOREIGN KEY `" . $fk['CONSTRAINT_NAME'] . "`"); } catch (\Exception $e) {}
                    }
                }
                try { $conn->query("ALTER TABLE attendance MODIFY COLUMN registration_id INT DEFAULT NULL"); } catch (\Exception $e) {}
                $bulkAttFixed = true;
            }

            dbInsert(
                "INSERT INTO attendance (student_id, registration_id, student_name, class_name, date, status) VALUES (?, ?, ?, ?, ?, ?)",
                [$studentId, $bulkRegVal, $studentName, $className, $date, $status],
                'iissss'
            );
            $count++;
        }
    }
    
    addActivityLog('Bulk Attendance', "Marked attendance for $count students on $date");
    respondSuccess(['count' => $count], "Attendance marked for $count students");
}

function handleUpdateProfile() {
    $body = getJsonBody();
    $teacherId = $body['id'] ?? 0;
    if (!$teacherId) respondError('Teacher ID required');
    
    $fields = [];
    $params = [];
    $types = '';
    
    $allowed = ['first_name', 'last_name', 'email', 'phone', 'subject', 'qualification', 'date_of_employment', 'national_id', 'residential_address', 'next_of_kin', 'next_of_kin_relationship', 'next_of_kin_phone', 'class_assigned'];
    foreach ($allowed as $field) {
        $camelField = lcfirst(str_replace('_', '', ucwords($field, '_')));
        if (isset($body[$camelField])) {
            $fields[] = "$field = ?";
            $params[] = $body[$camelField];
            $types .= 's';
        } elseif (isset($body[$field])) {
            $fields[] = "$field = ?";
            $params[] = $body[$field];
            $types .= 's';
        }
    }
    
    if (empty($fields)) respondError('No fields to update');
    
    $params[] = $teacherId;
    $types .= 'i';
    
    dbExecute("UPDATE teachers SET " . implode(', ', $fields) . " WHERE id = ?", $params, $types);
    respondSuccess([], 'Profile updated');
}

function handleChangePassword() {
    $body = getJsonBody();
    $teacherId = $body['teacherId'] ?? 0;
    $current = $body['currentPassword'] ?? '';
    $newPass = $body['newPassword'] ?? '';
    
    if (!$teacherId) respondError('Teacher ID required');
    
    $teacher = dbFetchOne("SELECT * FROM teachers WHERE id = ?", [$teacherId], 'i');
    if (!$teacher) respondError('Teacher not found');
    if ($teacher['password'] !== $current) respondError('Current password is incorrect');
    if (strlen($newPass) < 4) respondError('New password must be at least 4 characters');
    
    dbExecute("UPDATE teachers SET password = ? WHERE id = ?", [$newPass, $teacherId], 'si');
    respondSuccess([], 'Password changed');
}

// ===== EXAM MANAGEMENT =====

function handleGetMyExams() {
    $teacherId = (int)($_REQUEST['teacher_id'] ?? 0);
    if (!$teacherId) respondError('Teacher ID required');

    $rows = dbFetchAll(
        "SELECT * FROM teacher_exams WHERE teacher_id = ? ORDER BY created_at DESC LIMIT 100",
        [$teacherId], 'i'
    );

    $exams = array_map(function($r) {
        return [
            'id' => $r['id'],
            'teacherId' => $r['teacher_id'],
            'teacherName' => $r['teacher_name'],
            'title' => $r['title'],
            'subject' => $r['subject'],
            'className' => $r['class_name'],
            'term' => $r['term'],
            'description' => $r['description'],
            'fileUrl' => $r['file_url'],
            'fileName' => $r['file_name'],
            'status' => $r['status'],
            'approvedBy' => $r['approved_by'],
            'approvedAt' => $r['approved_at'],
            'adminNotes' => $r['admin_notes'],
            'createdAt' => $r['created_at']
        ];
    }, $rows);

    respondSuccess(['items' => $exams, 'total' => count($exams)]);
}

function handleUploadExam() {
    // This handles multipart/form-data (file upload)
    $teacherId = (int)($_POST['teacherId'] ?? $_POST['teacher_id'] ?? 0);
    $title = trim($_POST['title'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $className = trim($_POST['className'] ?? $_POST['class_name'] ?? '');
    $term = trim($_POST['term'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $teacherName = trim($_POST['teacherName'] ?? '');

    if (!$teacherId) respondError('Teacher ID required');
    if (empty($title)) respondError('Exam title is required');
    if (empty($_FILES['examFile'])) respondError('No file uploaded');

    $file = $_FILES['examFile'];
    $allowedTypes = ['application/pdf'];
    $maxSize = 10 * 1024 * 1024; // 10MB

    if (!in_array($file['type'], $allowedTypes)) {
        respondError('Only PDF files are allowed.');
    }
    if ($file['size'] > $maxSize) {
        respondError('File too large. Maximum size is 10MB.');
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        respondError('Upload error: ' . $file['error']);
    }

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if ($ext !== 'pdf') $ext = 'pdf';

    $newName = uniqid('exam_', true) . '.' . $ext;
    $uploadDir = __DIR__ . '/../uploads/';
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

    $dest = $uploadDir . $newName;
    if (!move_uploaded_file($file['tmp_name'], $dest)) {
        respondError('Failed to save uploaded file.');
    }

    $fileUrl = '../uploads/' . $newName;

    $id = dbInsert(
        "INSERT INTO teacher_exams (teacher_id, teacher_name, title, subject, class_name, term, description, file_url, file_name, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending')",
        [$teacherId, $teacherName, $title, $subject, $className, $term, $description, $fileUrl, $file['name']],
        'issssssss'
    );

    if ($id) {
        addActivityLog('Exam Uploaded', "Exam '$title' uploaded by $teacherName");
        respondSuccess(['id' => $id, 'fileUrl' => $fileUrl], 'Exam uploaded successfully! Waiting for admin approval.');
    }
    respondError('Failed to save exam record.');
}

function handleDeleteExam() {
    $body = getJsonBody();
    $id = (int)($body['id'] ?? 0);
    $teacherId = (int)($body['teacherId'] ?? 0);
    if (!$id || !$teacherId) respondError('Exam ID and Teacher ID required');

    // Ensure the exam belongs to this teacher
    $exam = dbFetchOne("SELECT * FROM teacher_exams WHERE id = ? AND teacher_id = ?", [$id, $teacherId], 'ii');
    if (!$exam) respondError('Exam not found or access denied');

    // Delete the file
    $filePath = __DIR__ . '/../' . ltrim($exam['file_url'], '/');
    // Normalize path
    $filePath = str_replace('../', '', $filePath);
    $filePath = __DIR__ . '/../' . $filePath;
    if (file_exists($filePath)) {
        @unlink($filePath);
    }

    dbExecute("DELETE FROM teacher_exams WHERE id = ?", [$id], 'i');
    addActivityLog('Exam Deleted', "Exam '{$exam['title']}' deleted");
    respondSuccess([], 'Exam deleted successfully');
}

// ===== SCHOOL REPORTS =====

function handleGetMyReports() {
    $teacherId = (int)($_REQUEST['teacher_id'] ?? 0);
    if (!$teacherId) respondError('Teacher ID required');

    $rows = dbFetchAll(
        "SELECT * FROM school_reports WHERE teacher_id = ? ORDER BY updated_at DESC LIMIT 200",
        [$teacherId], 'i'
    );

    $reports = array_map(function($r) {
        $data = json_decode($r['report_data'] ?? '[]', true);
        return [
            'id' => $r['id'],
            'teacherId' => $r['teacher_id'],
            'teacherName' => $r['teacher_name'],
            'studentId' => $r['student_id'],
            'studentName' => $r['student_name'],
            'className' => $r['class_name'],
            'term' => $r['term'],
            'academicYear' => $r['academic_year'],
            'reportData' => $data ?: [],
            'overallComment' => $r['overall_comment'],
            'overallGrade' => $r['overall_grade'],
            'signatureImg' => $r['signature_img'],
            'status' => $r['status'],
            'signedAt' => $r['signed_at'],
            'createdAt' => $r['created_at'],
            'updatedAt' => $r['updated_at'],
            'schoolAddress' => $r['school_address'] ?? '',
            'schoolEmail' => $r['school_email'] ?? '',
            'principalPhone' => $r['principal_phone'] ?? '',
            'adminPhone' => $r['admin_phone'] ?? ''
        ];
    }, $rows);

    respondSuccess(['items' => $reports, 'total' => count($reports)]);
}

function handleSaveReport() {
    $body = getJsonBody();
    if (!$body) respondError('Invalid request body');

    $teacherId = (int)($body['teacherId'] ?? 0);
    $teacherName = trim($body['teacherName'] ?? '');
    $studentId = !empty($body['studentId']) ? (int)$body['studentId'] : null;
    $studentName = trim($body['studentName'] ?? '');
    $className = trim($body['className'] ?? '');
    $term = trim($body['term'] ?? '');
    $academicYear = trim($body['academicYear'] ?? '');
    $reportData = json_encode($body['reportData'] ?? []);
    $overallComment = trim($body['overallComment'] ?? '');
    $overallGrade = trim($body['overallGrade'] ?? '');
    $reportId = (int)($body['id'] ?? 0);

    // School contact information
    $schoolAddress = trim($body['schoolAddress'] ?? '');
    $schoolEmail = trim($body['schoolEmail'] ?? '');
    $principalPhone = trim($body['principalPhone'] ?? '');
    $adminPhone = trim($body['adminPhone'] ?? '');

    if (!$teacherId) respondError('Teacher ID required');
    if (empty($studentName)) respondError('Student name is required');

    if ($reportId) {
        // Update existing report - only if Draft
        $existing = dbFetchOne("SELECT * FROM school_reports WHERE id = ? AND teacher_id = ?", [$reportId, $teacherId], 'ii');
        if (!$existing) respondError('Report not found or access denied');
        if ($existing['status'] !== 'Draft') respondError('Only draft reports can be edited');

        dbExecute(
            "UPDATE school_reports SET student_id=?, student_name=?, class_name=?, term=?, academic_year=?, report_data=?, overall_comment=?, overall_grade=?, school_address=?, school_email=?, principal_phone=?, admin_phone=? WHERE id=?",
            [$studentId, $studentName, $className, $term, $academicYear, $reportData, $overallComment, $overallGrade, $schoolAddress, $schoolEmail, $principalPhone, $adminPhone, $reportId],
            'isssssssssii'
        );
        addActivityLog('Report Updated', "Report for '$studentName' updated by $teacherName");
        respondSuccess(['id' => $reportId], 'Report updated successfully');
    } else {
        // Create new report
        $id = dbInsert(
            "INSERT INTO school_reports (teacher_id, teacher_name, student_id, student_name, class_name, term, academic_year, report_data, overall_comment, overall_grade, school_address, school_email, principal_phone, admin_phone, status)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Draft')",
            [$teacherId, $teacherName, $studentId, $studentName, $className, $term, $academicYear, $reportData, $overallComment, $overallGrade, $schoolAddress, $schoolEmail, $principalPhone, $adminPhone],
            'isisssssssssss'
        );
        if ($id) {
            addActivityLog('Report Created', "Report for '$studentName' created by $teacherName");
            respondSuccess(['id' => $id], 'Report created successfully');
        }
        respondError('Failed to save report');
    }
}

function handleSignReport() {
    $body = getJsonBody();
    if (!$body) respondError('Invalid request body');

    $reportId = (int)($body['id'] ?? 0);
    $teacherId = (int)($body['teacherId'] ?? 0);
    $signatureImg = $body['signatureImg'] ?? '';

    if (!$reportId || !$teacherId) respondError('Report ID and Teacher ID required');
    if (empty($signatureImg)) respondError('Signature image is required');

    $existing = dbFetchOne("SELECT * FROM school_reports WHERE id = ? AND teacher_id = ?", [$reportId, $teacherId], 'ii');
    if (!$existing) respondError('Report not found or access denied');

    dbExecute(
        "UPDATE school_reports SET signature_img=?, status='Signed', signed_at=NOW() WHERE id=?",
        [$signatureImg, $reportId],
        'si'
    );
    addActivityLog('Report Signed', "Report #{$reportId} signed");
    respondSuccess([], 'Report signed successfully');
}

function handleDeleteReport() {
    $body = getJsonBody();
    $id = (int)($body['id'] ?? 0);
    $teacherId = (int)($body['teacherId'] ?? 0);
    if (!$id || !$teacherId) respondError('Report ID and Teacher ID required');

    $report = dbFetchOne("SELECT * FROM school_reports WHERE id = ? AND teacher_id = ?", [$id, $teacherId], 'ii');
    if (!$report) respondError('Report not found or access denied');

    dbExecute("DELETE FROM school_reports WHERE id = ?", [$id], 'i');
    addActivityLog('Report Deleted', "Report for '{$report['student_name']}' deleted");
    respondSuccess([], 'Report deleted successfully');
}

function handleUploadFileToAdmin() {
    $teacherId = (int)($_REQUEST['teacher_id'] ?? 0);
    if (!$teacherId) respondError('Teacher ID required');
    
    $teacher = dbFetchOne("SELECT * FROM teachers WHERE id = ?", [$teacherId], 'i');
    if (!$teacher) respondError('Teacher not found');
    
    $title = trim($_POST['title'] ?? '');
    $category = trim($_POST['category'] ?? 'general');
    $description = trim($_POST['description'] ?? '');
    
    if (empty($title)) respondError('Title is required');
    
    // Handle file uploads
    if (empty($_FILES['file'])) {
        respondError('No files uploaded');
    }
    
    // Handle both single file and multiple file uploads
    $files = $_FILES['file'];
    if (!is_array($files['name'])) {
        // Single file upload - convert to array format
        $files = [
            'name' => [$files['name']],
            'type' => [$files['type']],
            'tmp_name' => [$files['tmp_name']],
            'error' => [$files['error']],
            'size' => [$files['size']]
        ];
    }
    
    $allowedTypes = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'image/jpeg', 'image/png', 'image/jpg'];
    $maxSize = 10 * 1024 * 1024; // 10MB
    
    $uploadedFiles = [];
    $uploadDir = __DIR__ . '/../uploads/teacher_files/';
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
    
    for ($i = 0; $i < count($files['name']); $i++) {
        if ($files['error'][$i] !== UPLOAD_ERR_OK) {
            continue;
        }
        
        $fileType = $files['type'][$i];
        $fileSize = $files['size'][$i];
        $fileName = $files['name'][$i];
        $tmpName = $files['tmp_name'][$i];
        
        if (!in_array($fileType, $allowedTypes)) {
            respondError("File '$fileName' has invalid type. Allowed: PDF, DOC, DOCX, XLS, XLSX, JPG, PNG");
        }
        
        if ($fileSize > $maxSize) {
            respondError("File '$fileName' exceeds 10MB limit");
        }
        
        $ext = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        $newName = 'teacher_' . uniqid() . '_' . $i . '.' . $ext;
        $dest = $uploadDir . $newName;
        
        if (!move_uploaded_file($tmpName, $dest)) {
            respondError("Failed to save file '$fileName'");
        }
        
        $fileUrl = '../uploads/teacher_files/' . $newName;
        $uploadedFiles[] = [
            'file_url' => $fileUrl,
            'file_name' => $fileName,
            'file_size' => $fileSize,
            'file_type' => $fileType
        ];
    }
    
    if (empty($uploadedFiles)) {
        respondError('No valid files were uploaded');
    }
    
    // Create teacher_files table if it doesn't exist
    $conn = getDB();
    $conn->query("CREATE TABLE IF NOT EXISTS teacher_files (
        id INT PRIMARY KEY AUTO_INCREMENT,
        teacher_id INT NOT NULL,
        teacher_name VARCHAR(255) NOT NULL,
        title VARCHAR(255) NOT NULL,
        category VARCHAR(50) DEFAULT 'general',
        description TEXT,
        file_url VARCHAR(500) NOT NULL,
        file_name VARCHAR(255) NOT NULL,
        file_size BIGINT NOT NULL,
        file_type VARCHAR(100) NOT NULL,
        status VARCHAR(20) DEFAULT 'pending',
        admin_notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_teacher (teacher_id),
        INDEX idx_status (status),
        INDEX idx_category (category),
        INDEX idx_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    
    // Check if teacher_id column exists, if not add it
    $columnCheck = $conn->query("SHOW COLUMNS FROM teacher_files LIKE 'teacher_id'");
    if ($columnCheck->num_rows == 0) {
        $conn->query("ALTER TABLE teacher_files ADD COLUMN teacher_id INT NOT NULL AFTER id");
        $conn->query("ALTER TABLE teacher_files ADD INDEX idx_teacher (teacher_id)");
    }
    
    // Check for other missing columns and add them if needed
    $requiredColumns = [
        'teacher_name' => "VARCHAR(255) NOT NULL",
        'title' => "VARCHAR(255) NOT NULL", 
        'category' => "VARCHAR(50) DEFAULT 'general'",
        'description' => "TEXT",
        'file_url' => "VARCHAR(500) NOT NULL",
        'file_name' => "VARCHAR(255) NOT NULL",
        'file_size' => "BIGINT NOT NULL",
        'file_type' => "VARCHAR(100) NOT NULL",
        'status' => "VARCHAR(20) DEFAULT 'pending'",
        'admin_notes' => "TEXT",
        'created_at' => "TIMESTAMP DEFAULT CURRENT_TIMESTAMP"
    ];
    
    foreach ($requiredColumns as $colName => $colDef) {
        $colCheck = $conn->query("SHOW COLUMNS FROM teacher_files LIKE '$colName'");
        if ($colCheck->num_rows == 0) {
            $conn->query("ALTER TABLE teacher_files ADD COLUMN $colName $colDef");
        }
    }
    
    // Insert each file into database
    $successCount = 0;
    $teacherName = $teacher['first_name'] . ' ' . $teacher['last_name'];
    
    foreach ($uploadedFiles as $fileData) {
        $id = dbInsert(
            "INSERT INTO teacher_files (teacher_id, teacher_name, title, category, description, file_url, file_name, file_size, file_type)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            [$teacherId, $teacherName, $title, $category, $description, $fileData['file_url'], $fileData['file_name'], $fileData['file_size'], $fileData['file_type']],
            'isssssiss'
        );
        
        if ($id) {
            $successCount++;
        }
    }
    
    if ($successCount > 0) {
        addActivityLog('Teacher File Uploaded', "Teacher $teacherName uploaded $successCount file(s) to admin: '$title'");
        respondSuccess(['uploadedCount' => $successCount], "$successCount file(s) uploaded successfully and sent to admin");
    }
    
    respondError('Failed to save files to database');
}

function handleGetMySentFiles() {
    $teacherId = (int)($_REQUEST['teacher_id'] ?? 0);
    if (!$teacherId) respondError('Teacher ID required');
    
    $teacher = dbFetchOne("SELECT * FROM teachers WHERE id = ?", [$teacherId], 'i');
    if (!$teacher) respondError('Teacher not found');
    
    $rows = dbFetchAll(
        "SELECT * FROM teacher_files WHERE teacher_id = ? ORDER BY created_at DESC LIMIT 100",
        [$teacherId], 'i'
    );
    
    $files = array_map(function($r) {
        return [
            'id' => $r['id'],
            'teacherId' => $r['teacher_id'],
            'teacherName' => $r['teacher_name'],
            'title' => $r['title'],
            'category' => $r['category'],
            'description' => $r['description'],
            'fileUrl' => $r['file_url'],
            'fileName' => $r['file_name'],
            'fileSize' => $r['file_size'],
            'fileType' => $r['file_type'],
            'status' => $r['status'],
            'adminNotes' => $r['admin_notes'],
            'createdAt' => $r['created_at']
        ];
    }, $rows);
    
    respondSuccess(['items' => $files, 'total' => count($files)]);
}

function handleGetClassComplaints() {
    $teacherId = (int)($_REQUEST['teacher_id'] ?? 0);
    if (!$teacherId) respondError('Teacher ID required');
    
    $teacher = dbFetchOne("SELECT * FROM teachers WHERE id = ?", [$teacherId], 'i');
    if (!$teacher) respondError('Teacher not found');
    
    $className = $teacher['class_assigned'] ?? '';
    if (empty($className)) {
        respondSuccess(['items' => [], 'total' => 0], 'No class assigned to you');
        return;
    }
    
    $rows = dbFetchAll(
        "SELECT * FROM complaints WHERE class_name = ? ORDER BY created_at DESC LIMIT 50",
        [$className], 's'
    );
    
    $complaints = array_map(function($r) {
        return [
            'id' => $r['id'],
            'parentId' => $r['parent_id'],
            'parentName' => $r['parent_name'],
            'className' => $r['class_name'],
            'complaintText' => $r['complaint_text'],
            'status' => $r['status'],
            'teacherResponse' => $r['teacher_response'],
            'respondedAt' => $r['responded_at'],
            'createdAt' => $r['created_at']
        ];
    }, $rows);
    
    respondSuccess(['items' => $complaints, 'total' => count($complaints)]);
}

function handleRespondComplaint() {
    $body = getJsonBody();
    $teacherId = $body['teacher_id'] ?? 0;
    if (!$teacherId) respondError('Teacher ID required');
    
    $teacher = dbFetchOne("SELECT * FROM teachers WHERE id = ?", [$teacherId], 'i');
    if (!$teacher) respondError('Teacher not found');
    
    $complaintId = (int)($body['complaint_id'] ?? 0);
    $response = trim($body['response'] ?? '');
    $status = trim($body['status'] ?? 'in_progress');
    
    if (!$complaintId) respondError('Complaint ID required');
    if (empty($response)) respondError('Response is required');
    
    // Update complaint with teacher response
    dbExecute(
        "UPDATE complaints SET teacher_response = ?, status = ?, responded_at = NOW() WHERE id = ?",
        [$response, $status, $complaintId],
        'ssi'
    );
    
    // Get complaint details for notification
    $complaint = dbFetchOne("SELECT * FROM complaints WHERE id = ?", [$complaintId], 'i');
    if (!$complaint) respondError('Complaint not found');
    
    // Create notification for parent
    $notificationMessage = "Your complaint for {$complaint['class_name']} has been viewed and responded to by the teacher.";
    dbInsert(
        "INSERT INTO admin_notifications (type, title, message, related_id, created_at, is_read) 
         VALUES ('complaint_response', 'Complaint Response Received', ?, ?, NOW(), 0)",
        [$notificationMessage, $complaint['parent_id']],
        'si'
    );
    
    addActivityLog('Complaint Response Submitted', "Teacher #$teacherId responded to complaint #$complaintId");
    respondSuccess([], 'Response submitted successfully! Parent will be notified.');
}

function handleEditComplaint() {
    $body = getJsonBody();
    $teacherId = $body['teacher_id'] ?? 0;
    if (!$teacherId) respondError('Teacher ID required');
    
    $teacher = dbFetchOne("SELECT * FROM teachers WHERE id = ?", [$teacherId], 'i');
    if (!$teacher) respondError('Teacher not found');
    
    $complaintId = (int)($body['complaint_id'] ?? 0);
    $newComplaintText = trim($body['complaint_text'] ?? '');
    
    if (!$complaintId) respondError('Complaint ID required');
    if (empty($newComplaintText)) respondError('Complaint text is required');
    
    // Verify complaint belongs to teacher's class
    $complaint = dbFetchOne("SELECT * FROM complaints WHERE id = ?", [$complaintId], 'i');
    if (!$complaint) respondError('Complaint not found');
    
    if ($complaint['class_name'] !== $teacher['class_assigned']) {
        respondError('You can only edit complaints for your assigned class');
    }
    
    // Update complaint
    dbExecute(
        "UPDATE complaints SET complaint_text = ?, updated_at = NOW() WHERE id = ?",
        [$newComplaintText, $complaintId],
        'si'
    );
    
    addActivityLog('Complaint Edited', "Teacher #$teacherId edited complaint #$complaintId");
    respondSuccess([], 'Complaint updated successfully');
}

function handleGetLoginHistory() {
    $teacherId = (int)($_REQUEST['teacher_id'] ?? 0);
    if (!$teacherId) respondError('Teacher ID required');
    
    $logs = dbFetchAll(
        "SELECT * FROM teacher_login_logs WHERE teacher_id = ? ORDER BY login_at DESC LIMIT 50",
        [$teacherId], 'i'
    );
    
    $items = array_map(function($log) {
        return [
            'id' => $log['id'],
            'ipAddress' => $log['ip_address'],
            'browser' => $log['browser'],
            'os' => $log['os'],
            'device' => $log['device'],
            'userAgent' => $log['user_agent'],
            'loginStatus' => $log['login_status'],
            'loginAt' => $log['login_at']
        ];
    }, $logs);
    
    respondSuccess(['items' => $items, 'total' => count($items)]);
}

function handleGetAuthorizedIps() {
    $teacherId = (int)($_REQUEST['teacher_id'] ?? 0);
    if (!$teacherId) respondError('Teacher ID required');
    
    $ips = dbFetchAll(
        "SELECT * FROM teacher_authorized_ips WHERE teacher_id = ? ORDER BY created_at DESC",
        [$teacherId], 'i'
    );
    
    $items = array_map(function($ip) {
        return [
            'id' => $ip['id'],
            'ipAddress' => $ip['ip_address'],
            'description' => $ip['description'],
            'createdAt' => $ip['created_at']
        ];
    }, $ips);
    
    respondSuccess(['items' => $items, 'total' => count($items)]);
}

function handleGetAuthorizedEmails() {
    $teacherId = (int)($_REQUEST['teacher_id'] ?? 0);
    if (!$teacherId) respondError('Teacher ID required');
    
    $emails = dbFetchAll(
        "SELECT * FROM teacher_authorized_emails WHERE teacher_id = ? ORDER BY created_at DESC",
        [$teacherId], 'i'
    );
    
    $items = array_map(function($email) {
        return [
            'id' => $email['id'],
            'email' => $email['email'],
            'description' => $email['description'],
            'createdAt' => $email['created_at']
        ];
    }, $emails);
    
    respondSuccess(['items' => $items, 'total' => count($items)]);
}

function handleAddAuthorizedIp() {
    $body = getJsonBody();
    $teacherId = $body['teacher_id'] ?? 0;
    $ipAddress = trim($body['ip_address'] ?? '');
    $description = trim($body['description'] ?? '');
    
    if (!$teacherId) respondError('Teacher ID required');
    if (empty($ipAddress)) respondError('IP address is required');
    
    $ipId = dbInsert(
        "INSERT INTO teacher_authorized_ips (teacher_id, ip_address, description, created_at) VALUES (?, ?, ?, NOW())",
        [$teacherId, $ipAddress, $description],
        'iss'
    );
    
    if (!$ipId) {
        respondError('Failed to add authorized IP');
    }
    
    addActivityLog('Authorized IP Added', "Teacher #$teacherId added IP: $ipAddress");
    respondSuccess(['id' => $ipId], 'Authorized IP added successfully');
}

function handleRevokeAuthorizedIp() {
    $body = getJsonBody();
    $ipId = $body['ip_id'] ?? 0;
    
    if (!$ipId) respondError('IP ID required');
    
    dbExecute("DELETE FROM teacher_authorized_ips WHERE id = ?", [$ipId], 'i');
    
    addActivityLog('Authorized IP Revoked', "IP #$ipId revoked");
    respondSuccess([], 'Authorized IP revoked successfully');
}

function handleAddAuthorizedEmail() {
    $body = getJsonBody();
    $teacherId = $body['teacher_id'] ?? 0;
    $email = trim($body['email'] ?? '');
    $description = trim($body['description'] ?? '');
    
    if (!$teacherId) respondError('Teacher ID required');
    if (empty($email)) respondError('Email address is required');
    
    $emailId = dbInsert(
        "INSERT INTO teacher_authorized_emails (teacher_id, email, description, created_at) VALUES (?, ?, ?, NOW())",
        [$teacherId, $email, $description],
        'iss'
    );
    
    if (!$emailId) {
        respondError('Failed to add authorized email');
    }
    
    addActivityLog('Authorized Email Added', "Teacher #$teacherId added email: $email");
    respondSuccess(['id' => $emailId], 'Authorized email added successfully');
}

function handleRevokeAuthorizedEmail() {
    $body = getJsonBody();
    $emailId = $body['email_id'] ?? 0;
    
    if (!$emailId) respondError('Email ID required');
    
    dbExecute("DELETE FROM teacher_authorized_emails WHERE id = ?", [$emailId], 'i');
    
    addActivityLog('Authorized Email Revoked', "Email #$emailId revoked");
    respondSuccess([], 'Authorized email revoked successfully');
}

// ===== RESOURCE MANAGEMENT =====

function handleGetMyResources() {
    $teacherId = (int)($_REQUEST['teacher_id'] ?? 0);
    if (!$teacherId) respondError('Teacher ID required');
    
    // Create teacher_resources table if it doesn't exist
    $conn = getDB();
    $conn->query("CREATE TABLE IF NOT EXISTS teacher_resources (
        id INT PRIMARY KEY AUTO_INCREMENT,
        teacher_id INT NOT NULL,
        teacher_name VARCHAR(255) NOT NULL,
        teacher_class VARCHAR(100),
        title VARCHAR(255) NOT NULL,
        category VARCHAR(50) NOT NULL,
        subject VARCHAR(100),
        url VARCHAR(500),
        description TEXT,
        file_url VARCHAR(500),
        file_name VARCHAR(255),
        file_type VARCHAR(100),
        share_with VARCHAR(20) DEFAULT 'private',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_teacher (teacher_id),
        INDEX idx_share (share_with),
        INDEX idx_class (teacher_class)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    
    $rows = dbFetchAll(
        "SELECT * FROM teacher_resources WHERE teacher_id = ? ORDER BY created_at DESC LIMIT 100",
        [$teacherId], 'i'
    );
    
    $resources = array_map(function($r) {
        return [
            'id' => $r['id'],
            'teacherId' => $r['teacher_id'],
            'teacherName' => $r['teacher_name'],
            'teacherClass' => $r['teacher_class'],
            'title' => $r['title'],
            'category' => $r['category'],
            'subject' => $r['subject'],
            'url' => $r['url'],
            'description' => $r['description'],
            'fileUrl' => $r['file_url'],
            'fileName' => $r['file_name'],
            'fileType' => $r['file_type'],
            'shareWith' => $r['share_with'],
            'createdAt' => $r['created_at']
        ];
    }, $rows);
    
    respondSuccess(['items' => $resources, 'total' => count($resources)]);
}

function handleGetSharedResources() {
    $teacherId = (int)($_REQUEST['teacher_id'] ?? 0);
    if (!$teacherId) respondError('Teacher ID required');
    
    $teacher = dbFetchOne("SELECT * FROM teachers WHERE id = ?", [$teacherId], 'i');
    if (!$teacher) respondError('Teacher not found');
    
    $teacherClass = $teacher['class_assigned'];
    
    // Get resources shared with this teacher's class or all teachers
    $rows = dbFetchAll(
        "SELECT * FROM teacher_resources WHERE 
         (share_with = 'class' AND teacher_class = ?) OR 
         share_with = 'all'
         AND teacher_id != ?
         ORDER BY created_at DESC LIMIT 100",
        [$teacherClass, $teacherId], 'si'
    );
    
    $resources = array_map(function($r) {
        return [
            'id' => $r['id'],
            'teacherId' => $r['teacher_id'],
            'teacherName' => $r['teacher_name'],
            'teacherClass' => $r['teacher_class'],
            'title' => $r['title'],
            'category' => $r['category'],
            'subject' => $r['subject'],
            'url' => $r['url'],
            'description' => $r['description'],
            'fileUrl' => $r['file_url'],
            'fileName' => $r['file_name'],
            'fileType' => $r['file_type'],
            'shareWith' => $r['share_with'],
            'createdAt' => $r['created_at']
        ];
    }, $rows);
    
    respondSuccess(['items' => $resources, 'total' => count($resources)]);
}

function handleSaveResource() {
    // Handle both JSON and multipart form data
    $teacherId = (int)($_REQUEST['teacher_id'] ?? $_POST['teacher_id'] ?? 0);
    if (!$teacherId) respondError('Teacher ID required');
    
    $teacher = dbFetchOne("SELECT * FROM teachers WHERE id = ?", [$teacherId], 'i');
    if (!$teacher) respondError('Teacher not found');
    
    // Check if this is a file upload (multipart) or JSON
    $isMultipart = isset($_FILES['resourceFile']);
    
    if ($isMultipart) {
        // Handle multipart form data with file upload
        $title = trim($_POST['title'] ?? '');
        $category = trim($_POST['category'] ?? 'Other');
        $subject = trim($_POST['subject'] ?? '');
        $url = trim($_POST['url'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $shareWith = trim($_POST['shareWith'] ?? 'private');
        $editId = (int)($_POST['editId'] ?? 0);
        
        if (empty($title)) respondError('Title is required');
        
        // Handle file upload
        $fileUrl = null;
        $fileName = null;
        $fileType = null;
        
        if (!empty($_FILES['resourceFile']) && $_FILES['resourceFile']['error'] === UPLOAD_ERR_OK) {
            $file = $_FILES['resourceFile'];
            $allowedTypes = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/vnd.ms-powerpoint', 'application/vnd.openxmlformats-officedocument.presentationml.presentation', 'image/jpeg', 'image/png', 'image/jpg'];
            $maxSize = 10 * 1024 * 1024; // 10MB
            
            if (!in_array($file['type'], $allowedTypes)) {
                respondError('Invalid file type. Allowed: PDF, DOC, DOCX, PPT, PPTX, JPG, PNG');
            }
            if ($file['size'] > $maxSize) {
                respondError('File too large. Maximum size is 10MB');
            }
            
            $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            $newName = 'resource_' . uniqid() . '.' . $ext;
            $uploadDir = __DIR__ . '/../uploads/teacher_resources/';
            if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
            
            $dest = $uploadDir . $newName;
            if (!move_uploaded_file($file['tmp_name'], $dest)) {
                respondError('Failed to save uploaded file');
            }
            
            $fileUrl = '../uploads/teacher_resources/' . $newName;
            $fileName = $file['name'];
            $fileType = $file['type'];
        }
        
        $teacherName = $teacher['first_name'] . ' ' . $teacher['last_name'];
        $teacherClass = $teacher['class_assigned'];
        
        if ($editId > 0) {
            // Update existing resource
            $existing = dbFetchOne("SELECT * FROM teacher_resources WHERE id = ? AND teacher_id = ?", [$editId, $teacherId], 'ii');
            if (!$existing) respondError('Resource not found or access denied');
            
            // Preserve existing file if no new file uploaded
            if (!$fileUrl && $existing['file_url']) {
                $fileUrl = $existing['file_url'];
                $fileName = $existing['file_name'];
                $fileType = $existing['file_type'];
            }
            
            dbExecute(
                "UPDATE teacher_resources SET title=?, category=?, subject=?, url=?, description=?, file_url=?, file_name=?, file_type=?, share_with=?, teacher_class=?, updated_at=NOW() WHERE id=?",
                [$title, $category, $subject, $url, $description, $fileUrl, $fileName, $fileType, $shareWith, $teacherClass, $editId],
                'sssssssssi'
            );
            
            addActivityLog('Resource Updated', "Teacher '$teacherName' updated resource: '$title'");
            respondSuccess([], 'Resource updated successfully');
        } else {
            // Create new resource
            $id = dbInsert(
                "INSERT INTO teacher_resources (teacher_id, teacher_name, teacher_class, title, category, subject, url, description, file_url, file_name, file_type, share_with)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                [$teacherId, $teacherName, $teacherClass, $title, $category, $subject, $url, $description, $fileUrl, $fileName, $fileType, $shareWith],
                'issssssssss'
            );
            
            if ($id) {
                $successMessage = 'Resource added successfully';
                if ($shareWith === 'class') {
                    $successMessage .= ' and shared with teachers in your class';
                } else if ($shareWith === 'all') {
                    $successMessage .= ' and shared with all teachers';
                }
                if ($fileUrl) {
                    $successMessage .= '. File attached.';
                }
                
                addActivityLog('Resource Created', "Teacher '$teacherName' added resource: '$title' (shared: $shareWith)");
                respondSuccess(['id' => $id], $successMessage);
            }
            respondError('Failed to save resource');
        }
    } else {
        // Handle JSON data (without file upload)
        $body = getJsonBody();
        if (!$body) respondError('Invalid request body');
        
        $editId = (int)($body['id'] ?? 0);
        $title = trim($body['title'] ?? '');
        $category = trim($body['category'] ?? 'Other');
        $subject = trim($body['subject'] ?? '');
        $url = trim($body['url'] ?? '');
        $description = trim($body['description'] ?? '');
        $shareWith = trim($body['shareWith'] ?? 'private');
        
        if (empty($title)) respondError('Title is required');
        
        $teacherName = $teacher['first_name'] . ' ' . $teacher['last_name'];
        $teacherClass = $teacher['class_assigned'];
        
        if ($editId > 0) {
            // Update existing resource
            $existing = dbFetchOne("SELECT * FROM teacher_resources WHERE id = ? AND teacher_id = ?", [$editId, $teacherId], 'ii');
            if (!$existing) respondError('Resource not found or access denied');
            
            dbExecute(
                "UPDATE teacher_resources SET title=?, category=?, subject=?, url=?, description=?, share_with=?, teacher_class=?, updated_at=NOW() WHERE id=?",
                [$title, $category, $subject, $url, $description, $shareWith, $teacherClass, $editId],
                'sssssssi'
            );
            
            addActivityLog('Resource Updated', "Teacher '$teacherName' updated resource: '$title'");
            respondSuccess([], 'Resource updated successfully');
        } else {
            // Create new resource
            $id = dbInsert(
                "INSERT INTO teacher_resources (teacher_id, teacher_name, teacher_class, title, category, subject, url, description, share_with)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                [$teacherId, $teacherName, $teacherClass, $title, $category, $subject, $url, $description, $shareWith],
                'issssssss'
            );
            
            if ($id) {
                $successMessage = 'Resource added successfully';
                if ($shareWith === 'class') {
                    $successMessage .= ' and shared with teachers in your class';
                } else if ($shareWith === 'all') {
                    $successMessage .= ' and shared with all teachers';
                }
                
                addActivityLog('Resource Created', "Teacher '$teacherName' added resource: '$title' (shared: $shareWith)");
                respondSuccess(['id' => $id], $successMessage);
            }
            respondError('Failed to save resource');
        }
    }
}

function handleDeleteResource() {
    $body = getJsonBody();
    $id = (int)($body['id'] ?? 0);
    $teacherId = (int)($body['teacherId'] ?? 0);
    if (!$id || !$teacherId) respondError('Resource ID and Teacher ID required');
    
    // Ensure the resource belongs to this teacher
    $resource = dbFetchOne("SELECT * FROM teacher_resources WHERE id = ? AND teacher_id = ?", [$id, $teacherId], 'ii');
    if (!$resource) respondError('Resource not found or access denied');
    
    // Delete the file if it exists
    if ($resource['file_url']) {
        $filePath = __DIR__ . '/../' . ltrim($resource['file_url'], '/');
        $filePath = str_replace('../', '', $filePath);
        $filePath = __DIR__ . '/../' . $filePath;
        if (file_exists($filePath)) {
            @unlink($filePath);
        }
    }
    
    dbExecute("DELETE FROM teacher_resources WHERE id = ?", [$id], 'i');
    addActivityLog('Resource Deleted', "Resource '{$resource['title']}' deleted");
    respondSuccess([], 'Resource deleted successfully');
}

function handleDeleteComplaint() {
    $body = getJsonBody();
    $teacherId = $body['teacher_id'] ?? 0;
    if (!$teacherId) respondError('Teacher ID required');
    
    $teacher = dbFetchOne("SELECT * FROM teachers WHERE id = ?", [$teacherId], 'i');
    if (!$teacher) respondError('Teacher not found');
    
    $complaintId = (int)($body['complaint_id'] ?? 0);
    if (!$complaintId) respondError('Complaint ID required');
    
    // Verify complaint belongs to teacher's class
    $complaint = dbFetchOne("SELECT * FROM complaints WHERE id = ?", [$complaintId], 'i');
    if (!$complaint) respondError('Complaint not found');
    
    if ($complaint['class_name'] !== $teacher['class_assigned']) {
        respondError('You can only delete complaints for your assigned class');
    }
    
    // Delete complaint
    dbExecute("DELETE FROM complaints WHERE id = ?", [$complaintId], 'i');
    
    addActivityLog('Complaint Deleted', "Teacher #$teacherId deleted complaint #$complaintId");
    respondSuccess([], 'Complaint deleted successfully');
}

function handleRejectComplaint() {
    $body = getJsonBody();
    $teacherId = $body['teacher_id'] ?? 0;
    if (!$teacherId) respondError('Teacher ID required');
    
    $teacher = dbFetchOne("SELECT * FROM teachers WHERE id = ?", [$teacherId], 'i');
    if (!$teacher) respondError('Teacher not found');
    
    $complaintId = (int)($body['complaint_id'] ?? 0);
    $rejectionReason = trim($body['rejection_reason'] ?? '');
    
    if (!$complaintId) respondError('Complaint ID required');
    if (empty($rejectionReason)) respondError('Rejection reason is required');
    
    // Verify complaint belongs to teacher's class
    $complaint = dbFetchOne("SELECT * FROM complaints WHERE id = ?", [$complaintId], 'i');
    if (!$complaint) respondError('Complaint not found');
    
    if ($complaint['class_name'] !== $teacher['class_assigned']) {
        respondError('You can only reject complaints for your assigned class');
    }
    
    // Update complaint status to rejected with reason
    dbExecute(
        "UPDATE complaints SET status = 'rejected', teacher_response = ?, responded_at = NOW() WHERE id = ?",
        [$rejectionReason, $complaintId],
        'si'
    );
    
    // Create notification for parent
    $notificationMessage = "Your complaint for {$complaint['class_name']} has been reviewed and rejected by the teacher. Reason: {$rejectionReason}";
    dbInsert(
        "INSERT INTO admin_notifications (type, title, message, related_id, created_at, is_read) 
         VALUES ('complaint_rejected', 'Complaint Rejected', ?, ?, NOW(), 0)",
        [$notificationMessage, $complaint['parent_id']],
        'si'
    );
    
    addActivityLog('Complaint Rejected', "Teacher #$teacherId rejected complaint #$complaintId");
    respondSuccess([], 'Complaint rejected successfully. Parent will be notified.');
}

// ===== LESSON PLANS =====

function handleGetMyLessonPlans() {
    $teacherId = (int)($_REQUEST['teacher_id'] ?? 0);
    if (!$teacherId) respondError('Teacher ID required');

    $rows = dbFetchAll(
        "SELECT * FROM lesson_plans WHERE teacher_id = ? ORDER BY lesson_date DESC, created_at DESC LIMIT 200",
        [$teacherId], 'i'
    );

    $lessonPlans = array_map(function($r) {
        return [
            'id' => $r['id'],
            'teacherId' => $r['teacher_id'],
            'academicYear' => $r['academic_year'],
            'term' => $r['term'],
            'week' => $r['week'],
            'gradeLevel' => $r['grade_level'],
            'className' => $r['class_name'],
            'subject' => $r['subject'],
            'topic' => $r['topic'],
            'lessonDate' => $r['lesson_date'],
            'startTime' => $r['start_time'],
            'duration' => $r['duration'],
            'status' => $r['status'],
            'createdAt' => $r['created_at'],
            'updatedAt' => $r['updated_at']
        ];
    }, $rows);

    respondSuccess(['items' => $lessonPlans, 'total' => count($lessonPlans)]);
}

function handleGetLessonPlan() {
    $lessonPlanId = (int)($_REQUEST['lesson_plan_id'] ?? 0);
    $teacherId = (int)($_REQUEST['teacher_id'] ?? 0);

    if (!$lessonPlanId) respondError('Lesson Plan ID required');
    if (!$teacherId) respondError('Teacher ID required');

    // Get main lesson plan
    $lessonPlan = dbFetchOne(
        "SELECT * FROM lesson_plans WHERE id = ? AND teacher_id = ?",
        [$lessonPlanId, $teacherId],
        'ii'
    );

    if (!$lessonPlan) respondError('Lesson plan not found or access denied');

    // Get objectives
    $objectives = dbFetchAll(
        "SELECT * FROM lesson_objectives WHERE lesson_plan_id = ? ORDER BY display_order ASC",
        [$lessonPlanId],
        'i'
    );

    // Get materials
    $materials = dbFetchAll(
        "SELECT * FROM lesson_materials WHERE lesson_plan_id = ? ORDER BY display_order ASC",
        [$lessonPlanId],
        'i'
    );

    // Get activities
    $activities = dbFetchAll(
        "SELECT * FROM lesson_activities WHERE lesson_plan_id = ? ORDER BY phase, display_order ASC",
        [$lessonPlanId],
        'i'
    );

    respondSuccess([
        'lessonPlan' => [
            'id' => $lessonPlan['id'],
            'teacherId' => $lessonPlan['teacher_id'],
            'academicYear' => $lessonPlan['academic_year'],
            'term' => $lessonPlan['term'],
            'week' => $lessonPlan['week'],
            'gradeLevel' => $lessonPlan['grade_level'],
            'className' => $lessonPlan['class_name'],
            'subject' => $lessonPlan['subject'],
            'topic' => $lessonPlan['topic'],
            'lessonDate' => $lessonPlan['lesson_date'],
            'startTime' => $lessonPlan['start_time'],
            'duration' => $lessonPlan['duration'],
            'successCriteria' => $lessonPlan['success_criteria'],
            'assessment' => $lessonPlan['assessment'],
            'homework' => $lessonPlan['homework'],
            'reflection' => $lessonPlan['reflection'],
            'whatWentWell' => $lessonPlan['what_went_well'],
            'challenges' => $lessonPlan['challenges'],
            'learnersSupport' => $lessonPlan['learners_support'],
            'improvements' => $lessonPlan['improvements'],
            'status' => $lessonPlan['status'],
            'createdAt' => $lessonPlan['created_at'],
            'updatedAt' => $lessonPlan['updated_at']
        ],
        'objectives' => array_map(function($r) {
            return [
                'id' => $r['id'],
                'objectiveText' => $r['objective_text'],
                'displayOrder' => $r['display_order']
            ];
        }, $objectives),
        'materials' => array_map(function($r) {
            return [
                'id' => $r['id'],
                'materialType' => $r['material_type'],
                'materialName' => $r['material_name'],
                'displayOrder' => $r['display_order']
            ];
        }, $materials),
        'activities' => array_map(function($r) {
            return [
                'id' => $r['id'],
                'phase' => $r['phase'],
                'teacherActivity' => $r['teacher_activity'],
                'learnerActivity' => $r['learner_activity'],
                'displayOrder' => $r['display_order']
            ];
        }, $activities)
    ]);
}

function handleSaveLessonPlan() {
    $body = getJsonBody();
    if (!$body) respondError('Invalid request body');

    $teacherId = (int)($body['teacherId'] ?? 0);
    if (!$teacherId) respondError('Teacher ID required');

    $editId = (int)($body['id'] ?? 0);

    // Validate required fields
    $academicYear = trim($body['academicYear'] ?? '');
    $term = trim($body['term'] ?? '');
    $week = trim($body['week'] ?? '');
    $gradeLevel = trim($body['gradeLevel'] ?? '');
    $className = trim($body['className'] ?? '');
    $subject = trim($body['subject'] ?? '');
    $topic = trim($body['topic'] ?? '');
    $lessonDate = trim($body['lessonDate'] ?? '');
    $startTime = trim($body['startTime'] ?? '');
    $duration = trim($body['duration'] ?? '');
    $status = trim($body['status'] ?? 'draft');

    if (empty($academicYear) || empty($term) || empty($week) || empty($gradeLevel) ||
        empty($className) || empty($subject) || empty($topic) || empty($lessonDate) ||
        empty($startTime) || empty($duration)) {
        respondError('All required fields must be filled');
    }

    $conn = getDB();

    if ($editId > 0) {
        // Update existing lesson plan
        $existing = dbFetchOne("SELECT * FROM lesson_plans WHERE id = ? AND teacher_id = ?", [$editId, $teacherId], 'ii');
        if (!$existing) respondError('Lesson plan not found or access denied');

        // Update main lesson plan
        dbExecute(
            "UPDATE lesson_plans SET
                academic_year=?, term=?, week=?, grade_level=?, class_name=?, subject=?, topic=?,
                lesson_date=?, start_time=?, duration=?, success_criteria=?, assessment=?, homework=?,
                reflection=?, what_went_well=?, challenges=?, learners_support=?, improvements=?, status=?
                WHERE id=?",
            [
                $academicYear, $term, $week, $gradeLevel, $className, $subject, $topic,
                $lessonDate, $startTime, $duration,
                $body['successCriteria'] ?? '', $body['assessment'] ?? '', $body['homework'] ?? '',
                $body['reflection'] ?? '', $body['whatWentWell'] ?? '', $body['challenges'] ?? '',
                $body['learnersSupport'] ?? '', $body['improvements'] ?? '', $status, $editId
            ],
            'sssssssssssssssssi'
        );

        // Delete existing related data
        dbExecute("DELETE FROM lesson_objectives WHERE lesson_plan_id = ?", [$editId], 'i');
        dbExecute("DELETE FROM lesson_materials WHERE lesson_plan_id = ?", [$editId], 'i');
        dbExecute("DELETE FROM lesson_activities WHERE lesson_plan_id = ?", [$editId], 'i');

        $lessonPlanId = $editId;
    } else {
        // Create new lesson plan
        $lessonPlanId = dbInsert(
            "INSERT INTO lesson_plans
                (teacher_id, academic_year, term, week, grade_level, class_name, subject, topic,
                 lesson_date, start_time, duration, success_criteria, assessment, homework,
                 reflection, what_went_well, challenges, learners_support, improvements, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            [
                $teacherId, $academicYear, $term, $week, $gradeLevel, $className, $subject, $topic,
                $lessonDate, $startTime, $duration,
                $body['successCriteria'] ?? '', $body['assessment'] ?? '', $body['homework'] ?? '',
                $body['reflection'] ?? '', $body['whatWentWell'] ?? '', $body['challenges'] ?? '',
                $body['learnersSupport'] ?? '', $body['improvements'] ?? '', $status
            ],
            'issssssssssssssssss'
        );

        if (!$lessonPlanId) respondError('Failed to create lesson plan');
    }

    // Save objectives
    if (isset($body['objectives']) && is_array($body['objectives'])) {
        foreach ($body['objectives'] as $index => $obj) {
            if (!empty(trim($obj['objectiveText'] ?? ''))) {
                dbInsert(
                    "INSERT INTO lesson_objectives (lesson_plan_id, objective_text, display_order) VALUES (?, ?, ?)",
                    [$lessonPlanId, trim($obj['objectiveText']), $index],
                    'isi'
                );
            }
        }
    }

    // Save materials
    if (isset($body['materials']) && is_array($body['materials'])) {
        foreach ($body['materials'] as $index => $mat) {
            if (!empty(trim($mat['materialName'] ?? ''))) {
                dbInsert(
                    "INSERT INTO lesson_materials (lesson_plan_id, material_type, material_name, display_order) VALUES (?, ?, ?, ?)",
                    [$lessonPlanId, $mat['materialType'] ?? 'other', trim($mat['materialName']), $index],
                    'issi'
                );
            }
        }
    }

    // Save activities
    if (isset($body['activities']) && is_array($body['activities'])) {
        foreach ($body['activities'] as $index => $act) {
            if (!empty(trim($act['teacherActivity'] ?? '')) || !empty(trim($act['learnerActivity'] ?? ''))) {
                dbInsert(
                    "INSERT INTO lesson_activities (lesson_plan_id, phase, teacher_activity, learner_activity, display_order) VALUES (?, ?, ?, ?, ?)",
                    [$lessonPlanId, $act['phase'] ?? 'introduction', $act['teacherActivity'] ?? '', $act['learnerActivity'] ?? '', $index],
                    'isssi'
                );
            }
        }
    }

    $action = $editId > 0 ? 'Lesson Plan Updated' : 'Lesson Plan Created';
    addActivityLog($action, "Teacher #$teacherId " . ($editId > 0 ? 'updated' : 'created') . " lesson plan: '$topic'");

    respondSuccess(['id' => $lessonPlanId], ($editId > 0 ? 'Lesson plan updated successfully!' : 'Lesson plan created successfully!'));
}

function handleDeleteLessonPlan() {
    $body = getJsonBody();
    $id = (int)($body['id'] ?? 0);
    $teacherId = (int)($body['teacherId'] ?? 0);

    if (!$id || !$teacherId) respondError('Lesson Plan ID and Teacher ID required');
}

// ===== SIMPLE LESSON PLAN (TEMPLATE-BASED) =====

function handleSimpleLessonPlan() {
    $action = $_REQUEST['action'] ?? '';
    $subAction = $_REQUEST['subaction'] ?? $_REQUEST['action'] ?? '';

    if ($subAction === 'list') {
        handleSimpleLessonPlanList();
    } elseif ($subAction === 'get') {
        handleSimpleLessonPlanGet();
    } elseif ($subAction === 'save') {
        handleSimpleLessonPlanSave();
    } elseif ($subAction === 'delete') {
        handleSimpleLessonPlanDelete();
    } else {
        respondError('Unknown lesson plan action: ' . $subAction);
    }
}

function handleSimpleLessonPlanList() {
    $teacherId = (int)($_REQUEST['teacher_id'] ?? 0);
    if (!$teacherId) respondError('Teacher ID required');

    $plans = dbFetchAll(
        "SELECT * FROM simple_lesson_plans WHERE teacher_id = ? ORDER BY created_at DESC",
        [$teacherId],
        'i'
    );

    respondSuccess($plans);
}

function handleSimpleLessonPlanGet() {
    $id = (int)($_REQUEST['id'] ?? 0);
    if (!$id) respondError('Lesson Plan ID required');

    $plan = dbFetchOne(
        "SELECT * FROM simple_lesson_plans WHERE id = ?",
        [$id],
        'i'
    );

    if (!$plan) respondError('Lesson plan not found');

    respondSuccess($plan);
}

function handleSimpleLessonPlanSave() {
    $body = getJsonBody();
    if (!$body) respondError('Invalid request body');

    $teacherId = (int)($body['teacher_id'] ?? 0);
    if (!$teacherId) respondError('Teacher ID required');

    $editId = (int)($body['id'] ?? 0);

    $conn = getDB();

    if ($editId > 0) {
        // Update existing
        $existing = dbFetchOne("SELECT * FROM simple_lesson_plans WHERE id = ? AND teacher_id = ?", [$editId, $teacherId], 'ii');
        if (!$existing) respondError('Lesson plan not found or access denied');

        dbExecute(
            "UPDATE simple_lesson_plans SET
                class=?, date=?, time=?, subject=?, success_criteria=?, materials=?,
                intro_teacher=?, intro_learner=?,
                step1_teacher=?, step1_learner=?,
                step2_teacher=?, step2_learner=?,
                step3_teacher=?, step3_learner=?,
                conclusion_teacher=?, conclusion_learner=?
                WHERE id=?",
            [
                $body['class'] ?? '', $body['date'] ?? '', $body['time'] ?? '', $body['subject'] ?? '',
                $body['success_criteria'] ?? '', $body['materials'] ?? '',
                $body['intro_teacher'] ?? '', $body['intro_learner'] ?? '',
                $body['step1_teacher'] ?? '', $body['step1_learner'] ?? '',
                $body['step2_teacher'] ?? '', $body['step2_learner'] ?? '',
                $body['step3_teacher'] ?? '', $body['step3_learner'] ?? '',
                $body['conclusion_teacher'] ?? '', $body['conclusion_learner'] ?? '',
                $editId
            ],
            'ssssssssssssssssi'
        );

        respondSuccess(['id' => $editId], 'Lesson plan updated successfully');
    } else {
        // Create new
        dbInsert(
            "INSERT INTO simple_lesson_plans (teacher_id, class, date, time, subject, success_criteria, materials,
                intro_teacher, intro_learner,
                step1_teacher, step1_learner,
                step2_teacher, step2_learner,
                step3_teacher, step3_learner,
                conclusion_teacher, conclusion_learner)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            [
                $teacherId, $body['class'] ?? '', $body['date'] ?? '', $body['time'] ?? '', $body['subject'] ?? '',
                $body['success_criteria'] ?? '', $body['materials'] ?? '',
                $body['intro_teacher'] ?? '', $body['intro_learner'] ?? '',
                $body['step1_teacher'] ?? '', $body['step1_learner'] ?? '',
                $body['step2_teacher'] ?? '', $body['step2_learner'] ?? '',
                $body['step3_teacher'] ?? '', $body['step3_learner'] ?? '',
                $body['conclusion_teacher'] ?? '', $body['conclusion_learner'] ?? ''
            ],
            'issssssssssssssss'
        );

        $newId = $conn->insert_id;
        respondSuccess(['id' => $newId], 'Lesson plan created successfully');
    }
}

function handleSimpleLessonPlanDelete() {
    $id = (int)($_REQUEST['id'] ?? 0);
    if (!$id) respondError('Lesson Plan ID required');

    $plan = dbFetchOne("SELECT * FROM simple_lesson_plans WHERE id = ?", [$id], 'i');
    if (!$plan) respondError('Lesson plan not found');

    dbExecute("DELETE FROM simple_lesson_plans WHERE id = ?", [$id], 'i');

    respondSuccess(null, 'Lesson plan deleted successfully');
}