<?php
/**
 * Database Connection - Noah Christian Academy
 * MySQLi connection with environment detection
 */

// Load .env file
$envFile = __DIR__ . '/../.env';
if (file_exists($envFile)) {
    $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos(trim($line), '#') === 0) continue;
        if (strpos($line, '=') !== false) {
            list($key, $value) = explode('=', $line, 2);
            $key = trim($key);
            $value = trim($value);
            // Remove quotes if present
            if (strpos($value, '"') === 0 || strpos($value, "'") === 0) {
                $value = substr($value, 1, -1);
            }
            putenv("$key=$value");
            $_ENV[$key] = $value;
        }
    }
}

// Detect environment and set appropriate database credentials
$host = $_SERVER['HTTP_HOST'] ?? $_SERVER['SERVER_NAME'] ?? 'localhost';

if (strpos($host, 'localhost') !== false || strpos($host, '127.0.0.1') !== false) {
    // Localhost environment
    define('DB_HOST', 'localhost');
    define('DB_USER', 'root');
    define('DB_PASS', '');
    define('DB_NAME', 'noh');
    define('DB_PORT', '3306');
} else {
    // InfinityFree / Production environment
    define('DB_HOST', 'sql202.infinityfree.com');
    define('DB_USER', 'if0_42495293');
    define('DB_PASS', 'dolodolo98');
    define('DB_NAME', 'if0_42495293_noh');
    define('DB_PORT', '3306');
}









function getDB() {
    static $conn = null;
    if ($conn === null) {
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME, DB_PORT);
        if ($conn->connect_error) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Database connection failed: ' . $conn->connect_error]);
            exit();
        }
        $conn->set_charset('utf8mb4');
    }
    return $conn;
}

/**
 * Execute a prepared statement and return results
 */
function dbQuery($sql, $params = [], $types = '') {
    $conn = getDB();
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        return ['error' => $conn->error, 'success' => false];
    }
    if (!empty($params)) {
        // Auto-detect types if not provided
        if (empty($types)) {
            $types = '';
            foreach ($params as $param) {
                if (is_int($param)) {
                    $types .= 'i';
                } elseif (is_float($param)) {
                    $types .= 'd';
                } else {
                    $types .= 's';
                }
            }
        }
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();
    return ['result' => $result, 'success' => true];
}

/**
 * Fetch all rows as associative array
 */
function dbFetchAll($sql, $params = [], $types = '') {
    $res = dbQuery($sql, $params, $types);
    if (!$res['success'] || !$res['result']) return [];
    return $res['result']->fetch_all(MYSQLI_ASSOC);
}

/**
 * Fetch single row as associative array
 */
function dbFetchOne($sql, $params = [], $types = '') {
    $res = dbQuery($sql, $params, $types);
    if (!$res['success'] || !$res['result']) return null;
    return $res['result']->fetch_assoc();
}

/**
 * Execute INSERT and return inserted ID
 */
function dbInsert($sql, $params = [], $types = '') {
    $conn = getDB();
    $stmt = $conn->prepare($sql);
    if (!$stmt) return 0;
    if (!empty($params)) {
        // Auto-detect types if not provided
        if (empty($types)) {
            $types = '';
            foreach ($params as $param) {
                if (is_int($param)) {
                    $types .= 'i';
                } elseif (is_float($param)) {
                    $types .= 'd';
                } else {
                    $types .= 's';
                }
            }
        }
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $id = $stmt->insert_id;
    $stmt->close();
    return $id;
}

/**
 * Execute INSERT on a table with data array and return inserted ID
 */
function dbInsertTable($table, $data) {
    $conn = getDB();
    
    // Build INSERT query
    $columns = array_keys($data);
    $placeholders = array_fill(0, count($columns), '?');
    
    $sql = "INSERT INTO $table (" . implode(', ', $columns) . ") VALUES (" . implode(', ', $placeholders) . ")";
    
    $params = array_values($data);
    $typeString = '';
    
    // Auto-detect types
    foreach ($params as $param) {
        if (is_int($param)) {
            $typeString .= 'i';
        } elseif (is_float($param)) {
            $typeString .= 'd';
        } else {
            $typeString .= 's';
        }
    }
    
    $stmt = $conn->prepare($sql);
    if (!$stmt) return 0;
    
    if (!empty($params)) {
        $stmt->bind_param($typeString, ...$params);
    }
    
    $result = $stmt->execute();
    $id = $stmt->insert_id;
    $stmt->close();
    
    return $result ? $id : 0;
}

/**
 * Execute UPDATE/DELETE and return affected rows
 */
function dbExecute($sql, $params = [], $types = '') {
    $conn = getDB();
    $stmt = $conn->prepare($sql);
    if (!$stmt) return 0;
    if (!empty($params)) {
        // Auto-detect types if not provided
        if (empty($types)) {
            $types = '';
            foreach ($params as $param) {
                if (is_int($param)) {
                    $types .= 'i';
                } elseif (is_float($param)) {
                    $types .= 'd';
                } else {
                    $types .= 's';
                }
            }
        }
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $affected = $stmt->affected_rows;
    $stmt->close();
    return $affected;
}

/**
 * Execute UPDATE on a table with conditions
 */
function dbUpdate($table, $data, $conditions = [], $types = '') {
    $conn = getDB();
    
    // Build SET clause
    $setParts = [];
    $params = [];
    $typeString = '';
    
    foreach ($data as $column => $value) {
        $setParts[] = "$column = ?";
        $params[] = $value;
        $typeString .= is_int($value) ? 'i' : 's';
    }
    
    // Build WHERE clause
    $whereParts = [];
    foreach ($conditions as $column => $value) {
        $whereParts[] = "$column = ?";
        $params[] = $value;
        $typeString .= is_int($value) ? 'i' : 's';
    }
    
    $sql = "UPDATE $table SET " . implode(', ', $setParts);
    if (!empty($whereParts)) {
        $sql .= " WHERE " . implode(' AND ', $whereParts);
    }
    
    $stmt = $conn->prepare($sql);
    if (!$stmt) return false;
    
    if (!empty($params)) {
        $stmt->bind_param($typeString, ...$params);
    }
    
    $result = $stmt->execute();
    $affected = $stmt->affected_rows;
    $stmt->close();
    
    return $result ? $affected : false;
}

/**
 * Add activity log entry
 */
function addActivityLog($action, $detail = '') {
    dbInsert(
        "INSERT INTO activity_log (action, detail) VALUES (?, ?)",
        [$action, $detail],
        'ss'
    );
}

/**
 * Send JSON response
 */
function respond($data, $statusCode = 200) {
    // Clean any buffered output to prevent stray HTML/text from corrupting JSON
    while (ob_get_level()) {
        ob_end_clean();
    }
    http_response_code($statusCode);
    echo json_encode($data);
    exit();
}

function respondSuccess($data = [], $message = 'Success') {
    respond(['success' => true, 'message' => $message, 'data' => $data]);
}

function respondError($message, $statusCode = 400) {
    respond(['success' => false, 'message' => $message], $statusCode);
}

/**
 * Get JSON body from request
 */
function getJsonBody() {
    $input = file_get_contents('php://input');
    if (empty($input)) {
        return [];
    }
    $decoded = json_decode($input, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        return [];
    }
    return $decoded ?: [];
}

?>