<?php
require_once __DIR__ . '/db.php';
header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') respondError('Method not allowed', 405);
$vacancyId=(int)($_POST['vacancy_id'] ?? $_POST['vacancyId'] ?? 0);
$name=trim($_POST['applicant_name'] ?? $_POST['name'] ?? '');
$email=trim($_POST['applicant_email'] ?? $_POST['email'] ?? '');
$phone=trim($_POST['phone'] ?? '');
$cover=trim($_POST['cover_letter'] ?? $_POST['coverLetter'] ?? '');
if (!$vacancyId || $name==='' || !filter_var($email,FILTER_VALIDATE_EMAIL)) respondError('Vacancy, applicant name and a valid email are required',400);
try {
    $id=dbInsert("INSERT INTO job_applications (vacancy_id,applicant_name,applicant_email,applicant_phone,cover_letter,status) VALUES (?,?,?,?,?,'Pending')",
        [$vacancyId,$name,$email,$phone,$cover],'issss');
    if(!$id) respondError('Failed to save application');
    if(!empty($_FILES)){
        foreach($_FILES as $field=>$upload){
            $uploads=is_array($upload['name'])?$upload['name']:[$upload['name']];
            foreach($uploads as $i=>$origName){
                $err=is_array($upload['error'])?$upload['error'][$i]:$upload['error'];
                if($err!==UPLOAD_ERR_OK) continue;
                $tmp=is_array($upload['tmp_name'])?$upload['tmp_name'][$i]:$upload['tmp_name'];
                $size=is_array($upload['size'])?$upload['size'][$i]:$upload['size'];
                $type=is_array($upload['type'])?$upload['type'][$i]:$upload['type'];
                $ext=strtolower(pathinfo($origName,PATHINFO_EXTENSION));
                if(!in_array($ext,['pdf','doc','docx','jpg','jpeg','png'])) continue;
                if($size>10*1024*1024) continue;
                $dir=__DIR__.'/../uploads/applications/';
                if(!is_dir($dir)) mkdir($dir,0755,true);
                $safe='application_'.$id.'_'.bin2hex(random_bytes(5)).'.'.$ext;
                if(move_uploaded_file($tmp,$dir.$safe)){
                    $rel='uploads/applications/'.$safe;
                    $docType='other';
                    if(isset($_POST['document_types'])){
                        $dt=$_POST['document_types'];
                        if(is_array($dt) && isset($dt[$i])) $docType=trim($dt[$i]);
                    }
                    dbInsert("INSERT INTO application_documents (application_id,document_type,file_name,file_path,file_size) VALUES (?,?,?,?,?)",
                        [$id,$docType,$origName,$rel,$size],'isssi');
                }
            }
        }
    }
    addActivityLog('Job Application Submitted',"Application #$id submitted by $name");
    respondSuccess(['id'=>$id],'Application submitted successfully');
}catch(Throwable $e){respondError('Failed to submit application: '.$e->getMessage(),500);}
?>
