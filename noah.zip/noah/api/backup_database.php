<?php
/**
 * Database Backup Script - Noah Christian Academy
 * Creates a backup of the current database before any merge operations
 */

require_once __DIR__ . '/db.php';

header('Content-Type: application/json');

try {
    $conn = getDB();
    $dbName = DB_NAME;
    
    // Generate backup filename with timestamp
    $timestamp = date('Y-m-d_H-i-s');
    $backupDir = __DIR__ . '/../backups';
    
    // Create backups directory if it doesn't exist
    if (!is_dir($backupDir)) {
        mkdir($backupDir, 0755, true);
    }
    
    $backupFile = $backupDir . "/backup_{$dbName}_{$timestamp}.sql";
    
    // Get all tables
    $tables = dbFetchAll("SHOW TABLES");
    
    $backupContent = "-- Database Backup: {$dbName}\n";
    $backupContent .= "-- Generated: " . date('Y-m-d H:i:s') . "\n";
    $backupContent .= "-- --------------------------------------------------------\n\n";
    
    foreach ($tables as $tableRow) {
        $tableName = array_values($tableRow)[0];
        
        // Get CREATE TABLE statement
        $createTable = dbFetchOne("SHOW CREATE TABLE `{$tableName}`");
        $createStatement = $createTable['Create Table'];
        
        $backupContent .= "--\n-- Table structure for table `{$tableName}`\n--\n\n";
        $backupContent .= "DROP TABLE IF EXISTS `{$tableName}`;\n";
        $backupContent .= $createStatement . ";\n\n";
        
        // Get table data
        $data = dbFetchAll("SELECT * FROM `{$tableName}`");
        
        if (!empty($data)) {
            $backupContent .= "--\n-- Dumping data for table `{$tableName}`\n--\n\n";
            $backupContent .= "INSERT INTO `{$tableName}` (";
            
            // Get column names
            $columns = array_keys($data[0]);
            $backupContent .= "`" . implode("`, `", $columns) . "`) VALUES\n";
            
            $values = [];
            foreach ($data as $row) {
                $rowValues = [];
                foreach ($row as $value) {
                    if ($value === null) {
                        $rowValues[] = 'NULL';
                    } elseif (is_numeric($value)) {
                        $rowValues[] = $value;
                    } else {
                        $rowValues[] = "'" . $conn->real_escape_string($value) . "'";
                    }
                }
                $values[] = "(" . implode(", ", $rowValues) . ")";
            }
            
            $backupContent .= implode(",\n", $values) . ";\n\n";
        }
    }
    
    // Write backup to file
    file_put_contents($backupFile, $backupContent);
    
    respondSuccess([
        'backupFile' => $backupFile,
        'size' => filesize($backupFile),
        'tables' => count($tables)
    ], 'Database backup created successfully');
    
} catch (Exception $e) {
    respondError('Backup failed: ' . $e->getMessage(), 500);
}
