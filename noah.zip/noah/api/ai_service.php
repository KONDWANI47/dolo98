<?php
/**
 * AI Service Layer - Noah Christian Academy
 * Abstracted AI provider interface supporting OpenAI, with extensibility for other providers
 */

require_once __DIR__ . '/db.php';

class AIService {
    private $provider;
    private $apiKey;
    private $model;
    private $baseUrl;

    public function __construct() {
        $this->provider = getenv('AI_PROVIDER') ?: 'openai';
        $this->apiKey = getenv('AI_API_KEY') ?: '';
        $this->model = getenv('AI_MODEL') ?: 'gpt-3.5-turbo';

        if ($this->provider === 'openai') {
            $this->baseUrl = 'https://api.openai.com/v1';
        } elseif ($this->provider === 'gemini') {
            $this->baseUrl = 'https://generativelanguage.googleapis.com/v1beta';
        } elseif ($this->provider === 'nvidia') {
            $this->baseUrl = 'https://integrate.api.nvidia.com/v1';
        } elseif ($this->provider === 'groq') {
            $this->baseUrl = 'https://api.groq.com/openai/v1';
        }
    }

    /**
     * Generate AI response with context and tools
     */
    public function generateResponse($messages, $tools = [], $context = []) {
        if (empty($this->apiKey)) {
            return [
                'success' => false,
                'message' => 'AI API key not configured. Please set AI_API_KEY in .env file.'
            ];
        }

        $payload = [];
        $endpoint = '';

        if ($this->provider === 'gemini') {
            // Gemini API format
            $endpoint = '/models/' . $this->model . ':generateContent';
            $contents = [];
            foreach ($messages as $msg) {
                if ($msg['role'] === 'system') {
                    $payload['systemInstruction'] = [
                        'parts' => [['text' => $msg['content']]]
                    ];
                } else {
                    $contents[] = [
                        'role' => $msg['role'] === 'assistant' ? 'model' : 'user',
                        'parts' => [['text' => $msg['content']]]
                    ];
                }
            }
            $payload['contents'] = $contents;
            $payload['generationConfig'] = [
                'temperature' => 0.7,
                'maxOutputTokens' => 2000
            ];
        } else {
            // OpenAI API format
            $endpoint = '/chat/completions';
            $payload = [
                'model' => $this->model,
                'messages' => $messages,
                'temperature' => 0.7,
                'max_tokens' => 2000
            ];

            // Add tools if provided
            if (!empty($tools)) {
                $payload['tools'] = $tools;
                $payload['tool_choice'] = 'auto';
            }
        }

        $response = $this->makeRequest($endpoint, $payload);

        if (!$response['success']) {
            return $response;
        }

        $data = $response['data'];
        $choice = $data['choices'][0] ?? null;

        if (!$choice) {
            return [
                'success' => false,
                'message' => 'No response from AI provider'
            ];
        }

        $result = [
            'success' => true,
            'content' => $choice['message']['content'] ?? '',
            'tool_calls' => $choice['message']['tool_calls'] ?? null,
            'usage' => $data['usage'] ?? null
        ];

        return $result;
    }

    /**
     * Stream AI response for real-time output
     */
    public function streamResponse($messages, $tools = [], $context = []) {
        if (empty($this->apiKey)) {
            echo "data: " . json_encode([
                'error' => 'AI API key not configured. Please set AI_API_KEY in .env file.'
            ]) . "\n\n";
            ob_flush();
            flush();
            return;
        }

        $payload = [];
        $endpoint = '';

        if ($this->provider === 'gemini') {
            // Gemini API format
            $endpoint = '/models/' . $this->model . ':streamGenerateContent';
            $contents = [];
            foreach ($messages as $msg) {
                if ($msg['role'] === 'system') {
                    $payload['systemInstruction'] = [
                        'parts' => [['text' => $msg['content']]]
                    ];
                } else {
                    $contents[] = [
                        'role' => $msg['role'] === 'assistant' ? 'model' : 'user',
                        'parts' => [['text' => $msg['content']]]
                    ];
                }
            }
            $payload['contents'] = $contents;
            $payload['generationConfig'] = [
                'temperature' => 0.7,
                'maxOutputTokens' => 2000
            ];
        } else {
            // OpenAI API format
            $endpoint = '/chat/completions';
            $payload = [
                'model' => $this->model,
                'messages' => $messages,
                'temperature' => 0.7,
                'max_tokens' => 2000,
                'stream' => true
            ];

            if (!empty($tools)) {
                $payload['tools'] = $tools;
                $payload['tool_choice'] = 'auto';
            }
        }

        $this->streamRequest($endpoint, $payload);
    }

    /**
     * Generate structured output with JSON schema
     */
    public function generateStructuredOutput($messages, $schema) {
        if (empty($this->apiKey)) {
            return [
                'success' => false,
                'message' => 'AI API key not configured'
            ];
        }

        $payload = [
            'model' => $this->model,
            'messages' => $messages,
            'response_format' => [
                'type' => 'json_schema',
                'json_schema' => $schema
            ],
            'temperature' => 0.3
        ];

        $response = $this->makeRequest('/chat/completions', $payload);

        if (!$response['success']) {
            return $response;
        }

        $data = $response['data'];
        $content = $data['choices'][0]['message']['content'] ?? '';

        return [
            'success' => true,
            'content' => json_decode($content, true),
            'usage' => $data['usage'] ?? null
        ];
    }

    /**
     * Create embedding for semantic search
     */
    public function createEmbedding($text) {
        if (empty($this->apiKey)) {
            return [
                'success' => false,
                'message' => 'AI API key not configured'
            ];
        }

        $payload = [
            'model' => 'text-embedding-3-small',
            'input' => $text
        ];

        $response = $this->makeRequest('/embeddings', $payload);

        if (!$response['success']) {
            return $response;
        }

        $data = $response['data'];
        $embedding = $data['data'][0]['embedding'] ?? [];

        return [
            'success' => true,
            'embedding' => $embedding,
            'usage' => $data['usage'] ?? null
        ];
    }

    /**
     * Analyze document content
     */
    public function analyzeDocument($content, $query) {
        $messages = [
            [
                'role' => 'system',
                'content' => 'You are a document analysis assistant for a school management system. Analyze the provided document content and answer questions about it accurately.'
            ],
            [
                'role' => 'user',
                'content' => "Document content:\n\n{$content}\n\nQuestion: {$query}"
            ]
        ];

        return $this->generateResponse($messages);
    }

    /**
     * Make HTTP request to AI provider
     */
    private function makeRequest($endpoint, $payload) {
        $url = $this->baseUrl . $endpoint;

        error_log("AI Service Request: Provider={$this->provider}, URL={$url}");

        // Adjust for Gemini API
        if ($this->provider === 'gemini') {
            $url .= '?key=' . $this->apiKey;
            $headers = ['Content-Type: application/json'];
        } else {
            // OpenAI, NVIDIA, and Groq use Bearer token
            $headers = [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $this->apiKey
            ];
        }

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_TIMEOUT, 60);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // For localhost testing
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false); // For localhost testing

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            error_log("AI Service CURL Error: " . $error);
            return [
                'success' => false,
                'message' => 'CURL error: ' . $error
            ];
        }

        error_log("AI Service Response: HTTP {$httpCode}, Response: " . substr($response, 0, 500));

        if ($httpCode >= 400) {
            $errorData = json_decode($response, true);
            $errorMessage = $errorData['error']['message'] ?? $errorData['error'] ?? "HTTP {$httpCode} error";
            error_log("AI Service HTTP Error: {$httpCode} - {$errorMessage}");
            error_log("AI Service Full Response: " . $response);
            return [
                'success' => false,
                'message' => $errorMessage,
                'status' => $httpCode
            ];
        }

        $data = json_decode($response, true);

        // Convert Gemini response to OpenAI format for consistency
        if ($this->provider === 'gemini') {
            $data = $this->convertGeminiToOpenAI($data);
        }

        return [
            'success' => true,
            'data' => $data
        ];
    }

    /**
     * Stream HTTP request for real-time output
     */
    private function streamRequest($endpoint, $payload) {
        $url = $this->baseUrl . $endpoint;

        // Adjust for Gemini API
        if ($this->provider === 'gemini') {
            $url .= '?key=' . $this->apiKey;
            $headers = ['Content-Type: application/json'];
        } else {
            // OpenAI and NVIDIA use Bearer token
            $headers = [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $this->apiKey
            ];
        }

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_TIMEOUT, 120);
        curl_setopt($ch, CURLOPT_WRITEFUNCTION, function($ch, $data) {
            echo $data;
            ob_flush();
            flush();
            return strlen($data);
        });

        curl_exec($ch);
        curl_close($ch);
    }

    /**
     * Validate user permissions for AI request
     */
    public function validatePermissions($userRole, $requestedAction) {
        $rolePermissions = [
            'admin' => ['read', 'write', 'delete', 'admin_actions'],
            'teacher' => ['read', 'write', 'teacher_actions'],
            'parent' => ['read', 'parent_actions']
        ];

        $allowed = $rolePermissions[$userRole] ?? ['read'];

        // Check if action is allowed
        if (strpos($requestedAction, 'delete') !== false && !in_array('delete', $allowed)) {
            return false;
        }

        if (strpos($requestedAction, 'admin') !== false && !in_array('admin_actions', $allowed)) {
            return false;
        }

        return true;
    }

    /**
     * Convert Gemini API response to OpenAI format for consistency
     */
    private function convertGeminiToOpenAI($geminiData) {
        if (!isset($geminiData['candidates'][0]['content']['parts'][0]['text'])) {
            return $geminiData;
        }

        $text = $geminiData['candidates'][0]['content']['parts'][0]['text'];
        $usage = $geminiData['usageMetadata'] ?? null;

        return [
            'choices' => [
                [
                    'message' => [
                        'content' => $text,
                        'role' => 'assistant'
                    ],
                    'finish_reason' => 'stop'
                ]
            ],
            'usage' => $usage ? [
                'prompt_tokens' => $usage['promptTokenCount'] ?? 0,
                'completion_tokens' => $usage['candidatesTokenCount'] ?? 0,
                'total_tokens' => $usage['totalTokenCount'] ?? 0
            ] : null
        ];
    }
}
