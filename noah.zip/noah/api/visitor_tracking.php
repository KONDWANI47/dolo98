<?php
/**
 * Visitor Tracking API - Noah Christian Academy
 * Handles visitor location tracking and analytics
 */

require_once __DIR__ . '/db.php';

header('Content-Type: application/json');

$action = $_REQUEST['action'] ?? '';

switch ($action) {
    case 'page_view':
    case 'location_update':
    case 'activity_update':
    case 'heartbeat':
    case 'session_end':
        handleVisitorTracking($action);
        break;
    case 'get_visitors':
        getVisitorData();
        break;
    case 'get_visitor_details':
        getVisitorDetails();
        break;
    case 'get_analytics':
        getVisitorAnalytics();
        break;
    default:
        respondError('Invalid action');
        break;
}

/**
 * Handle visitor tracking requests
 */
function handleVisitorTracking($action) {
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!$data) {
        respondError('Invalid request data');
        return;
    }

    $sessionId = sanitizeInput($data['session_id'] ?? '');
    $ip = sanitizeInput($data['ip'] ?? '');
    $location = $data['location'] ?? [];
    $currentPage = sanitizeInput($data['current_page'] ?? '');
    $referrer = sanitizeInput($data['referrer'] ?? 'Direct');
    $userAgent = sanitizeInput($data['user_agent'] ?? '');
    $firstVisit = sanitizeInput($data['first_visit'] ?? date('Y-m-d H:i:s'));
    $lastActivity = sanitizeInput($data['last_activity'] ?? date('Y-m-d H:i:s'));
    $pageViews = intval($data['page_views'] ?? 0);
    $pages = $data['pages'] ?? [];

    // Validate required fields
    if (empty($sessionId)) {
        respondError('Session ID is required');
        return;
    }

    try {
        // Check if visitor exists
        $existingVisitor = dbFetchOne(
            "SELECT * FROM visitor_tracking WHERE session_id = ?",
            [$sessionId]
        );

        if ($existingVisitor) {
            // Update existing visitor
            $updateData = [
                'last_activity' => $lastActivity,
                'page_views' => $pageViews,
                'current_page' => $currentPage,
                'last_action' => $action
            ];

            // Update location if provided
            if (!empty($location)) {
                $updateData['ip_address'] = $ip;
                $updateData['city'] = sanitizeInput($location['city'] ?? '');
                $updateData['region'] = sanitizeInput($location['region'] ?? '');
                $updateData['country'] = sanitizeInput($location['country'] ?? '');
                $updateData['country_code'] = sanitizeInput($location['countryCode'] ?? '');
                $updateData['latitude'] = floatval($location['latitude'] ?? 0);
                $updateData['longitude'] = floatval($location['longitude'] ?? 0);
                $updateData['postal_code'] = sanitizeInput($location['postal'] ?? '');
                $updateData['isp'] = sanitizeInput($location['isp'] ?? '');
                $updateData['timezone'] = sanitizeInput($location['timezone'] ?? '');
            }

            // Update visitor record
            dbUpdate(
                'visitor_tracking',
                $updateData,
                ['session_id' => $sessionId]
            );

            // Add page view history
            if ($action === 'page_view' && !empty($pages)) {
                $latestPage = end($pages);
                if ($latestPage) {
                    dbInsertTable('visitor_page_history', [
                        'session_id' => $sessionId,
                        'url' => sanitizeInput($latestPage['url'] ?? ''),
                        'path' => sanitizeInput($latestPage['path'] ?? ''),
                        'title' => sanitizeInput($latestPage['title'] ?? ''),
                        'referrer' => sanitizeInput($latestPage['referrer'] ?? ''),
                        'visited_at' => sanitizeInput($latestPage['timestamp'] ?? date('Y-m-d H:i:s'))
                    ]);
                }
            }

        } else {
            // Insert new visitor
            $insertData = [
                'session_id' => $sessionId,
                'ip_address' => $ip,
                'city' => sanitizeInput($location['city'] ?? ''),
                'region' => sanitizeInput($location['region'] ?? ''),
                'country' => sanitizeInput($location['country'] ?? ''),
                'country_code' => sanitizeInput($location['countryCode'] ?? ''),
                'latitude' => floatval($location['latitude'] ?? 0),
                'longitude' => floatval($location['longitude'] ?? 0),
                'postal_code' => sanitizeInput($location['postal'] ?? ''),
                'isp' => sanitizeInput($location['isp'] ?? ''),
                'timezone' => sanitizeInput($location['timezone'] ?? ''),
                'user_agent' => $userAgent,
                'referrer' => $referrer,
                'current_page' => $currentPage,
                'first_visit' => $firstVisit,
                'last_activity' => $lastActivity,
                'page_views' => $pageViews,
                'last_action' => $action
            ];

            dbInsertTable('visitor_tracking', $insertData);

            // Add initial page view
            if (!empty($pages)) {
                $firstPage = $pages[0];
                if ($firstPage) {
                    dbInsertTable('visitor_page_history', [
                        'session_id' => $sessionId,
                        'url' => sanitizeInput($firstPage['url'] ?? ''),
                        'path' => sanitizeInput($firstPage['path'] ?? ''),
                        'title' => sanitizeInput($firstPage['title'] ?? ''),
                        'referrer' => sanitizeInput($firstPage['referrer'] ?? ''),
                        'visited_at' => sanitizeInput($firstPage['timestamp'] ?? date('Y-m-d H:i:s'))
                    ]);
                }
            }
        }

        respondSuccess(['message' => 'Visitor data recorded successfully']);

    } catch (Exception $e) {
        respondError('Failed to record visitor data: ' . $e->getMessage());
    }
}

/**
 * Get visitor data for admin dashboard
 */
function getVisitorData() {
    $limit = intval($_REQUEST['limit'] ?? 100);
    $offset = intval($_REQUEST['offset'] ?? 0);
    $country = sanitizeInput($_REQUEST['country'] ?? '');
    $startDate = sanitizeInput($_REQUEST['start_date'] ?? '');
    $endDate = sanitizeInput($_REQUEST['end_date'] ?? '');

    try {
        $whereConditions = ['1=1'];
        $params = [];

        if (!empty($country)) {
            $whereConditions[] = 'country = ?';
            $params[] = $country;
        }

        if (!empty($startDate)) {
            $whereConditions[] = 'first_visit >= ?';
            $params[] = $startDate;
        }

        if (!empty($endDate)) {
            $whereConditions[] = 'first_visit <= ?';
            $params[] = $endDate;
        }

        $whereClause = implode(' AND ', $whereConditions);

        $visitors = dbFetchAll(
            "SELECT * FROM visitor_tracking 
             WHERE $whereClause 
             ORDER BY last_activity DESC 
             LIMIT $limit OFFSET $offset",
            $params
        );

        // Get total count
        $total = dbFetchOne(
            "SELECT COUNT(*) as count FROM visitor_tracking WHERE $whereClause",
            $params
        )['count'] ?? 0;

        respondSuccess([
            'data' => $visitors,
            'total' => $total,
            'limit' => $limit,
            'offset' => $offset
        ]);

    } catch (Exception $e) {
        respondError('Failed to fetch visitor data: ' . $e->getMessage());
    }
}

/**
 * Get detailed visitor information
 */
function getVisitorDetails() {
    $sessionId = sanitizeInput($_REQUEST['session_id'] ?? '');

    if (empty($sessionId)) {
        respondError('Session ID is required');
        return;
    }

    try {
        // Get visitor basic info
        $visitor = dbFetchOne(
            "SELECT * FROM visitor_tracking WHERE session_id = ?",
            [$sessionId]
        );

        if (!$visitor) {
            respondError('Visitor not found');
            return;
        }

        // Get page history
        $pageHistory = dbFetchAll(
            "SELECT * FROM visitor_page_history 
             WHERE session_id = ? 
             ORDER BY visited_at DESC 
             LIMIT 50",
            [$sessionId]
        );

        respondSuccess([
            'visitor' => $visitor,
            'page_history' => $pageHistory
        ]);

    } catch (Exception $e) {
        respondError('Failed to fetch visitor details: ' . $e->getMessage());
    }
}

/**
 * Get visitor analytics data
 */
function getVisitorAnalytics() {
    try {
        // Get basic statistics
        $totalVisitors = dbFetchOne("SELECT COUNT(*) as count FROM visitor_tracking")['count'] ?? 0;
        $uniqueCountries = dbFetchOne("SELECT COUNT(DISTINCT country) as count FROM visitor_tracking")['count'] ?? 0;
        $uniqueCities = dbFetchOne("SELECT COUNT(DISTINCT city) as count FROM visitor_tracking")['count'] ?? 0;
        
        // Recent activity (last 24 hours)
        $recentActivity = dbFetchOne(
            "SELECT COUNT(*) as count FROM visitor_tracking 
             WHERE last_activity >= DATE_SUB(NOW(), INTERVAL 24 HOUR)"
        )['count'] ?? 0;

        // Top countries
        $topCountries = dbFetchAll(
            "SELECT country, COUNT(*) as visitor_count 
             FROM visitor_tracking 
             WHERE country IS NOT NULL AND country != ''
             GROUP BY country 
             ORDER BY visitor_count DESC 
             LIMIT 10"
        );

        // Top cities
        $topCities = dbFetchAll(
            "SELECT city, country, COUNT(*) as visitor_count 
             FROM visitor_tracking 
             WHERE city IS NOT NULL AND city != ''
             GROUP BY city, country 
             ORDER BY visitor_count DESC 
             LIMIT 10"
        );

        // Visitor trends (last 7 days)
        $visitorTrends = dbFetchAll(
            "SELECT DATE(first_visit) as visit_date, COUNT(*) as visitor_count 
             FROM visitor_tracking 
             WHERE first_visit >= DATE_SUB(NOW(), INTERVAL 7 DAY)
             GROUP BY DATE(first_visit) 
             ORDER BY visit_date ASC"
        );

        // Current online visitors (last 5 minutes)
        $onlineVisitors = dbFetchOne(
            "SELECT COUNT(*) as count FROM visitor_tracking 
             WHERE last_activity >= DATE_SUB(NOW(), INTERVAL 5 MINUTE)"
        )['count'] ?? 0;

        respondSuccess([
            'statistics' => [
                'total_visitors' => $totalVisitors,
                'unique_countries' => $uniqueCountries,
                'unique_cities' => $uniqueCities,
                'recent_activity' => $recentActivity,
                'online_visitors' => $onlineVisitors
            ],
            'top_countries' => $topCountries,
            'top_cities' => $topCities,
            'visitor_trends' => $visitorTrends
        ]);

    } catch (Exception $e) {
        respondError('Failed to fetch visitor analytics: ' . $e->getMessage());
    }
}

/**
 * Sanitize input data
 */
function sanitizeInput($input) {
    if (is_array($input)) {
        return array_map('sanitizeInput', $input);
    }
    return htmlspecialchars(strip_tags(trim($input)), ENT_QUOTES, 'UTF-8');
}