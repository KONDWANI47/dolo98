<?php
/**
 * File Upload Handler for Calendar Events
 * Handles PDF and Word document uploads
 */

require_once __DIR__ . '/db.php';

// Allowed file types
$allowedTypes = [
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
];

// Allowed extensions
$allowedExtensions = ['pdf', 'doc', 'docx'];

// Max file size (10MB)
$maxSize = 10 * 1024 * 1024;

// Upload directory
$uploadDir = __DIR__ . '/../uploads/calendar/';

// Create directory if it doesn't exist
if (!file_exists($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

try {
    if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
        throw new Exception('No file uploaded or upload error');
    }

    $file = $_FILES['file'];
    
    // Validate file size
    if ($file['size'] > $maxSize) {
        throw new Exception('File size exceeds 10MB limit');
    }

    // Validate file type
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mimeType = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    if (!in_array($mimeType, $allowedTypes)) {
        throw new Exception('Invalid file type. Only PDF and Word documents are allowed');
    }

    // Validate file extension
    $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($extension, $allowedExtensions)) {
        throw new Exception('Invalid file extension. Only .pdf, .doc, and .docx are allowed');
    }

    // Generate unique filename
    $basename = pathinfo($file['name'], PATHINFO_FILENAME);
    $sanitizedBasename = preg_replace('/[^a-zA-Z0-9_-]/', '_', $basename);
    $uniqueFilename = $sanitizedBasename . '_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $extension;
    $destination = $uploadDir . $uniqueFilename;

    // Move uploaded file
    if (!move_uploaded_file($file['tmp_name'], $destination)) {
        throw new Exception('Failed to move uploaded file');
    }

    // Get event data if provided
    $eventData = [];
    if (isset($_POST['data'])) {
        $eventData = json_decode($_POST['data'], true);
    }

    // Add file info to event data
    $eventData['attachmentPath'] = '../uploads/calendar/' . $uniqueFilename;
    $eventData['attachmentName'] = $file['name'];

    // Save the calendar event with attachment
    $conn = getDB();
    $title = trim($eventData['title'] ?? '');
    $description = trim($eventData['description'] ?? '');
    $eventType = trim($eventData['eventType'] ?? 'general');
    $eventDate = $eventData['eventDate'] ?? date('Y-m-d');
    $eventTime = $eventData['eventTime'] ?? null;
    $endTime = $eventData['endTime'] ?? null;
    $location = trim($eventData['location'] ?? '');
    $createdBy = trim($eventData['createdBy'] ?? '');
    $createdById = (int)($eventData['createdById'] ?? 0);
    $targetAudience = trim($eventData['targetAudience'] ?? 'all');
    $className = trim($eventData['className'] ?? '');
    $status = trim($eventData['status'] ?? 'Active');
    $editId = (int)($eventData['id'] ?? 0);

    if (empty($title) || empty($eventDate)) {
        throw new Exception('Title and Event Date required');
    }

    if ($editId > 0) {
        // Update existing event
        $query = "UPDATE calendar_events SET title = ?, description = ?, event_type = ?, event_date = ?, event_time = ?, end_time = ?, location = ?, target_audience = ?, class_name = ?, attachment_path = ?, attachment_name = ?, status = ? WHERE id = ?";
        $params = [$title, $description, $eventType, $eventDate, $eventTime, $endTime, $location, $targetAudience, $className, $eventData['attachmentPath'], $eventData['attachmentName'], $status, $editId];
        $types = 'sssssssssssi';
        $result = $conn->prepare($query);
        $result->bind_param($types, ...$params);
        $result->execute();
        
        if ($result->affected_rows > 0) {
            addActivityLog('Calendar Event Updated', "Event '$title' updated with attachment");
            respond(['success' => true, 'message' => 'Calendar event updated successfully with attachment', 'id' => $editId]);
        } else {
            throw new Exception('Failed to update calendar event');
        }
    } else {
        // Create new event
        $query = "INSERT INTO calendar_events (title, description, event_type, event_date, event_time, end_time, location, created_by, created_by_id, target_audience, class_name, attachment_path, attachment_name, status)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $params = [$title, $description, $eventType, $eventDate, $eventTime, $endTime, $location, $createdBy, $createdById, $targetAudience, $className, $eventData['attachmentPath'], $eventData['attachmentName'], $status];
        $types = 'sssssssiissss';
        $result = $conn->prepare($query);
        $result->bind_param($types, ...$params);
        $result->execute();
        
        $newId = $conn->insert_id;
        
        if ($newId) {
            addActivityLog('Calendar Event Created', "Event '$title' created with attachment");
            respond(['success' => true, 'message' => 'Calendar event created successfully with attachment', 'id' => $newId]);
        } else {
            throw new Exception('Failed to create calendar event');
        }
    }

} catch (Exception $e) {
    respondError($e->getMessage(), 500);
}
