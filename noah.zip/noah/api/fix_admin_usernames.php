<?php
/**
 * Fix Admin Usernames - Ensure all admin accounts have a username
 * Run this file once to populate missing usernames
 */

require_once __DIR__ . '/db.php';

header('Content-Type: text/html; charset=utf-8');

echo "<h2>Fixing Admin Usernames</h2>";

try {
    $conn = getDB();
    
    // Check for admins without username
    $result = $conn->query("SELECT id, first_name, last_name, email FROM admins WHERE username IS NULL OR username = '' OR username = 'undefined'");
    
    if ($result && $result->num_rows > 0) {
        echo "<p>Found {$result->num_rows} admin(s) without username. Fixing...</p>";
        
        while ($row = $result->fetch_assoc()) {
            $id = $row['id'];
            $firstName = $row['first_name'] ?? '';
            $lastName = $row['last_name'] ?? '';
            $email = $row['email'] ?? '';
            
            // Generate username from email or name
            if ($email && strpos($email, '@') !== false) {
                $baseUsername = strtolower(preg_replace('/[^a-z0-9]/i', '.', strstr($email, '@', true)));
            } else {
                $baseUsername = strtolower(preg_replace('/[^a-z0-9]/i', '', $firstName . $lastName));
            }
            
            $baseUsername = trim($baseUsername, '.');
            if (empty($baseUsername)) {
                $baseUsername = 'admin_' . $id;
            }
            
            // Ensure uniqueness
            $username = $baseUsername;
            $counter = 1;
            while ($conn->query("SELECT id FROM admins WHERE username = '$username' AND id != $id")->num_rows > 0) {
                $username = $baseUsername . '.' . $counter++;
            }
            
            // Update the record
            $stmt = $conn->prepare("UPDATE admins SET username = ? WHERE id = ?");
            $stmt->bind_param('si', $username, $id);
            $stmt->execute();
            
            echo "<p>✓ Updated admin #$id: username = '$username'</p>";
        }
        
        echo "<p style='color: green; font-weight: bold;'>✓ All admin usernames have been fixed!</p>";
    } else {
        echo "<p style='color: green;'>✓ All admin accounts already have usernames.</p>";
    }
    
    // Display current admin accounts
    echo "<h3>Current Admin Accounts:</h3>";
    $admins = $conn->query("SELECT id, first_name, last_name, username, email, status FROM admins ORDER BY id");
    
    if ($admins && $admins->num_rows > 0) {
        echo "<table border='1' cellpadding='10' style='border-collapse: collapse;'>";
        echo "<tr><th>ID</th><th>Name</th><th>Username</th><th>Email</th><th>Status</th></tr>";
        
        while ($admin = $admins->fetch_assoc()) {
            echo "<tr>";
            echo "<td>{$admin['id']}</td>";
            echo "<td>{$admin['first_name']} {$admin['last_name']}</td>";
            echo "<td><strong>{$admin['username']}</strong></td>";
            echo "<td>{$admin['email']}</td>";
            echo "<td>{$admin['status']}</td>";
            echo "</tr>";
        }
        
        echo "</table>";
    } else {
        echo "<p>No admin accounts found.</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>Error: " . htmlspecialchars($e->getMessage()) . "</p>";
}

echo "<p><a href='../admin/admin.html'>Return to Admin Dashboard</a></p>";
