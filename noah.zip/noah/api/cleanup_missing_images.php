<?php
/**
 * Cleanup Missing Gallery Images
 * Removes database records for gallery images that don't exist in the uploads directory
 */

require_once __DIR__ . '/db.php';

echo "=== Cleaning up missing gallery images ===\n\n";

$conn = getDB();
$totalDeleted = 0;

// Check gallery table
$tableCheck = $conn->query("SHOW TABLES LIKE 'gallery'");
if ($tableCheck->num_rows > 0) {
    echo "Checking 'gallery' table...\n";
    
    $result = $conn->query("SELECT id, title, image_url FROM gallery");
    $deleted = 0;
    
    while ($row = $result->fetch_assoc()) {
        $imagePath = __DIR__ . '/../' . $row['image_url'];
        if (!file_exists($imagePath)) {
            echo "  Deleting missing image record ID {$row['id']}: {$row['image_url']}\n";
            $conn->query("DELETE FROM gallery WHERE id = {$row['id']}");
            $deleted++;
        }
    }
    
    echo "  Cleaned up $deleted missing image records from gallery table.\n";
    $totalDeleted += $deleted;
}

// Check students table for gallery_image column
$colCheck = $conn->query("SHOW COLUMNS FROM students LIKE 'gallery_image'");
if ($colCheck->num_rows > 0) {
    echo "\nChecking 'students' table for gallery_image column...\n";
    
    $result = $conn->query("SELECT id, first_name, last_name, gallery_image FROM students WHERE gallery_image IS NOT NULL AND gallery_image != ''");
    $deleted = 0;
    
    while ($row = $result->fetch_assoc()) {
        $imagePath = __DIR__ . '/../' . $row['gallery_image'];
        if (!file_exists($imagePath)) {
            echo "  Clearing missing image for student {$row['first_name']} {$row['last_name']}: {$row['gallery_image']}\n";
            $conn->query("UPDATE students SET gallery_image = NULL WHERE id = {$row['id']}");
            $deleted++;
        }
    }
    
    echo "  Cleaned up $deleted missing image records from students table.\n";
    $totalDeleted += $deleted;
}

// Check for any other tables that might reference gallery images
$allTables = $conn->query("SHOW TABLES");
while ($tableRow = $allTables->fetch_array()) {
    $tableName = $tableRow[0];
    
    // Skip tables we already checked
    if ($tableName === 'gallery' || $tableName === 'students') continue;
    
    // Check for image_url or gallery_image columns
    $colCheck = $conn->query("SHOW COLUMNS FROM $tableName LIKE 'image_url'");
    if ($colCheck->num_rows > 0) {
        echo "\nChecking '$tableName' table for image_url column...\n";
        
        $result = $conn->query("SELECT id, image_url FROM $tableName WHERE image_url IS NOT NULL AND image_url != ''");
        $deleted = 0;
        
        while ($row = $result->fetch_assoc()) {
            $imagePath = __DIR__ . '/../' . $row['image_url'];
            if (!file_exists($imagePath)) {
                echo "  Clearing missing image in $tableName ID {$row['id']}: {$row['image_url']}\n";
                $conn->query("UPDATE $tableName SET image_url = NULL WHERE id = {$row['id']}");
                $deleted++;
            }
        }
        
        echo "  Cleaned up $deleted missing image records from $tableName table.\n";
        $totalDeleted += $deleted;
    }
}

echo "\n=== Cleanup complete ===\n";
echo "Total records cleaned: $totalDeleted\n";
