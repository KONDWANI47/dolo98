-- Visitor Tracking Tables for Noah Christian Academy
-- Run this SQL to create the necessary tables for visitor location tracking

-- Main visitor tracking table
CREATE TABLE IF NOT EXISTS `visitor_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_id` varchar(100) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `region` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `country_code` varchar(10) DEFAULT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `postal_code` varchar(20) DEFAULT NULL,
  `isp` varchar(255) DEFAULT NULL,
  `timezone` varchar(50) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `referrer` varchar(500) DEFAULT NULL,
  `current_page` varchar(500) DEFAULT NULL,
  `first_visit` datetime NOT NULL,
  `last_activity` datetime NOT NULL,
  `page_views` int(11) DEFAULT 0,
  `last_action` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `session_id` (`session_id`),
  KEY `ip_address` (`ip_address`),
  KEY `country` (`country`),
  KEY `city` (`city`),
  KEY `last_activity` (`last_activity`),
  KEY `first_visit` (`first_visit`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Visitor page history table
CREATE TABLE IF NOT EXISTS `visitor_page_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_id` varchar(100) NOT NULL,
  `url` varchar(500) DEFAULT NULL,
  `path` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `referrer` varchar(500) DEFAULT NULL,
  `visited_at` datetime NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session_id` (`session_id`),
  KEY `visited_at` (`visited_at`),
  FOREIGN KEY (`session_id`) REFERENCES `visitor_tracking` (`session_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Index for better performance on location queries
CREATE INDEX IF NOT EXISTS `idx_location_coords` ON `visitor_tracking` (`latitude`, `longitude`);
CREATE INDEX IF NOT EXISTS `idx_country_city` ON `visitor_tracking` (`country`, `city`);

-- Create a view for quick analytics
CREATE OR REPLACE VIEW `visitor_analytics_view` AS
SELECT 
    DATE(first_visit) as visit_date,
    COUNT(*) as total_visitors,
    COUNT(DISTINCT ip_address) as unique_ips,
    COUNT(DISTINCT country) as unique_countries,
    COUNT(DISTINCT city) as unique_cities,
    SUM(page_views) as total_page_views
FROM visitor_tracking
GROUP BY DATE(first_visit)
ORDER BY visit_date DESC;