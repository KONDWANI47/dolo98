<?php
require_once __DIR__ . '/db.php';
header('Content-Type: application/json');
try {
    $rows = dbFetchAll("SELECT *, created_at AS applied_at FROM job_applications ORDER BY created_at DESC");
    respondSuccess($rows);
} catch (Throwable $e) {
    respondError('Failed to load job applications: ' . $e->getMessage(), 500);
}
