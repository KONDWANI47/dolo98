<?php
/**
 * Setup script to create complaints table for parent-teacher complaints
 */

require_once __DIR__ . '/db.php';

echo "Setting up complaints table...\n";

// SQL to create the complaints table
$sql = "
-- Create complaints table
CREATE TABLE IF NOT EXISTS complaints (
    id INT AUTO_INCREMENT PRIMARY KEY,
    parent_id INT NOT NULL,
    parent_name VARCHAR(255) NOT NULL,
    class_name VARCHAR(100) NOT NULL,
    complaint_text TEXT NOT NULL,
    status VARCHAR(20) DEFAULT 'pending',
    teacher_response TEXT,
    responded_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_parent (parent_id),
    INDEX idx_class (class_name),
    INDEX idx_status (status),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
";

// Execute the SQL
$conn = getDB();

// Split by semicolon to get individual statements
$statements = explode(';', $sql);

foreach ($statements as $statement) {
    $statement = trim($statement);
    if (!empty($statement)) {
        if ($conn->query($statement)) {
            echo "✓ Successfully executed: " . substr($statement, 0, 50) . "...\n";
        } else {
            echo "✗ Error executing: " . $conn->error . "\n";
        }
    }
}

echo "\nComplaints table setup complete!\n";
?>
