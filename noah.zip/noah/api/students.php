<?php
/**
 * Students API - Noah Christian Academy
 *
 * MySQL-based student management.
 * Students are LINKED TO registrations (the central point) via
 * registration_id. When a registration is approved, a student record
 * is auto-created with the registration_id set.
 *
 * Endpoints:
 *   GET    api/students.php                      → list all students
 *   GET    api/students.php?id=1                 → get single student
 *   GET    api/students.php?registrationId=1     → students for a registration
 *   POST   api/students.php                      → create new student
 *   PUT    api/students.php?id=1                 → update student
 *   DELETE api/students.php?id=1                 → delete student
 */

require_once __DIR__ . '/db.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$method = $_SERVER['REQUEST_METHOD'];
$id = $_REQUEST['id'] ?? null;
$registrationId = $_REQUEST['registrationId'] ?? null;

// ============================================================
// GET — List, filter, single item
// ============================================================
if ($method === 'GET') {
    // Single student
    if ($id) {
        $student = dbFetchOne("SELECT * FROM students WHERE id = ?", [$id], 'i');
        if (!$student) {
            respondError('Student not found', 404);
        }
        respondSuccess(formatStudent($student));
    }

    // Build query with filters
    $where = [];
    $params = [];
    $types = '';

    // Filter by registration_id (central point link)
    if ($registrationId) {
        $where[] = "registration_id = ?";
        $params[] = (int)$registrationId;
        $types .= 'i';
    }

    // Filter by grade
    $grade = $_REQUEST['grade'] ?? null;
    if ($grade) {
        $where[] = "grade = ?";
        $params[] = $grade;
        $types .= 's';
    }

    // Search
    $search = $_REQUEST['search'] ?? null;
    if ($search) {
        $where[] = "(first_name LIKE ? OR last_name LIKE ? OR parent_name LIKE ?)";
        $searchParam = '%' . $search . '%';
        $params[] = $searchParam;
        $params[] = $searchParam;
        $params[] = $searchParam;
        $types .= 'sss';
    }

    $whereClause = empty($where) ? '' : 'WHERE ' . implode(' AND ', $where);
    $sql = "SELECT * FROM students $whereClause ORDER BY created_at DESC";

    $rows = dbFetchAll($sql, $params, $types);
    $students = array_map('formatStudent', $rows);

    respondSuccess(['items' => $students, 'total' => count($students)]);
}

// ============================================================
// POST — Create new student (linked to registration)
// ============================================================
if ($method === 'POST') {
    $body = getJsonBody();
    if (!$body) {
        respondError('Invalid request body');
    }

    $firstName = trim($body['firstName'] ?? $body['first_name'] ?? '');
    $lastName = trim($body['lastName'] ?? $body['last_name'] ?? '');
    $grade = $body['grade'] ?? '';
    $parentName = trim($body['parentName'] ?? $body['parent_name'] ?? $body['parent'] ?? '');
    $phone = $body['phone'] ?? '';
    $email = $body['email'] ?? '';
    $address = $body['address'] ?? '';
    $dob = $body['dateOfBirth'] ?? $body['dob'] ?? null;
    $registrationId = $body['registrationId'] ?? $body['registration_id'] ?? null;
    $status = $body['status'] ?? 'Active';
    $feesStatus = $body['feesStatus'] ?? 'Pending';

    if (empty($firstName)) respondError('First name is required');
    if (empty($lastName)) respondError('Last name is required');

    $id = dbInsert(
        "INSERT INTO students (first_name, last_name, grade, parent_name, phone, email, address, dob, enrollment_date, status, fees_status, registration_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        [
            $firstName, $lastName, $grade, $parentName, $phone, $email, $address,
            $dob, date('Y-m-d'), $status, $feesStatus, $registrationId ? (int)$registrationId : null
        ],
        'sssssssssiss'
    );

    if ($id) {
        addActivityLog('Student Created', "$firstName $lastName (registration_id: " . ($registrationId ?? 'none') . ")");
        respondSuccess(['id' => $id], 'Student created successfully');
    }
    respondError('Failed to create student');
}

// ============================================================
// PUT — Update student
// ============================================================
if ($method === 'PUT') {
    if (!$id) {
        respondError('ID is required for update');
    }

    $body = getJsonBody();
    if (!$body) {
        respondError('Invalid request body');
    }

    $updatable = [
        'firstName' => 'first_name', 'lastName' => 'last_name', 'grade' => 'grade',
        'parentName' => 'parent_name', 'phone' => 'phone', 'email' => 'email',
        'address' => 'address', 'dateOfBirth' => 'dob', 'enrollmentDate' => 'enrollment_date',
        'status' => 'status', 'feesStatus' => 'fees_status', 'registrationId' => 'registration_id'
    ];

    $fields = [];
    $params = [];
    $types = '';
    foreach ($updatable as $camel => $snake) {
        if (isset($body[$camel])) {
            $fields[] = "$snake = ?";
            $params[] = $body[$camel];
            $types .= 's';
        }
    }

    if (empty($fields)) {
        respondError('No fields to update');
    }

    $params[] = $id;
    $types .= 'i';

    $affected = dbExecute(
        "UPDATE students SET " . implode(', ', $fields) . " WHERE id = ?",
        $params,
        $types
    );

    if ($affected === false) {
        respondError('Failed to update student');
    }

    addActivityLog('Student Updated', "Student #$id updated");

    // Fetch and return updated student
    $student = dbFetchOne("SELECT * FROM students WHERE id = ?", [$id], 'i');
    respondSuccess(formatStudent($student), 'Student updated successfully');
}

// ============================================================
// DELETE — Remove student
// ============================================================
if ($method === 'DELETE') {
    if (!$id) {
        respondError('ID is required for deletion');
    }

    $found = dbFetchOne("SELECT id FROM students WHERE id = ?", [$id], 'i');
    if (!$found) {
        respondError('Student not found', 404);
    }

    $affected = dbExecute("DELETE FROM students WHERE id = ?", [$id], 'i');
    if ($affected > 0) {
        addActivityLog('Student Deleted', "Student #$id deleted");
        respondSuccess([], 'Student deleted successfully');
    }
    respondError('Failed to delete student');
}

respondError('Method not allowed', 405);

// ============================================================
// Helper: Format student row for API response
// ============================================================
function formatStudent($s) {
    return [
        'id' => (int)$s['id'],
        'registrationId' => $s['registration_id'] ?? null,
        'firstName' => $s['first_name'] ?? '',
        'lastName' => $s['last_name'] ?? '',
        'grade' => $s['grade'] ?? '',
        'parentName' => $s['parent_name'] ?? '',
        'phone' => $s['phone'] ?? '',
        'email' => $s['email'] ?? '',
        'address' => $s['address'] ?? '',
        'dateOfBirth' => $s['dob'] ?? null,
        'enrollmentDate' => $s['enrollment_date'] ?? null,
        'status' => $s['status'] ?? 'Active',
        'feesStatus' => $s['fees_status'] ?? 'Pending',
        'createdAt' => $s['created_at'] ?? null,
        'updatedAt' => $s['updated_at'] ?? null
    ];
}
