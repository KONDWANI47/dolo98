<?php
/**
 * Registration API - Noah Christian Academy
 *
 * MySQL-based registration system.
 * The registration table is the CENTRAL POINT — all other entities
 * (students, payments, attendance) link back to registrations via
 * registration_id.
 *
 * Endpoints:
 *   GET    api/registration.php                      → list all registrations
 *   GET    api/registration.php?id=1                 → get single registration
 *   GET    api/registration.php?status=Pending       → filter by status
 *   GET    api/registration.php?action=stats         → registration statistics
 *   POST   api/registration.php                      → create new registration
 *   PUT    api/registration.php?id=1                 → update registration
 *   DELETE api/registration.php?id=1                 → delete registration
 */

require_once __DIR__ . '/db.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: ' . 'GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, Content-Disposition');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$method = $_SERVER['REQUEST_METHOD'];
$id = $_REQUEST['id'] ?? null;
$action = $_REQUEST['action'] ?? '';
$status = $_REQUEST['status'] ?? null;

// ============================================================
// GET — List, filter, search, single item, stats
// ============================================================
if ($method === 'GET') {
    // Stats endpoint
    if ($action === 'stats') {
        $stats = [
            'total' => 0,
            'pending' => 0,
            'approved' => 0,
            'rejected' => 0
        ];
        $rows = dbFetchAll("SELECT status, COUNT(*) as cnt FROM registrations GROUP BY status");
        foreach ($rows as $row) {
            $stats['total'] += (int)$row['cnt'];
            if ($row['status'] === 'Pending') $stats['pending'] = (int)$row['cnt'];
            elseif ($row['status'] === 'Approved') $stats['approved'] = (int)$row['cnt'];
            elseif ($row['status'] === 'Rejected') $stats['rejected'] = (int)$row['cnt'];
        }
        respondSuccess($stats);
    }

    // Single registration
    if ($id) {
        $reg = dbFetchOne("SELECT * FROM registrations WHERE id = ?", [$id], 'i');
        if (!$reg) {
            respondError('Registration not found', 404);
        }
        respondSuccess(formatRegistration($reg));
    }

    // Build query with filters
    $where = [];
    $params = [];
    $types = '';

    if ($status) {
        $where[] = "status = ?";
        $params[] = $status;
        $types .= 's';
    }

    // Search by keyword (student name, parent name, email, phone)
    $search = $_REQUEST['search'] ?? null;
    if ($search) {
        $where[] = "(student_name LIKE ? OR parent_name LIKE ? OR email LIKE ? OR phone LIKE ?)";
        $searchParam = '%' . $search . '%';
        $params[] = $searchParam;
        $params[] = $searchParam;
        $params[] = $searchParam;
        $params[] = $searchParam;
        $types .= 'ssss';
    }

    $whereClause = empty($where) ? '' : 'WHERE ' . implode(' AND ', $where);
    $sql = "SELECT * FROM registrations $whereClause ORDER BY created_at DESC";

    $rows = dbFetchAll($sql, $params, $types);
    $registrations = array_map('formatRegistration', $rows);

    respondSuccess(['items' => $registrations, 'total' => count($registrations)]);
}

// ============================================================
// POST — Create new registration
// ============================================================
if ($method === 'POST') {
    // Handle multipart/form-data for file uploads
    if (isset($_FILES['idPhoto']) && $_FILES['idPhoto']['error'] === UPLOAD_ERR_OK) {
        // Handle file upload
        $uploadDir = __DIR__ . '/../uploads/registrations/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        
        $file = $_FILES['idPhoto'];
        $fileName = time() . '_' . basename($file['name']);
        $targetPath = $uploadDir . $fileName;
        
        // Validate file type
        $allowedTypes = ['image/jpeg', 'image/png', 'image/jpg', 'image/gif'];
        if (!in_array($file['type'], $allowedTypes)) {
            respondError('Invalid file type. Only JPEG, PNG, and GIF images are allowed.');
        }
        
        // Validate file size (max 5MB)
        if ($file['size'] > 5 * 1024 * 1024) {
            respondError('File size too large. Maximum size is 5MB.');
        }
        
        if (move_uploaded_file($file['tmp_name'], $targetPath)) {
            $idPhoto = 'uploads/registrations/' . $fileName;
        } else {
            respondError('Failed to upload file');
        }
    } else {
        $idPhoto = null;
    }
    
    // Get form data
    $studentName = trim($_POST['studentName'] ?? $_POST['student_name'] ?? '');
    $grade = $_POST['grade'] ?? '';
    $parentName = trim($_POST['parentName'] ?? $_POST['parent_name'] ?? '');
    $phone = $_POST['phone'] ?? '';
    $email = $_POST['email'] ?? '';
    $address = $_POST['address'] ?? $_POST['origin'] ?? '';
    $dob = $_POST['dateOfBirth'] ?? $_POST['dob'] ?? null;
    $notes = $_POST['notes'] ?? $_POST['message'] ?? '';

    // Map grade values from form to database values
    $gradeMap = [
        'daycare' => 'Daycare',
        'grade1' => 'Standard 1', 'grade2' => 'Standard 2', 'grade3' => 'Standard 3',
        'grade4' => 'Standard 4', 'grade5' => 'Standard 5', 'grade6' => 'Standard 6',
        'grade7' => 'Standard 7', 'grade8' => 'Standard 8',
        'grade9' => 'Form 1', 'grade10' => 'Form 2', 'grade11' => 'Form 3', 'grade12' => 'Form 4'
    ];
    if (isset($gradeMap[$grade])) {
        $grade = $gradeMap[$grade];
    }

    // Validation
    if (empty($studentName)) respondError('Student name is required');
    if (empty($parentName)) respondError('Parent name is required');
    if (empty($phone) && empty($email)) respondError('Phone or email is required');

    $id = dbInsert(
        "INSERT INTO registrations (student_name, grade, parent_name, phone, email, address, dob, notes, id_photo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
        [$studentName, $grade, $parentName, $phone, $email, $address, $dob, $notes, $idPhoto],
        'sssssssss'
    );

    if ($id) {
        addActivityLog('New Registration', "$studentName registered for $grade");
        respondSuccess(['id' => $id], 'Registration submitted successfully! We will contact you soon.');
    }
    respondError('Failed to submit registration');
}

// ============================================================
// PUT — Update registration (status change auto-creates student)
// ============================================================
if ($method === 'PUT') {
    if (!$id) {
        respondError('ID is required for update');
    }

    $body = getJsonBody();
    if (!$body) {
        respondError('Invalid request body');
    }

    // Build update fields
    $updatable = [
        'studentName' => 'student_name',
        'grade' => 'grade',
        'parentName' => 'parent_name',
        'phone' => 'phone',
        'email' => 'email',
        'address' => 'address',
        'dateOfBirth' => 'dob',
        'notes' => 'notes',
        'status' => 'status'
    ];

    $fields = [];
    $params = [];
    $types = '';
    foreach ($updatable as $camel => $snake) {
        if (isset($body[$camel])) {
            $fields[] = "$snake = ?";
            $params[] = $body[$camel];
            $types .= 's';
        }
    }

    if (empty($fields)) {
        respondError('No fields to update');
    }

    $params[] = $id;
    $types .= 'i';

    $affected = dbExecute(
        "UPDATE registrations SET " . implode(', ', $fields) . " WHERE id = ?",
        $params,
        $types
    );

    if ($affected === false) {
        respondError('Failed to update registration');
    }

    // Fetch the updated registration
    $updatedReg = dbFetchOne("SELECT * FROM registrations WHERE id = ?", [$id], 'i');

    // If status changed to Approved, auto-create a student record
    if (($updatedReg['status'] ?? '') === 'Approved' && empty($updatedReg['student_id'])) {
        $studentId = createStudentFromRegistration($updatedReg);
        if ($studentId) {
            dbExecute(
                "UPDATE registrations SET student_id = ? WHERE id = ?",
                [$studentId, $id],
                'ii'
            );
            // Re-fetch to include student_id
            $updatedReg = dbFetchOne("SELECT * FROM registrations WHERE id = ?", [$id], 'i');
        }
    }

    addActivityLog('Registration Updated', "Registration #$id status: " . ($updatedReg['status'] ?? 'Pending'));

    respondSuccess(formatRegistration($updatedReg), 'Registration updated successfully');
}

// ============================================================
// DELETE — Remove registration
// ============================================================
if ($method === 'DELETE') {
    if (!$id) {
        respondError('ID is required for deletion');
    }

    // Get registration info before deleting
    $reg = dbFetchOne("SELECT student_name FROM registrations WHERE id = ?", [$id], 'i');
    if (!$reg) {
        respondError('Registration not found', 404);
    }

    $affected = dbExecute("DELETE FROM registrations WHERE id = ?", [$id], 'i');
    if ($affected > 0) {
        addActivityLog('Registration Deleted', "Registration #$id deleted");
        respondSuccess([], 'Registration deleted successfully');
    }
    respondError('Failed to delete registration');
}

respondError('Method not allowed', 405);

// ============================================================
// Helper: Format registration row for API response
// ============================================================
function formatRegistration($reg) {
    // Look up payment ID if exists
    $paymentId = null;
    $payment = dbFetchOne("SELECT id FROM payments WHERE registration_id = ? LIMIT 1", [$reg['id']], 'i');
    if ($payment) {
        $paymentId = (int)$payment['id'];
    }

    return [
        'id' => (int)$reg['id'],
        'studentName' => $reg['student_name'] ?? '',
        'grade' => $reg['grade'] ?? '',
        'parentName' => $reg['parent_name'] ?? '',
        'phone' => $reg['phone'] ?? '',
        'email' => $reg['email'] ?? '',
        'address' => $reg['address'] ?? '',
        'dateOfBirth' => $reg['dob'] ?? null,
        'notes' => $reg['notes'] ?? '',
        'status' => $reg['status'] ?? 'Pending',
        'createdAt' => $reg['created_at'] ?? null,
        'updatedAt' => $reg['updated_at'] ?? null,
        'studentId' => $reg['student_id'] ?? null,
        'paymentId' => $paymentId,
        'idPhoto' => $reg['id_photo'] ?? null
    ];
}

// ============================================================
// Helper: Create a student record from an approved registration
// ============================================================
function createStudentFromRegistration($reg) {
    // Parse student name into first/last
    $nameParts = explode(' ', trim($reg['student_name'] ?? ''), 2);
    $firstName = $nameParts[0] ?? '';
    $lastName = $nameParts[1] ?? '';

    // Check if student already exists with same name and parent
    $existing = dbFetchOne(
        "SELECT id FROM students WHERE first_name = ? AND last_name = ? AND parent_name = ?",
        [$firstName, $lastName, $reg['parent_name'] ?? ''],
        'sss'
    );

    if ($existing) {
        // Update existing student to link to this registration
        dbExecute(
            "UPDATE students SET registration_id = ? WHERE id = ? AND registration_id IS NULL",
            [$reg['id'], $existing['id']],
            'ii'
        );
        addActivityLog('Student Linked', "$firstName $lastName linked to registration #{$reg['id']}");
        return $existing['id'];
    }

    // Create new student record
    $studentId = dbInsert(
        "INSERT INTO students (first_name, last_name, grade, parent_name, phone, address, dob, enrollment_date, status, registration_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Active', ?)",
        [
            $firstName,
            $lastName,
            $reg['grade'] ?? '',
            $reg['parent_name'] ?? '',
            $reg['phone'] ?? '',
            $reg['address'] ?? '',
            $reg['dob'] ?? null,
            date('Y-m-d'),
            $reg['id']
        ],
        'ssssssssi'
    );

    if ($studentId) {
        addActivityLog('Student Created', "$firstName $lastName auto-created from registration #{$reg['id']}");
    }

    return $studentId;
}
