<?php
require_once __DIR__ . '/db.php';
header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') respondError('Method not allowed', 405);
$id = (int)($_POST['id'] ?? 0);
$status = trim($_POST['status'] ?? '');
if (!$id || $status === '') respondError('Application ID and status are required', 400);
$allowed = ['Pending','Reviewed','Accepted','Rejected'];
if (!in_array($status, $allowed, true)) respondError('Invalid application status', 400);
try {
    $updated = dbExecute("UPDATE job_applications SET status = ? WHERE id = ?", [$status, $id], 'si');
    if ($updated === false) respondError('Failed to update application');
    addActivityLog('Application Status Updated', "Application #$id marked as $status");
    respondSuccess(['id' => $id, 'status' => $status], 'Application status updated');
} catch (Throwable $e) {
    respondError('Failed to update application: ' . $e->getMessage(), 500);
}
