<?php
/**
 * Setup Certificate Tables
 * Run this file to create certificate-related database tables
 */

require_once __DIR__ . '/db.php';

$sqlFile = __DIR__ . '/../database/setup_certificate_tables.sql';
if (!file_exists($sqlFile)) {
    die("SQL file not found: $sqlFile");
}

$sql = file_get_contents($sqlFile);
$conn = getDB();

// Split by semicolon and execute each statement
$statements = explode(';', $sql);
$successCount = 0;
$errorCount = 0;

foreach ($statements as $statement) {
    $statement = trim($statement);
    if (empty($statement)) continue;

    if ($conn->query($statement)) {
        $successCount++;
    } else {
        $errorCount++;
        echo "Error: " . $conn->error . "\n";
        echo "Statement: " . substr($statement, 0, 100) . "...\n\n";
    }
}

echo "\nCertificate tables setup complete!\n";
echo "Successful statements: $successCount\n";
echo "Failed statements: $errorCount\n";
?>
