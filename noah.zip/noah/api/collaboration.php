<?php
/**
 * Collaboration API Handler - Noah Christian Academy
 * Handles teacher collaboration features: class assignments, shared reports, messaging, calendar
 */

require_once __DIR__ . '/db.php';

// Safety net: always return JSON even on fatal errors
ob_start();
register_shutdown_function(function() {
    $error = error_get_last();
    if ($error && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        while (ob_get_level()) { ob_end_clean(); }
        http_response_code(500);
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Server error: ' . $error['message']]);
    }
});

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$method = $_SERVER['REQUEST_METHOD'];
$action = $_REQUEST['action'] ?? '';

// Auto-create teacher_class_assignments table if not exists
try {
    getDB()->query("CREATE TABLE IF NOT EXISTS teacher_class_assignments (
        id INT PRIMARY KEY AUTO_INCREMENT,
        teacher_id INT NOT NULL,
        class_name VARCHAR(100) NOT NULL,
        role VARCHAR(50) DEFAULT 'Primary Teacher',
        subject_focus VARCHAR(255) DEFAULT '',
        assigned_date DATE DEFAULT CURRENT_DATE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY unique_teacher_class (teacher_id, class_name),
        INDEX idx_teacher (teacher_id),
        INDEX idx_class (class_name),
        INDEX idx_role (role)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
} catch (Exception $e) {
    // Silently ignore table creation errors
}

// Auto-create collaboration_logs table if not exists
try {
    getDB()->query("CREATE TABLE IF NOT EXISTS collaboration_logs (
        id INT PRIMARY KEY AUTO_INCREMENT,
        teacher_id INT NOT NULL,
        collaborator_id INT NOT NULL,
        class_name VARCHAR(100) DEFAULT '',
        activity_type VARCHAR(100) NOT NULL,
        description TEXT,
        related_report_id INT DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_teacher (teacher_id),
        INDEX idx_collaborator (collaborator_id),
        INDEX idx_class (class_name),
        INDEX idx_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
} catch (Exception $e) {
    // Silently ignore table creation errors
}

// Auto-create shared_report_drafts table if not exists
try {
    getDB()->query("CREATE TABLE IF NOT EXISTS shared_report_drafts (
        id INT PRIMARY KEY AUTO_INCREMENT,
        report_id INT NOT NULL,
        owner_teacher_id INT NOT NULL,
        shared_with_teacher_id INT NOT NULL,
        access_level VARCHAR(50) DEFAULT 'view',
        comments TEXT,
        status VARCHAR(50) DEFAULT 'Active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_report (report_id),
        INDEX idx_owner (owner_teacher_id),
        INDEX idx_shared (shared_with_teacher_id),
        INDEX idx_status (status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
} catch (Exception $e) {
    // Silently ignore table creation errors
}

// Auto-create teacher_notes table if not exists
try {
    getDB()->query("CREATE TABLE IF NOT EXISTS teacher_notes (
        id INT PRIMARY KEY AUTO_INCREMENT,
        teacher_id INT NOT NULL,
        class_name VARCHAR(100) DEFAULT '',
        student_id INT DEFAULT NULL,
        note_content TEXT NOT NULL,
        note_type VARCHAR(50) DEFAULT 'general',
        is_private TINYINT(1) DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_teacher (teacher_id),
        INDEX idx_class (class_name),
        INDEX idx_student (student_id),
        INDEX idx_type (note_type)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
} catch (Exception $e) {
    // Silently ignore table creation errors
}

// Auto-create shared_resources table if not exists
try {
    getDB()->query("CREATE TABLE IF NOT EXISTS shared_resources (
        id INT PRIMARY KEY AUTO_INCREMENT,
        teacher_id INT NOT NULL,
        resource_type VARCHAR(50) DEFAULT 'document',
        title VARCHAR(255) NOT NULL,
        description TEXT,
        file_url VARCHAR(500) NOT NULL,
        file_name VARCHAR(255) NOT NULL,
        shared_with_class VARCHAR(100) DEFAULT '',
        shared_with_all TINYINT(1) DEFAULT 0,
        download_count INT DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_teacher (teacher_id),
        INDEX idx_class (shared_with_class),
        INDEX idx_type (resource_type)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
} catch (Exception $e) {
    // Silently ignore table creation errors
}

// Auto-create collaboration_sessions table if not exists
try {
    getDB()->query("CREATE TABLE IF NOT EXISTS collaboration_sessions (
        id INT PRIMARY KEY AUTO_INCREMENT,
        session_name VARCHAR(255) NOT NULL,
        class_name VARCHAR(100) DEFAULT '',
        participants JSON,
        start_time DATETIME DEFAULT NULL,
        end_time DATETIME DEFAULT NULL,
        notes TEXT,
        status VARCHAR(50) DEFAULT 'Scheduled',
        created_by INT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_class (class_name),
        INDEX idx_status (status),
        INDEX idx_creator (created_by)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
} catch (Exception $e) {
    // Silently ignore table creation errors
}

// Auto-create calendar_events table if not exists
try {
    getDB()->query("CREATE TABLE IF NOT EXISTS calendar_events (
        id INT PRIMARY KEY AUTO_INCREMENT,
        title VARCHAR(255) NOT NULL,
        description TEXT,
        event_type VARCHAR(50) DEFAULT 'general',
        event_date DATE NOT NULL,
        event_time TIME DEFAULT NULL,
        end_time TIME DEFAULT NULL,
        location VARCHAR(255) DEFAULT '',
        created_by VARCHAR(255) DEFAULT '',
        created_by_id INT DEFAULT NULL,
        target_audience VARCHAR(50) DEFAULT 'all',
        class_name VARCHAR(100) DEFAULT '',
        attachment_path VARCHAR(500) DEFAULT '',
        attachment_name VARCHAR(255) DEFAULT '',
        reminder_sent TINYINT(1) DEFAULT 0,
        status VARCHAR(50) DEFAULT 'Active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_date (event_date),
        INDEX idx_audience (target_audience),
        INDEX idx_class (class_name),
        INDEX idx_status (status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
} catch (Exception $e) {
    // Silently ignore table creation errors
}

// Auto-create report_collaboration_comments table if not exists
try {
    getDB()->query("CREATE TABLE IF NOT EXISTS report_collaboration_comments (
        id INT PRIMARY KEY AUTO_INCREMENT,
        report_id INT NOT NULL,
        teacher_id INT NOT NULL,
        section_reference VARCHAR(255) DEFAULT '',
        comment_text TEXT NOT NULL,
        is_resolved TINYINT(1) DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_report (report_id),
        INDEX idx_teacher (teacher_id),
        INDEX idx_resolved (is_resolved)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
} catch (Exception $e) {
    // Silently ignore table creation errors
}

// Auto-create teacher_messages table if not exists
try {
    getDB()->query("CREATE TABLE IF NOT EXISTS teacher_messages (
        id INT PRIMARY KEY AUTO_INCREMENT,
        sender_id INT NOT NULL,
        receiver_id INT NOT NULL,
        subject VARCHAR(255) DEFAULT '',
        message TEXT NOT NULL,
        read_status TINYINT(1) DEFAULT 0,
        reply_to_id INT DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_sender (sender_id),
        INDEX idx_receiver (receiver_id),
        INDEX idx_read (read_status),
        INDEX idx_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
} catch (Exception $e) {
    // Silently ignore table creation errors
}


switch ($action) {
    // Teacher Class Assignments
    case 'my_class_colleagues':
        handleGetMyClassColleagues();
        break;
    case 'assign_teacher_to_class':
        handleAssignTeacherToClass();
        break;
    case 'remove_teacher_from_class':
        handleRemoveTeacherFromClass();
        break;
    case 'class_assignments':
        handleGetClassAssignments();
        break;
    
    // Collaboration Logs
    case 'collaboration_logs':
        handleGetCollaborationLogs();
        break;
    case 'log_collaboration':
        handleLogCollaboration();
        break;
    
    // Shared Report Drafts
    case 'shared_reports':
        handleGetSharedReports();
        break;
    case 'share_report':
        handleShareReport();
        break;
    case 'update_shared_report_access':
        handleUpdateSharedReportAccess();
        break;
    
    // Teacher Messages
    case 'teacher_messages':
        handleGetTeacherMessages();
        break;
    case 'send_teacher_message':
        handleSendTeacherMessage();
        break;
    case 'mark_message_read':
        handleMarkMessageRead();
        break;
    
    // Teacher Notes
    case 'teacher_notes':
        handleGetTeacherNotes();
        break;
    case 'save_teacher_note':
        handleSaveTeacherNote();
        break;
    case 'delete_teacher_note':
        handleDeleteTeacherNote();
        break;
    
    // Shared Resources
    case 'shared_resources':
        handleGetSharedResources();
        break;
    case 'upload_shared_resource':
        handleUploadSharedResource();
        break;
    case 'delete_shared_resource':
        handleDeleteSharedResource();
        break;
    
    // Collaboration Sessions
    case 'collaboration_sessions':
        handleGetCollaborationSessions();
        break;
    case 'create_collaboration_session':
        handleCreateCollaborationSession();
        break;
    case 'update_collaboration_session':
        handleUpdateCollaborationSession();
        break;
    
    // Calendar Events
    case 'calendar_events':
        handleGetCalendarEvents();
        break;
    case 'create_calendar_event':
        handleCreateCalendarEvent();
        break;
    case 'update_calendar_event':
        handleUpdateCalendarEvent();
        break;
    case 'delete_calendar_event':
        handleDeleteCalendarEvent();
        break;
    
    // Report Collaboration Comments
    case 'report_comments':
        handleGetReportComments();
        break;
    case 'add_report_comment':
        handleAddReportComment();
        break;
    case 'resolve_report_comment':
        handleResolveReportComment();
        break;
    
    default:
        respondError('Unknown action: ' . $action, 404);
}

// ============================================================
// TEACHER CLASS ASSIGNMENTS
// ============================================================

function handleGetMyClassColleagues() {
    $teacherId = (int)($_REQUEST['teacher_id'] ?? 0);
    if (!$teacherId) respondError('Teacher ID required');
    
    // Get teacher's assigned class
    $teacher = dbFetchOne("SELECT class_assigned FROM teachers WHERE id = ?", [$teacherId], 'i');
    if (!$teacher) respondError('Teacher not found');
    
    $className = $teacher['class_assigned'];
    if (empty($className)) {
        respondSuccess(['items' => [], 'total' => 0, 'className' => '']);
    }
    
    // Get all teachers assigned to this class from teachers table only
    $colleagues = [];
    
    $teachersFromTable = dbFetchAll(
        "SELECT id, first_name, last_name, email, phone, subject, class_assigned, approved 
         FROM teachers WHERE class_assigned = ? AND id != ? AND approved = 1",
        [$className, $teacherId], 'si'
    );
    
    foreach ($teachersFromTable as $t) {
        $colleagues[] = [
            'id' => $t['id'],
            'firstName' => $t['first_name'],
            'lastName' => $t['last_name'],
            'email' => $t['email'],
            'phone' => $t['phone'],
            'subject' => $t['subject'],
            'className' => $t['class_assigned'],
            'role' => 'Teacher',
            'source' => 'teachers_table'
        ];
    }
    
    respondSuccess(['items' => $colleagues, 'total' => count($colleagues), 'className' => $className]);
}

function handleAssignTeacherToClass() {
    $body = getJsonBody();
    if (!$body) respondError('Invalid request body');
    
    $teacherId = (int)($body['teacherId'] ?? 0);
    $className = trim($body['className'] ?? '');
    $role = trim($body['role'] ?? 'Primary Teacher');
    $subjectFocus = trim($body['subjectFocus'] ?? '');
    $assignedDate = $body['assignedDate'] ?? date('Y-m-d');
    
    if (!$teacherId || empty($className)) respondError('Teacher ID and Class Name required');
    
    // Check if teacher exists
    $teacher = dbFetchOne("SELECT * FROM teachers WHERE id = ?", [$teacherId], 'i');
    if (!$teacher) respondError('Teacher not found');
    
    // Insert or update assignment
    $id = dbInsert(
        "INSERT INTO teacher_class_assignments (teacher_id, class_name, role, subject_focus, assigned_date)
         VALUES (?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE role=?, subject_focus=?, assigned_date=?",
        [$teacherId, $className, $role, $subjectFocus, $assignedDate, $role, $subjectFocus, $assignedDate],
        'isssssss'
    );
    
    if ($id) {
        addActivityLog('Teacher Assigned', "Teacher #{$teacherId} assigned to {$className}");
        respondSuccess(['id' => $id], 'Teacher assigned to class successfully');
    }
    respondError('Failed to assign teacher to class');
}

function handleRemoveTeacherFromClass() {
    $body = getJsonBody();
    $teacherId = (int)($body['teacherId'] ?? 0);
    $className = trim($body['className'] ?? '');
    
    if (!$teacherId || empty($className)) respondError('Teacher ID and Class Name required');
    
    dbExecute(
        "DELETE FROM teacher_class_assignments WHERE teacher_id = ? AND class_name = ?",
        [$teacherId, $className], 'is'
    );
    
    addActivityLog('Teacher Removed', "Teacher #{$teacherId} removed from {$className}");
    respondSuccess([], 'Teacher removed from class successfully');
}

function handleGetClassAssignments() {
    $className = trim($_REQUEST['class_name'] ?? '');
    
    // If no class_name provided, return all assignments
    if (empty($className)) {
        $assignments = dbFetchAll(
            "SELECT tca.*, t.first_name, t.last_name, t.email, t.phone, t.subject 
             FROM teacher_class_assignments tca
             JOIN teachers t ON tca.teacher_id = t.id
             WHERE t.approved = 1
             ORDER BY tca.class_name, tca.role, t.first_name"
        );
    } else {
        $assignments = dbFetchAll(
            "SELECT tca.*, t.first_name, t.last_name, t.email, t.phone, t.subject 
             FROM teacher_class_assignments tca
             JOIN teachers t ON tca.teacher_id = t.id
             WHERE tca.class_name = ? AND t.approved = 1
             ORDER BY tca.role, t.first_name",
            [$className], 's'
        );
    }
    
    $items = array_map(function($a) {
        return [
            'id' => $a['id'],
            'teacherId' => $a['teacher_id'],
            'teacherName' => $a['first_name'] . ' ' . $a['last_name'],
            'email' => $a['email'],
            'phone' => $a['phone'],
            'subject' => $a['subject'],
            'className' => $a['class_name'],
            'role' => $a['role'],
            'subjectFocus' => $a['subject_focus'],
            'assignedDate' => $a['assigned_date']
        ];
    }, $assignments);
    
    respondSuccess(['items' => $items, 'total' => count($items)]);
}

// ============================================================
// COLLABORATION LOGS
// ============================================================

function handleGetCollaborationLogs() {
    $teacherId = (int)($_REQUEST['teacher_id'] ?? 0);
    $limit = (int)($_REQUEST['limit'] ?? 50);
    
    if (!$teacherId) respondError('Teacher ID required');
    
    $logs = dbFetchAll(
        "SELECT cl.*, t1.first_name as teacher_name, t2.first_name as collaborator_name
         FROM collaboration_logs cl
         LEFT JOIN teachers t1 ON cl.teacher_id = t1.id
         LEFT JOIN teachers t2 ON cl.collaborator_id = t2.id
         WHERE cl.teacher_id = ? OR cl.collaborator_id = ?
         ORDER BY cl.created_at DESC LIMIT ?",
        [$teacherId, $teacherId, $limit], 'iii'
    );
    
    $items = array_map(function($l) {
        return [
            'id' => $l['id'],
            'teacherId' => $l['teacher_id'],
            'teacherName' => $l['teacher_name'],
            'collaboratorId' => $l['collaborator_id'],
            'collaboratorName' => $l['collaborator_name'],
            'className' => $l['class_name'],
            'activityType' => $l['activity_type'],
            'description' => $l['description'],
            'relatedReportId' => $l['related_report_id'],
            'createdAt' => $l['created_at']
        ];
    }, $logs);
    
    respondSuccess(['items' => $items, 'total' => count($items)]);
}

function handleLogCollaboration() {
    $body = getJsonBody();
    if (!$body) respondError('Invalid request body');
    
    $teacherId = (int)($body['teacherId'] ?? 0);
    $collaboratorId = (int)($body['collaboratorId'] ?? 0);
    $className = trim($body['className'] ?? '');
    $activityType = trim($body['activityType'] ?? '');
    $description = trim($body['description'] ?? '');
    $relatedReportId = (int)($body['relatedReportId'] ?? 0);
    
    if (!$teacherId || !$collaboratorId || empty($activityType)) {
        respondError('Teacher ID, Collaborator ID, and Activity Type required');
    }
    
    $id = dbInsert(
        "INSERT INTO collaboration_logs (teacher_id, collaborator_id, class_name, activity_type, description, related_report_id)
         VALUES (?, ?, ?, ?, ?, ?)",
        [$teacherId, $collaboratorId, $className, $activityType, $description, $relatedReportId ?: null],
        'iissii'
    );
    
    if ($id) {
        respondSuccess(['id' => $id], 'Collaboration logged successfully');
    }
    respondError('Failed to log collaboration');
}

// ============================================================
// SHARED REPORT DRAFTS
// ============================================================

function handleGetSharedReports() {
    $teacherId = (int)($_REQUEST['teacher_id'] ?? 0);
    if (!$teacherId) respondError('Teacher ID required');
    
    $shared = dbFetchAll(
        "SELECT srd.*, sr.student_name, sr.class_name, sr.term, sr.status as report_status,
         t1.first_name as owner_name, t2.first_name as shared_with_name
         FROM shared_report_drafts srd
         JOIN school_reports sr ON srd.report_id = sr.id
         LEFT JOIN teachers t1 ON srd.owner_teacher_id = t1.id
         LEFT JOIN teachers t2 ON srd.shared_with_teacher_id = t2.id
         WHERE srd.owner_teacher_id = ? OR srd.shared_with_teacher_id = ?
         ORDER BY srd.updated_at DESC",
        [$teacherId, $teacherId], 'ii'
    );
    
    $items = array_map(function($s) {
        return [
            'id' => $s['id'],
            'reportId' => $s['report_id'],
            'ownerTeacherId' => $s['owner_teacher_id'],
            'ownerName' => $s['owner_name'],
            'sharedWithTeacherId' => $s['shared_with_teacher_id'],
            'sharedWithName' => $s['shared_with_name'],
            'studentName' => $s['student_name'],
            'className' => $s['class_name'],
            'term' => $s['term'],
            'reportStatus' => $s['report_status'],
            'accessLevel' => $s['access_level'],
            'comments' => $s['comments'],
            'status' => $s['status'],
            'createdAt' => $s['created_at'],
            'updatedAt' => $s['updated_at']
        ];
    }, $shared);
    
    respondSuccess(['items' => $items, 'total' => count($items)]);
}

function handleShareReport() {
    $body = getJsonBody();
    if (!$body) respondError('Invalid request body');
    
    $reportId = (int)($body['reportId'] ?? 0);
    $ownerTeacherId = (int)($body['ownerTeacherId'] ?? 0);
    $sharedWithTeacherId = (int)($body['sharedWithTeacherId'] ?? 0);
    $accessLevel = trim($body['accessLevel'] ?? 'view');
    $comments = trim($body['comments'] ?? '');
    
    if (!$reportId || !$ownerTeacherId || !$sharedWithTeacherId) {
        respondError('Report ID, Owner Teacher ID, and Shared With Teacher ID required');
    }
    
    // Check if report exists
    $report = dbFetchOne("SELECT * FROM school_reports WHERE id = ?", [$reportId], 'i');
    if (!$report) respondError('Report not found');
    
    $id = dbInsert(
        "INSERT INTO shared_report_drafts (report_id, owner_teacher_id, shared_with_teacher_id, access_level, comments, status)
         VALUES (?, ?, ?, ?, ?, 'Active')",
        [$reportId, $ownerTeacherId, $sharedWithTeacherId, $accessLevel, $comments],
        'iiiss'
    );
    
    if ($id) {
        addActivityLog('Report Shared', "Report #{$reportId} shared with teacher #{$sharedWithTeacherId}");
        respondSuccess(['id' => $id], 'Report shared successfully');
    }
    respondError('Failed to share report');
}

function handleUpdateSharedReportAccess() {
    $body = getJsonBody();
    $id = (int)($body['id'] ?? 0);
    $accessLevel = trim($body['accessLevel'] ?? 'view');
    $comments = trim($body['comments'] ?? '');
    $status = trim($body['status'] ?? 'Active');
    
    if (!$id) respondError('Shared Report ID required');
    
    dbExecute(
        "UPDATE shared_report_drafts SET access_level=?, comments=?, status=? WHERE id=?",
        [$accessLevel, $comments, $status, $id],
        'sssi'
    );
    
    respondSuccess([], 'Shared report access updated');
}

// ============================================================
// TEACHER MESSAGES
// ============================================================

function handleGetTeacherMessages() {
    $teacherId = (int)($_REQUEST['teacher_id'] ?? 0);
    $limit = (int)($_REQUEST['limit'] ?? 50);
    
    if (!$teacherId) respondError('Teacher ID required');
    
    $messages = dbFetchAll(
        "SELECT tm.*, CONCAT(t1.first_name, ' ', t1.last_name) as sender_name, CONCAT(t2.first_name, ' ', t2.last_name) as receiver_name
         FROM teacher_messages tm
         LEFT JOIN teachers t1 ON tm.sender_id = t1.id
         LEFT JOIN teachers t2 ON tm.receiver_id = t2.id
         WHERE tm.sender_id = ? OR tm.receiver_id = ?
         ORDER BY tm.created_at DESC LIMIT ?",
        [$teacherId, $teacherId, $limit], 'iii'
    );
    
    $items = array_map(function($m) {
        return [
            'id' => $m['id'],
            'senderId' => $m['sender_id'],
            'senderName' => $m['sender_name'],
            'receiverId' => $m['receiver_id'],
            'receiverName' => $m['receiver_name'],
            'subject' => $m['subject'],
            'message' => $m['message'],
            'readStatus' => (bool)$m['read_status'],
            'replyToId' => $m['reply_to_id'],
            'createdAt' => $m['created_at']
        ];
    }, $messages);
    
    respondSuccess(['items' => $items, 'total' => count($items)]);
}

function handleSendTeacherMessage() {
    $body = getJsonBody();
    if (!$body) respondError('Invalid request body');
    
    $senderId = (int)($body['senderId'] ?? 0);
    $receiverId = (int)($body['receiverId'] ?? 0);
    $subject = trim($body['subject'] ?? '');
    $message = trim($body['message'] ?? '');
    $replyToId = (int)($body['replyToId'] ?? 0);
    
    if (!$senderId || !$receiverId || empty($message)) {
        respondError('Sender ID, Receiver ID, and Message required');
    }
    
    $id = dbInsert(
        "INSERT INTO teacher_messages (sender_id, receiver_id, subject, message, reply_to_id)
         VALUES (?, ?, ?, ?, ?)",
        [$senderId, $receiverId, $subject, $message, $replyToId ?: null],
        'iissi'
    );
    
    if ($id) {
        respondSuccess(['id' => $id], 'Message sent successfully');
    }
    respondError('Failed to send message');
}

function handleMarkMessageRead() {
    $body = getJsonBody();
    $id = (int)($body['id'] ?? 0);
    
    if (!$id) respondError('Message ID required');
    
    dbExecute("UPDATE teacher_messages SET read_status=1 WHERE id=?", [$id], 'i');
    respondSuccess([], 'Message marked as read');
}

// ============================================================
// TEACHER NOTES
// ============================================================

function handleGetTeacherNotes() {
    $teacherId = (int)($_REQUEST['teacher_id'] ?? 0);
    $className = trim($_REQUEST['class_name'] ?? '');
    
    if (!$teacherId) respondError('Teacher ID required');
    
    $query = "SELECT tn.*, s.first_name as student_first_name, s.last_name as student_last_name
              FROM teacher_notes tn
              LEFT JOIN students s ON tn.student_id = s.id
              WHERE tn.teacher_id = ?";
    $params = [$teacherId];
    $types = 'i';
    
    if (!empty($className)) {
        $query .= " AND tn.class_name = ?";
        $params[] = $className;
        $types .= 's';
    }
    
    $query .= " ORDER BY tn.created_at DESC";
    
    $notes = dbFetchAll($query, $params, $types);
    
    $items = array_map(function($n) {
        return [
            'id' => $n['id'],
            'teacherId' => $n['teacher_id'],
            'className' => $n['class_name'],
            'studentId' => $n['student_id'],
            'studentName' => $n['student_first_name'] ? $n['student_first_name'] . ' ' . $n['student_last_name'] : '',
            'noteContent' => $n['note_content'],
            'noteType' => $n['note_type'],
            'isPrivate' => (bool)$n['is_private'],
            'createdAt' => $n['created_at'],
            'updatedAt' => $n['updated_at']
        ];
    }, $notes);
    
    respondSuccess(['items' => $items, 'total' => count($items)]);
}

function handleSaveTeacherNote() {
    $body = getJsonBody();
    if (!$body) respondError('Invalid request body');
    
    $editId = $body['id'] ?? null;
    $teacherId = (int)($body['teacherId'] ?? 0);
    $className = trim($body['className'] ?? '');
    $studentId = (int)($body['studentId'] ?? 0);
    $noteContent = trim($body['noteContent'] ?? '');
    $noteType = trim($body['noteType'] ?? 'general');
    $isPrivate = (int)($body['isPrivate'] ?? 1);
    
    if (!$teacherId || empty($noteContent)) respondError('Teacher ID and Note Content required');
    
    if ($editId) {
        dbExecute(
            "UPDATE teacher_notes SET class_name=?, student_id=?, note_content=?, note_type=?, is_private=? WHERE id=?",
            [$className, $studentId ?: null, $noteContent, $noteType, $isPrivate, (int)$editId],
            'sisiii'
        );
        respondSuccess(['id' => $editId], 'Note updated successfully');
    } else {
        $id = dbInsert(
            "INSERT INTO teacher_notes (teacher_id, class_name, student_id, note_content, note_type, is_private)
             VALUES (?, ?, ?, ?, ?, ?)",
            [$teacherId, $className, $studentId ?: null, $noteContent, $noteType, $isPrivate],
            'isisii'
        );
        if ($id) {
            respondSuccess(['id' => $id], 'Note created successfully');
        }
        respondError('Failed to create note');
    }
}

function handleDeleteTeacherNote() {
    $body = getJsonBody();
    $id = (int)($body['id'] ?? 0);
    $teacherId = (int)($body['teacherId'] ?? 0);
    
    if (!$id || !$teacherId) respondError('Note ID and Teacher ID required');
    
    // Ensure note belongs to teacher
    $note = dbFetchOne("SELECT id FROM teacher_notes WHERE id = ? AND teacher_id = ?", [$id, $teacherId], 'ii');
    if (!$note) respondError('Note not found or access denied');
    
    dbExecute("DELETE FROM teacher_notes WHERE id = ?", [$id], 'i');
    respondSuccess([], 'Note deleted successfully');
}

// ============================================================
// SHARED RESOURCES
// ============================================================

function handleGetSharedResources() {
    $teacherId = (int)($_REQUEST['teacher_id'] ?? 0);
    $className = trim($_REQUEST['class_name'] ?? '');
    
    if (!$teacherId) respondError('Teacher ID required');
    
    $query = "SELECT sr.*, t.first_name as teacher_name
              FROM shared_resources sr
              JOIN teachers t ON sr.teacher_id = t.id
              WHERE (sr.teacher_id = ? OR sr.shared_with_all = 1";
    $params = [$teacherId];
    $types = 'i';
    
    if (!empty($className)) {
        $query .= " OR sr.shared_with_class = ?";
        $params[] = $className;
        $types .= 's';
    }
    
    $query .= ") ORDER BY sr.created_at DESC";
    
    $resources = dbFetchAll($query, $params, $types);
    
    $items = array_map(function($r) {
        return [
            'id' => $r['id'],
            'teacherId' => $r['teacher_id'],
            'teacherName' => $r['teacher_name'],
            'resourceType' => $r['resource_type'],
            'title' => $r['title'],
            'description' => $r['description'],
            'fileUrl' => $r['file_url'],
            'fileName' => $r['file_name'],
            'sharedWithClass' => $r['shared_with_class'],
            'sharedWithAll' => (bool)$r['shared_with_all'],
            'downloadCount' => $r['download_count'],
            'createdAt' => $r['created_at']
        ];
    }, $resources);
    
    respondSuccess(['items' => $items, 'total' => count($items)]);
}

function handleUploadSharedResource() {
    $teacherId = (int)($_POST['teacherId'] ?? 0);
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $resourceType = trim($_POST['resourceType'] ?? 'document');
    $sharedWithClass = trim($_POST['sharedWithClass'] ?? '');
    $sharedWithAll = (int)($_POST['sharedWithAll'] ?? 0);
    
    if (!$teacherId || empty($title)) respondError('Teacher ID and Title required');
    if (empty($_FILES['resourceFile'])) respondError('No file uploaded');
    
    $file = $_FILES['resourceFile'];
    $allowedTypes = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'image/jpeg', 'image/png'];
    $maxSize = 10 * 1024 * 1024; // 10MB
    
    if (!in_array($file['type'], $allowedTypes)) {
        respondError('Invalid file type. Allowed: PDF, DOC, DOCX, JPG, PNG');
    }
    if ($file['size'] > $maxSize) {
        respondError('File too large. Maximum size is 10MB');
    }
    
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $newName = uniqid('resource_', true) . '.' . $ext;
    $uploadDir = __DIR__ . '/../uploads/';
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
    
    $dest = $uploadDir . $newName;
    if (!move_uploaded_file($file['tmp_name'], $dest)) {
        respondError('Failed to save uploaded file');
    }
    
    $fileUrl = '../uploads/' . $newName;
    
    $id = dbInsert(
        "INSERT INTO shared_resources (teacher_id, resource_type, title, description, file_url, file_name, shared_with_class, shared_with_all)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        [$teacherId, $resourceType, $title, $description, $fileUrl, $file['name'], $sharedWithClass, $sharedWithAll],
        'isssssii'
    );
    
    if ($id) {
        addActivityLog('Resource Shared', "Resource '$title' uploaded by teacher #{$teacherId}");
        respondSuccess(['id' => $id, 'fileUrl' => $fileUrl], 'Resource uploaded successfully');
    }
    respondError('Failed to save resource');
}

function handleDeleteSharedResource() {
    $body = getJsonBody();
    $id = (int)($body['id'] ?? 0);
    $teacherId = (int)($body['teacherId'] ?? 0);
    
    if (!$id || !$teacherId) respondError('Resource ID and Teacher ID required');
    
    $resource = dbFetchOne("SELECT * FROM shared_resources WHERE id = ? AND teacher_id = ?", [$id, $teacherId], 'ii');
    if (!$resource) respondError('Resource not found or access denied');
    
    // Delete file
    $filePath = __DIR__ . '/../' . ltrim($resource['file_url'], '/');
    if (file_exists($filePath)) {
        @unlink($filePath);
    }
    
    dbExecute("DELETE FROM shared_resources WHERE id = ?", [$id], 'i');
    respondSuccess([], 'Resource deleted successfully');
}

// ============================================================
// COLLABORATION SESSIONS
// ============================================================

function handleGetCollaborationSessions() {
    $teacherId = (int)($_REQUEST['teacher_id'] ?? 0);
    $className = trim($_REQUEST['class_name'] ?? '');
    
    if (!$teacherId) respondError('Teacher ID required');
    
    $query = "SELECT cs.*, t.first_name as created_by_name
              FROM collaboration_sessions cs
              LEFT JOIN teachers t ON cs.created_by = t.id
              WHERE cs.created_by = ? OR cs.participants LIKE ?";
    $params = [$teacherId, "%\"$teacherId\"%"];
    $types = 'is';
    
    if (!empty($className)) {
        $query .= " OR cs.class_name = ?";
        $params[] = $className;
        $types .= 's';
    }
    
    $query .= " ORDER BY cs.created_at DESC";
    
    $sessions = dbFetchAll($query, $params, $types);
    
    $items = array_map(function($s) {
        return [
            'id' => $s['id'],
            'sessionName' => $s['session_name'],
            'className' => $s['class_name'],
            'participants' => json_decode($s['participants'], true) ?: [],
            'startTime' => $s['start_time'],
            'endTime' => $s['end_time'],
            'notes' => $s['notes'],
            'status' => $s['status'],
            'createdBy' => $s['created_by'],
            'createdByName' => $s['created_by_name'],
            'createdAt' => $s['created_at']
        ];
    }, $sessions);
    
    respondSuccess(['items' => $items, 'total' => count($items)]);
}

function handleCreateCollaborationSession() {
    $body = getJsonBody();
    if (!$body) respondError('Invalid request body');
    
    $sessionName = trim($body['sessionName'] ?? '');
    $className = trim($body['className'] ?? '');
    $participants = json_encode($body['participants'] ?? []);
    $startTime = $body['startTime'] ?? null;
    $endTime = $body['endTime'] ?? null;
    $notes = trim($body['notes'] ?? '');
    $status = trim($body['status'] ?? 'Scheduled');
    $createdBy = (int)($body['createdBy'] ?? 0);
    
    if (empty($sessionName) || !$createdBy) respondError('Session Name and Created By required');
    
    $id = dbInsert(
        "INSERT INTO collaboration_sessions (session_name, class_name, participants, start_time, end_time, notes, status, created_by)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        [$sessionName, $className, $participants, $startTime, $endTime, $notes, $status, $createdBy],
        'ssssssii'
    );
    
    if ($id) {
        addActivityLog('Collaboration Session Created', "Session '$sessionName' created");
        respondSuccess(['id' => $id], 'Collaboration session created successfully');
    }
    respondError('Failed to create collaboration session');
}

function handleUpdateCollaborationSession() {
    $body = getJsonBody();
    $id = (int)($body['id'] ?? 0);
    
    if (!$id) respondError('Session ID required');
    
    $fields = [];
    $params = [];
    $types = '';
    
    $allowed = ['session_name', 'class_name', 'participants', 'start_time', 'end_time', 'notes', 'status'];
    foreach ($allowed as $field) {
        $camelField = lcfirst(str_replace('_', '', ucwords($field, '_')));
        if (isset($body[$camelField])) {
            $fields[] = "$field = ?";
            $params[] = is_array($body[$camelField]) ? json_encode($body[$camelField]) : $body[$camelField];
            $types .= 's';
        }
    }
    
    if (empty($fields)) respondError('No fields to update');
    
    $params[] = $id;
    $types .= 'i';
    
    dbExecute("UPDATE collaboration_sessions SET " . implode(', ', $fields) . " WHERE id = ?", $params, $types);
    respondSuccess([], 'Collaboration session updated');
}

// ============================================================
// CALENDAR EVENTS
// ============================================================

function handleGetCalendarEvents() {
    $teacherId = (int)($_REQUEST['teacher_id'] ?? 0);
    $targetAudience = trim($_REQUEST['target_audience'] ?? 'teachers');
    $className = trim($_REQUEST['class_name'] ?? '');
    $startDate = $_REQUEST['start_date'] ?? null;
    $endDate = $_REQUEST['end_date'] ?? null;
    
    $query = "SELECT * FROM calendar_events WHERE target_audience IN ('all', ?)";
    $params = [$targetAudience];
    $types = 's';
    
    if (!empty($className)) {
        $query .= " AND (class_name = ? OR class_name = '')";
        $params[] = $className;
        $types .= 's';
    }
    
    if ($startDate && $endDate) {
        $query .= " AND event_date BETWEEN ? AND ?";
        $params[] = $startDate;
        $params[] = $endDate;
        $types .= 'ss';
    }
    
    $query .= " ORDER BY event_date ASC, event_time ASC";
    
    $events = dbFetchAll($query, $params, $types);
    
    $items = array_map(function($e) {
        return [
            'id' => $e['id'],
            'title' => $e['title'],
            'description' => $e['description'],
            'eventType' => $e['event_type'],
            'eventDate' => $e['event_date'],
            'eventTime' => $e['event_time'],
            'endTime' => $e['end_time'],
            'location' => $e['location'],
            'createdBy' => $e['created_by'],
            'createdById' => $e['created_by_id'],
            'targetAudience' => $e['target_audience'],
            'className' => $e['class_name'],
            'attachmentPath' => $e['attachment_path'],
            'attachmentName' => $e['attachment_name'],
            'reminderSent' => (bool)$e['reminder_sent'],
            'status' => $e['status'],
            'createdAt' => $e['created_at']
        ];
    }, $events);
    
    respondSuccess(['items' => $items, 'total' => count($items)]);
}

function handleCreateCalendarEvent() {
    $body = getJsonBody();
    if (!$body) respondError('Invalid request body');
    
    $title = trim($body['title'] ?? '');
    $description = trim($body['description'] ?? '');
    $eventType = trim($body['eventType'] ?? 'general');
    $eventDate = $body['eventDate'] ?? date('Y-m-d');
    $eventTime = $body['eventTime'] ?? null;
    $endTime = $body['endTime'] ?? null;
    $location = trim($body['location'] ?? '');
    $createdBy = trim($body['createdBy'] ?? '');
    $createdById = (int)($body['createdById'] ?? 0);
    $targetAudience = trim($body['targetAudience'] ?? 'all');
    $className = trim($body['className'] ?? '');
    $attachmentPath = trim($body['attachmentPath'] ?? '');
    $attachmentName = trim($body['attachmentName'] ?? '');
    
    if (empty($title) || empty($eventDate)) respondError('Title and Event Date required');
    
    $id = dbInsert(
        "INSERT INTO calendar_events (title, description, event_type, event_date, event_time, end_time, location, created_by, created_by_id, target_audience, class_name, attachment_path, attachment_name, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Active')",
        [$title, $description, $eventType, $eventDate, $eventTime, $endTime, $location, $createdBy, $createdById, $targetAudience, $className, $attachmentPath, $attachmentName],
        'sssssssiissss'
    );
    
    if ($id) {
        addActivityLog('Calendar Event Created', "Event '$title' created");
        respondSuccess(['id' => $id], 'Calendar event created successfully');
    }
    respondError('Failed to create calendar event');
}

function handleUpdateCalendarEvent() {
    $body = getJsonBody();
    $id = (int)($body['id'] ?? 0);
    
    if (!$id) respondError('Event ID required');
    
    $fields = [];
    $params = [];
    $types = '';
    
    $allowed = ['title', 'description', 'event_type', 'event_date', 'event_time', 'end_time', 'location', 'target_audience', 'class_name', 'status', 'attachment_path', 'attachment_name'];
    foreach ($allowed as $field) {
        $camelField = lcfirst(str_replace('_', '', ucwords($field, '_')));
        if (isset($body[$camelField])) {
            $fields[] = "$field = ?";
            $params[] = $body[$camelField];
            $types .= 's';
        }
    }
    
    if (empty($fields)) respondError('No fields to update');
    
    $params[] = $id;
    $types .= 'i';
    
    dbExecute("UPDATE calendar_events SET " . implode(', ', $fields) . " WHERE id = ?", $params, $types);
    respondSuccess([], 'Calendar event updated');
}

function handleDeleteCalendarEvent() {
    $body = getJsonBody();
    $id = (int)($body['id'] ?? 0);
    
    if (!$id) respondError('Event ID required');
    
    dbExecute("DELETE FROM calendar_events WHERE id = ?", [$id], 'i');
    respondSuccess([], 'Calendar event deleted');
}

// ============================================================
// REPORT COLLABORATION COMMENTS
// ============================================================

function handleGetReportComments() {
    $reportId = (int)($_REQUEST['report_id'] ?? 0);
    
    if (!$reportId) respondError('Report ID required');
    
    $comments = dbFetchAll(
        "SELECT rcc.*, t.first_name as teacher_name
         FROM report_collaboration_comments rcc
         LEFT JOIN teachers t ON rcc.teacher_id = t.id
         WHERE rcc.report_id = ?
         ORDER BY rcc.created_at ASC",
        [$reportId], 'i'
    );
    
    $items = array_map(function($c) {
        return [
            'id' => $c['id'],
            'reportId' => $c['report_id'],
            'teacherId' => $c['teacher_id'],
            'teacherName' => $c['teacher_name'],
            'sectionReference' => $c['section_reference'],
            'commentText' => $c['comment_text'],
            'isResolved' => (bool)$c['is_resolved'],
            'createdAt' => $c['created_at'],
            'updatedAt' => $c['updated_at']
        ];
    }, $comments);
    
    respondSuccess(['items' => $items, 'total' => count($items)]);
}

function handleAddReportComment() {
    $body = getJsonBody();
    if (!$body) respondError('Invalid request body');
    
    $reportId = (int)($body['reportId'] ?? 0);
    $teacherId = (int)($body['teacherId'] ?? 0);
    $sectionReference = trim($body['sectionReference'] ?? '');
    $commentText = trim($body['commentText'] ?? '');
    
    if (!$reportId || !$teacherId || empty($commentText)) {
        respondError('Report ID, Teacher ID, and Comment Text required');
    }
    
    $id = dbInsert(
        "INSERT INTO report_collaboration_comments (report_id, teacher_id, section_reference, comment_text)
         VALUES (?, ?, ?, ?)",
        [$reportId, $teacherId, $sectionReference, $commentText],
        'iiss'
    );
    
    if ($id) {
        respondSuccess(['id' => $id], 'Comment added successfully');
    }
    respondError('Failed to add comment');
}

function handleResolveReportComment() {
    $body = getJsonBody();
    $id = (int)($body['id'] ?? 0);
    
    if (!$id) respondError('Comment ID required');
    
    dbExecute("UPDATE report_collaboration_comments SET is_resolved=1 WHERE id=?", [$id], 'i');
    respondSuccess([], 'Comment resolved');
}

// ============================================================
// HELPER FUNCTIONS
// ============================================================
// Using respond functions from db.php

?>