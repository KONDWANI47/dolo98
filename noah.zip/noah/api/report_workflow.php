<?php
/**
 * Report Workflow API Handler - Noah Christian Academy
 * Handles bidirectional report sharing between teachers, admins, and parents
 */

require_once __DIR__ . '/db.php';

// Safety net: always return JSON even on fatal errors
ob_start();
register_shutdown_function(function() {
    $error = error_get_last();
    if ($error && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        while (ob_get_level()) { ob_end_clean(); }
        http_response_code(500);
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Server error: ' . $error['message']]);
    }
});

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$method = $_SERVER['REQUEST_METHOD'];
$action = $_REQUEST['action'] ?? '';

switch ($action) {
    // Teacher Actions
    case 'send_to_admin':
        handleSendToAdmin();
        break;
    case 'send_to_parent':
        handleSendToParent();
        break;
    case 'teacher_get_inbox':
        handleTeacherGetInbox();
        break;
    case 'teacher_get_outbox':
        handleTeacherGetOutbox();
        break;
    
    // Admin Actions
    case 'admin_get_pending_reports':
        handleAdminGetPendingReports();
        break;
    case 'admin_approve_report':
        handleAdminApproveReport();
        break;
    case 'admin_reject_report':
        handleAdminRejectReport();
        break;
    case 'admin_return_to_teacher':
        handleAdminReturnToTeacher();
        break;
    case 'admin_publish_to_parent':
        handleAdminPublishToParent();
        break;
    case 'admin_get_all_reports':
        handleAdminGetAllReports();
        break;
    
    // Parent Actions
    case 'parent_get_reports':
        handleParentGetReports();
        break;
    case 'parent_view_report':
        handleParentViewReport();
        break;
    case 'parent_submit_feedback':
        handleParentSubmitFeedback();
        break;
    
    // General Actions
    case 'get_report_history':
        handleGetReportHistory();
        break;
    case 'get_report_recipients':
        handleGetReportRecipients();
        break;
    
    default:
        respondError('Unknown action: ' . $action, 404);
}

// ============================================================
// TEACHER ACTIONS
// ============================================================

function handleSendToAdmin() {
    $body = getJsonBody();
    if (!$body) respondError('Invalid request body');
    
    $reportId = (int)($body['reportId'] ?? 0);
    $teacherId = (int)($body['teacherId'] ?? 0);
    $message = trim($body['message'] ?? '');
    $priority = trim($body['priority'] ?? 'normal');
    
    if (!$reportId || !$teacherId) respondError('Report ID and Teacher ID required');
    
    // Verify report belongs to teacher
    $report = dbFetchOne("SELECT * FROM school_reports WHERE id = ? AND teacher_id = ?", [$reportId, $teacherId], 'ii');
    if (!$report) respondError('Report not found or access denied');
    
    // Check if already sent to admin
    $existing = dbFetchOne("SELECT id FROM report_recipients WHERE report_id = ? AND recipient_type = 'Admin'", [$reportId], 'i');
    if ($existing) respondError('Report already sent to admin');
    
    // Update report workflow status
    dbExecute(
        "UPDATE school_reports SET workflow_status = 'Pending', current_location = 'Admin', sent_to_admin = 1 WHERE id = ?",
        [$reportId], 'i'
    );
    
    // Create recipient record for admin
    dbInsert(
        "INSERT INTO report_recipients (report_id, recipient_type, recipient_id, access_level, status, assigned_by, assigned_by_id, message)
         VALUES (?, 'Admin', 0, 'approve', 'Pending', 'Teacher', ?, ?)",
        [$reportId, $teacherId, $message], 'iis'
    );
    
    // Log the sharing action
    dbInsert(
        "INSERT INTO report_sharing_log (report_id, sent_from_type, sent_from_id, sent_to_type, sent_to_id, action, access_level, message, status)
         VALUES (?, 'Teacher', ?, 'Admin', 0, 'Submitted', 'approve', ?, 'Pending')",
        [$reportId, $teacherId, $message], 'iis'
    );
    
    addActivityLog('Report Sent to Admin', "Report #{$reportId} sent to admin by teacher #{$teacherId}");
    respondSuccess([], 'Report sent to admin successfully');
}

function handleSendToParent() {
    $body = getJsonBody();
    if (!$body) respondError('Invalid request body');
    
    $reportId = (int)($body['reportId'] ?? 0);
    $teacherId = (int)($body['teacherId'] ?? 0);
    $parentId = (int)($body['parentId'] ?? 0);
    $studentId = (int)($body['studentId'] ?? 0);
    $message = trim($body['message'] ?? '');
    $pdfData = trim($body['pdfData'] ?? '');
    
    if (!$reportId || !$teacherId || !$parentId || !$studentId) {
        respondError('Report ID, Teacher ID, Parent ID, and Student ID required');
    }
    
    // Verify report belongs to teacher
    $report = dbFetchOne("SELECT * FROM school_reports WHERE id = ? AND teacher_id = ?", [$reportId, $teacherId], 'ii');
    if (!$report) respondError('Report not found or access denied');
    
    // Check if already sent to this parent
    $existing = dbFetchOne(
        "SELECT id FROM parent_report_access WHERE report_id = ? AND parent_id = ?",
        [$reportId, $parentId], 'ii'
    );
    if ($existing) respondError('Report already sent to this parent');
    
    // Update report workflow status
    dbExecute(
        "UPDATE school_reports SET workflow_status = 'Published', current_location = 'Parent', sent_to_parent = 1 WHERE id = ?",
        [$reportId], 'i'
    );
    
    // Create parent access record with PDF data
    dbInsert(
        "INSERT INTO parent_report_access (report_id, parent_id, student_id, access_granted_by, access_granted_by_id, access_level, message, pdf_data)
         VALUES (?, ?, ?, 'Teacher', ?, 'view', ?, ?)",
        [$reportId, $parentId, $studentId, $teacherId, $message, $pdfData ? $pdfData : null], 'iiisss'
    );
    
    // Create recipient record
    dbInsert(
        "INSERT INTO report_recipients (report_id, recipient_type, recipient_id, access_level, status, assigned_by, assigned_by_id, message)
         VALUES (?, 'Parent', ?, 'view', 'Pending', 'Teacher', ?, ?)",
        [$reportId, $parentId, $teacherId, $message], 'iis'
    );
    
    // Log the sharing action
    dbInsert(
        "INSERT INTO report_sharing_log (report_id, sent_from_type, sent_from_id, sent_to_type, sent_to_id, action, access_level, message, status)
         VALUES (?, 'Teacher', ?, 'Parent', ?, 'Published', 'view', ?, 'Completed')",
        [$reportId, $teacherId, $parentId, $message], 'iis'
    );
    
    addActivityLog('Report Sent to Parent', "Report #{$reportId} sent to parent #{$parentId} by teacher #{$teacherId}");
    respondSuccess([], 'Report sent to parent successfully');
}

function handleTeacherGetInbox() {
    $teacherId = (int)($_REQUEST['teacher_id'] ?? 0);
    if (!$teacherId) respondError('Teacher ID required');
    
    // Get reports returned from admin
    $returned = dbFetchAll(
        "SELECT sr.*, rsl.message as return_message, rsl.created_at as returned_at
         FROM school_reports sr
         JOIN report_sharing_log rsl ON sr.id = rsl.report_id
         WHERE rsl.sent_to_type = 'Teacher' AND rsl.sent_to_id = ? AND rsl.action = 'Returned'
         ORDER BY rsl.created_at DESC",
        [$teacherId], 'i'
    );
    
    $items = array_map(function($r) {
        return [
            'id' => $r['id'],
            'studentName' => $r['student_name'],
            'className' => $r['class_name'],
            'term' => $r['term'],
            'workflowStatus' => $r['workflow_status'],
            'currentLocation' => $r['current_location'],
            'returnMessage' => $r['return_message'],
            'returnedAt' => $r['returned_at'],
            'updatedAt' => $r['updated_at']
        ];
    }, $returned);
    
    respondSuccess(['items' => $items, 'total' => count($items)]);
}

function handleTeacherGetOutbox() {
    $teacherId = (int)($_REQUEST['teacher_id'] ?? 0);
    if (!$teacherId) respondError('Teacher ID required');
    
    // Get reports sent by this teacher
    $sent = dbFetchAll(
        "SELECT sr.*, rsl.sent_to_type, rsl.sent_to_id, rsl.action, rsl.status as sharing_status, rsl.created_at as sent_at
         FROM school_reports sr
         JOIN report_sharing_log rsl ON sr.id = rsl.report_id
         WHERE rsl.sent_from_type = 'Teacher' AND rsl.sent_from_id = ?
         ORDER BY rsl.created_at DESC",
        [$teacherId], 'i'
    );
    
    $items = array_map(function($r) {
        $recipientName = '';
        if ($r['sent_to_type'] === 'Admin') {
            $recipientName = 'Administrator';
        } elseif ($r['sent_to_type'] === 'Parent') {
            $parent = dbFetchOne("SELECT first_name, last_name FROM parents WHERE id = ?", [$r['sent_to_id']], 'i');
            $recipientName = $parent ? $parent['first_name'] . ' ' . $parent['last_name'] : 'Parent';
        }
        
        return [
            'id' => $r['id'],
            'studentName' => $r['student_name'],
            'className' => $r['class_name'],
            'term' => $r['term'],
            'workflowStatus' => $r['workflow_status'],
            'sentToType' => $r['sent_to_type'],
            'sentToId' => $r['sent_to_id'],
            'recipientName' => $recipientName,
            'action' => $r['action'],
            'sharingStatus' => $r['sharing_status'],
            'sentAt' => $r['sent_at']
        ];
    }, $sent);
    
    respondSuccess(['items' => $items, 'total' => count($items)]);
}

// ============================================================
// ADMIN ACTIONS
// ============================================================

function handleAdminGetPendingReports() {
    $pending = dbFetchAll(
        "SELECT sr.*, t.first_name as teacher_first_name, t.last_name as teacher_last_name, rr.message as submission_message
         FROM school_reports sr
         JOIN teachers t ON sr.teacher_id = t.id
         JOIN report_recipients rr ON sr.id = rr.report_id
         WHERE rr.recipient_type = 'Admin' AND rr.status = 'Pending'
         ORDER BY sr.created_at DESC"
    );
    
    $items = array_map(function($r) {
        return [
            'id' => $r['id'],
            'teacherId' => $r['teacher_id'],
            'teacherName' => $r['teacher_first_name'] . ' ' . $r['teacher_last_name'],
            'studentName' => $r['student_name'],
            'className' => $r['class_name'],
            'term' => $r['term'],
            'workflowStatus' => $r['workflow_status'],
            'submissionMessage' => $r['submission_message'],
            'createdAt' => $r['created_at'],
            'overallGrade' => $r['overall_grade']
        ];
    }, $pending);
    
    respondSuccess(['items' => $items, 'total' => count($items)]);
}

function handleAdminApproveReport() {
    $body = getJsonBody();
    if (!$body) respondError('Invalid request body');
    
    $reportId = (int)($body['reportId'] ?? 0);
    $adminId = (int)($body['adminId'] ?? 0);
    $feedback = trim($body['feedback'] ?? '');
    
    if (!$reportId || !$adminId) respondError('Report ID and Admin ID required');
    
    // Update report workflow status
    dbExecute(
        "UPDATE school_reports SET workflow_status = 'Approved', admin_feedback = ?, admin_reviewed_at = NOW() WHERE id = ?",
        [$feedback, $reportId], 'si'
    );
    
    // Update recipient status
    dbExecute(
        "UPDATE report_recipients SET status = 'Approved', responded_at = NOW() WHERE report_id = ? AND recipient_type = 'Admin'",
        [$reportId], 'i'
    );
    
    // Create admin review record
    dbInsert(
        "INSERT INTO admin_report_review (report_id, admin_id, decision, feedback, reviewed_at)
         VALUES (?, ?, 'Approved', ?, NOW())",
        [$reportId, $adminId, $feedback], 'iis'
    );
    
    // Log the action
    dbInsert(
        "INSERT INTO report_sharing_log (report_id, sent_from_type, sent_from_id, sent_to_type, sent_to_id, action, message, status, completed_at)
         VALUES (?, 'Admin', ?, 'Teacher', (SELECT teacher_id FROM school_reports WHERE id = ?), 'Approved', ?, 'Completed', NOW())",
        [$reportId, $adminId, $reportId, $feedback], 'iis'
    );
    
    addActivityLog('Report Approved', "Report #{$reportId} approved by admin #{$adminId}");
    respondSuccess([], 'Report approved successfully');
}

function handleAdminRejectReport() {
    $body = getJsonBody();
    if (!$body) respondError('Invalid request body');
    
    $reportId = (int)($body['reportId'] ?? 0);
    $adminId = (int)($body['adminId'] ?? 0);
    $feedback = trim($body['feedback'] ?? '');
    
    if (!$reportId || !$adminId) respondError('Report ID and Admin ID required');
    
    // Update report workflow status
    dbExecute(
        "UPDATE school_reports SET workflow_status = 'Rejected', admin_feedback = ?, admin_reviewed_at = NOW() WHERE id = ?",
        [$feedback, $reportId], 'si'
    );
    
    // Update recipient status
    dbExecute(
        "UPDATE report_recipients SET status = 'Rejected', responded_at = NOW() WHERE report_id = ? AND recipient_type = 'Admin'",
        [$reportId], 'i'
    );
    
    // Create admin review record
    dbInsert(
        "INSERT INTO admin_report_review (report_id, admin_id, decision, feedback, reviewed_at)
         VALUES (?, ?, 'Rejected', ?, NOW())",
        [$reportId, $adminId, $feedback], 'iis'
    );
    
    // Log the action
    dbInsert(
        "INSERT INTO report_sharing_log (report_id, sent_from_type, sent_from_id, sent_to_type, sent_to_id, action, message, status, completed_at)
         VALUES (?, 'Admin', ?, 'Teacher', (SELECT teacher_id FROM school_reports WHERE id = ?), 'Rejected', ?, 'Completed', NOW())",
        [$reportId, $adminId, $reportId, $feedback], 'iis'
    );
    
    addActivityLog('Report Rejected', "Report #{$reportId} rejected by admin #{$adminId}");
    respondSuccess([], 'Report rejected successfully');
}

function handleAdminReturnToTeacher() {
    $body = getJsonBody();
    if (!$body) respondError('Invalid request body');
    
    $reportId = (int)($body['reportId'] ?? 0);
    $adminId = (int)($body['adminId'] ?? 0);
    $message = trim($body['message'] ?? '');
    
    if (!$reportId || !$adminId) respondError('Report ID and Admin ID required');
    
    $report = dbFetchOne("SELECT teacher_id FROM school_reports WHERE id = ?", [$reportId], 'i');
    if (!$report) respondError('Report not found');
    
    // Update report workflow status
    dbExecute(
        "UPDATE school_reports SET workflow_status = 'Draft', current_location = 'Teacher', admin_feedback = ? WHERE id = ?",
        [$message, $reportId], 'si'
    );
    
    // Update recipient status
    dbExecute(
        "UPDATE report_recipients SET status = 'Completed', responded_at = NOW() WHERE report_id = ? AND recipient_type = 'Admin'",
        [$reportId], 'i'
    );
    
    // Create new recipient for teacher
    dbInsert(
        "INSERT INTO report_recipients (report_id, recipient_type, recipient_id, access_level, status, assigned_by, assigned_by_id, message)
         VALUES (?, 'Teacher', ?, 'edit', 'Pending', 'Admin', ?, ?)",
        [$reportId, $report['teacher_id'], $adminId, $message], 'iis'
    );
    
    // Log the action
    dbInsert(
        "INSERT INTO report_sharing_log (report_id, sent_from_type, sent_from_id, sent_to_type, sent_to_id, action, access_level, message, status, completed_at)
         VALUES (?, 'Admin', ?, 'Teacher', ?, 'Returned', 'edit', ?, 'Completed', NOW())",
        [$reportId, $adminId, $report['teacher_id'], $message], 'iis'
    );
    
    addActivityLog('Report Returned to Teacher', "Report #{$reportId} returned to teacher by admin #{$adminId}");
    respondSuccess([], 'Report returned to teacher successfully');
}

function handleAdminPublishToParent() {
    $body = getJsonBody();
    if (!$body) respondError('Invalid request body');
    
    $reportId = (int)($body['reportId'] ?? 0);
    $adminId = (int)($body['adminId'] ?? 0);
    $parentId = (int)($body['parentId'] ?? 0);
    $studentId = (int)($body['studentId'] ?? 0);
    $message = trim($body['message'] ?? '');
    
    if (!$reportId || !$adminId || !$parentId || !$studentId) {
        respondError('Report ID, Admin ID, Parent ID, and Student ID required');
    }
    
    // Check if already published to this parent
    $existing = dbFetchOne(
        "SELECT id FROM parent_report_access WHERE report_id = ? AND parent_id = ?",
        [$reportId, $parentId], 'ii'
    );
    if ($existing) respondError('Report already published to this parent');
    
    // Update report workflow status
    dbExecute(
        "UPDATE school_reports SET workflow_status = 'Published', current_location = 'Parent', sent_to_parent = 1 WHERE id = ?",
        [$reportId], 'i'
    );
    
    // Create parent access record
    dbInsert(
        "INSERT INTO parent_report_access (report_id, parent_id, student_id, access_granted_by, access_granted_by_id, access_level, message)
         VALUES (?, ?, ?, 'Admin', ?, 'view', ?)",
        [$reportId, $parentId, $studentId, $adminId, $message], 'iiis'
    );
    
    // Create recipient record
    dbInsert(
        "INSERT INTO report_recipients (report_id, recipient_type, recipient_id, access_level, status, assigned_by, assigned_by_id, message)
         VALUES (?, 'Parent', ?, 'view', 'Pending', 'Admin', ?, ?)",
        [$reportId, $parentId, $adminId, $message], 'iis'
    );
    
    // Log the action
    dbInsert(
        "INSERT INTO report_sharing_log (report_id, sent_from_type, sent_from_id, sent_to_type, sent_to_id, action, access_level, message, status, completed_at)
         VALUES (?, 'Admin', ?, 'Parent', ?, 'Published', 'view', ?, 'Completed', NOW())",
        [$reportId, $adminId, $parentId, $message], 'iis'
    );
    
    addActivityLog('Report Published to Parent', "Report #{$reportId} published to parent #{$parentId} by admin #{$adminId}");
    respondSuccess([], 'Report published to parent successfully');
}

function handleAdminGetAllReports() {
    $reports = dbFetchAll(
        "SELECT sr.*, t.first_name as teacher_first_name, t.last_name as teacher_last_name
         FROM school_reports sr
         JOIN teachers t ON sr.teacher_id = t.id
         ORDER BY sr.created_at DESC LIMIT 500"
    );
    
    $items = array_map(function($r) {
        return [
            'id' => $r['id'],
            'teacherId' => $r['teacher_id'],
            'teacherName' => $r['teacher_first_name'] . ' ' . $r['teacher_last_name'],
            'studentName' => $r['student_name'],
            'className' => $r['class_name'],
            'term' => $r['term'],
            'workflowStatus' => $r['workflow_status'],
            'currentLocation' => $r['current_location'],
            'sentToAdmin' => (bool)$r['sent_to_admin'],
            'sentToParent' => (bool)$r['sent_to_parent'],
            'overallGrade' => $r['overall_grade'],
            'status' => $r['status'],
            'createdAt' => $r['created_at'],
            'updatedAt' => $r['updated_at']
        ];
    }, $reports);
    
    respondSuccess(['items' => $items, 'total' => count($items)]);
}

// ============================================================
// PARENT ACTIONS
// ============================================================

function handleParentGetReports() {
    $parentId = (int)($_REQUEST['parent_id'] ?? 0);
    if (!$parentId) respondError('Parent ID required');
    
    $reports = dbFetchAll(
        "SELECT pra.*, sr.student_name, sr.class_name, sr.term, sr.overall_grade, sr.overall_comment, sr.report_data,
         t.first_name as teacher_first_name, t.last_name as teacher_last_name
         FROM parent_report_access pra
         JOIN school_reports sr ON pra.report_id = sr.id
         JOIN teachers t ON sr.teacher_id = t.id
         WHERE pra.parent_id = ? AND pra.status != 'Archived'
         ORDER BY pra.granted_at DESC",
        [$parentId], 'i'
    );
    
    $items = array_map(function($r) {
        $data = json_decode($r['report_data'] ?? '[]', true);
        return [
            'id' => $r['report_id'],
            'accessId' => $r['id'],
            'studentName' => $r['student_name'],
            'className' => $r['class_name'],
            'term' => $r['term'],
            'teacherName' => $r['teacher_first_name'] . ' ' . $r['teacher_last_name'],
            'overallGrade' => $r['overall_grade'],
            'overallComment' => $r['overall_comment'],
            'reportData' => $data ?: [],
            'accessLevel' => $r['access_level'],
            'status' => $r['status'],
            'grantedAt' => $r['granted_at'],
            'viewedAt' => $r['viewed_at'],
            'message' => $r['message']
        ];
    }, $reports);
    
    respondSuccess(['items' => $items, 'total' => count($items)]);
}

function handleParentViewReport() {
    $body = getJsonBody();
    if (!$body) respondError('Invalid request body');
    
    $accessId = (int)($body['accessId'] ?? 0);
    $parentId = (int)($body['parentId'] ?? 0);
    
    if (!$accessId || !$parentId) respondError('Access ID and Parent ID required');
    
    // Update viewed timestamp
    dbExecute(
        "UPDATE parent_report_access SET viewed_at = NOW(), status = 'Viewed' WHERE id = ? AND parent_id = ?",
        [$accessId, $parentId], 'ii'
    );
    
    // Get full report details
    $access = dbFetchOne(
        "SELECT pra.*, sr.* FROM parent_report_access pra JOIN school_reports sr ON pra.report_id = sr.id WHERE pra.id = ? AND pra.parent_id = ?",
        [$accessId, $parentId], 'ii'
    );
    
    if (!$access) respondError('Access record not found');
    
    $data = json_decode($access['report_data'] ?? '[]', true);
    
    respondSuccess([
        'report' => [
            'id' => $access['report_id'],
            'studentName' => $access['student_name'],
            'className' => $access['class_name'],
            'term' => $access['term'],
            'academicYear' => $access['academic_year'],
            'reportData' => $data ?: [],
            'overallComment' => $access['overall_comment'],
            'overallGrade' => $access['overall_grade'],
            'signatureImg' => $access['signature_img'],
            'teacherName' => $access['teacher_name'],
            'createdAt' => $access['created_at']
        ],
        'accessInfo' => [
            'id' => $access['id'],
            'accessLevel' => $access['access_level'],
            'grantedAt' => $access['granted_at'],
            'viewedAt' => $access['viewed_at'],
            'message' => $access['message']
        ]
    ]);
}

function handleParentSubmitFeedback() {
    $body = getJsonBody();
    if (!$body) respondError('Invalid request body');
    
    $reportId = (int)($body['reportId'] ?? 0);
    $parentId = (int)($body['parentId'] ?? 0);
    $feedback = trim($body['feedback'] ?? '');
    
    if (!$reportId || !$parentId) respondError('Report ID and Parent ID required');
    
    // Update report with parent feedback
    dbExecute(
        "UPDATE school_reports SET parent_feedback = ? WHERE id = ?",
        [$feedback, $reportId], 'si'
    );
    
    // Log the feedback
    dbInsert(
        "INSERT INTO report_sharing_log (report_id, sent_from_type, sent_from_id, sent_to_type, sent_to_id, action, message, status, completed_at)
         VALUES (?, 'Parent', ?, 'Teacher', (SELECT teacher_id FROM school_reports WHERE id = ?), 'Feedback Submitted', ?, 'Completed', NOW())",
        [$reportId, $parentId, $reportId, $feedback], 'iis'
    );
    
    addActivityLog('Parent Feedback Submitted', "Parent #{$parentId} submitted feedback for report #{$reportId}");
    respondSuccess([], 'Feedback submitted successfully');
}

// ============================================================
// GENERAL ACTIONS
// ============================================================

function handleGetReportHistory() {
    $reportId = (int)($_REQUEST['report_id'] ?? 0);
    if (!$reportId) respondError('Report ID required');
    
    $history = dbFetchAll(
        "SELECT rsl.* FROM report_sharing_log rsl WHERE rsl.report_id = ? ORDER BY rsl.created_at ASC",
        [$reportId], 'i'
    );
    
    $items = array_map(function($h) {
        $senderName = '';
        $receiverName = '';
        
        if ($h['sent_from_type'] === 'Teacher') {
            $teacher = dbFetchOne("SELECT first_name, last_name FROM teachers WHERE id = ?", [$h['sent_from_id']], 'i');
            $senderName = $teacher ? $teacher['first_name'] . ' ' . $teacher['last_name'] : 'Teacher';
        } elseif ($h['sent_from_type'] === 'Admin') {
            $admin = dbFetchOne("SELECT first_name, last_name FROM admins WHERE id = ?", [$h['sent_from_id']], 'i');
            $senderName = $admin ? $admin['first_name'] . ' ' . $admin['last_name'] : 'Admin';
        } elseif ($h['sent_from_type'] === 'Parent') {
            $parent = dbFetchOne("SELECT first_name, last_name FROM parents WHERE id = ?", [$h['sent_from_id']], 'i');
            $senderName = $parent ? $parent['first_name'] . ' ' . $parent['last_name'] : 'Parent';
        }
        
        if ($h['sent_to_type'] === 'Teacher') {
            $teacher = dbFetchOne("SELECT first_name, last_name FROM teachers WHERE id = ?", [$h['sent_to_id']], 'i');
            $receiverName = $teacher ? $teacher['first_name'] . ' ' . $teacher['last_name'] : 'Teacher';
        } elseif ($h['sent_to_type'] === 'Admin') {
            $receiverName = 'Administrator';
        } elseif ($h['sent_to_type'] === 'Parent') {
            $parent = dbFetchOne("SELECT first_name, last_name FROM parents WHERE id = ?", [$h['sent_to_id']], 'i');
            $receiverName = $parent ? $parent['first_name'] . ' ' . $parent['last_name'] : 'Parent';
        }
        
        return [
            'id' => $h['id'],
            'fromType' => $h['sent_from_type'],
            'fromId' => $h['sent_from_id'],
            'fromName' => $senderName,
            'toType' => $h['sent_to_type'],
            'toId' => $h['sent_to_id'],
            'toName' => $receiverName,
            'action' => $h['action'],
            'accessLevel' => $h['access_level'],
            'message' => $h['message'],
            'status' => $h['status'],
            'createdAt' => $h['created_at'],
            'completedAt' => $h['completed_at']
        ];
    }, $history);
    
    respondSuccess(['items' => $items, 'total' => count($items)]);
}

function handleGetReportRecipients() {
    $reportId = (int)($_REQUEST['report_id'] ?? 0);
    if (!$reportId) respondError('Report ID required');
    
    $recipients = dbFetchAll(
        "SELECT rr.* FROM report_recipients rr WHERE rr.report_id = ? ORDER BY rr.assigned_at ASC",
        [$reportId], 'i'
    );
    
    $items = array_map(function($r) {
        $recipientName = '';
        
        if ($r['recipient_type'] === 'Teacher') {
            $teacher = dbFetchOne("SELECT first_name, last_name FROM teachers WHERE id = ?", [$r['recipient_id']], 'i');
            $recipientName = $teacher ? $teacher['first_name'] . ' ' . $teacher['last_name'] : 'Teacher';
        } elseif ($r['recipient_type'] === 'Admin') {
            $recipientName = 'Administrator';
        } elseif ($r['recipient_type'] === 'Parent') {
            $parent = dbFetchOne("SELECT first_name, last_name FROM parents WHERE id = ?", [$r['recipient_id']], 'i');
            $recipientName = $parent ? $parent['first_name'] . ' ' . $parent['last_name'] : 'Parent';
        }
        
        return [
            'id' => $r['id'],
            'recipientType' => $r['recipient_type'],
            'recipientId' => $r['recipient_id'],
            'recipientName' => $recipientName,
            'accessLevel' => $r['access_level'],
            'status' => $r['status'],
            'assignedBy' => $r['assigned_by'],
            'assignedById' => $r['assigned_by_id'],
            'message' => $r['message'],
            'assignedAt' => $r['assigned_at'],
            'viewedAt' => $r['viewed_at'],
            'respondedAt' => $r['responded_at']
        ];
    }, $recipients);
    
    respondSuccess(['items' => $items, 'total' => count($items)]);
}