<?php
/**
 * API Configuration - Noah Christian Academy
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Handle preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Data storage path (JSON files)
define('DATA_DIR', __DIR__ . '/data');

// Ensure data directory exists
if (!is_dir(DATA_DIR)) {
    mkdir(DATA_DIR, 0755, true);
}

// Files
define('ADMIN_FILE', DATA_DIR . '/admin.json');
define('TEACHER_FILE', DATA_DIR . '/teachers.json');
define('REGISTRATIONS_FILE', DATA_DIR . '/registrations.json');
define('STUDENTS_FILE', DATA_DIR . '/students.json');
define('PAYMENTS_FILE', DATA_DIR . '/payments.json');

/**
 * Read JSON data from a file
 */
function readJson($file) {
    if (!file_exists($file)) {
        return null;
    }
    $content = file_get_contents($file);
    return json_decode($content, true);
}

/**
 * Write JSON data to a file
 */
function writeJson($file, $data) {
    $dir = dirname($file);
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    return file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT));
}

/**
 * Send JSON response
 */
function respond($data, $statusCode = 200) {
    // Clean any buffered output to prevent stray HTML/text from corrupting JSON
    while (ob_get_level()) {
        ob_end_clean();
    }
    http_response_code($statusCode);
    echo json_encode($data);
    exit();
}

/**
 * Send error response
 */
function respondError($message, $statusCode = 400) {
    respond(['success' => false, 'message' => $message], $statusCode);
}

/**
 * Send success response
 */
function respondSuccess($data = [], $message = 'Success') {
    respond(['success' => true, 'message' => $message, 'data' => $data]);
}

/**
 * Get JSON body from request
 */
function getJsonBody() {
    $input = file_get_contents('php://input');
    return json_decode($input, true);
}

/**
 * Get next ID from a collection
 */
function getNextId($collection) {
    if (empty($collection)) return 1;
    $ids = array_column($collection, 'id');
    return max($ids) + 1;
}

/**
 * Get default admin data structure
 */
function getDefaultAdminData() {
    return [
        'students' => [],
        'teachers' => [],
        'events' => [],
        'gallery' => [],
        'blog' => [],
        'services' => [],
        'messages' => [],
        'registrations' => [],
        'payments' => [],
        'attendance' => [],
        'content' => [],
        'classSummary' => [],
        'classTeachers' => [],
        'settings' => [
            'username' => 'admin',
            'displayName' => 'Admin',
            'email' => 'admin@nca.edu',
            'password' => 'admin123',
            'schoolName' => 'Noah Christian Academy'
        ],
        'activity' => []
    ];
}

/**
 * Get default teacher data structure
 */
function getDefaultTeacherData() {
    return [
        'accounts' => [],
        'assessments' => [],
        'pendingRegistrations' => []
    ];
}

/**
 * Load admin data
 */
function loadAdminData() {
    $data = readJson(ADMIN_FILE);
    if ($data === null) {
        $data = getDefaultAdminData();
        writeJson(ADMIN_FILE, $data);
    }
    // Ensure all sections exist
    $def = getDefaultAdminData();
    foreach ($def as $key => $value) {
        if (!isset($data[$key])) {
            $data[$key] = $value;
        }
    }
    return $data;
}

/**
 * Save admin data
 */
function saveAdminData($data) {
    return writeJson(ADMIN_FILE, $data);
}

/**
 * Load teacher data
 */
function loadTeacherData() {
    $data = readJson(TEACHER_FILE);
    if ($data === null) {
        $data = getDefaultTeacherData();
        writeJson(TEACHER_FILE, $data);
    }
    $def = getDefaultTeacherData();
    foreach ($def as $key => $value) {
        if (!isset($data[$key])) {
            $data[$key] = $value;
        }
    }
    return $data;
}

/**
 * Save teacher data
 */
function saveTeacherData($data) {
    return writeJson(TEACHER_FILE, $data);
}

/**
 * Add activity log
 */
function addActivity($action, $detail) {
    $data = loadAdminData();
    if (!isset($data['activity'])) $data['activity'] = [];
    array_unshift($data['activity'], [
        'action' => $action,
        'detail' => $detail,
        'time' => date('c')
    ]);
    if (count($data['activity']) > 50) {
        $data['activity'] = array_slice($data['activity'], 0, 50);
    }
    saveAdminData($data);
}