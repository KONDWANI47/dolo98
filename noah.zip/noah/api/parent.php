<?php
/**
 * Parent API Handler - Noah Christian Academy
 * Handles parent-specific operations: view children, progress, announcements, events,
 * register child, make payments, view report cards
 */

require_once __DIR__ . '/db.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Read JSON body if present
$rawInput = file_get_contents('php://input');
$jsonInput = json_decode($rawInput, true);

if (is_array($jsonInput)) {
    // Merge JSON input with GET/POST
    $input = array_merge($_GET, $_POST, $jsonInput);
} else {
    $input = $_REQUEST;
}

// Make $input available to all functions
$GLOBALS['input'] = $input;

$method = $_SERVER['REQUEST_METHOD'];
$action = $input['action'] ?? '';

switch ($action) {
    // GET actions
    case 'my_children':
        handleGetMyChildren();
        break;
    case 'child_progress':
        handleGetChildProgress();
        break;
    case 'child_report':
        handleGetChildReport();
        break;
    case 'workflow_reports':
        handleGetWorkflowReports();
        break;
    case 'view_workflow_report':
        handleViewWorkflowReport();
        break;
    case 'submit_report_feedback':
        handleSubmitReportFeedback();
        break;
    case 'announcements':
        handleGetAnnouncements();
        break;
    case 'upcoming_events':
        handleGetUpcomingEvents();
        break;
    case 'parent_profile':
        handleGetProfile();
        break;
    case 'my_payments':
        handleGetMyPayments();
        break;
    case 'my_registrations':
        handleGetMyRegistrations();
        break;
    case 'my_complaints':
        handleGetMyComplaints();
        break;
    case 'my_notifications':
        handleGetMyNotifications();
        break;
    case 'mark_notification_read':
        handleMarkNotificationRead();
        break;
    case 'login_history':
        handleGetLoginHistory();
        break;
    case 'get_authorized_ips':
        handleGetAuthorizedIps();
        break;
    case 'get_authorized_emails':
        handleGetAuthorizedEmails();
        break;
    // POST actions
    case 'update_profile':
        handleUpdateProfile();
        break;
    case 'change_password':
        handleChangePassword();
        break;
    case 'register_child':
        handleRegisterChild();
        break;
    case 'make_payment':
        handleMakePayment();
        break;
    case 'submit_complaint':
        handleSubmitComplaint();
        break;
    case 'edit_complaint':
        handleEditComplaint();
        break;
    case 'delete_complaint':
        handleDeleteComplaint();
        break;
    case 'add_authorized_ip':
        handleAddAuthorizedIp();
        break;
    case 'revoke_authorized_ip':
        handleRevokeAuthorizedIp();
        break;
    case 'add_authorized_email':
        handleAddAuthorizedEmail();
        break;
    case 'revoke_authorized_email':
        handleRevokeAuthorizedEmail();
        break;
    case 'my_lesson_plans':
        handleGetMyLessonPlans();
        break;
    case 'get_lesson_plan':
        handleGetLessonPlan();
        break;
    default:
        respondError('Unknown action: ' . $action, 404);
}

function handleGetMyChildren() {
    global $input;
    $parentId = (int)($input['parent_id'] ?? 0);
    if (!$parentId) respondError('Parent ID required');
    
    $parent = dbFetchOne("SELECT * FROM parents WHERE id = ?", [$parentId], 'i');
    if (!$parent) respondError('Parent not found');
    
    $studentIdsStr = $parent['student_ids'] ?? '';
    $studentIds = array_filter(array_map('trim', explode(',', $studentIdsStr)), 'is_numeric');
    
    if (empty($studentIds)) {
        respondSuccess(['items' => [], 'total' => 0]);
    }
    
    $placeholders = implode(',', array_fill(0, count($studentIds), '?'));
    $students = dbFetchAll(
        "SELECT * FROM students WHERE id IN ($placeholders) AND status = 'Active' ORDER BY first_name",
        $studentIds,
        str_repeat('i', count($studentIds))
    );
    
    $rows = array_map(function($r) {
        // Get average grade for this student
        $assessments = dbFetchAll(
            "SELECT score FROM assessments WHERE student_id = ?",
            [$r['id']],
            'i'
        );
        $avgScore = 0;
        if (count($assessments) > 0) {
            $total = array_sum(array_column($assessments, 'score'));
            $avgScore = round($total / count($assessments));
        }
        
        // Get attendance for current month
        $currentMonth = date('Y-m');
        $attendanceRows = dbFetchAll(
            "SELECT status FROM attendance WHERE student_id = ? AND DATE_FORMAT(date, '%Y-%m') = ?",
            [$r['id'], $currentMonth],
            'is'
        );
        $presentCount = 0;
        foreach ($attendanceRows as $a) {
            if ($a['status'] === 'Present') {
                $presentCount++;
            }
        }
        
        // Get total attendance days this month
        $totalDays = count($attendanceRows);
        
        return [
            'id' => $r['id'],
            'firstName' => $r['first_name'],
            'lastName' => $r['last_name'],
            'gender' => $r['gender'],
            'grade' => $r['grade'],
            'parent' => $r['parent_name'],
            'phone' => $r['phone'],
            'status' => $r['status'],
            'avgScore' => $avgScore,
            'presentThisMonth' => $presentCount,
            'totalDaysThisMonth' => $totalDays
        ];
    }, $students);
    
    respondSuccess(['items' => $rows, 'total' => count($rows)]);
}

function handleGetChildProgress() {
    global $input;
    $parentId = (int)($input['parent_id'] ?? 0);
    $studentId = (int)($input['student_id'] ?? 0);
    if (!$parentId || !$studentId) respondError('Parent ID and Student ID required');
    
    // Verify that the student belongs to the parent
    $parent = dbFetchOne("SELECT * FROM parents WHERE id = ?", [$parentId], 'i');
    if (!$parent) respondError('Parent not found');
    
    $studentIdsStr = $parent['student_ids'] ?? '';
    $studentIds = array_filter(array_map('trim', explode(',', $studentIdsStr)), 'is_numeric');
    if (!in_array($studentId, $studentIds)) respondError('Access denied to this student');
    
    $assessments = dbFetchAll(
        "SELECT * FROM assessments WHERE student_id = ? ORDER BY date DESC LIMIT 50",
        [$studentId], 'i'
    );
    
    $student = dbFetchOne("SELECT * FROM students WHERE id = ?", [$studentId], 'i');
    if (!$student) respondError('Student not found');
    
    $avgScore = 0;
    $subjectBreakdown = [];
    if (count($assessments) > 0) {
        $total = 0;
        foreach ($assessments as $a) {
            $total += $a['score'];
            $subj = $a['subject'];
            if (!isset($subjectBreakdown[$subj])) {
                $subjectBreakdown[$subj] = ['count' => 0, 'total' => 0];
            }
            $subjectBreakdown[$subj]['count']++;
            $subjectBreakdown[$subj]['total'] += $a['score'];
        }
        $avgScore = round($total / count($assessments));
    }
    
    $data = [
        'student' => [
            'id' => $student['id'],
            'firstName' => $student['first_name'],
            'lastName' => $student['last_name'],
            'gender' => $student['gender'],
            'grade' => $student['grade'],
        ],
        'assessments' => array_map(function($a) {
            return [
                'id' => $a['id'],
                'subject' => $a['subject'],
                'type' => $a['type'],
                'score' => $a['score'],
                'date' => $a['date'],
                'remarks' => $a['remarks']
            ];
        }, $assessments),
        'averageScore' => $avgScore,
        'totalAssessments' => count($assessments),
        'subjectBreakdown' => $subjectBreakdown
    ];
    
    respondSuccess($data);
}

function handleGetChildReport() {
    global $input;
    $parentId = (int)($input['parent_id'] ?? 0);
    $studentId = (int)($input['student_id'] ?? 0);
    if (!$parentId || !$studentId) respondError('Parent ID and Student ID required');
    
    // Verify that the student belongs to the parent
    $parent = dbFetchOne("SELECT * FROM parents WHERE id = ?", [$parentId], 'i');
    if (!$parent) respondError('Parent not found');
    
    $studentIdsStr = $parent['student_ids'] ?? '';
    $studentIds = array_filter(array_map('trim', explode(',', $studentIdsStr)), 'is_numeric');
    if (!in_array($studentId, $studentIds)) respondError('Access denied to this student');
    
    $student = dbFetchOne("SELECT * FROM students WHERE id = ?", [$studentId], 'i');
    if (!$student) respondError('Student not found');
    
    // Get all assessments grouped by subject
    $assessments = dbFetchAll(
        "SELECT * FROM assessments WHERE student_id = ? ORDER BY subject, date DESC",
        [$studentId], 'i'
    );
    
    // Get attendance record
    $attendance = dbFetchAll(
        "SELECT * FROM attendance WHERE student_id = ? ORDER BY date DESC LIMIT 100",
        [$studentId], 'i'
    );
    
    // Calculate subject averages
    $subjectData = [];
    $totalScore = 0;
    $totalCount = 0;
    
    foreach ($assessments as $a) {
        $subj = $a['subject'];
        if (!isset($subjectData[$subj])) {
            $subjectData[$subj] = [
                'assessments' => [],
                'total' => 0,
                'count' => 0,
                'average' => 0
            ];
        }
        $subjectData[$subj]['assessments'][] = [
            'type' => $a['type'],
            'score' => $a['score'],
            'date' => $a['date'],
            'remarks' => $a['remarks']
        ];
        $subjectData[$subj]['total'] += $a['score'];
        $subjectData[$subj]['count']++;
        $totalScore += $a['score'];
        $totalCount++;
    }
    
    foreach ($subjectData as $subj => &$data) {
        $data['average'] = $data['count'] > 0 ? round($data['total'] / $data['count']) : 0;
    }
    unset($data);
    
    $overallAverage = $totalCount > 0 ? round($totalScore / $totalCount) : 0;
    
    // Attendance stats
    $totalPresent = 0;
    $totalAbsent = 0;
    $totalLate = 0;
    foreach ($attendance as $a) {
        if ($a['status'] === 'Present') $totalPresent++;
        elseif ($a['status'] === 'Absent') $totalAbsent++;
        elseif ($a['status'] === 'Late') $totalLate++;
    }
    
    $data = [
        'student' => [
            'id' => $student['id'],
            'firstName' => $student['first_name'],
            'lastName' => $student['last_name'],
            'gender' => $student['gender'],
            'grade' => $student['grade'],
            'parentName' => $student['parent_name'],
            'phone' => $student['phone'],
            'enrollmentDate' => $student['enrollment_date'],
            'status' => $student['status']
        ],
        'overallAverage' => $overallAverage,
        'totalAssessments' => $totalCount,
        'subjects' => $subjectData,
        'attendance' => [
            'present' => $totalPresent,
            'absent' => $totalAbsent,
            'late' => $totalLate,
            'total' => count($attendance)
        ]
    ];
    
    respondSuccess($data);
}

function handleGetAnnouncements() {
    $rows = dbFetchAll(
        "SELECT * FROM announcements WHERE status = 'Published' AND (target_audience = 'all' OR target_audience = 'parents') ORDER BY pinned DESC, created_at DESC LIMIT 50"
    );
    
    $announcements = array_map(function($r) {
        return [
            'id' => $r['id'],
            'title' => $r['title'],
            'content' => $r['content'],
            'priority' => $r['priority'],
            'targetAudience' => $r['target_audience'],
            'status' => $r['status'],
            'createdBy' => $r['created_by'],
            'pinned' => (bool)$r['pinned'],
            'createdAt' => $r['created_at']
        ];
    }, $rows);
    
    respondSuccess(['items' => $announcements, 'total' => count($announcements)]);
}

function handleGetUpcomingEvents() {
    $today = date('Y-m-d');
    $rows = dbFetchAll(
        "SELECT * FROM events WHERE date >= ? AND status = 'Upcoming' ORDER BY date ASC LIMIT 20",
        [$today], 's'
    );
    
    $events = array_map(function($r) {
        return [
            'id' => $r['id'],
            'title' => $r['title'],
            'date' => $r['date'],
            'time' => $r['time'],
            'location' => $r['location'],
            'description' => $r['description'],
            'status' => $r['status']
        ];
    }, $rows);
    
    respondSuccess(['items' => $events, 'total' => count($events)]);
}

function handleGetProfile() {
    global $input;
    $parentId = (int)($input['parent_id'] ?? 0);
    if (!$parentId) respondError('Parent ID required');
    
    $parent = dbFetchOne("SELECT * FROM parents WHERE id = ?", [$parentId], 'i');
    if (!$parent) respondError('Parent not found');
    
    respondSuccess([
        'id' => $parent['id'],
        'firstName' => $parent['first_name'],
        'lastName' => $parent['last_name'],
        'username' => $parent['username'],
        'email' => $parent['email'],
        'phone' => $parent['phone'],
        'studentIds' => $parent['student_ids'],
        'approved' => (bool)$parent['approved'],
        'createdAt' => $parent['created_at'] ?? null
    ]);
}

function handleUpdateProfile() {
    $body = getJsonBody();
    $parentId = $body['parent_id'] ?? 0;
    if (!$parentId) respondError('Parent ID required');
    
    $fields = [];
    $params = [];
    $types = '';
    
    $allowed = ['first_name', 'last_name', 'username', 'email', 'phone', 'student_ids'];
    foreach ($allowed as $field) {
        if (isset($body[$field])) {
            $fields[] = "$field = ?";
            $params[] = $body[$field];
            $types .= 's';
        }
    }
    
    // Handle password update (hash it if provided)
    if (!empty($body['password'])) {
        $fields[] = "password = ?";
        $params[] = password_hash($body['password'], PASSWORD_DEFAULT);
        $types .= 's';
    }
    
    if (empty($fields)) respondError('No fields to update');
    
    $params[] = $parentId;
    $types .= 'i';
    
    dbExecute("UPDATE parents SET " . implode(', ', $fields) . " WHERE id = ?", $params, $types);
    respondSuccess([], 'Profile updated');
}

function handleChangePassword() {
    $body = getJsonBody();
    $parentId = $body['parentId'] ?? 0;
    $current = $body['currentPassword'] ?? '';
    $newPass = $body['newPassword'] ?? '';
    
    if (!$parentId) respondError('Parent ID required');
    
    $parent = dbFetchOne("SELECT * FROM parents WHERE id = ?", [$parentId], 'i');
    if (!$parent) respondError('Parent not found');
    if ($parent['password'] !== $current) respondError('Current password is incorrect');
    if (strlen($newPass) < 4) respondError('New password must be at least 4 characters');
    
    dbExecute("UPDATE parents SET password = ? WHERE id = ?", [$newPass, $parentId], 'si');
    respondSuccess([], 'Password changed');
}

function handleRegisterChild() {
    $body = getJsonBody();
    $parentId = $body['parent_id'] ?? 0;
    if (!$parentId) respondError('Parent ID required. Please ensure you are logged in.');
    
    $parent = dbFetchOne("SELECT * FROM parents WHERE id = ?", [$parentId], 'i');
    if (!$parent) respondError('Parent account not found. Please log in again.');
    
    $firstName = trim($body['firstName'] ?? '');
    $lastName = trim($body['lastName'] ?? '');
    $grade = trim($body['grade'] ?? '');
    $gender = trim($body['gender'] ?? '');
    $dob = $body['dob'] ?? null;
    $phone = trim($body['phone'] ?? '');
    $address = trim($body['address'] ?? '');
    $emergencyContact = trim($body['emergencyContact'] ?? '');
    $emergencyPhone = trim($body['emergencyPhone'] ?? '');
    $medicalInfo = trim($body['medicalInfo'] ?? '');
    
    if (empty($firstName) || empty($lastName)) {
        respondError('Child first and last name are required');
    }
    
    $parentName = $parent['first_name'] . ' ' . $parent['last_name'];
    $fullName = $firstName . ' ' . $lastName;
    
    // Create registration record as PENDING for admin approval
    $regId = dbInsert(
        "INSERT INTO registrations (student_name, grade, parent_name, phone, email, address, dob, notes, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Pending')",
        [$fullName, $grade, $parentName, $phone, $parent['email'], $address, $dob, 'Registered via parent portal. Emergency: ' . $emergencyContact . ' (' . $emergencyPhone . ') Medical: ' . $medicalInfo],
        'ssssssss'
    );
    
    if (!$regId) {
        respondError('Failed to submit registration. Please try again or contact admin.');
    }
    
    addActivityLog('Child Registration Submitted', "$fullName registered by parent #$parentId (pending approval)");
    respondSuccess(['registrationId' => $regId], 'Child registration submitted! Waiting for admin approval.');
}

function handleMakePayment() {
    $body = getJsonBody();
    $parentId = $body['parent_id'] ?? 0;
    if (!$parentId) respondError('Parent ID required');
    
    $parent = dbFetchOne("SELECT * FROM parents WHERE id = ?", [$parentId], 'i');
    if (!$parent) respondError('Parent not found');
    
    $payerName = $parent['first_name'] . ' ' . $parent['last_name'];
    $studentName = trim($body['studentName'] ?? '');
    $amount = (float)($body['amount'] ?? 0);
    $paymentType = trim($body['paymentType'] ?? '');
    $phone = trim($body['phone'] ?? $parent['phone'] ?? '');
    $paymentMethod = trim($body['paymentMethod'] ?? '');
    $notes = trim($body['notes'] ?? '');
    
    if (empty($studentName)) respondError('Student name is required');
    if ($amount <= 0) respondError('Amount must be greater than 0');
    if (empty($paymentType)) respondError('Payment type is required');
    if (empty($paymentMethod)) respondError('Payment method is required');
    
    $paymentId = dbInsert(
        "INSERT INTO payments (payer_name, student_name, amount, payment_type, phone, payment_method, notes, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'Pending')",
        [$payerName, $studentName, $amount, $paymentType, $phone, $paymentMethod, $notes],
        'ssdssss'
    );
    
    if (!$paymentId) {
        respondError('Failed to submit payment');
    }
    
    addActivityLog('Payment Made', "$payerName paid MK$amount for $studentName");
    respondSuccess(['paymentId' => $paymentId], 'Payment submitted successfully! It will be reviewed by admin.');
}

function handleGetMyPayments() {
    global $input;
    $parentId = (int)($input['parent_id'] ?? 0);
    if (!$parentId) respondError('Parent ID required');
    
    $parent = dbFetchOne("SELECT * FROM parents WHERE id = ?", [$parentId], 'i');
    if (!$parent) respondError('Parent not found');
    
    $payerName = $parent['first_name'] . ' ' . $parent['last_name'];
    
    $rows = dbFetchAll(
        "SELECT * FROM payments WHERE payer_name = ? ORDER BY created_at DESC LIMIT 50",
        [$payerName], 's'
    );
    
    $payments = array_map(function($r) {
        return [
            'id' => $r['id'],
            'payerName' => $r['payer_name'],
            'studentName' => $r['student_name'],
            'amount' => $r['amount'],
            'paymentType' => $r['payment_type'],
            'phone' => $r['phone'],
            'paymentMethod' => $r['payment_method'],
            'notes' => $r['notes'],
            'status' => $r['status'],
            'createdAt' => $r['created_at']
        ];
    }, $rows);
    
    respondSuccess(['items' => $payments, 'total' => count($payments)]);
}

function handleGetMyRegistrations() {
    global $input;
    $parentId = (int)($input['parent_id'] ?? 0);
    if (!$parentId) respondError('Parent ID required');
    
    $parent = dbFetchOne("SELECT * FROM parents WHERE id = ?", [$parentId], 'i');
    if (!$parent) respondError('Parent not found');
    
    $parentName = $parent['first_name'] . ' ' . $parent['last_name'];
    
    $rows = dbFetchAll(
        "SELECT * FROM registrations WHERE parent_name = ? ORDER BY created_at DESC LIMIT 50",
        [$parentName], 's'
    );
    
    $registrations = array_map(function($r) {
        return [
            'id' => $r['id'],
            'studentName' => $r['student_name'],
            'grade' => $r['grade'],
            'parentName' => $r['parent_name'],
            'phone' => $r['phone'],
            'email' => $r['email'],
            'address' => $r['address'],
            'dob' => $r['dob'],
            'notes' => $r['notes'],
            'status' => $r['status'],
            'createdAt' => $r['created_at']
        ];
    }, $rows);
    
    respondSuccess(['items' => $registrations, 'total' => count($registrations)]);
}

function handleGetWorkflowReports() {
    global $input;
    $parentId = (int)($input['parent_id'] ?? 0);
    if (!$parentId) respondError('Parent ID required');
    
    $reports = dbFetchAll(
        "SELECT pra.*, sr.student_name, sr.class_name, sr.term, sr.overall_grade, sr.overall_comment, sr.report_data,
         t.first_name as teacher_first_name, t.last_name as teacher_last_name
         FROM parent_report_access pra
         JOIN school_reports sr ON pra.report_id = sr.id
         JOIN teachers t ON sr.teacher_id = t.id
         WHERE pra.parent_id = ? AND pra.status != 'Archived'
         ORDER BY pra.granted_at DESC",
        [$parentId], 'i'
    );
    
    $items = array_map(function($r) {
        $data = json_decode($r['report_data'] ?? '[]', true);
        return [
            'id' => $r['report_id'],
            'accessId' => $r['id'],
            'studentName' => $r['student_name'],
            'className' => $r['class_name'],
            'term' => $r['term'],
            'teacherName' => $r['teacher_first_name'] . ' ' . $r['teacher_last_name'],
            'overallGrade' => $r['overall_grade'],
            'overallComment' => $r['overall_comment'],
            'reportData' => $data ?: [],
            'accessLevel' => $r['access_level'],
            'status' => $r['status'],
            'grantedAt' => $r['granted_at'],
            'viewedAt' => $r['viewed_at'],
            'message' => $r['message']
        ];
    }, $reports);
    
    respondSuccess(['items' => $items, 'total' => count($items)]);
}

function handleViewWorkflowReport() {
    $body = getJsonBody();
    if (!$body) respondError('Invalid request body');
    
    $accessId = (int)($body['accessId'] ?? 0);
    $parentId = (int)($body['parentId'] ?? 0);
    
    if (!$accessId || !$parentId) respondError('Access ID and Parent ID required');
    
    // Update viewed timestamp
    dbExecute(
        "UPDATE parent_report_access SET viewed_at = NOW(), status = 'Viewed' WHERE id = ? AND parent_id = ?",
        [$accessId, $parentId], 'ii'
    );
    
    // Get full report details
    $access = dbFetchOne(
        "SELECT pra.*, sr.* FROM parent_report_access pra JOIN school_reports sr ON pra.report_id = sr.id WHERE pra.id = ? AND pra.parent_id = ?",
        [$accessId, $parentId], 'ii'
    );
    
    if (!$access) respondError('Access record not found');
    
    $data = json_decode($access['report_data'] ?? '[]', true);
    
    respondSuccess([
        'report' => [
            'id' => $access['report_id'],
            'studentName' => $access['student_name'],
            'className' => $access['class_name'],
            'term' => $access['term'],
            'academicYear' => $access['academic_year'],
            'reportData' => $data ?: [],
            'overallComment' => $access['overall_comment'],
            'overallGrade' => $access['overall_grade'],
            'signatureImg' => $access['signature_img'],
            'teacherName' => $access['teacher_name'],
            'createdAt' => $access['created_at']
        ],
        'accessInfo' => [
            'id' => $access['id'],
            'accessLevel' => $access['access_level'],
            'grantedAt' => $access['granted_at'],
            'viewedAt' => $access['viewed_at'],
            'message' => $access['message']
        ]
    ]);
}

function handleSubmitReportFeedback() {
    $body = getJsonBody();
    if (!$body) respondError('Invalid request body');
    
    $reportId = (int)($body['reportId'] ?? 0);
    $parentId = (int)($body['parentId'] ?? 0);
    $feedback = trim($body['feedback'] ?? '');
    
    if (!$reportId || !$parentId) respondError('Report ID and Parent ID required');
    
    // Update report with parent feedback
    dbExecute(
        "UPDATE school_reports SET parent_feedback = ? WHERE id = ?",
        [$feedback, $reportId], 'si'
    );
    
    // Log the feedback
    dbInsert(
        "INSERT INTO report_sharing_log (report_id, sent_from_type, sent_from_id, sent_to_type, sent_to_id, action, message, status, completed_at)
         VALUES (?, 'Parent', ?, 'Teacher', (SELECT teacher_id FROM school_reports WHERE id = ?), 'Feedback Submitted', ?, 'Completed', NOW())",
        [$reportId, $parentId, $reportId, $feedback], 'iis'
    );
    
    addActivityLog('Parent Feedback Submitted', "Parent #{$parentId} submitted feedback for report #{$reportId}");
    respondSuccess([], 'Feedback submitted successfully');
}

function handleGetMyComplaints() {
    global $input;
    $parentId = (int)($input['parent_id'] ?? 0);
    if (!$parentId) respondError('Parent ID required');
    
    $parent = dbFetchOne("SELECT * FROM parents WHERE id = ?", [$parentId], 'i');
    if (!$parent) respondError('Parent not found');
    
    $parentName = $parent['first_name'] . ' ' . $parent['last_name'];
    
    $rows = dbFetchAll(
        "SELECT * FROM complaints WHERE parent_name = ? ORDER BY created_at DESC LIMIT 50",
        [$parentName], 's'
    );
    
    $complaints = array_map(function($r) {
        return [
            'id' => $r['id'],
            'parentName' => $r['parent_name'],
            'className' => $r['class_name'],
            'complaintText' => $r['complaint_text'],
            'status' => $r['status'],
            'teacherResponse' => $r['teacher_response'],
            'respondedAt' => $r['responded_at'],
            'createdAt' => $r['created_at']
        ];
    }, $rows);
    
    respondSuccess(['items' => $complaints, 'total' => count($complaints)]);
}

function handleSubmitComplaint() {
    $body = getJsonBody();
    $parentId = $body['parent_id'] ?? 0;
    if (!$parentId) respondError('Parent ID required');
    
    $parent = dbFetchOne("SELECT * FROM parents WHERE id = ?", [$parentId], 'i');
    if (!$parent) respondError('Parent not found');
    
    $parentName = $parent['first_name'] . ' ' . $parent['last_name'];
    $studentName = trim($body['studentName'] ?? '');
    $className = trim($body['className'] ?? '');
    $complaintText = trim($body['complaintText'] ?? '');
    
    if (empty($studentName)) respondError('Student name is required');
    if (empty($className)) respondError('Class/Grade is required');
    if (empty($complaintText)) respondError('Complaint details are required');
    
    $complaintId = dbInsert(
        "INSERT INTO complaints (parent_id, parent_name, class_name, complaint_text, status) VALUES (?, ?, ?, ?, 'pending')",
        [$parentId, $parentName, $className, $complaintText],
        'isss'
    );
    
    if (!$complaintId) {
        respondError('Failed to submit complaint');
    }
    
    addActivityLog('Complaint Submitted', "Complaint from parent #$parentId for class $className");
    respondSuccess(['complaintId' => $complaintId], 'Complaint submitted successfully! The class teacher will review it.');
}

function handleGetMyNotifications() {
    global $input;
    $parentId = (int)($input['parent_id'] ?? 0);
    if (!$parentId) respondError('Parent ID required');
    
    $notifications = dbFetchAll(
        "SELECT * FROM admin_notifications WHERE related_id = ? ORDER BY created_at DESC LIMIT 20",
        [$parentId], 'i'
    );
    
    $items = array_map(function($r) {
        return [
            'id' => $r['id'],
            'type' => $r['type'],
            'title' => $r['title'],
            'message' => $r['message'],
            'isRead' => (bool)$r['is_read'],
            'readAt' => $r['read_at'],
            'createdAt' => $r['created_at']
        ];
    }, $notifications);
    
    respondSuccess(['items' => $items, 'total' => count($items)]);
}

function handleMarkNotificationRead() {
    $body = getJsonBody();
    $notificationId = (int)($body['notification_id'] ?? 0);
    
    if (!$notificationId) respondError('Notification ID required');
    
    dbExecute(
        "UPDATE admin_notifications SET is_read = 1, read_at = NOW() WHERE id = ?",
        [$notificationId], 'i'
    );
    
    respondSuccess([], 'Notification marked as read');
}

function handleEditComplaint() {
    $body = getJsonBody();
    $parentId = $body['parent_id'] ?? 0;
    if (!$parentId) respondError('Parent ID required');
    
    $parent = dbFetchOne("SELECT * FROM parents WHERE id = ?", [$parentId], 'i');
    if (!$parent) respondError('Parent not found');
    
    $complaintId = (int)($body['complaint_id'] ?? 0);
    $newComplaintText = trim($body['complaint_text'] ?? '');
    
    if (!$complaintId) respondError('Complaint ID required');
    if (empty($newComplaintText)) respondError('Complaint text is required');
    
    // Verify complaint belongs to this parent
    $complaint = dbFetchOne("SELECT * FROM complaints WHERE id = ?", [$complaintId], 'i');
    if (!$complaint) respondError('Complaint not found');
    
    if ($complaint['parent_id'] !== $parentId) {
        respondError('You can only edit your own complaints');
    }
    
    // Only allow editing pending complaints
    if ($complaint['status'] !== 'pending') {
        respondError('You can only edit pending complaints');
    }
    
    // Update complaint
    dbExecute(
        "UPDATE complaints SET complaint_text = ?, updated_at = NOW() WHERE id = ?",
        [$newComplaintText, $complaintId],
        'si'
    );
    
    addActivityLog('Complaint Edited', "Parent #$parentId edited complaint #$complaintId");
    respondSuccess([], 'Complaint updated successfully');
}

function handleDeleteComplaint() {
    $body = getJsonBody();
    $parentId = $body['parent_id'] ?? 0;
    if (!$parentId) respondError('Parent ID required');
    
    $parent = dbFetchOne("SELECT * FROM parents WHERE id = ?", [$parentId], 'i');
    if (!$parent) respondError('Parent not found');
    
    $complaintId = (int)($body['complaint_id'] ?? 0);
    if (!$complaintId) respondError('Complaint ID required');
    
    // Verify complaint belongs to this parent
    $complaint = dbFetchOne("SELECT * FROM complaints WHERE id = ?", [$complaintId], 'i');
    if (!$complaint) respondError('Complaint not found');
    
    if ($complaint['parent_id'] !== $parentId) {
        respondError('You can only delete your own complaints');
    }
    
    // Delete complaint
    dbExecute("DELETE FROM complaints WHERE id = ?", [$complaintId], 'i');
    
    addActivityLog('Complaint Deleted', "Parent #$parentId deleted complaint #$complaintId");
    respondSuccess([], 'Complaint deleted successfully');
}

function handleGetLoginHistory() {
    global $input;
    $parentId = (int)($input['parent_id'] ?? 0);
    if (!$parentId) respondError('Parent ID required');

    $logs = dbFetchAll(
        "SELECT * FROM parent_login_logs WHERE parent_id = ? ORDER BY id DESC LIMIT 50",
        [$parentId], 'i'
    );

    $items = array_map(function($log) {
        return [
            'id' => $log['id'],
            'ipAddress' => $log['ip_address'] ?? '',
            'browser' => $log['browser'] ?? '',
            'os' => $log['os'] ?? '',
            'device' => $log['device'] ?? '',
            'userAgent' => $log['user_agent'] ?? '',
            'loginStatus' => $log['login_status'] ?? '',
            'loginAt' => $log['created_at'] ?? ''
        ];
    }, $logs);

    respondSuccess(['items' => $items, 'total' => count($items)]);
}

function handleGetAuthorizedIps() {
    global $input;
    $parentId = (int)($input['parent_id'] ?? 0);
    if (!$parentId) respondError('Parent ID required');
    
    $ips = dbFetchAll(
        "SELECT * FROM parent_authorized_ips WHERE parent_id = ? ORDER BY created_at DESC",
        [$parentId], 'i'
    );
    
    $items = array_map(function($ip) {
        return [
            'id' => $ip['id'],
            'ipAddress' => $ip['ip_address'],
            'description' => $ip['description'],
            'createdAt' => $ip['created_at']
        ];
    }, $ips);
    
    respondSuccess(['items' => $items, 'total' => count($items)]);
}

function handleGetAuthorizedEmails() {
    global $input;
    $parentId = (int)($input['parent_id'] ?? 0);
    if (!$parentId) respondError('Parent ID required');
    
    $emails = dbFetchAll(
        "SELECT * FROM parent_authorized_emails WHERE parent_id = ? ORDER BY created_at DESC",
        [$parentId], 'i'
    );
    
    $items = array_map(function($email) {
        return [
            'id' => $email['id'],
            'email' => $email['email'],
            'description' => $email['description'],
            'createdAt' => $email['created_at']
        ];
    }, $emails);
    
    respondSuccess(['items' => $items, 'total' => count($items)]);
}

function handleAddAuthorizedIp() {
    $body = getJsonBody();
    $parentId = $body['parent_id'] ?? 0;
    $ipAddress = trim($body['ip_address'] ?? '');
    $description = trim($body['description'] ?? '');
    
    if (!$parentId) respondError('Parent ID required');
    if (empty($ipAddress)) respondError('IP address is required');
    
    $ipId = dbInsert(
        "INSERT INTO parent_authorized_ips (parent_id, ip_address, description, created_at) VALUES (?, ?, ?, NOW())",
        [$parentId, $ipAddress, $description],
        'iss'
    );
    
    if (!$ipId) {
        respondError('Failed to add authorized IP');
    }
    
    addActivityLog('Authorized IP Added', "Parent #$parentId added IP: $ipAddress");
    respondSuccess(['id' => $ipId], 'Authorized IP added successfully');
}

function handleRevokeAuthorizedIp() {
    $body = getJsonBody();
    $ipId = $body['ip_id'] ?? 0;
    
    if (!$ipId) respondError('IP ID required');
    
    dbExecute("DELETE FROM parent_authorized_ips WHERE id = ?", [$ipId], 'i');
    
    addActivityLog('Authorized IP Revoked', "IP #$ipId revoked");
    respondSuccess([], 'Authorized IP revoked successfully');
}

function handleAddAuthorizedEmail() {
    $body = getJsonBody();
    $parentId = $body['parent_id'] ?? 0;
    $email = trim($body['email'] ?? '');
    $description = trim($body['description'] ?? '');
    
    if (!$parentId) respondError('Parent ID required');
    if (empty($email)) respondError('Email address is required');
    
    $emailId = dbInsert(
        "INSERT INTO parent_authorized_emails (parent_id, email, description, created_at) VALUES (?, ?, ?, NOW())",
        [$parentId, $email, $description],
        'iss'
    );
    
    if (!$emailId) {
        respondError('Failed to add authorized email');
    }
    
    addActivityLog('Authorized Email Added', "Parent #$parentId added email: $email");
    respondSuccess(['id' => $emailId], 'Authorized email added successfully');
}

function handleRevokeAuthorizedEmail() {
    $body = getJsonBody();
    $emailId = $body['email_id'] ?? 0;

    if (!$emailId) respondError('Email ID required');

    dbExecute("DELETE FROM parent_authorized_emails WHERE id = ?", [$emailId], 'i');

    addActivityLog('Authorized Email Revoked', "Email #$emailId revoked");
    respondSuccess([], 'Authorized email revoked successfully');
}

// ===== LESSON PLANS (Read-only for Parents) =====

function handleGetMyLessonPlans() {
    global $input;
    $parentId = (int)($input['parent_id'] ?? 0);
    if (!$parentId) respondError('Parent ID required');

    // Get parent's children and their classes
    $parent = dbFetchOne("SELECT * FROM parents WHERE id = ?", [$parentId], 'i');
    if (!$parent) respondError('Parent not found');

    $studentIdsStr = $parent['student_ids'] ?? '';
    $studentIds = array_filter(array_map('trim', explode(',', $studentIdsStr)), 'is_numeric');

    if (empty($studentIds)) {
        respondSuccess(['items' => [], 'total' => 0]);
    }

    // Get children's classes
    $placeholders = implode(',', array_fill(0, count($studentIds), '?'));
    $students = dbFetchAll(
        "SELECT id, grade FROM students WHERE id IN ($placeholders) AND status = 'Active'",
        $studentIds,
        str_repeat('i', count($studentIds))
    );

    $classNames = array_unique(array_column($students, 'grade'));

    if (empty($classNames)) {
        respondSuccess(['items' => [], 'total' => 0]);
    }

    // Get published lesson plans for these classes
    $classPlaceholders = implode(',', array_fill(0, count($classNames), '?'));
    $rows = dbFetchAll(
        "SELECT lp.*, t.first_name as teacher_first_name, t.last_name as teacher_last_name
         FROM lesson_plans lp
         JOIN teachers t ON lp.teacher_id = t.id
         WHERE lp.class_name IN ($classPlaceholders) AND lp.status = 'published'
         ORDER BY lp.lesson_date DESC, lp.created_at DESC LIMIT 200",
        $classNames,
        str_repeat('s', count($classNames))
    );

    $lessonPlans = array_map(function($r) {
        return [
            'id' => $r['id'],
            'teacherName' => $r['teacher_first_name'] . ' ' . $r['teacher_last_name'],
            'academicYear' => $r['academic_year'],
            'term' => $r['term'],
            'week' => $r['week'],
            'gradeLevel' => $r['grade_level'],
            'className' => $r['class_name'],
            'subject' => $r['subject'],
            'topic' => $r['topic'],
            'lessonDate' => $r['lesson_date'],
            'startTime' => $r['start_time'],
            'duration' => $r['duration'],
            'status' => $r['status'],
            'createdAt' => $r['created_at'],
            'updatedAt' => $r['updated_at']
        ];
    }, $rows);

    respondSuccess(['items' => $lessonPlans, 'total' => count($lessonPlans)]);
}

function handleGetLessonPlan() {
    global $input;
    $lessonPlanId = (int)($input['lesson_plan_id'] ?? 0);
    $parentId = (int)($input['parent_id'] ?? 0);

    if (!$lessonPlanId) respondError('Lesson Plan ID required');
    if (!$parentId) respondError('Parent ID required');

    // Verify parent has access to this lesson plan's class
    $parent = dbFetchOne("SELECT * FROM parents WHERE id = ?", [$parentId], 'i');
    if (!$parent) respondError('Parent not found');

    $studentIdsStr = $parent['student_ids'] ?? '';
    $studentIds = array_filter(array_map('trim', explode(',', $studentIdsStr)), 'is_numeric');

    if (empty($studentIds)) {
        respondError('No children found for this parent');
    }

    $placeholders = implode(',', array_fill(0, count($studentIds), '?'));
    $students = dbFetchAll(
        "SELECT grade FROM students WHERE id IN ($placeholders) AND status = 'Active'",
        $studentIds,
        str_repeat('i', count($studentIds))
    );

    $classNames = array_unique(array_column($students, 'grade'));

    // Get lesson plan (only if published and for child's class)
    $lessonPlan = dbFetchOne(
        "SELECT lp.*, t.first_name as teacher_first_name, t.last_name as teacher_last_name
         FROM lesson_plans lp
         JOIN teachers t ON lp.teacher_id = t.id
         WHERE lp.id = ? AND lp.status = 'published'",
        [$lessonPlanId],
        'i'
    );

    if (!$lessonPlan) respondError('Lesson plan not found or not published');

    // Verify class access
    if (!in_array($lessonPlan['class_name'], $classNames)) {
        respondError('You do not have access to this lesson plan');
    }

    // Get objectives
    $objectives = dbFetchAll(
        "SELECT * FROM lesson_objectives WHERE lesson_plan_id = ? ORDER BY display_order ASC",
        [$lessonPlanId],
        'i'
    );

    // Get materials
    $materials = dbFetchAll(
        "SELECT * FROM lesson_materials WHERE lesson_plan_id = ? ORDER BY display_order ASC",
        [$lessonPlanId],
        'i'
    );

    // Get activities
    $activities = dbFetchAll(
        "SELECT * FROM lesson_activities WHERE lesson_plan_id = ? ORDER BY phase, display_order ASC",
        [$lessonPlanId],
        'i'
    );

    respondSuccess([
        'lessonPlan' => [
            'id' => $lessonPlan['id'],
            'teacherName' => $lessonPlan['teacher_first_name'] . ' ' . $lessonPlan['teacher_last_name'],
            'academicYear' => $lessonPlan['academic_year'],
            'term' => $lessonPlan['term'],
            'week' => $lessonPlan['week'],
            'gradeLevel' => $lessonPlan['grade_level'],
            'className' => $lessonPlan['class_name'],
            'subject' => $lessonPlan['subject'],
            'topic' => $lessonPlan['topic'],
            'lessonDate' => $lessonPlan['lesson_date'],
            'startTime' => $lessonPlan['start_time'],
            'duration' => $lessonPlan['duration'],
            'successCriteria' => $lessonPlan['success_criteria'],
            'assessment' => $lessonPlan['assessment'],
            'homework' => $lessonPlan['homework'],
            'reflection' => $lessonPlan['reflection'],
            'whatWentWell' => $lessonPlan['what_went_well'],
            'challenges' => $lessonPlan['challenges'],
            'learnersSupport' => $lessonPlan['learners_support'],
            'improvements' => $lessonPlan['improvements'],
            'status' => $lessonPlan['status'],
            'createdAt' => $lessonPlan['created_at'],
            'updatedAt' => $lessonPlan['updated_at']
        ],
        'objectives' => array_map(function($r) {
            return [
                'id' => $r['id'],
                'objectiveText' => $r['objective_text'],
                'displayOrder' => $r['display_order']
            ];
        }, $objectives),
        'materials' => array_map(function($r) {
            return [
                'id' => $r['id'],
                'materialType' => $r['material_type'],
                'materialName' => $r['material_name'],
                'displayOrder' => $r['display_order']
            ];
        }, $materials),
        'activities' => array_map(function($r) {
            return [
                'id' => $r['id'],
                'phase' => $r['phase'],
                'teacherActivity' => $r['teacher_activity'],
                'learnerActivity' => $r['learner_activity'],
                'displayOrder' => $r['display_order']
            ];
        }, $activities)
    ]);
}