<?php
require_once __DIR__ . '/db.php';
header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') respondError('Method not allowed', 405);
$id = (int)($_POST['id'] ?? 0);
if (!$id) respondError('Application ID is required', 400);
try {
    $exists = dbFetchOne("SELECT id FROM job_applications WHERE id = ?", [$id], 'i');
    if (!$exists) respondError('Job application not found', 404);
    dbExecute("DELETE FROM application_documents WHERE application_id = ?", [$id], 'i');
    $deleted = dbExecute("DELETE FROM job_applications WHERE id = ?", [$id], 'i');
    if ($deleted === false) respondError('Failed to delete application');
    addActivityLog('Job Application Deleted', "Application #$id deleted");
    respondSuccess(['id' => $id], 'Application deleted');
} catch (Throwable $e) {
    respondError('Failed to delete application: ' . $e->getMessage(), 500);
}
