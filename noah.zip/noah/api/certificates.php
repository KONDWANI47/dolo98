<?php
/**
 * Certificate API - Noah Christian Academy
 * Handles certificate templates, generation, and management
 */

require_once __DIR__ . '/db.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$action = $_GET['action'] ?? '';

try {
    switch ($action) {
        case 'save_template':
            saveCertificateTemplate();
            break;
        case 'get_templates':
            getCertificateTemplates();
            break;
        case 'get_template':
            getCertificateTemplate();
            break;
        case 'delete_template':
            deleteCertificateTemplate();
            break;
        case 'generate_certificate':
            generateCertificate();
            break;
        case 'get_recent_certificates':
            getRecentCertificates();
            break;
        case 'get_certificate':
            getCertificate();
            break;
        case 'verify_certificate':
            verifyCertificate();
            break;
        default:
            respondError('Invalid action');
    }
} catch (Exception $e) {
    respondError($e->getMessage());
}

// ===== SAVE TEMPLATE =====
function saveCertificateTemplate() {
    $data = getJsonBody();

    if (empty($data['name'])) {
        respondError('Template name is required');
    }

    $conn = getDB();

    $sql = "INSERT INTO certificate_templates (
        name, description, category, canvas_width, canvas_height, unit, orientation,
        background_type, background_color, design_json, preview_image,
        created_by, created_by_name, is_system_template, is_public, status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $params = [
        $data['name'],
        $data['description'] ?? '',
        $data['category'] ?? 'Academic',
        $data['canvas_width'] ?? 1123,
        $data['canvas_height'] ?? 794,
        $data['unit'] ?? 'px',
        $data['orientation'] ?? 'landscape',
        $data['background_type'] ?? 'solid',
        $data['background_color'] ?? '#FFFFFF',
        $data['design_json'] ?? '{}',
        $data['preview_image'] ?? '',
        $data['created_by'] ?? null,
        $data['created_by_name'] ?? 'System',
        0,
        1,
        'active'
    ];

    $templateId = dbInsert($sql, $params);

    if ($templateId > 0) {
        respondSuccess(['id' => $templateId], 'Template saved successfully');
    } else {
        respondError('Failed to save template');
    }
}

// ===== GET TEMPLATES =====
function getCertificateTemplates() {
    $conn = getDB();
    $teacherId = $_GET['teacher_id'] ?? 0;

    $sql = "SELECT * FROM certificate_templates
            WHERE status = 'active'
            AND (is_public = 1 OR created_by = ?)
            ORDER BY created_at DESC";

    $templates = dbFetchAll($sql, [$teacherId]);

    respondSuccess(['items' => $templates], 'Templates retrieved successfully');
}

// ===== GET SINGLE TEMPLATE =====
function getCertificateTemplate() {
    $templateId = $_GET['id'] ?? 0;

    if (!$templateId) {
        respondError('Template ID is required');
    }

    $conn = getDB();
    $template = dbFetchOne("SELECT * FROM certificate_templates WHERE id = ?", [$templateId]);

    if ($template) {
        respondSuccess($template, 'Template retrieved successfully');
    } else {
        respondError('Template not found');
    }
}

// ===== DELETE TEMPLATE =====
function deleteCertificateTemplate() {
    $templateId = $_GET['id'] ?? 0;

    if (!$templateId) {
        respondError('Template ID is required');
    }

    $conn = getDB();
    $affected = dbExecute("UPDATE certificate_templates SET status = 'deleted' WHERE id = ?", [$templateId]);

    if ($affected > 0) {
        respondSuccess([], 'Template deleted successfully');
    } else {
        respondError('Failed to delete template');
    }
}

// ===== GENERATE CERTIFICATE =====
function generateCertificate() {
    $data = getJsonBody();

    if (empty($data['template_id']) || empty($data['student_id'])) {
        respondError('Template ID and Student ID are required');
    }

    $conn = getDB();

    // Generate certificate number
    $certificateNumber = 'CERT-' . date('Y') . '-' . str_pad(rand(1, 99999), 5, '0', STR_PAD_LEFT);

    $sql = "INSERT INTO certificate_records (
        template_id, certificate_number, student_id, student_name, student_class,
        award_title, description, date_issued, academic_year,
        generated_by, generated_by_name, status, data_json
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $params = [
        $data['template_id'],
        $certificateNumber,
        $data['student_id'],
        $data['student_name'] ?? '',
        $data['student_class'] ?? '',
        $data['award_title'] ?? '',
        $data['description'] ?? '',
        $data['date_issued'] ?? date('Y-m-d'),
        $data['academic_year'] ?? date('Y'),
        $data['generated_by'] ?? null,
        $data['generated_by_name'] ?? 'System',
        'active',
        json_encode($data)
    ];

    $certificateId = dbInsert($sql, $params);

    if ($certificateId > 0) {
        respondSuccess(['id' => $certificateId, 'certificate_number' => $certificateNumber], 'Certificate generated successfully');
    } else {
        respondError('Failed to generate certificate');
    }
}

// ===== GET RECENT CERTIFICATES =====
function getRecentCertificates() {
    $teacherId = $_GET['teacher_id'] ?? 0;
    $limit = $_GET['limit'] ?? 10;

    $conn = getDB();
    $sql = "SELECT * FROM certificate_records
            WHERE generated_by = ? OR 1=1
            ORDER BY created_at DESC
            LIMIT ?";

    $certificates = dbFetchAll($sql, [$teacherId, $limit]);

    respondSuccess(['items' => $certificates], 'Certificates retrieved successfully');
}

// ===== GET SINGLE CERTIFICATE =====
function getCertificate() {
    $certificateId = $_GET['id'] ?? 0;

    if (!$certificateId) {
        respondError('Certificate ID is required');
    }

    $conn = getDB();
    $certificate = dbFetchOne("SELECT * FROM certificate_records WHERE id = ?", [$certificateId]);

    if ($certificate) {
        respondSuccess($certificate, 'Certificate retrieved successfully');
    } else {
        respondError('Certificate not found');
    }
}

// ===== VERIFY CERTIFICATE =====
function verifyCertificate() {
    $certificateNumber = $_GET['certificate_number'] ?? '';

    if (!$certificateNumber) {
        respondError('Certificate number is required');
    }

    $conn = getDB();
    $certificate = dbFetchOne(
        "SELECT * FROM certificate_records WHERE certificate_number = ? AND status = 'active'",
        [$certificateNumber]
    );

    if ($certificate) {
        // Log verification
        dbInsert(
            "INSERT INTO certificate_verification_log (certificate_id, certificate_number, verification_result, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)",
            [
                $certificate['id'],
                $certificateNumber,
                'valid',
                $_SERVER['REMOTE_ADDR'] ?? '',
                $_SERVER['HTTP_USER_AGENT'] ?? ''
            ]
        );

        respondSuccess($certificate, 'Certificate verified successfully');
    } else {
        respondError('Certificate not found or invalid');
    }
}
?>
