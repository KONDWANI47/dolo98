<?php
/**
 * Test Merge Script - Merges only account_deletion_requests table
 * Safe test before full merge
 */

require_once __DIR__ . '/db.php';

// Path to the SQL file
$sqlFile = __DIR__ . '/../if0_42680773_noh.sql';

// Check if file exists
if (!file_exists($sqlFile)) {
    die("SQL file not found: $sqlFile\n");
}

// Read the SQL file
$sqlContent = file_get_contents($sqlFile);

// Extract only account_deletion_requests INSERT statements
$pattern = '/INSERT INTO `account_deletion_requests`.*?VALUES\s*(.*?);/s';
preg_match($pattern, $sqlContent, $matches);

if (empty($matches[0])) {
    die("No INSERT statements found for account_deletion_requests\n");
}

$insertStatement = $matches[0];

// Convert to INSERT IGNORE to handle duplicates
$modifiedStatement = preg_replace('/^INSERT\s+INTO/i', 'INSERT IGNORE INTO', $insertStatement);

echo "Testing merge for account_deletion_requests table...\n";
echo "================================\n";
echo "Statement to execute:\n";
echo substr($modifiedStatement, 0, 500) . "...\n\n";

try {
    // Check current count before
    $beforeResult = dbFetchOne("SELECT COUNT(*) as count FROM account_deletion_requests");
    $beforeCount = $beforeResult['count'] ?? 0;
    echo "Current records in account_deletion_requests: $beforeCount\n\n";
    
    // Execute the INSERT IGNORE
    dbExecute($modifiedStatement);
    
    // Check count after
    $afterResult = dbFetchOne("SELECT COUNT(*) as count FROM account_deletion_requests");
    $afterCount = $afterResult['count'] ?? 0;
    
    $addedCount = $afterCount - $beforeCount;
    
    echo "✓ Test successful!\n";
    echo "Records before: $beforeCount\n";
    echo "Records after: $afterCount\n";
    echo "New records added: $addedCount\n";
    echo "================================\n";
    echo "Test passed. You can now run the full merge.\n";
    
} catch (Exception $e) {
    echo "✗ Error: " . $e->getMessage() . "\n";
    echo "Test failed. Please review the error.\n";
}
