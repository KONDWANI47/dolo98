<?php
/**
 * AI Chat API - Noah Christian Academy
 * Main endpoint for AI assistant interactions
 */

// Disable error output to prevent HTML in JSON responses
ini_set('display_errors', 0);
error_reporting(E_ALL);

// Log errors to file
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/../logs/ai_errors.log');

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/ai_service.php';
require_once __DIR__ . '/ai_tools.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Read JSON body if present
$rawInput = file_get_contents('php://input');
$jsonInput = json_decode($rawInput, true);

if (is_array($jsonInput)) {
    $input = $jsonInput;
} else {
    $input = $_POST;
}

// Make $input available to all functions
$GLOBALS['input'] = $input;

// Create AI tables if they don't exist
try {
    $conn = getDB();
    $conn->query("CREATE TABLE IF NOT EXISTS ai_conversations (
        id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT NOT NULL,
        user_role VARCHAR(20) NOT NULL,
        conversation_id VARCHAR(100) DEFAULT NULL,
        user_message TEXT NOT NULL,
        ai_response TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_user (user_id, user_role),
        INDEX idx_conversation (conversation_id),
        INDEX idx_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $conn->query("CREATE TABLE IF NOT EXISTS ai_usage_log (
        id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT NOT NULL,
        user_role VARCHAR(20) NOT NULL,
        message TEXT,
        prompt_tokens INT DEFAULT 0,
        completion_tokens INT DEFAULT 0,
        total_tokens INT DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_user (user_id),
        INDEX idx_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $conn->query("CREATE TABLE IF NOT EXISTS ai_user_profile (
        id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT NOT NULL,
        user_role VARCHAR(20) NOT NULL,
        interaction_tone VARCHAR(20) DEFAULT 'neutral',
        friendliness_score INT DEFAULT 50,
        preferred_topics TEXT,
        communication_style VARCHAR(20) DEFAULT 'balanced',
        last_interaction TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        total_interactions INT DEFAULT 0,
        INDEX idx_user (user_id),
        UNIQUE KEY unique_user (user_id, user_role)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $conn->query("CREATE TABLE IF NOT EXISTS ai_topic_history (
        id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT NOT NULL,
        user_role VARCHAR(20) NOT NULL,
        topic VARCHAR(100) NOT NULL,
        subtopic VARCHAR(100),
        helpful_rating INT DEFAULT 3,
        interaction_count INT DEFAULT 1,
        last_discussed TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_user_topic (user_id, topic),
        INDEX idx_user (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
} catch (Exception $e) {
    error_log("Database connection error: " . $e->getMessage());
    respondError('Database connection failed', 500);
}

$action = trim($input['action'] ?? '');

if ($action === '') {
    respondError('Missing action parameter', 400);
}

switch ($action) {
    case 'test':
        respondSuccess(['status' => 'API is working', 'time' => date('Y-m-d H:i:s')], 'API test successful');
        break;
    case 'test_model':
        $testResult = testModelConnection();
        if ($testResult['success']) {
            respondSuccess($testResult, 'Model connection successful');
        } else {
            respondError($testResult['message'], 500);
        }
        break;
    case 'chat':
        handleChat();
        break;
    case 'stream':
        handleStream();
        break;
    case 'upload':
        handleUpload();
        break;
    case 'generate_image':
        handleGenerateImage();
        break;
    case 'confirm_action':
        handleConfirmAction();
        break;
    case 'get_conversations':
        handleGetConversations();
        break;
    case 'delete_conversation':
        handleDeleteConversation();
        break;
    default:
        respondError('Unknown action: ' . $action, 404);
}

/**
 * Handle chat request
 */
function handleChat() {
    global $input;

    // Validate required fields
    $message = $input['message'] ?? '';
    $userId = $input['user_id'] ?? null;
    $userRole = $input['user_role'] ?? '';
    $userClass = $input['user_class'] ?? null;
    $conversationId = $input['conversation_id'] ?? null;
    $history = $input['history'] ?? [];

    if (empty($message) || empty($userId) || empty($userRole)) {
        respondError('Missing required fields: message, user_id, user_role', 400);
    }

    // Validate user role
    if (!in_array($userRole, ['admin', 'teacher', 'parent'])) {
        respondError('Invalid user role', 400);
    }

    // Analyze user message tone
    $tone = analyzeUserTone($message);

    // Detect language
    $language = detectLanguage($message);

    // Extract topics from message
    $topics = extractTopics($message, $userRole);

    // Track topics
    foreach ($topics as $topic) {
        trackTopic($userId, $userRole, $topic);
    }

    // Update user profile
    $userProfile = updateUserProfile($userId, $userRole, $message, $tone);
    $userProfile['user_id'] = $userId; // Add user_id for topic tracking

    // Initialize AI service
    $aiService = new AIService();

    // Initialize tools with user context
    $tools = new AITools($userId, $userRole, $userClass);

    // Build system prompt with context (including user profile, topics, and language)
    $systemPrompt = buildSystemPrompt($userRole, $userClass, $userProfile, $topics, $userId, $language);

    // Build messages array
    $messages = [
        ['role' => 'system', 'content' => $systemPrompt],
        ...$history,
        ['role' => 'user', 'content' => $message]
    ];

    // Define available tools for AI
    $toolDefinitions = getToolDefinitions($userRole);

    // Generate response
    $response = $aiService->generateResponse($messages, $toolDefinitions);

    if (!$response['success']) {
        respondError($response['message'], 500);
    }

    // Handle tool calls if present
    if (!empty($response['tool_calls'])) {
        $toolResults = executeToolCalls($tools, $response['tool_calls']);

        // Add tool results to conversation and get final response
        $messages[] = [
            'role' => 'assistant',
            'content' => $response['content'],
            'tool_calls' => $response['tool_calls']
        ];

        foreach ($toolResults as $result) {
            $messages[] = [
                'role' => 'tool',
                'tool_call_id' => $result['tool_call_id'],
                'content' => json_encode($result['result'])
            ];
        }

        $finalResponse = $aiService->generateResponse($messages, $toolDefinitions);

        if (!$finalResponse['success']) {
            respondError($finalResponse['message'], 500);
        }

        $response = $finalResponse;
    }

    // Save conversation to database
    saveConversation($userId, $userRole, $conversationId, $message, $response['content']);

    // Log AI usage
    logAIUsage($userId, $userRole, $message, $response['usage'] ?? null);

    respondSuccess([
        'content' => $response['content'],
        'conversation_id' => $conversationId,
        'usage' => $response['usage']
    ]);
}

/**
 * Handle streaming chat request
 */
function handleStream() {
    $body = getJsonBody();

    $message = $body['message'] ?? '';
    $userId = $body['user_id'] ?? null;
    $userRole = $body['user_role'] ?? '';
    $userClass = $body['user_class'] ?? null;
    $history = $body['history'] ?? [];

    if (empty($message) || empty($userId) || empty($userRole)) {
        echo "data: " . json_encode(['error' => 'Missing required fields']) . "\n\n";
        ob_flush();
        flush();
        exit();
    }

    // Set headers for streaming
    header('Content-Type: text/event-stream');
    header('Cache-Control: no-cache');
    header('Connection: keep-alive');

    $aiService = new AIService();
    $tools = new AITools($userId, $userRole, $userClass);

    $systemPrompt = buildSystemPrompt($userRole, $userClass);
    $messages = [
        ['role' => 'system', 'content' => $systemPrompt],
        ...$history,
        ['role' => 'user', 'content' => $message]
    ];

    $toolDefinitions = getToolDefinitions($userRole);

    // Stream response
    $aiService->streamResponse($messages, $toolDefinitions);

    exit();
}

/**
 * Generate image using Pollinations.ai (free, no API key)
 */
function generateImageAI($prompt) {
    // Pollinations.ai - completely free, no API key needed
    $encodedPrompt = urlencode($prompt);
    $imageUrl = "https://image.pollinations.ai/prompt/{$encodedPrompt}?width=1024&height=1024&seed=" . rand(1, 1000);

    // Download the image
    $ch = curl_init($imageUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

    $imageData = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);

    if ($error) {
        error_log("Pollinations CURL Error: " . $error);
        return ['success' => false, 'message' => 'Failed to connect to image service: ' . $error];
    }

    if ($httpCode >= 400 || empty($imageData)) {
        error_log("Pollinations HTTP Error: {$httpCode}");
        return ['success' => false, 'message' => 'Image generation failed'];
    }

    // Save image to local storage
    $uploadDir = __DIR__ . '/../uploads/ai_images/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    $filename = uniqid('img_', true) . '.png';
    $filepath = $uploadDir . $filename;

    if (file_put_contents($filepath, $imageData) === false) {
        return ['success' => false, 'message' => 'Failed to save generated image'];
    }

    // Return URL to the image
    $localImageUrl = '../uploads/ai_images/' . $filename;

    return [
        'success' => true,
        'image_url' => $localImageUrl,
        'prompt' => $prompt,
        'model' => 'Pollinations.ai (Stable Diffusion)'
    ];
}

/**
 * Handle image generation using Pollinations.ai
 */
function handleGenerateImage() {
    global $input;

    $prompt = $input['prompt'] ?? '';
    $userId = $input['user_id'] ?? null;
    $userRole = $input['user_role'] ?? '';

    if (empty($prompt)) {
        respondError('Missing prompt', 400);
    }

    // Use the same function as AI tool calls
    $result = generateImageAI($prompt);

    if (!$result['success']) {
        respondError($result['message'], 500);
    }

    respondSuccess([
        'image_url' => $result['image_url'],
        'prompt' => $result['prompt'],
        'model' => $result['model']
    ], 'Image generated successfully');
}

/**
 * Handle file upload for document analysis
 */
function handleUpload() {
    if (!isset($_FILES['file'])) {
        respondError('No file uploaded', 400);
    }

    $file = $_FILES['file'];
    $userId = $_POST['user_id'] ?? null;
    $userRole = $_POST['user_role'] ?? '';

    // Check for upload errors
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $errorMessages = [
            UPLOAD_ERR_INI_SIZE => 'File exceeds upload_max_filesize directive in php.ini',
            UPLOAD_ERR_FORM_SIZE => 'File exceeds MAX_FILE_SIZE directive in HTML form',
            UPLOAD_ERR_PARTIAL => 'File was only partially uploaded',
            UPLOAD_ERR_NO_FILE => 'No file was uploaded',
            UPLOAD_ERR_NO_TMP_DIR => 'Missing temporary folder',
            UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk',
            UPLOAD_ERR_EXTENSION => 'A PHP extension stopped the file upload'
        ];
        $errorMsg = $errorMessages[$file['error']] ?? 'Unknown upload error';
        respondError('Upload error: ' . $errorMsg, 400);
    }

    // Validate file
    $allowedExtensions = ['pdf', 'docx', 'xlsx', 'csv', 'txt', 'jpg', 'jpeg', 'png', 'gif', 'webp'];

    $fileExt = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

    if (!in_array($fileExt, $allowedExtensions)) {
        respondError('Invalid file type. Allowed: PDF, DOCX, XLSX, CSV, TXT, JPG, PNG, GIF. You uploaded: ' . $fileExt, 400);
    }

    // Create upload directory
    $uploadDir = __DIR__ . '/../uploads/ai_documents/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    // Generate unique filename
    $filename = uniqid('doc_', true) . '_' . $file['name'];
    $filepath = $uploadDir . $filename;

    // Move file
    if (!move_uploaded_file($file['tmp_name'], $filepath)) {
        respondError('Failed to upload file to server. Check directory permissions.', 500);
    }

    // Extract text based on file type
    $content = extractDocumentContent($filepath, $fileExt);

    respondSuccess([
        'filename' => $filename,
        'content' => $content,
        'file_size' => $file['size'],
        'file_type' => $fileExt
    ], 'File uploaded successfully');
}

/**
 * Handle action confirmation
 */
function handleConfirmAction() {
    global $input;

    $actionId = $input['action_id'] ?? '';
    $confirmed = $input['confirmed'] ?? false;
    $userId = $input['user_id'] ?? null;

    if (empty($actionId)) {
        respondError('Missing action_id', 400);
    }

    // This would execute the confirmed action
    // For now, just log it
    addActivityLog('AI Action Confirmed', "Action ID: {$actionId}, Confirmed: " . ($confirmed ? 'Yes' : 'No'));

    respondSuccess(['confirmed' => $confirmed], 'Action confirmation recorded');
}

/**
 * Get conversation history
 */
function handleGetConversations() {
    global $input;

    $userId = $input['user_id'] ?? null;
    $userRole = $input['user_role'] ?? '';
    $limit = $input['limit'] ?? 20;

    if (empty($userId) || empty($userRole)) {
        respondError('Missing user_id or user_role', 400);
    }

    $conversations = dbFetchAll(
        "SELECT id, user_message, ai_response, created_at
         FROM ai_conversations
         WHERE user_id = ? AND user_role = ?
         ORDER BY created_at DESC
         LIMIT ?",
        [$userId, $userRole, $limit],
        'isi'
    );

    respondSuccess($conversations);
}

/**
 * Delete conversation
 */
function handleDeleteConversation() {
    global $input;

    $conversationId = $input['conversation_id'] ?? null;
    $userId = $input['user_id'] ?? null;

    if (empty($conversationId) || empty($userId)) {
        respondError('Missing conversation_id or user_id', 400);
    }

    $affected = dbExecute(
        "DELETE FROM ai_conversations WHERE id = ? AND user_id = ?",
        [$conversationId, $userId],
        'ii'
    );

    if ($affected > 0) {
        respondSuccess([], 'Conversation deleted');
    } else {
        respondError('Conversation not found or access denied', 404);
    }
}

/**
 * Get or create user profile
 */
function getUserProfile($userId, $userRole) {
    $profile = dbFetchOne(
        "SELECT * FROM ai_user_profile WHERE user_id = ? AND user_role = ?",
        [$userId, $userRole],
        'is'
    );

    if (!$profile) {
        // Create new profile
        dbInsert(
            "INSERT INTO ai_user_profile (user_id, user_role, interaction_tone, friendliness_score, communication_style, total_interactions)
             VALUES (?, ?, 'neutral', 50, 'balanced', 0)",
            [$userId, $userRole],
            'is'
        );
        $profile = [
            'interaction_tone' => 'neutral',
            'friendliness_score' => 50,
            'communication_style' => 'balanced',
            'total_interactions' => 0
        ];
    }

    return $profile;
}

/**
 * Detect if message is in Chichewa
 */
function detectLanguage($message) {
    $message = strtolower($message);

    // Common Chichewa words
    $chichewaWords = [
        'moni', 'muli', 'bwanji', 'tikudziwa', 'ndife', 'anu', 'anthu',
        'mwana', 'ana', 'achikulire', 'sukulu', 'kugwira', 'ndalama',
        'zambiri', 'bwino', 'zosatheka', 'chifukwa', 'koma', 'pangani',
        'ndi', 'kapena', 'kotero', 'chinthu', 'malo', 'mwina', 'tsopano',
        'masiku', 'lero', 'adazi', 'bambo', 'mayi', 'atate', 'azamba',
        'achibaba', 'akazi', 'mibadwo', 'mwana', 'mwana wanu', 'wane',
        'kalasi', 'phunziro', 'chikondi', 'tatizo', 'thandizo', 'tikufuna',
        'tidzakwaniritsa', 'zathu', 'zimene', 'zothandiza', 'kukhala',
        'abale', 'agogo', 'azamba', 'achikulire', 'ana a sukulu',
        'phunziro', 'mayiko', 'nyumba', 'chikondi', 'umboni', 'chikumbumtsata'
    ];

    $chichewaCount = 0;
    foreach ($chichewaWords as $word) {
        if (strpos($message, $word) !== false) {
            $chichewaCount++;
        }
    }

    // If more than 2 Chichewa words detected, consider it Chichewa
    return $chichewaCount >= 2 ? 'chichewa' : 'english';
}

/**
 * Analyze user message tone
 */
function analyzeUserTone($message) {
    $message = strtolower($message);

    // Friendly indicators (English)
    $friendlyWords = ['please', 'thank', 'thanks', 'appreciate', 'kindly', 'would you', 'could you', 'help me', 'hello', 'hi', 'hey', 'good morning', 'good afternoon'];
    // Friendly indicators (Chichewa)
    $friendlyWordsChichewa = ['ndikumbukira', 'zikomo', 'zikuone', 'bwino', 'wabwino', 'nthandizeni', 'moni', 'tikufuna'];
    $friendlyCount = 0;
    foreach ($friendlyWords as $word) {
        if (strpos($message, $word) !== false) {
            $friendlyCount++;
        }
    }
    foreach ($friendlyWordsChichewa as $word) {
        if (strpos($message, $word) !== false) {
            $friendlyCount++;
        }
    }

    // Formal indicators (English)
    $formalWords = ['request', 'require', 'regarding', 'accordingly', 'kindly', 'respectfully', 'sir', 'madam'];
    $formalCount = 0;
    foreach ($formalWords as $word) {
        if (strpos($message, $word) !== false) {
            $formalCount++;
        }
    }

    // Casual indicators (English)
    $casualWords = ['lol', 'haha', 'omg', 'awesome', 'cool', 'yeah', 'nope', 'yep', 'gonna', 'wanna'];
    $casualCount = 0;
    foreach ($casualWords as $word) {
        if (strpos($message, $word) !== false) {
            $casualCount++;
        }
    }

    // Determine tone
    if ($friendlyCount > $formalCount && $friendlyCount > $casualCount) {
        return 'friendly';
    } elseif ($formalCount > $friendlyCount && $formalCount > $casualCount) {
        return 'formal';
    } elseif ($casualCount > $friendlyCount && $casualCount > $formalCount) {
        return 'casual';
    } else {
        return 'neutral';
    }
}

/**
 * Extract topics from user message
 */
function extractTopics($message, $userRole) {
    $message = strtolower($message);
    $topics = [];

    // School-related topics (English + Chichewa)
    $topicMap = [
        'student' => ['student', 'students', 'pupil', 'learners', 'child', 'children', 'mwana', 'ana', 'aphunziri', 'mphunziti'],
        'attendance' => ['attendance', 'absent', 'present', 'attend', 'kubwerera', 'tsogolo', 'sukulu'],
        'results' => ['result', 'results', 'marks', 'grade', 'score', 'performance', 'exam', 'zotsatira', 'maikhalidwe', 'mayiko'],
        'lesson' => ['lesson', 'lesson plan', 'teaching', 'curriculum', 'phunziro', 'kugwira ntchito', 'kufunditsa'],
        'homework' => ['homework', 'assignment', 'task', 'ntchito', 'kugwira'],
        'exam' => ['exam', 'examination', 'test', 'quiz', 'assessment', 'mayiko', 'zivikitsa'],
        'fee' => ['fee', 'payment', 'balance', 'money', 'cost', 'ndalama', 'maliro'],
        'teacher' => ['teacher', 'staff', 'faculty', 'atsikulu', 'mphunzitsi', 'akulu'],
        'class' => ['class', 'form', 'grade', 'standard', 'level', 'kalasi', 'gulu', 'bungwe'],
        'early_childhood' => ['daycare', 'day care', 'nursery', 'baby', 'reception', 'early childhood', 'preschool', 'kindergarten', 'mwana wamkulu', 'achikulire'],
        'primary' => ['standard 1', 'standard 2', 'standard 3', 'standard 4', 'standard 5', 'standard 6', 'standard 7', 'standard 8', 'std 1', 'std 2', 'std 3', 'std 4', 'std 5', 'std 6', 'std 7', 'std 8', 'grade 1', 'grade 2', 'grade 3', 'grade 4', 'grade 5', 'grade 6', 'grade 7', 'grade 8'],
        'subject' => ['subject', 'math', 'english', 'science', 'history', 'chidule', 'chigawo'],
        'announcement' => ['announcement', 'notice', 'news', 'mawu', 'nkhani', 'zidikwire'],
        'event' => ['event', 'calendar', 'schedule', 'nthawi', 'kalendala', 'ndondomeko'],
        'report' => ['report', 'summary', 'analysis', 'malingaliro', 'mawonekedwe']
    ];

    foreach ($topicMap as $topic => $keywords) {
        foreach ($keywords as $keyword) {
            if (strpos($message, $keyword) !== false) {
                if (!in_array($topic, $topics)) {
                    $topics[] = $topic;
                }
                break;
            }
        }
    }

    return $topics;
}

/**
 * Get related topics based on user's interests
 */
function getRelatedTopics($userId, $userRole, $currentTopic) {
    $relatedTopics = [];

    // Topic relationships
    $topicRelations = [
        'student' => ['attendance', 'results', 'class', 'subject', 'early_childhood', 'primary'],
        'attendance' => ['student', 'class', 'report', 'early_childhood', 'primary'],
        'results' => ['student', 'exam', 'subject', 'report', 'early_childhood', 'primary'],
        'lesson' => ['subject', 'class', 'homework', 'exam', 'early_childhood', 'primary'],
        'homework' => ['subject', 'lesson', 'student', 'early_childhood', 'primary'],
        'exam' => ['results', 'subject', 'lesson', 'student', 'early_childhood', 'primary'],
        'fee' => ['student', 'report', 'early_childhood', 'primary'],
        'teacher' => ['class', 'subject', 'student', 'early_childhood', 'primary'],
        'class' => ['student', 'attendance', 'results', 'teacher', 'early_childhood', 'primary'],
        'subject' => ['lesson', 'exam', 'results', 'student', 'early_childhood', 'primary'],
        'early_childhood' => ['student', 'attendance', 'results', 'lesson', 'homework', 'teacher'],
        'primary' => ['student', 'attendance', 'results', 'lesson', 'homework', 'exam', 'subject'],
        'report' => ['results', 'attendance', 'student', 'fee', 'early_childhood', 'primary'],
        'event' => ['announcement', 'class', 'student', 'early_childhood', 'primary'],
        'announcement' => ['event', 'student', 'teacher', 'early_childhood', 'primary']
    ];

    // Add related topics based on current topic
    if (isset($topicRelations[$currentTopic])) {
        foreach ($topicRelations[$currentTopic] as $related) {
            if (!in_array($related, $relatedTopics)) {
                $relatedTopics[] = $related;
            }
        }
    }

    // Get user's topic history
    if ($userId) {
        $userTopics = dbFetchAll(
            "SELECT topic, interaction_count, helpful_rating
             FROM ai_topic_history
             WHERE user_id = ? AND user_role = ?
             ORDER BY interaction_count DESC, helpful_rating DESC
             LIMIT 10",
            [$userId, $userRole],
            'is'
        );

        // Add topics user frequently asks about
        foreach ($userTopics as $ut) {
            if ($ut['topic'] !== $currentTopic && !in_array($ut['topic'], $relatedTopics)) {
                $relatedTopics[] = $ut['topic'];
            }
        }
    }

    return array_slice($relatedTopics, 0, 5); // Return top 5
}

/**
 * Track topic in history
 */
function trackTopic($userId, $userRole, $topic, $subtopic = null) {
    // Check if topic exists
    $existing = dbFetchOne(
        "SELECT * FROM ai_topic_history WHERE user_id = ? AND user_role = ? AND topic = ?",
        [$userId, $userRole, $topic],
        'iss'
    );

    if ($existing) {
        // Update existing
        dbExecute(
            "UPDATE ai_topic_history
             SET interaction_count = interaction_count + 1,
                 last_discussed = NOW()
             WHERE id = ?",
            [$existing['id']],
            'i'
        );
    } else {
        // Insert new
        dbInsert(
            "INSERT INTO ai_topic_history (user_id, user_role, topic, subtopic, interaction_count)
             VALUES (?, ?, ?, ?, 1)",
            [$userId, $userRole, $topic, $subtopic],
            'isss'
        );
    }
}

/**
 * Update user profile based on interaction
 */
function updateUserProfile($userId, $userRole, $message, $tone) {
    $profile = getUserProfile($userId, $userRole);

    // Update friendliness score
    $friendlinessChange = 0;
    if ($tone === 'friendly') {
        $friendlinessChange = 5;
    } elseif ($tone === 'casual') {
        $friendlinessChange = 3;
    } elseif ($tone === 'formal') {
        $friendlinessChange = -2;
    }

    $newFriendliness = max(0, min(100, $profile['friendliness_score'] + $friendlinessChange));

    // Update tone (exponential moving average)
    if ($profile['interaction_tone'] === 'neutral') {
        $newTone = $tone;
    } else {
        // 70% weight to existing tone, 30% to new tone
        $newTone = ($profile['interaction_tone'] === $tone) ? $tone : $profile['interaction_tone'];
    }

    // Update communication style
    $newStyle = $profile['communication_style'];
    if ($newFriendliness > 70) {
        $newStyle = 'warm';
    } elseif ($newFriendliness < 30) {
        $newStyle = 'professional';
    } else {
        $newStyle = 'balanced';
    }

    // Update database
    dbExecute(
        "UPDATE ai_user_profile
         SET interaction_tone = ?, friendliness_score = ?, communication_style = ?,
             last_interaction = NOW(), total_interactions = total_interactions + 1
         WHERE user_id = ? AND user_role = ?",
        [$newTone, $newFriendliness, $newStyle, $userId, $userRole],
        'siisi'
    );

    return [
        'tone' => $newTone,
        'friendliness_score' => $newFriendliness,
        'communication_style' => $newStyle
    ];
}

/**
 * Build system prompt with user context
 */
function buildSystemPrompt($userRole, $userClass, $userProfile = null, $currentTopics = [], $userId = null, $language = 'english') {
    $basePrompt = "You are NCA AI Assistant, a helpful AI assistant for Noah Christian Academy school management system.\n\n";
    $basePrompt .= "Your role: {$userRole}\n";

    if ($userClass) {
        $basePrompt .= "Assigned class: {$userClass}\n";
    }

    // Add language support
    if ($language === 'chichewa') {
        $basePrompt .= "\n=== LANGUAGE ===\n";
        $basePrompt .= "The user is communicating in Chichewa (a language from Malawi).\n";
        $basePrompt .= "You MUST respond in Chichewa.\n";
        $basePrompt .= "Use simple, clear Chichewa that a Malawian would understand.\n";
        $basePrompt .= "If you need to use technical terms, explain them in Chichewa.\n\n";
    }

    // Add adaptive personality based on user profile
    if ($userProfile) {
        $basePrompt .= "\n=== USER INTERACTION PROFILE ===\n";
        $basePrompt .= "User's communication style: {$userProfile['communication_style']}\n";
        $basePrompt .= "User's friendliness score: {$userProfile['friendliness_score']}/100\n";
        $basePrompt .= "User's preferred tone: {$userProfile['tone']}\n";
        $basePrompt .= "Total interactions: {$userProfile['total_interactions']}\n\n";

        // Adapt AI behavior based on profile
        if ($userProfile['communication_style'] === 'warm') {
            $basePrompt .= "Adapt your response to be warm, friendly, and conversational. Use emojis occasionally. Be more personal and engaging.\n\n";
        } elseif ($userProfile['communication_style'] === 'professional') {
            $basePrompt .= "Adapt your response to be professional, concise, and formal. Focus on efficiency and clarity. Avoid casual language.\n\n";
        } else {
            $basePrompt .= "Maintain a balanced communication style - professional yet approachable.\n\n";
        }

        if ($userProfile['friendliness_score'] > 70) {
            $basePrompt .= "This user is very friendly. You can be more casual, use occasional humor, and build rapport.\n\n";
        } elseif ($userProfile['friendliness_score'] < 30) {
            $basePrompt .= "This user prefers direct, no-nonsense communication. Be concise and professional.\n\n";
        }
    }

    // Add topic context and suggestions
    if (!empty($currentTopics)) {
        $basePrompt .= "=== CURRENT TOPICS ===\n";
        $basePrompt .= "User is asking about: " . implode(', ', $currentTopics) . "\n\n";

        // Get related topics if we have user ID
        if ($userId && !empty($currentTopics)) {
            $relatedTopics = getRelatedTopics($userId, $userRole, $currentTopics[0]);
            if (!empty($relatedTopics)) {
                $basePrompt .= "Based on user's interests, you can proactively suggest these related topics:\n";
                $basePrompt .= "- " . implode("\n- ", $relatedTopics) . "\n\n";
                $basePrompt .= "After answering the current question, briefly mention: \"Based on your interests, you might also want to know about [related topic]. Would you like me to help with that?\"\n\n";
            }
        }
    }

    $basePrompt .= "=== CAPABILITIES ===\n";
    $basePrompt .= "You can help with:\n";
    $basePrompt .= "- School-related questions using available tools (students, results, attendance, lesson plans, etc.)\n";
    $basePrompt .= "- General knowledge questions, jokes, entertainment, and any other topics\n";
    $basePrompt .= "- Image generation using the generate_image tool when users ask for images\n";
    $basePrompt .= "- You are a full-featured AI assistant like ChatGPT\n\n";

    $basePrompt .= "For school data:\n";
    $basePrompt .= "- Use the available tools to fetch real data from the database\n";
    $basePrompt .= "- Answer questions about school data accurately using tools\n";
    $basePrompt .= "- Never invent or hallucinate student data, marks, fees, or other records\n";
    $basePrompt .= "- Respect user permissions - do not reveal information beyond their access level\n";
    $basePrompt .= "- For destructive actions, ask for confirmation before proceeding\n";
    $basePrompt .= "- If asked about sensitive information (passwords, salaries, etc.), refuse politely\n";
    $basePrompt .= "- Format data in tables when appropriate\n\n";

    if ($userRole === 'teacher') {
        $basePrompt .= "As a teacher, you have tools for:\n";
        $basePrompt .= "- Viewing your assigned students and their performance\n";
        $basePrompt .= "- Checking attendance records\n";
        $basePrompt .= "- Creating lesson plans using AI generation tools\n";
        $basePrompt .= "- Generating examination papers\n";
        $basePrompt .= "- Creating homework assignments\n";
        $basePrompt .= "- Analyzing class performance\n";
        $basePrompt .= "- Saving generated lesson plans to the database\n";
        $basePrompt .= "- Checking fee balances for students\n";
    } elseif ($userRole === 'admin') {
        $basePrompt .= "As an administrator, you have tools for:\n";
        $basePrompt .= "- School-wide student data and analytics\n";
        $basePrompt .= "- Fee balances and payments\n";
        $basePrompt .= "- Teacher information and management (search, list, details)\n";
        $basePrompt .= "- Attendance reports and analysis\n";
        $basePrompt .= "- Financial summaries and reports\n";
        $basePrompt .= "- Performance reports for any class\n";
        $basePrompt .= "- School-wide analytics\n";
    }

    $basePrompt .= "\n=== SCHOOL STRUCTURE ===\n";
    $basePrompt .= "The school has these educational levels:\n";
    $basePrompt .= "- Early Childhood: Day Care, Nursery, Baby, Reception\n";
    $basePrompt .= "- Primary Education: Standard 1 through Standard 8\n";
    $basePrompt .= "When users ask about classes, students, or levels, recognize these specific terms.\n";

    return $basePrompt;
}

/**
 * Get tool definitions for AI
 */
function getToolDefinitions($userRole) {
    $tools = [
        [
            'type' => 'function',
            'function' => [
                'name' => 'search_students',
                'description' => 'Search for students by name, admission number, or class',
                'parameters' => [
                    'type' => 'object',
                    'properties' => [
                        'query' => ['type' => 'string', 'description' => 'Search query'],
                        'limit' => ['type' => 'integer', 'description' => 'Maximum results (default 20)']
                    ],
                    'required' => ['query']
                ]
            ]
        ],
        [
            'type' => 'function',
            'function' => [
                'name' => 'get_student',
                'description' => 'Get detailed information about a specific student',
                'parameters' => [
                    'type' => 'object',
                    'properties' => [
                        'student_id' => ['type' => 'integer', 'description' => 'Student ID']
                    ],
                    'required' => ['student_id']
                ]
            ]
        ],
        [
            'type' => 'function',
            'function' => [
                'name' => 'get_students_by_class',
                'description' => 'Get all students in a specific class',
                'parameters' => [
                    'type' => 'object',
                    'properties' => [
                        'class' => ['type' => 'string', 'description' => 'Class name (e.g., Form 2A)']
                    ],
                    'required' => ['class']
                ]
            ]
        ],
        [
            'type' => 'function',
            'function' => [
                'name' => 'get_student_attendance',
                'description' => 'Get attendance records for a student',
                'parameters' => [
                    'type' => 'object',
                    'properties' => [
                        'student_id' => ['type' => 'integer', 'description' => 'Student ID'],
                        'term' => ['type' => 'string', 'description' => 'Term (optional)']
                    ],
                    'required' => ['student_id']
                ]
            ]
        ],
        [
            'type' => 'function',
            'function' => [
                'name' => 'get_class_attendance',
                'description' => 'Get attendance summary for a class',
                'parameters' => [
                    'type' => 'object',
                    'properties' => [
                        'class' => ['type' => 'string', 'description' => 'Class name'],
                        'term' => ['type' => 'string', 'description' => 'Term (optional)']
                    ],
                    'required' => ['class']
                ]
            ]
        ],
        [
            'type' => 'function',
            'function' => [
                'name' => 'get_student_results',
                'description' => 'Get assessment results for a student',
                'parameters' => [
                    'type' => 'object',
                    'properties' => [
                        'student_id' => ['type' => 'integer', 'description' => 'Student ID'],
                        'subject' => ['type' => 'string', 'description' => 'Subject (optional)']
                    ],
                    'required' => ['student_id']
                ]
            ]
        ],
        [
            'type' => 'function',
            'function' => [
                'name' => 'get_class_results',
                'description' => 'Get results summary for a class',
                'parameters' => [
                    'type' => 'object',
                    'properties' => [
                        'class' => ['type' => 'string', 'description' => 'Class name'],
                        'subject' => ['type' => 'string', 'description' => 'Subject (optional)'],
                        'term' => ['type' => 'string', 'description' => 'Term (optional)']
                    ],
                    'required' => ['class']
                ]
            ]
        ],
        [
            'type' => 'function',
            'function' => [
                'name' => 'get_announcements',
                'description' => 'Get school announcements',
                'parameters' => [
                    'type' => 'object',
                    'properties' => [
                        'limit' => ['type' => 'integer', 'description' => 'Maximum results (default 10)']
                    ]
                ]
            ]
        ],
        [
            'type' => 'function',
            'function' => [
                'name' => 'get_lesson_plans',
                'description' => 'Get lesson plans',
                'parameters' => [
                    'type' => 'object',
                    'properties' => [
                        'teacher_id' => ['type' => 'integer', 'description' => 'Teacher ID (optional)'],
                        'class' => ['type' => 'string', 'description' => 'Class (optional)'],
                        'subject' => ['type' => 'string', 'description' => 'Subject (optional)']
                    ]
                ]
            ]
        ],
        [
            'type' => 'function',
            'function' => [
                'name' => 'generate_lesson_plan',
                'description' => 'Generate a lesson plan using AI',
                'parameters' => [
                    'type' => 'object',
                    'properties' => [
                        'subject' => ['type' => 'string', 'description' => 'Subject'],
                        'class' => ['type' => 'string', 'description' => 'Class'],
                        'topic' => ['type' => 'string', 'description' => 'Topic'],
                        'duration' => ['type' => 'integer', 'description' => 'Duration in minutes (default 45)'],
                        'term' => ['type' => 'string', 'description' => 'Term (optional)']
                    ],
                    'required' => ['subject', 'class', 'topic']
                ]
            ]
        ],
        [
            'type' => 'function',
            'function' => [
                'name' => 'generate_exam',
                'description' => 'Generate an examination paper using AI',
                'parameters' => [
                    'type' => 'object',
                    'properties' => [
                        'subject' => ['type' => 'string', 'description' => 'Subject'],
                        'class' => ['type' => 'string', 'description' => 'Class'],
                        'topics' => ['type' => 'string', 'description' => 'Topics to cover'],
                        'question_count' => ['type' => 'integer', 'description' => 'Number of questions (default 20)'],
                        'difficulty' => ['type' => 'string', 'description' => 'Difficulty level (easy, medium, hard)'],
                        'duration' => ['type' => 'integer', 'description' => 'Duration in minutes (default 60)']
                    ],
                    'required' => ['subject', 'class', 'topics']
                ]
            ]
        ],
        [
            'type' => 'function',
            'function' => [
                'name' => 'generate_homework',
                'description' => 'Generate a homework assignment using AI',
                'parameters' => [
                    'type' => 'object',
                    'properties' => [
                        'subject' => ['type' => 'string', 'description' => 'Subject'],
                        'class' => ['type' => 'string', 'description' => 'Class'],
                        'topic' => ['type' => 'string', 'description' => 'Topic'],
                        'difficulty' => ['type' => 'string', 'description' => 'Difficulty level (easy, medium, hard)']
                    ],
                    'required' => ['subject', 'class', 'topic']
                ]
            ]
        ],
        [
            'type' => 'function',
            'function' => [
                'name' => 'save_lesson_plan',
                'description' => 'Save a lesson plan to the database (requires confirmation)',
                'parameters' => [
                    'type' => 'object',
                    'properties' => [
                        'title' => ['type' => 'string', 'description' => 'Lesson plan title'],
                        'subject' => ['type' => 'string', 'description' => 'Subject'],
                        'class' => ['type' => 'string', 'description' => 'Class'],
                        'topic' => ['type' => 'string', 'description' => 'Topic'],
                        'term' => ['type' => 'string', 'description' => 'Term'],
                        'date' => ['type' => 'string', 'description' => 'Date (YYYY-MM-DD)'],
                        'objectives' => ['type' => 'string', 'description' => 'Learning objectives'],
                        'activities' => ['type' => 'string', 'description' => 'Teaching activities'],
                        'resources' => ['type' => 'string', 'description' => 'Required resources'],
                        'assessment' => ['type' => 'string', 'description' => 'Assessment methods']
                    ],
                    'required' => ['title', 'subject', 'class', 'topic']
                ]
            ]
        ],
        [
            'type' => 'function',
            'function' => [
                'name' => 'generate_performance_report',
                'description' => 'Generate a performance report for a class',
                'parameters' => [
                    'type' => 'object',
                    'properties' => [
                        'class' => ['type' => 'string', 'description' => 'Class name'],
                        'term' => ['type' => 'string', 'description' => 'Term (optional)'],
                        'subject' => ['type' => 'string', 'description' => 'Subject (optional)']
                    ],
                    'required' => ['class']
                ]
            ]
        ],
        [
            'type' => 'function',
            'function' => [
                'name' => 'generate_financial_report',
                'description' => 'Generate a financial report (admin only)',
                'parameters' => [
                    'type' => 'object',
                    'properties' => [
                        'term' => ['type' => 'string', 'description' => 'Term (optional)']
                    ]
                ]
            ]
        ],
        [
            'type' => 'function',
            'function' => [
                'name' => 'generate_attendance_report',
                'description' => 'Generate an attendance report',
                'parameters' => [
                    'type' => 'object',
                    'properties' => [
                        'class' => ['type' => 'string', 'description' => 'Class name (optional for admin)'],
                        'term' => ['type' => 'string', 'description' => 'Term (optional)']
                    ]
                ]
            ]
        ],
        [
            'type' => 'function',
            'function' => [
                'name' => 'generate_image',
                'description' => 'Generate an image using AI based on a text description',
                'parameters' => [
                    'type' => 'object',
                    'properties' => [
                        'prompt' => ['type' => 'string', 'description' => 'Detailed description of the image to generate']
                    ],
                    'required' => ['prompt']
                ]
            ]
        ]
    ];

    // Add admin-only tools
    if ($userRole === 'admin') {
        $tools[] = [
            'type' => 'function',
            'function' => [
                'name' => 'get_teachers',
                'description' => 'Get list of teachers (admin only)',
                'parameters' => [
                    'type' => 'object',
                    'properties' => [
                        'limit' => ['type' => 'integer', 'description' => 'Maximum results (default 50)']
                    ]
                ]
            ]
        ];
        $tools[] = [
            'type' => 'function',
            'function' => [
                'name' => 'search_teachers',
                'description' => 'Search teachers by name, email, or subject (admin only)',
                'parameters' => [
                    'type' => 'object',
                    'properties' => [
                        'query' => ['type' => 'string', 'description' => 'Search query'],
                        'limit' => ['type' => 'integer', 'description' => 'Maximum results (default 20)']
                    ],
                    'required' => ['query']
                ]
            ]
        ];
    }

    // Fee balances - available to both teachers and admins
    $tools[] = [
        'type' => 'function',
        'function' => [
            'name' => 'get_fee_balances',
            'description' => 'Get fee balances for students',
            'parameters' => [
                'type' => 'object',
                'properties' => [
                    'student_id' => ['type' => 'integer', 'description' => 'Student ID (optional)']
                ]
            ]
        ]
    ];

    return $tools;
}

/**
 * Execute tool calls
 */
function executeToolCalls($tools, $toolCalls) {
    $results = [];

    foreach ($toolCalls as $call) {
        $functionName = $call['function']['name'];
        $arguments = json_decode($call['function']['arguments'], true);

        $result = null;

        try {
            switch ($functionName) {
                case 'search_students':
                    $result = $tools->searchStudents($arguments['query'] ?? '', $arguments['limit'] ?? 20);
                    break;
                case 'get_student':
                    $result = $tools->getStudent($arguments['student_id']);
                    break;
                case 'get_students_by_class':
                    $result = $tools->getStudentsByClass($arguments['class']);
                    break;
                case 'get_student_attendance':
                    $result = $tools->getStudentAttendance($arguments['student_id'], $arguments['term'] ?? null);
                    break;
                case 'get_class_attendance':
                    $result = $tools->getClassAttendance($arguments['class'], $arguments['term'] ?? null);
                    break;
                case 'get_student_results':
                    $result = $tools->getStudentResults($arguments['student_id'], $arguments['subject'] ?? null);
                    break;
                case 'get_class_results':
                    $result = $tools->getClassResults($arguments['class'], $arguments['subject'] ?? null, $arguments['term'] ?? null);
                    break;
                case 'get_fee_balances':
                    $result = $tools->getFeeBalances($arguments['student_id'] ?? null);
                    break;
                case 'get_teachers':
                    $result = $tools->getTeachers($arguments['limit'] ?? 50);
                    break;
                case 'search_teachers':
                    $result = $tools->searchTeachers($arguments['query'] ?? '', $arguments['limit'] ?? 20);
                    break;
                case 'get_announcements':
                    $result = $tools->getAnnouncements($arguments['limit'] ?? 10);
                    break;
                case 'get_lesson_plans':
                    $result = $tools->getLessonPlans($arguments['teacher_id'] ?? null, $arguments['class'] ?? null, $arguments['subject'] ?? null);
                    break;
                case 'generate_lesson_plan':
                    $result = $tools->generateLessonPlan(
                        $arguments['subject'],
                        $arguments['class'],
                        $arguments['topic'],
                        $arguments['duration'] ?? 45,
                        $arguments['term'] ?? null
                    );
                    break;
                case 'generate_exam':
                    $result = $tools->generateExam(
                        $arguments['subject'],
                        $arguments['class'],
                        $arguments['topics'],
                        $arguments['question_count'] ?? 20,
                        $arguments['difficulty'] ?? 'medium',
                        $arguments['duration'] ?? 60
                    );
                    break;
                case 'generate_homework':
                    $result = $tools->generateHomework(
                        $arguments['subject'],
                        $arguments['class'],
                        $arguments['topic'],
                        $arguments['difficulty'] ?? 'medium'
                    );
                    break;
                case 'save_lesson_plan':
                    $result = $tools->saveLessonPlan($arguments);
                    break;
                case 'generate_performance_report':
                    $result = $tools->generatePerformanceReport(
                        $arguments['class'],
                        $arguments['term'] ?? null,
                        $arguments['subject'] ?? null
                    );
                    break;
                case 'generate_financial_report':
                    $result = $tools->generateFinancialReport($arguments['term'] ?? null);
                    break;
                case 'generate_attendance_report':
                    $result = $tools->generateAttendanceReport(
                        $arguments['class'] ?? null,
                        $arguments['term'] ?? null
                    );
                    break;
                case 'generate_image':
                    $result = generateImageAI($arguments['prompt']);
                    break;
                default:
                    $result = ['success' => false, 'message' => 'Unknown tool: ' . $functionName];
            }
        } catch (Exception $e) {
            $result = ['success' => false, 'message' => 'Tool execution error: ' . $e->getMessage()];
        }

        $results[] = [
            'tool_call_id' => $call['id'],
            'result' => $result
        ];
    }

    return $results;
}

/**
 * Save conversation to database
 */
function saveConversation($userId, $userRole, $conversationId, $userMessage, $aiResponse) {
    // Create ai_conversations table if it doesn't exist
    $conn = getDB();
    $conn->query("CREATE TABLE IF NOT EXISTS ai_conversations (
        id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT NOT NULL,
        user_role VARCHAR(20) NOT NULL,
        conversation_id VARCHAR(100) DEFAULT NULL,
        user_message TEXT NOT NULL,
        ai_response TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_user (user_id, user_role),
        INDEX idx_conversation (conversation_id),
        INDEX idx_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    dbInsert(
        "INSERT INTO ai_conversations (user_id, user_role, conversation_id, user_message, ai_response)
         VALUES (?, ?, ?, ?, ?)",
        [$userId, $userRole, $conversationId, $userMessage, $aiResponse],
        'iisss'
    );
}

/**
 * Log AI usage
 */
function logAIUsage($userId, $userRole, $message, $usage) {
    // Create ai_usage_log table if it doesn't exist
    $conn = getDB();
    $conn->query("CREATE TABLE IF NOT EXISTS ai_usage_log (
        id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT NOT NULL,
        user_role VARCHAR(20) NOT NULL,
        message TEXT,
        prompt_tokens INT DEFAULT 0,
        completion_tokens INT DEFAULT 0,
        total_tokens INT DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_user (user_id),
        INDEX idx_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    if ($usage) {
        dbInsert(
            "INSERT INTO ai_usage_log (user_id, user_role, message, prompt_tokens, completion_tokens, total_tokens)
             VALUES (?, ?, ?, ?, ?, ?)",
            [$userId, $userRole, substr($message, 0, 500), $usage['prompt_tokens'] ?? 0, $usage['completion_tokens'] ?? 0, $usage['total_tokens'] ?? 0],
            'isiiii'
        );
    }
}

/**
 * Extract PDF using CLI tool (pdftotext) as fallback
 */
function extractPDFWithCLI($filepath) {
    // Try pdftotext command
    $output = [];
    $returnCode = 0;

    // Try different command names
    $commands = ['pdftotext', 'pdftotext.exe'];
    foreach ($commands as $cmd) {
        exec("{$cmd} \"{$filepath}\" -", $output, $returnCode);
        if ($returnCode === 0 && !empty($output)) {
            return implode("\n", $output);
        }
    }

    return null;
}

/**
 * Extract text from document
 */
function extractDocumentContent($filepath, $fileExt) {
    // Load Composer autoloader
    $autoloadFile = __DIR__ . '/../vendor/autoload.php';
    if (file_exists($autoloadFile)) {
        require_once $autoloadFile;
    }

    // TXT files - direct read
    if ($fileExt === 'txt' || $fileExt === 'csv') {
        return file_get_contents($filepath);
    }

    // Image files - return message
    if (in_array($fileExt, ['jpg', 'jpeg', 'png', 'gif', 'webp'])) {
        return "[Image uploaded successfully. AI can analyze images if vision capabilities are enabled. Current file: " . basename($filepath) . "]";
    }

    // Extract from DOCX using PhpWord
    if ($fileExt === 'docx') {
        // Check if ZipArchive is available (required for DOCX)
        if (!class_exists('ZipArchive')) {
            return "[DOCX Error: PHP zip extension is not enabled. To fix: 1) Open C:\\xampp\\php\\php.ini 2) Remove semicolon from ;extension=zip 3) Restart Apache. For now, please upload TXT files instead.]";
        }

        if (class_exists('PhpOffice\PhpWord\IOFactory')) {
            try {
                $phpWord = \PhpOffice\PhpWord\IOFactory::load($filepath);
                $text = '';
                foreach ($phpWord->getSections() as $section) {
                    foreach ($section->getElements() as $element) {
                        if (method_exists($element, 'getText')) {
                            $text .= $element->getText() . ' ';
                        }
                    }
                }
                return trim($text);
            } catch (Exception $e) {
                return "Error extracting DOCX: " . $e->getMessage();
            }
        } else {
            return "[Error: PhpOffice\PhpWord library not installed. Run: composer require phpoffice/phpword]";
        }
    }

    // Extract from PDF using Smalot PDF Parser
    if ($fileExt === 'pdf') {
        if (class_exists('Smalot\PdfParser\Parser')) {
            try {
                $parser = new \Smalot\PdfParser\Parser();
                $pdf = $parser->parseFile($filepath);
                $text = '';

                // Extract text from all pages
                $pages = $pdf->getPages();
                foreach ($pages as $page) {
                    $text .= $page->getText() . "\n";
                }

                $extractedText = trim($text);

                if (empty($extractedText)) {
                    return "[PDF uploaded but text extraction failed. The PDF might be scanned images. File: " . basename($filepath) . "]";
                }

                return $extractedText;
            } catch (Exception $e) {
                return "Error extracting PDF: " . $e->getMessage();
            }
        } else {
            // Try using pdftotext command-line tool as fallback
            $text = extractPDFWithCLI($filepath);
            if ($text) {
                return $text;
            }
            // Fallback: save PDF info for now
            return "[PDF uploaded successfully. File: " . basename($filepath) . "\n\nNote: PDF text extraction requires the smalot/pdfparser library.\nTo enable:\n1. Install Composer from https://getcomposer.org/Composer-Setup.exe\n2. Run: composer update in C:\\xampp\\htdocs\\noah\n\nFor now, you can ask the AI questions about the PDF content manually.]";
        }
    }

    // XLSX - not yet implemented
    if ($fileExt === 'xlsx') {
        return "[XLSX uploaded successfully. Content extraction not yet implemented for XLSX files. File saved as: " . basename($filepath) . "]";
    }

    // Unknown format
    return "[Unsupported file type: {$fileExt}. Supported: TXT, CSV, JPG, PNG, GIF, DOCX, PDF]";
}

/**
 * Test model connection
 */
function testModelConnection() {
    try {
        $aiService = new AIService();

        // Simple test message
        $messages = [
            ['role' => 'user', 'content' => 'Test']
        ];

        $response = $aiService->generateResponse($messages, []);

        return $response;
    } catch (Exception $e) {
        error_log("Model test error: " . $e->getMessage());
        return [
            'success' => false,
            'message' => 'Test failed: ' . $e->getMessage()
        ];
    }
}
