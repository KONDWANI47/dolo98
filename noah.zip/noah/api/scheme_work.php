<?php
/**
 * Scheme of Work API
 * Handles CRUD operations for schemes of work
 */
require_once __DIR__ . '/db.php';

// Enable error logging for debugging
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$action = $_REQUEST['action'] ?? '';

try {
    switch ($action) {
        case 'list':
            handleListSchemes();
            break;
        case 'get':
            handleGetScheme();
            break;
        case 'create':
            handleCreateScheme();
            break;
        case 'update':
            handleUpdateScheme();
            break;
        case 'delete':
            handleDeleteScheme();
            break;
        default:
            respondError('Unknown action: ' . $action, 404);
    }
} catch (Exception $e) {
    error_log('Scheme API error: ' . $e->getMessage());
    respondError('Server error: ' . $e->getMessage(), 500);
}

/**
 * List all schemes for a teacher
 */
function handleListSchemes() {
    $teacherId = $_REQUEST['teacher_id'] ?? 0;
    if (!$teacherId) {
        respondError('Teacher ID is required');
    }

    $schemes = dbFetchAll(
        "SELECT id, title, subject, term, number_of_periods, learning_area, created_at, updated_at
         FROM schemes_of_work
         WHERE teacher_id = ?
         ORDER BY created_at DESC",
        [$teacherId],
        'i'
    );

    respondSuccess($schemes);
}

/**
 * Get a single scheme with all rows
 */
function handleGetScheme() {
    $schemeId = $_REQUEST['id'] ?? 0;
    if (!$schemeId) {
        respondError('Scheme ID is required');
    }

    // Get scheme details
    $scheme = dbFetchOne(
        "SELECT * FROM schemes_of_work WHERE id = ?",
        [$schemeId],
        'i'
    );

    if (!$scheme) {
        respondError('Scheme not found', 404);
    }

    // Convert row columns to rows array
    $rows = [];
    for ($i = 1; $i <= 20; $i++) {
        $weekDate = $scheme["row{$i}_week_date"] ?? '';
        $successCriteria = $scheme["row{$i}_success_criteria"] ?? '';
        $plannedActivities = $scheme["row{$i}_planned_activities"] ?? '';
        $teachingMethods = $scheme["row{$i}_teaching_methods"] ?? '';
        $resources = $scheme["row{$i}_resources"] ?? '';
        $references = $scheme["row{$i}_references"] ?? '';
        $outcomes = $scheme["row{$i}_outcomes"] ?? '';
        $remarks = $scheme["row{$i}_remarks"] ?? '';

        // Only add row if it has data
        if ($weekDate || $successCriteria || $plannedActivities || $teachingMethods ||
            $resources || $references || $outcomes || $remarks) {
            $rows[] = [
                'week_date' => $weekDate,
                'success_criteria' => $successCriteria,
                'planned_activities' => $plannedActivities,
                'teaching_methods' => $teachingMethods,
                'resources' => $resources,
                'references' => $references,
                'outcomes' => $outcomes,
                'remarks' => $remarks
            ];
        }
    }

    // Remove row columns from scheme
    for ($i = 1; $i <= 20; $i++) {
        unset($scheme["row{$i}_week_date"]);
        unset($scheme["row{$i}_success_criteria"]);
        unset($scheme["row{$i}_planned_activities"]);
        unset($scheme["row{$i}_teaching_methods"]);
        unset($scheme["row{$i}_resources"]);
        unset($scheme["row{$i}_references"]);
        unset($scheme["row{$i}_outcomes"]);
        unset($scheme["row{$i}_remarks"]);
    }

    $scheme['rows'] = $rows;
    respondSuccess($scheme);
}

/**
 * Create a new scheme
 */
function handleCreateScheme() {
    try {
        $body = getJsonBody();
        $teacherId = (int)($body['teacher_id'] ?? 0);
        $title = trim($body['title'] ?? '');
        $subject = trim($body['subject'] ?? '');
        $term = trim($body['term'] ?? '');
        $numberOfPeriods = (int)($body['number_of_periods'] ?? 0);
        $learningArea = trim($body['learning_area'] ?? '');
        $rows = $body['rows'] ?? [];

        if (!$teacherId || !$title || !$subject || !$term) {
            respondError('Teacher ID, title, subject, and term are required');
        }

        // Check if teacher exists
        $teacher = dbFetchOne("SELECT id FROM teachers WHERE id = ?", [$teacherId], 'i');
        if (!$teacher) {
            respondError('Teacher not found in database. Teacher ID: ' . $teacherId);
        }

        // Build column names and values for all 20 rows
        $columns = ['teacher_id', 'title', 'subject', 'term', 'number_of_periods', 'learning_area'];
        $values = [$teacherId, $title, $subject, $term, $numberOfPeriods, $learningArea];
        $types = 'issisi';

        for ($i = 1; $i <= 20; $i++) {
            $rowData = $rows[$i - 1] ?? null;
            $columns[] = "row{$i}_week_date";
            $columns[] = "row{$i}_success_criteria";
            $columns[] = "row{$i}_planned_activities";
            $columns[] = "row{$i}_teaching_methods";
            $columns[] = "row{$i}_resources";
            $columns[] = "row{$i}_references";
            $columns[] = "row{$i}_outcomes";
            $columns[] = "row{$i}_remarks";

            if ($rowData) {
                $values[] = $rowData['week_date'] ?? '';
                $values[] = $rowData['success_criteria'] ?? '';
                $values[] = $rowData['planned_activities'] ?? '';
                $values[] = $rowData['teaching_methods'] ?? '';
                $values[] = $rowData['resources'] ?? '';
                $values[] = $rowData['references'] ?? '';
                $values[] = $rowData['outcomes'] ?? '';
                $values[] = $rowData['remarks'] ?? '';
            } else {
                $values[] = '';
                $values[] = '';
                $values[] = '';
                $values[] = '';
                $values[] = '';
                $values[] = '';
                $values[] = '';
                $values[] = '';
            }
            $types .= 'ssssssss';
        }

        // Insert scheme with all row data
        $insertSql = "INSERT INTO schemes_of_work (" . implode(', ', $columns) . ") VALUES (" . str_repeat('?, ', count($values) - 1) . "?)";
        $conn = getDB();
        $stmt = $conn->prepare($insertSql);
        $stmt->bind_param($types, ...$values);
        $stmt->execute();
        $schemeId = $stmt->insert_id;
        $stmt->close();

        if (!$schemeId) {
            respondError('Failed to create scheme');
        }

        if (function_exists('addActivityLog')) {
            addActivityLog('Scheme Created', "Teacher ID {$teacherId} created scheme: {$title}");
        }
        respondSuccess(['id' => $schemeId], 'Scheme created successfully');
    } catch (Exception $e) {
        error_log('Scheme creation error: ' . $e->getMessage());
        respondError('Error creating scheme: ' . $e->getMessage(), 500);
    }
}

/**
 * Update an existing scheme
 */
function handleUpdateScheme() {
    try {
        $body = getJsonBody();
        $schemeId = (int)($body['id'] ?? 0);
        $teacherId = (int)($body['teacher_id'] ?? 0);
        $title = trim($body['title'] ?? '');
        $subject = trim($body['subject'] ?? '');
        $term = trim($body['term'] ?? '');
        $numberOfPeriods = (int)($body['number_of_periods'] ?? 0);
        $learningArea = trim($body['learning_area'] ?? '');
        $rows = $body['rows'] ?? [];

        if (!$schemeId || !$title || !$subject || !$term) {
            respondError('Scheme ID, title, subject, and term are required');
        }

        // Check if teacher exists
        $teacher = dbFetchOne("SELECT id FROM teachers WHERE id = ?", [$teacherId], 'i');
        if (!$teacher) {
            respondError('Teacher not found in database. Teacher ID: ' . $teacherId);
        }

        // Check if scheme exists and belongs to this teacher
        $existingScheme = dbFetchOne("SELECT id, teacher_id FROM schemes_of_work WHERE id = ?", [$schemeId], 'i');
        if (!$existingScheme) {
            respondError('Scheme not found. Scheme ID: ' . $schemeId);
        }
        if ($existingScheme['teacher_id'] != $teacherId) {
            respondError('You do not have permission to update this scheme');
        }

        // Build SET clause for all columns
        $setClauses = ['title = ?', 'subject = ?', 'term = ?', 'number_of_periods = ?', 'learning_area = ?', 'updated_at = NOW()'];
        $values = [$title, $subject, $term, $numberOfPeriods, $learningArea];
        $types = 'ssisi';

        for ($i = 1; $i <= 20; $i++) {
            $rowData = $rows[$i - 1] ?? null;
            $setClauses[] = "row{$i}_week_date = ?";
            $setClauses[] = "row{$i}_success_criteria = ?";
            $setClauses[] = "row{$i}_planned_activities = ?";
            $setClauses[] = "row{$i}_teaching_methods = ?";
            $setClauses[] = "row{$i}_resources = ?";
            $setClauses[] = "row{$i}_references = ?";
            $setClauses[] = "row{$i}_outcomes = ?";
            $setClauses[] = "row{$i}_remarks = ?";

            if ($rowData) {
                $values[] = $rowData['week_date'] ?? '';
                $values[] = $rowData['success_criteria'] ?? '';
                $values[] = $rowData['planned_activities'] ?? '';
                $values[] = $rowData['teaching_methods'] ?? '';
                $values[] = $rowData['resources'] ?? '';
                $values[] = $rowData['references'] ?? '';
                $values[] = $rowData['outcomes'] ?? '';
                $values[] = $rowData['remarks'] ?? '';
            } else {
                $values[] = '';
                $values[] = '';
                $values[] = '';
                $values[] = '';
                $values[] = '';
                $values[] = '';
                $values[] = '';
                $values[] = '';
            }
            $types .= 'ssssssss';
        }

        $values[] = $schemeId;
        $types .= 'i';

        // Update scheme with all row data
        $updateSql = "UPDATE schemes_of_work SET " . implode(', ', $setClauses) . " WHERE id = ?";
        $conn = getDB();
        $stmt = $conn->prepare($updateSql);
        $stmt->bind_param($types, ...$values);
        $stmt->execute();
        $stmt->close();

        if (function_exists('addActivityLog')) {
            addActivityLog('Scheme Updated', "Scheme ID {$schemeId} updated: {$title}");
        }
        respondSuccess(['id' => $schemeId], 'Scheme updated successfully');
    } catch (Exception $e) {
        error_log('Scheme update error: ' . $e->getMessage());
        respondError('Error updating scheme: ' . $e->getMessage(), 500);
    }
}

/**
 * Delete a scheme
 */
function handleDeleteScheme() {
    try {
        $schemeId = (int)($_REQUEST['id'] ?? 0);
        if (!$schemeId) {
            respondError('Scheme ID is required');
        }

        // Get scheme info for logging
        $scheme = dbFetchOne("SELECT title FROM schemes_of_work WHERE id = ?", [$schemeId], 'i');
        if (!$scheme) {
            respondError('Scheme not found', 404);
        }

        // Delete scheme (all row data is in the same table now)
        dbExecute("DELETE FROM schemes_of_work WHERE id = ?", [$schemeId], 'i');

        if (function_exists('addActivityLog')) {
            addActivityLog('Scheme Deleted', "Scheme ID {$schemeId} deleted: {$scheme['title']}");
        }
        respondSuccess([], 'Scheme deleted successfully');
    } catch (Exception $e) {
        error_log('Scheme deletion error: ' . $e->getMessage());
        respondError('Error deleting scheme: ' . $e->getMessage(), 500);
    }
}
?>
