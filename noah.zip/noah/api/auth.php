<?php
/**
 * Authentication API - Noah Christian Academy
 * Handles admin login, teacher login/register
 * Supports code-based approval system for teachers and parents
 */

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/email_service.php';

ensureEmailAuthSchema();

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$action = $_REQUEST['action'] ?? '';

switch ($action) {
    case 'admin_login':
        handleAdminLogin();
        break;
    case 'admin_register':
        handleAdminRegister();
        break;
    case 'teacher_login':
        handleTeacherLogin();
        break;
    case 'teacher_register':
        handleTeacherRegister();
        break;
    case 'parent_login':
        handleParentLogin();
        break;
    case 'parent_register':
        handleParentRegister();
        break;
    case 'change_password':
        handleChangePassword();
        break;
    case 'generate_code':
        handleGenerateCode();
        break;
    case 'verify_code':
        handleVerifyCode();
        break;
    case 'resend_code':
        handleResendCode();
        break;
    case 'verify_email':
        handleVerifyEmail();
        break;
    case 'resend_verification':
        handleResendVerification();
        break;
    case 'oauth_exchange':
        handleOAuthExchange();
        break;
    case 'request_account_deletion':
        handleRequestAccountDeletion();
        break;
    case 'check_deletion_status':
        handleCheckDeletionStatus();
        break;
    case 'cancel_deletion_request':
        handleCancelDeletionRequest();
        break;
    default:
        respondError('Unknown action: ' . $action, 404);
}

/**
 * Ensure the email-authentication fields exist without breaking existing installations.
 * Existing accounts are marked verified so this change does not lock out current users.
 */
function ensureEmailAuthSchema() {
    static $done = false;
    if ($done) return;
    $done = true;
    try {
        $conn = getDB();
        foreach (['admins','teachers','parents'] as $table) {
            $checks = [
                'email_verified' => "TINYINT(1) NOT NULL DEFAULT 1",
                'email_verification_token' => "VARCHAR(128) DEFAULT NULL",
                'email_verification_expires' => "DATETIME DEFAULT NULL",
                'registration_code' => "VARCHAR(20) DEFAULT NULL",
                'code_expires_at' => "DATETIME DEFAULT NULL"
            ];
            foreach ($checks as $column => $definition) {
                $safeTable = preg_replace('/[^a-z_]/i', '', $table);
                $safeColumn = preg_replace('/[^a-z_]/i', '', $column);
                $result = $conn->query("SHOW COLUMNS FROM `$safeTable` LIKE '$safeColumn'");
                if ($result && $result->num_rows === 0) {
                    $conn->query("ALTER TABLE `$safeTable` ADD COLUMN `$safeColumn` $definition");
                }
            }
        }
    } catch (Throwable $e) {
        error_log('Schema migration error: ' . $e->getMessage());
    }
}

function normalizeLoginIdentifier($value) {
    return trim((string)$value);
}

function findAccountByLogin($table, $identifier) {
    return dbFetchOne(
        "SELECT * FROM `$table` WHERE username = ? OR LOWER(email) = LOWER(?) LIMIT 1",
        [$identifier, $identifier],
        'ss'
    );
}

function createEmailVerification($table, $id, $email, $name, $type) {
    $token = bin2hex(random_bytes(32));
    $expires = date('Y-m-d H:i:s', strtotime('+24 hours'));
    dbExecute(
        "UPDATE `$table` SET email_verified = 0, email_verification_token = ?, email_verification_expires = ? WHERE id = ?",
        [$token, $expires, $id],
        'ssi'
    );

    $base = rtrim(getenv('APP_URL') ?: '', '/');
    if ($base === '') {
        $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
        $base = $scheme . '://' . $host;
    }
    $link = $base . '/verify-email.html?type=' . rawurlencode($type) . '&token=' . rawurlencode($token);

    $subject = 'Verify your Noah Christian Academy account';
    $message = "Hello {$name},\n\nPlease verify your {$type} account by opening this link:\n\n{$link}\n\nThis verification link expires in 24 hours.\n\nNoah Christian Academy";

    $sent = false;
    if (function_exists('sendApplicationEmail')) {
        try {
            $sent = sendApplicationEmail($email, $name, $subject, $message);
            error_log("Verification email sent to {$email}: " . ($sent ? 'SUCCESS' : 'FAILED'));
        } catch (Throwable $e) {
            error_log("Verification email error for {$email}: " . $e->getMessage());
        }
    } else {
        error_log("sendApplicationEmail function not available");
    }

    return ['sent' => $sent, 'link' => $link, 'expiresAt' => $expires];
}

function handleVerifyEmail() {
    ensureEmailAuthSchema();
    $type = strtolower(trim($_REQUEST['account_type'] ?? $_REQUEST['type'] ?? ''));
    $token = trim($_REQUEST['token'] ?? '');
    if (!in_array($type, ['admin','teacher','parent'], true) || $token === '') {
        respondError('Invalid verification request', 400);
    }

    $table = $type === 'admin' ? 'admins' : ($type === 'teacher' ? 'teachers' : 'parents');
    $row = dbFetchOne(
        "SELECT id, first_name, last_name, email, email_verification_expires FROM `$table` WHERE email_verification_token = ? LIMIT 1",
        [$token], 's'
    );
    if (!$row) respondError('Verification link is invalid or has already been used.', 400);
    if (!empty($row['email_verification_expires']) && strtotime($row['email_verification_expires']) < time()) {
        respondError('Verification link has expired. Please request a new one.', 400);
    }

    dbExecute(
        "UPDATE `$table` SET email_verified = 1, email_verification_token = NULL, email_verification_expires = NULL" .
        ($type !== 'admin' ? ", approved = 1, registration_code = NULL, code_expires_at = NULL" : "") .
        " WHERE id = ?",
        [$row['id']], 'i'
    );

    addActivityLog(ucfirst($type) . ' Email Verified', ($row['email'] ?? '') . ' verified their account');
    respondSuccess(['id' => $row['id'], 'type' => $type, 'email' => $row['email']], 'Email verified successfully. You can now log in.');
}

function handleResendVerification() {
    ensureEmailAuthSchema();
    $body = getJsonBody();
    $type = strtolower(trim($body['type'] ?? ''));
    $identifier = normalizeLoginIdentifier($body['email'] ?? $body['username'] ?? '');
    if (!in_array($type, ['admin','teacher','parent'], true) || $identifier === '') {
        respondError('Account type and email/username are required', 400);
    }
    $table = $type === 'admin' ? 'admins' : ($type === 'teacher' ? 'teachers' : 'parents');
    $row = findAccountByLogin($table, $identifier);
    if (!$row) respondError('Account not found', 404);
    $name = trim(($row['first_name'] ?? '') . ' ' . ($row['last_name'] ?? '')) ?: ($row['username'] ?? 'User');
    $result = createEmailVerification($table, $row['id'], $row['email'], $name, $type);
    if (!$result['sent']) {
        respondError('Verification email could not be sent. Check the email/SMTP configuration.', 500);
    }
    respondSuccess(['email' => $row['email']], 'A new verification email has been sent.');
}

/**
 * Generate a random alphanumeric code
 */
function generateRegistrationCode($length = 8) {
    $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    $code = '';
    for ($i = 0; $i < $length; $i++) {
        $code .= $chars[random_int(0, strlen($chars) - 1)];
    }
    // Format: NCA-XXXX-XXXX
    return 'NCA-' . substr($code, 0, 4) . '-' . substr($code, 4, 4);
}

/**
 * Admin generates an approval code for a teacher or parent
 */
function handleGenerateCode() {
    $body = getJsonBody();
    $targetType = $body['type'] ?? ''; // 'teacher' or 'parent'
    $targetId = (int)($body['id'] ?? 0);
    
    if (!in_array($targetType, ['teacher', 'parent'])) {
        respondError('Invalid target type. Must be "teacher" or "parent"');
    }
    if (!$targetId) respondError('Target ID required');
    
    $table = $targetType === 'teacher' ? 'teachers' : 'parents';
    $user = dbFetchOne("SELECT * FROM $table WHERE id = ?", [$targetId], 'i');
    if (!$user) respondError(ucfirst($targetType) . ' not found');
    
    // Generate a unique code
    $code = generateRegistrationCode();
    $expiresAt = date('Y-m-d H:i:s', strtotime('+24 hours')); // Code valid for 24 hours
    
    // Save code to database
    $updated = dbExecute(
        "UPDATE $table SET registration_code = ?, code_expires_at = ? WHERE id = ?",
        [$code, $expiresAt, $targetId],
        'ssi'
    );
    
    if ($updated === false) {
        respondError('Failed to generate code');
    }
    
    // "Send" code via email (simulated - log it)
    $email = $user['email'] ?? '';
    $name = trim(($user['first_name'] ?? '') . ' ' . ($user['last_name'] ?? ''));
    if (empty($name)) {
        $name = $user['username'] ?? 'User';
    }
    $subject = "Your Registration Code - Noah Christian Academy";
    $message = "Hello $name,\n\nYour registration approval code is: $code\n\nThis code expires on: $expiresAt\n\nUse this code during registration to complete your account setup.\n\nThank you,\nNoah Christian Academy";
    
    // Log the code generation
    addActivityLog("Registration Code Generated", "Code $code sent to $name ($email) for $targetType account #$targetId");
    
    respondSuccess([
        'code' => $code,
        'expiresAt' => $expiresAt,
        'email' => $email
    ], "Registration code generated and sent to $email. Code: $code");
}

/**
 * Verify a registration code (used during registration)
 */
function handleVerifyCode() {
    $body = getJsonBody();
    $code = trim($body['code'] ?? '');
    $type = $body['type'] ?? ''; // 'admin', 'teacher' or 'parent'

    if (empty($code)) respondError('Code is required');
    if (!in_array($type, ['admin', 'teacher', 'parent'])) respondError('Invalid type');

    $table = $type === 'admin' ? 'admins' : ($type === 'teacher' ? 'teachers' : 'parents');

    // Find user with this code
    $user = dbFetchOne(
        "SELECT id, first_name, last_name, email, registration_code, code_expires_at, approved FROM $table WHERE registration_code = ?",
        [$code], 's'
    );

    if (!$user) {
        respondError('Invalid code. Please check and try again.', 400);
    }

    // Check if expired
    if ($user['code_expires_at'] && strtotime($user['code_expires_at']) < time()) {
        respondError('Code has expired. Please request a new one.', 400);
    }

    // Check if already verified/approved
    if ($type === 'admin') {
        if (isset($user['email_verified']) && $user['email_verified'] == 1) {
            respondError('Account is already verified. Please login directly.', 400);
        }
        // Verify admin account
        dbExecute("UPDATE $table SET email_verified = 1, registration_code = NULL, code_expires_at = NULL WHERE id = ?", [$user['id']], 'i');
    } else {
        if ($user['approved']) {
            respondError('Account is already approved. Please login directly.', 400);
        }
        // Auto-approve teacher/parent account
        dbExecute("UPDATE $table SET approved = 1, registration_code = NULL, code_expires_at = NULL WHERE id = ?", [$user['id']], 'i');
    }

    $label = ucfirst($type);
    $userName = trim(($user['first_name'] ?? '') . ' ' . ($user['last_name'] ?? ''));
    if (empty($userName)) {
        $userName = $user['username'] ?? 'User';
    }
    addActivityLog("$label Verified via Code", "$userName verified using code $code");

    respondSuccess([
        'id' => $user['id'],
        'firstName' => $user['first_name'],
        'lastName' => $user['last_name'],
        'email' => $user['email']
    ], "Account verified successfully! You can now login.");
}

/**
 * Resend/regenerate code
 */
function handleResendCode() {
    $body = getJsonBody();
    $targetType = $body['type'] ?? '';
    $targetId = (int)($body['id'] ?? 0);
    
    if (!in_array($targetType, ['teacher', 'parent'])) {
        respondError('Invalid target type. Must be "teacher" or "parent"');
    }
    if (!$targetId) respondError('Target ID required');
    
    // Re-generate and re-send
    $_REQUEST['action'] = 'generate_code';
    handleGenerateCode();
}


function ensureOAuthTokenSchema() {
    try {
        $conn = getDB();
        $conn->query("CREATE TABLE IF NOT EXISTS oauth_login_tokens (
            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            token_hash CHAR(64) NOT NULL UNIQUE,
            user_type VARCHAR(20) NOT NULL,
            user_id INT NOT NULL,
            expires_at DATETIME NOT NULL,
            used_at DATETIME DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_oauth_user (user_type, user_id),
            INDEX idx_oauth_expires (expires_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Throwable $e) {}
}

function createOAuthLoginToken($userType, $userId) {
    ensureOAuthTokenSchema();
    $raw = bin2hex(random_bytes(32));
    $hash = hash('sha256', $raw);
    $expires = date('Y-m-d H:i:s', strtotime('+5 minutes'));
    dbInsert(
        "INSERT INTO oauth_login_tokens (token_hash, user_type, user_id, expires_at) VALUES (?, ?, ?, ?)",
        [$hash, $userType, $userId, $expires],
        'ssis'
    );
    return $raw;
}

function handleOAuthExchange() {
    ensureOAuthTokenSchema();
    $body = getJsonBody();
    $token = trim($body['token'] ?? '');
    if ($token === '') respondError('OAuth token is required', 400);
    $hash = hash('sha256', $token);
    $row = dbFetchOne(
        "SELECT * FROM oauth_login_tokens WHERE token_hash = ? AND used_at IS NULL AND expires_at > NOW() LIMIT 1",
        [$hash], 's'
    );
    if (!$row) respondError('OAuth login token is invalid or expired.', 401);

    dbExecute("UPDATE oauth_login_tokens SET used_at = NOW() WHERE id = ?", [$row['id']], 'i');

    $type = $row['user_type'];
    if ($type === 'teacher') {
        $u = dbFetchOne("SELECT * FROM teachers WHERE id = ?", [$row['user_id']], 'i');
        if (!$u) respondError('Teacher account not found', 404);
        respondSuccess([
            'id'=>$u['id'],'firstName'=>$u['first_name'],'lastName'=>$u['last_name'],'username'=>$u['username'],
            'email'=>$u['email'],'phone'=>$u['phone'],'subject'=>$u['subject'],'qualification'=>$u['qualification'],
            'class'=>$u['class_assigned'],'approved'=>(bool)$u['approved'],'emailVerified'=>true
        ], 'Google login successful');
    } elseif ($type === 'parent') {
        $u = dbFetchOne("SELECT * FROM parents WHERE id = ?", [$row['user_id']], 'i');
        if (!$u) respondError('Parent account not found', 404);
        respondSuccess([
            'id'=>$u['id'],'firstName'=>$u['first_name'],'lastName'=>$u['last_name'],'username'=>$u['username'],
            'email'=>$u['email'],'phone'=>$u['phone'],'studentIds'=>$u['student_ids'],
            'approved'=>(bool)$u['approved'],'emailVerified'=>true
        ], 'Google login successful');
    } else {
        $u = dbFetchOne("SELECT * FROM admins WHERE id = ?", [$row['user_id']], 'i');
        if (!$u) respondError('Admin account not found', 404);
        $displayName = trim(($u['first_name'] ?? '').' '.($u['last_name'] ?? '')) ?: $u['username'];
        respondSuccess([
            'id'=>$u['id'],'username'=>$u['username'],'displayName'=>$displayName,'email'=>$u['email'],
            'role'=>$u['role'] ?? 'Admin','sessionToken'=>bin2hex(random_bytes(32)),'schoolName'=>'Noah Christian Academy'
        ], 'Google login successful');
    }
}

function handleAdminLogin() {
    $body = getJsonBody();
    $username = normalizeLoginIdentifier($body['username'] ?? $body['email'] ?? '');
    $password = $body['password'] ?? '';

    if (empty($username) || empty($password)) {
        respondError('Username and password required');
    }

    // Check admins table first (for multi-admin support)
    $admin = dbFetchOne(
        "SELECT * FROM admins WHERE (username = ? OR LOWER(email) = LOWER(?)) AND status = 'Active'",
        [$username, $username],
        'ss'
    );

    if ($admin) {
        // Check if account requires code verification
        if (isset($admin['email_verified']) && $admin['email_verified'] == 0) {
            respondError('Please verify your account using the code sent to your email.', 403);
        }

        // Verify password
        if (password_verify($password, $admin['password'])) {
            // Create session record
            $sessionToken = bin2hex(random_bytes(32));
            $ipAddress = $_SERVER['REMOTE_ADDR'] ?? '';
            $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
            $displayName = trim(($admin['first_name'] ?? '') . ' ' . ($admin['last_name'] ?? ''));
            if (empty($displayName)) {
                $displayName = $admin['username'] ?? 'Admin';
            }

            dbInsert(
                "INSERT INTO admin_sessions (admin_id, username, display_name, session_token, ip_address, user_agent) VALUES (?, ?, ?, ?, ?, ?)",
                [$admin['id'], $admin['username'], $displayName, $sessionToken, $ipAddress, $userAgent],
                'issss'
            );

            addActivityLog('Admin Login', "Admin {$admin['username']} logged in");

            respondSuccess([
                'id' => $admin['id'],
                'username' => $admin['username'],
                'displayName' => $displayName,
                'email' => $admin['email'] ?? '',
                'role' => $admin['role'] ?? 'Admin',
                'sessionToken' => $sessionToken,
                'schoolName' => 'Noah Christian Academy'
            ], 'Login successful');
        }
    }

    // Fallback to settings table for backward compatibility
    $rows = dbFetchAll("SELECT setting_key, setting_value FROM settings");
    $config = [];
    foreach ($rows as $row) {
        $config[$row['setting_key']] = $row['setting_value'];
    }

    $storedUsername = $config['username'] ?? 'admin';
    $storedPassword = $config['password'] ?? 'admin123';

    // Check if password is hashed (starts with $2y$) or plain text
    if (strpos($storedPassword, '$2y$') === 0) {
        // Hashed password - use password_verify
        if ($username === $storedUsername && password_verify($password, $storedPassword)) {
            addActivityLog('Login', 'Admin logged in');
            respondSuccess([
                'username' => $config['username'],
                'displayName' => $config['displayName'] ?? 'Admin',
                'email' => $config['email'] ?? '',
                'role' => 'Super Admin',
                'schoolName' => $config['schoolName'] ?? 'Noah Christian Academy'
            ], 'Login successful');
        }
    } else {
        // Plain text password - direct comparison (for backward compatibility)
        if ($username === $storedUsername && $password === $storedPassword) {
            // Auto-upgrade to hashed password
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            dbExecute("UPDATE settings SET setting_value = ? WHERE setting_key = 'password'", [$hashedPassword], 's');
            
            addActivityLog('Login', 'Admin logged in (password upgraded to hash)');
            respondSuccess([
                'username' => $config['username'],
                'displayName' => $config['displayName'] ?? 'Admin',
                'email' => $config['email'] ?? '',
                'role' => 'Super Admin',
                'schoolName' => $config['schoolName'] ?? 'Noah Christian Academy'
            ], 'Login successful');
        }
    }
    respondError('Invalid username or password', 401);
}

function handleAdminRegister() {
    try {
        ensureEmailAuthSchema();
        $body = getJsonBody();
        $firstName = trim($body['firstName'] ?? '');
        $lastName = trim($body['lastName'] ?? '');
        $email = strtolower(trim($body['email'] ?? ''));
        $password = $body['password'] ?? '';

        if ($firstName === '' || $lastName === '' || $email === '' || $password === '') {
            respondError('First name, last name, email and password are required');
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            respondError('Please enter a valid email address.');
        }
        if (strlen($password) < 6) {
            respondError('Password must be at least 6 characters.');
        }

        // Generate username from email
        $username = strtolower(preg_replace('/[^a-z0-9]+/i', '.', $email));
        $username = trim($username, '.');

        // Check if username exists
        if (dbFetchOne("SELECT id FROM admins WHERE username = ? LIMIT 1", [$username], 's')) {
            respondError('Username already exists. Please use a different email.');
        }

        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $displayName = trim($firstName . ' ' . $lastName);

        // Generate verification code
        $code = generateRegistrationCode();
        $expiresAt = date('Y-m-d H:i:s', strtotime('+24 hours'));

        // Create account with code (pending verification)
        $id = dbInsert(
            "INSERT INTO admins (first_name, last_name, username, email, password, role, status, email_verified, registration_code, code_expires_at)
         VALUES (?, ?, ?, ?, ?, 'Admin', 'Active', 0, ?, ?)",
            [$firstName, $lastName, $username, $email, $hashedPassword, $code, $expiresAt],
            'sssssss'
        );

        if (!$id) {
            respondError('Failed to create admin account.');
        }

        // Send code via email
        $subject = "Your Verification Code - Noah Christian Academy";
        $message = "Hello $displayName,\n\nYour admin account registration verification code is: $code\n\nThis code expires on: $expiresAt\n\nEnter this code to activate your account and complete registration.\n\nThank you,\nNoah Christian Academy";

        $sent = false;
        $emailError = '';
        if (function_exists('sendApplicationEmail')) {
            try {
                $sent = sendApplicationEmail($email, $displayName, $subject, $message);
                error_log("Verification code sent to {$email}: " . ($sent ? 'SUCCESS' : 'FAILED'));
            } catch (Throwable $e) {
                $emailError = $e->getMessage();
                error_log("Verification code error for {$email}: " . $emailError);
            }
        } else {
            $emailError = 'sendApplicationEmail function not available';
            error_log($emailError);
        }

        addActivityLog('Admin Registered', "$displayName ($email) created a new admin account (code: $code)");

        if ($sent) {
            respondSuccess([
                'id' => $id,
                'firstName' => $firstName,
                'lastName' => $lastName,
                'email' => $email,
                'username' => $username,
                'code' => $code,
                'requiresCode' => true
            ], 'Admin account created successfully. Your verification code is: ' . $code);
        } else {
            respondSuccess([
                'id' => $id,
                'firstName' => $firstName,
                'lastName' => $lastName,
                'email' => $email,
                'username' => $username,
                'code' => $code,
                'requiresCode' => true,
                'emailError' => $emailError
            ], 'Admin account created. Your verification code is: ' . $code . ' (Email delivery failed: ' . $emailError . '. Use this code manually.)');
        }
    } catch (Throwable $e) {
        error_log('Admin registration error: ' . $e->getMessage());
        respondError('Registration failed: ' . $e->getMessage(), 500);
    }
}

function handleTeacherLogin() {
    ensureEmailAuthSchema();
    $body = getJsonBody();
    $username = normalizeLoginIdentifier($body['username'] ?? $body['email'] ?? '');
    $password = $body['password'] ?? '';

    if (empty($username) || empty($password)) {
        respondError('Username and password required');
    }

    $teacher = dbFetchOne(
        "SELECT * FROM teachers WHERE username = ? OR LOWER(email) = LOWER(?)",
        [$username, $username],
        'ss'
    );

    if (!$teacher) {
        respondError('Account not found', 401);
    }
    
    // Check if password is hashed or plain text
    $storedPassword = $teacher['password'];
    if (strpos($storedPassword, '$2y$') === 0) {
        // Hashed password
        if (!password_verify($password, $storedPassword)) {
            respondError('Incorrect password', 401);
        }
    } else {
        // Plain text - direct comparison with auto-upgrade
        if ($storedPassword !== $password) {
            respondError('Incorrect password', 401);
        }
        // Auto-upgrade to hashed password
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        dbExecute("UPDATE teachers SET password = ? WHERE id = ?", [$hashedPassword, $teacher['id']], 'si');
    }
    
    if (isset($teacher['email_verified']) && !$teacher['email_verified']) {
        respondError('Please verify your email address before logging in. Check your inbox.', 403);
    }

    if (!$teacher['approved']) {
        respondError('Your account is pending approval. Contact the admin for a registration code.', 401);
    }

    $teacherName = trim(($teacher['first_name'] ?? '') . ' ' . ($teacher['last_name'] ?? ''));
    if (empty($teacherName)) {
        $teacherName = $teacher['username'] ?? 'Teacher';
    }
    addActivityLog('Teacher Login', $teacherName . ' logged in');
    respondSuccess([
        'id' => $teacher['id'],
        'firstName' => $teacher['first_name'],
        'lastName' => $teacher['last_name'],
        'username' => $teacher['username'],
        'email' => $teacher['email'],
        'phone' => $teacher['phone'],
        'subject' => $teacher['subject'],
        'qualification' => $teacher['qualification'],
        'class' => $teacher['class_assigned'],
        'approved' => (bool)$teacher['approved'],
        'dateOfEmployment' => $teacher['date_of_employment'] ?? '',
        'nationalId' => $teacher['national_id'] ?? '',
        'residentialAddress' => $teacher['residential_address'] ?? '',
        'nextOfKin' => $teacher['next_of_kin'] ?? '',
        'nextOfKinRelationship' => $teacher['next_of_kin_relationship'] ?? '',
        'nextOfKinPhone' => $teacher['next_of_kin_phone'] ?? ''
    ], 'Login successful');
}

function handleTeacherRegister() {
    ensureEmailAuthSchema();
    $body = getJsonBody();
    $firstName = trim($body['firstName'] ?? '');
    $lastName = trim($body['lastName'] ?? '');
    $fullName = trim($body['fullName'] ?? ''); // Fallback for old format
    $username = trim($body['username'] ?? '');
    $email = strtolower(trim($body['email'] ?? ''));
    $password = $body['password'] ?? '';

    // Handle both old fullName and new firstName/lastName formats
    if ($fullName && !$firstName && !$lastName) {
        $parts = preg_split('/\s+/', $fullName, 2);
        $firstName = $parts[0] ?? '';
        $lastName = $parts[1] ?? '';
    }

    if ($firstName === '' || $lastName === '' || $email === '' || $password === '') respondError('First name, last name, email and password are required');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) respondError('Please enter a valid email address.');
    if (strlen($password) < 8) respondError('Password must be at least 8 characters.');

    if ($username === '') {
        $username = strtolower(preg_replace('/[^a-z0-9]+/i', '.', $email));
        $username = trim($username, '.');
    }

    if (dbFetchOne("SELECT id FROM teachers WHERE username = ? OR LOWER(email) = LOWER(?) LIMIT 1", [$username, $email], 'ss')) {
        respondError('That username or email is already registered.');
    }

    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    $displayName = trim($firstName . ' ' . $lastName);

    // Generate verification code
    $code = generateRegistrationCode();
    $expiresAt = date('Y-m-d H:i:s', strtotime('+24 hours'));

    $id = dbInsert(
        "INSERT INTO teachers (first_name, last_name, username, email, password, approved, registration_code, code_expires_at, email_verified)
         VALUES (?, ?, ?, ?, ?, 1, ?, ?, 0)",
        [$firstName, $lastName, $username, $email, $hashedPassword, $code, $expiresAt],
        'sssssss'
    );

    if (!$id) respondError('Failed to create teacher account.');

    // Send code via email
    $subject = "Your Verification Code - Noah Christian Academy";
    $message = "Hello $displayName,\n\nYour teacher account registration verification code is: $code\n\nThis code expires on: $expiresAt\n\nEnter this code to activate your account and complete registration.\n\nThank you,\nNoah Christian Academy";

    $sent = false;
    $emailError = '';
    if (function_exists('sendApplicationEmail')) {
        try {
            $sent = sendApplicationEmail($email, $displayName, $subject, $message);
            error_log("Verification code sent to {$email}: " . ($sent ? 'SUCCESS' : 'FAILED'));
        } catch (Throwable $e) {
            $emailError = $e->getMessage();
            error_log("Verification code error for {$email}: " . $emailError);
        }
    } else {
        $emailError = 'sendApplicationEmail function not available';
        error_log($emailError);
    }

    addActivityLog('Teacher Registered', "$displayName ($email) created a new teacher account (code: $code)");

    if ($sent) {
        respondSuccess([
            'id' => $id,
            'firstName' => $firstName,
            'lastName' => $lastName,
            'email' => $email,
            'username' => $username,
            'code' => $code,
            'requiresCode' => true
        ], 'Teacher account created successfully. Your verification code is: ' . $code);
    } else {
        respondSuccess([
            'id' => $id,
            'firstName' => $firstName,
            'lastName' => $lastName,
            'email' => $email,
            'username' => $username,
            'code' => $code,
            'requiresCode' => true,
            'emailError' => $emailError
        ], 'Teacher account created. Your verification code is: ' . $code . ' (Email delivery failed: ' . $emailError . '. Use this code manually.)');
    }
}

function handleParentRegister() {
    ensureEmailAuthSchema();
    $body = getJsonBody();
    $firstName = trim($body['firstName'] ?? '');
    $lastName = trim($body['lastName'] ?? '');
    $fullName = trim($body['fullName'] ?? ''); // Fallback for old format
    $username = trim($body['username'] ?? '');
    $email = strtolower(trim($body['email'] ?? ''));
    $password = $body['password'] ?? '';

    // Handle both old fullName and new firstName/lastName formats
    if ($fullName && !$firstName && !$lastName) {
        $parts = preg_split('/\s+/', $fullName, 2);
        $firstName = $parts[0] ?? '';
        $lastName = $parts[1] ?? '';
    }

    if ($firstName === '' || $lastName === '' || $email === '' || $password === '') respondError('First name, last name, email and password are required');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) respondError('Please enter a valid email address.');
    if (strlen($password) < 8) respondError('Password must be at least 8 characters.');

    if ($username === '') {
        $username = strtolower(preg_replace('/[^a-z0-9]+/i', '.', $email));
        $username = trim($username, '.');
    }

    if (dbFetchOne("SELECT id FROM parents WHERE username = ? OR LOWER(email) = LOWER(?) LIMIT 1", [$username, $email], 'ss')) {
        respondError('That username or email is already registered.');
    }

    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    $displayName = trim($firstName . ' ' . $lastName);

    // Generate verification code
    $code = generateRegistrationCode();
    $expiresAt = date('Y-m-d H:i:s', strtotime('+24 hours'));

    $id = dbInsert(
        "INSERT INTO parents (first_name, last_name, username, email, password, approved, registration_code, code_expires_at, email_verified)
         VALUES (?, ?, ?, ?, ?, 1, ?, ?, 0)",
        [$firstName, $lastName, $username, $email, $hashedPassword, $code, $expiresAt],
        'sssssss'
    );

    if (!$id) respondError('Failed to create parent account.');

    // Send code via email
    $subject = "Your Verification Code - Noah Christian Academy";
    $message = "Hello $displayName,\n\nYour parent account registration verification code is: $code\n\nThis code expires on: $expiresAt\n\nEnter this code to activate your account and complete registration.\n\nThank you,\nNoah Christian Academy";

    $sent = false;
    $emailError = '';
    if (function_exists('sendApplicationEmail')) {
        try {
            $sent = sendApplicationEmail($email, $displayName, $subject, $message);
            error_log("Verification code sent to {$email}: " . ($sent ? 'SUCCESS' : 'FAILED'));
        } catch (Throwable $e) {
            $emailError = $e->getMessage();
            error_log("Verification code error for {$email}: " . $emailError);
        }
    } else {
        $emailError = 'sendApplicationEmail function not available';
        error_log($emailError);
    }

    addActivityLog('Parent Registered', "$displayName ($email) created a new parent account (code: $code)");

    if ($sent) {
        respondSuccess([
            'id' => $id,
            'firstName' => $firstName,
            'lastName' => $lastName,
            'email' => $email,
            'username' => $username,
            'code' => $code,
            'requiresCode' => true
        ], 'Parent account created successfully. Your verification code is: ' . $code);
    } else {
        respondSuccess([
            'id' => $id,
            'firstName' => $firstName,
            'lastName' => $lastName,
            'email' => $email,
            'username' => $username,
            'code' => $code,
            'requiresCode' => true,
            'emailError' => $emailError
        ], 'Parent account created. Your verification code is: ' . $code . ' (Email delivery failed: ' . $emailError . '. Use this code manually.)');
    }
}

function handleChangePassword() {
    $body = getJsonBody();
    $current = $body['currentPassword'] ?? '';
    $newPass = $body['newPassword'] ?? '';
    $type = $body['type'] ?? 'admin'; // 'admin' or 'teacher' or 'parent'
    $teacherId = $body['teacherId'] ?? null;
    $parentId = $body['parentId'] ?? null;

    if ($type === 'admin') {
        $row = dbFetchOne("SELECT setting_value FROM settings WHERE setting_key = 'password'");
        $currentPassword = $row['setting_value'] ?? 'admin123';
        if ($current !== $currentPassword) {
            respondError('Current password is incorrect');
        }
        if (strlen($newPass) < 4) {
            respondError('New password must be at least 4 characters');
        }
        dbExecute("UPDATE settings SET setting_value = ? WHERE setting_key = 'password'", [$newPass], 's');
        addActivityLog('Password Changed', 'Admin password was changed');
        respondSuccess([], 'Password changed successfully');
    } elseif ($type === 'teacher' && $teacherId) {
        $teacher = dbFetchOne("SELECT * FROM teachers WHERE id = ?", [$teacherId], 'i');
        if (!$teacher) respondError('Teacher not found');
        if ($current !== $teacher['password']) {
            respondError('Current password is incorrect');
        }
        if (strlen($newPass) < 4) {
            respondError('New password must be at least 4 characters');
        }
        dbExecute("UPDATE teachers SET password = ? WHERE id = ?", [$newPass, $teacherId], 'si');
        respondSuccess([], 'Password changed successfully');
    } elseif ($type === 'parent' && $parentId) {
        $parent = dbFetchOne("SELECT * FROM parents WHERE id = ?", [$parentId], 'i');
        if (!$parent) respondError('Parent not found');
        if ($current !== $parent['password']) {
            respondError('Current password is incorrect');
        }
        if (strlen($newPass) < 4) {
            respondError('New password must be at least 4 characters');
        }
        dbExecute("UPDATE parents SET password = ? WHERE id = ?", [$newPass, $parentId], 'si');
        respondSuccess([], 'Password changed successfully');
    } else {
        respondError('Invalid request');
    }
}

function handleParentLogin() {
    ensureEmailAuthSchema();
    $body = getJsonBody();
    $username = normalizeLoginIdentifier($body['username'] ?? $body['email'] ?? '');
    $password = $body['password'] ?? '';

    if (empty($username) || empty($password)) {
        respondError('Username and password required');
    }

    $parent = dbFetchOne(
        "SELECT * FROM parents WHERE username = ? OR LOWER(email) = LOWER(?)",
        [$username, $username],
        'ss'
    );

    if (!$parent) {
        respondError('Account not found', 401);
    }
    
    // Check if account is deactivated
    if (isset($parent['is_active']) && !$parent['is_active']) {
        logParentLogin($parent['id'], 'blocked');
        respondError('Your account has been deactivated. Contact the admin.', 403);
    }
    
    // Check if password is hashed or plain text
    $storedPassword = $parent['password'];
    if (strpos($storedPassword, '$2y$') === 0) {
        // Hashed password
        if (!password_verify($password, $storedPassword)) {
            logParentLogin($parent['id'], 'failed');
            respondError('Incorrect password', 401);
        }
    } else {
        // Plain text - direct comparison with auto-upgrade
        if ($storedPassword !== $password) {
            logParentLogin($parent['id'], 'failed');
            respondError('Incorrect password', 401);
        }
        // Auto-upgrade to hashed password
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        dbExecute("UPDATE parents SET password = ? WHERE id = ?", [$hashedPassword, $parent['id']], 'si');
    }
    
    if (isset($parent['email_verified']) && !$parent['email_verified']) {
        respondError('Please verify your email address before logging in. Check your inbox.', 403);
    }

    if (!$parent['approved']) {
        respondError('Your account is pending approval. Contact the admin for a registration code.', 401);
    }

    // Log successful login
    logParentLogin($parent['id'], 'success');
    $parentName = trim(($parent['first_name'] ?? '') . ' ' . ($parent['last_name'] ?? ''));
    if (empty($parentName)) {
        $parentName = $parent['username'] ?? 'Parent';
    }
    addActivityLog('Parent Login', $parentName . ' logged in');
    respondSuccess([
        'id' => $parent['id'],
        'firstName' => $parent['first_name'],
        'lastName' => $parent['last_name'],
        'username' => $parent['username'],
        'email' => $parent['email'],
        'phone' => $parent['phone'],
        'studentIds' => $parent['student_ids'],
        'approved' => (bool)$parent['approved']
    ], 'Login successful');
}

function logParentLogin($parentId, $status) {
    try {
        $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';
        $browser = detectBrowser($ua);
        $os = detectOS($ua);
        $device = detectDevice($ua);
        dbInsert(
            "INSERT INTO parent_login_logs (parent_id, ip_address, browser, os, device, user_agent, login_status) VALUES (?, ?, ?, ?, ?, ?, ?)",
            [$parentId, $ip, $browser, $os, $device, substr($ua, 0, 500), $status],
            'issssss'
        );
    } catch (\Exception $e) { /* silent */ }
}

function detectBrowser($ua) {
    if (strpos($ua, 'Chrome') !== false && strpos($ua, 'Edg') === false) return 'Chrome';
    if (strpos($ua, 'Firefox') !== false) return 'Firefox';
    if (strpos($ua, 'Safari') !== false && strpos($ua, 'Chrome') === false) return 'Safari';
    if (strpos($ua, 'Edg') !== false) return 'Edge';
    if (strpos($ua, 'OPR') !== false || strpos($ua, 'Opera') !== false) return 'Opera';
    return 'Unknown';
}

function detectOS($ua) {
    if (strpos($ua, 'Windows NT 10.0') !== false) return 'Windows 10/11';
    if (strpos($ua, 'Windows') !== false) return 'Windows';
    if (strpos($ua, 'Mac OS X') !== false) return 'macOS';
    if (strpos($ua, 'Android') !== false) return 'Android';
    if (strpos($ua, 'iPhone') !== false || strpos($ua, 'iPad') !== false) return 'iOS';
    if (strpos($ua, 'Linux') !== false) return 'Linux';
    return 'Unknown';
}

function detectDevice($ua) {
    if (preg_match('/Mobile|Android|iPhone|iPod/i', $ua)) {
        if (preg_match('/iPad|Tablet/i', $ua)) return 'Tablet';
        return 'Mobile';
    }
    return 'Desktop';
}

/**
 * Handle account deletion request
 */
function handleRequestAccountDeletion() {
    $body = getJsonBody();
    $userType = $body['userType'] ?? ''; // 'teacher' or 'parent'
    $userId = $body['userId'] ?? null;

    if (!in_array($userType, ['teacher', 'parent'])) {
        respondError('Invalid user type. Must be "teacher" or "parent"');
    }

    if (!$userId) respondError('User ID required');

    $table = $userType === 'teacher' ? 'teachers' : 'parents';
    $user = dbFetchOne("SELECT * FROM $table WHERE id = ?", [$userId], 'i');
    if (!$user) respondError(ucfirst($userType) . ' not found');

    // Check if there's already a pending deletion request
    $existingRequest = dbFetchOne(
        "SELECT * FROM account_deletion_requests WHERE user_type = ? AND user_id = ? AND status = 'pending'",
        [$userType, $userId],
        'si'
    );

    if ($existingRequest) {
        respondError('You already have a pending deletion request. Please wait for it to be processed or cancel it.');
    }

    // Calculate deletion time (24 hours from now)
    $deletionTime = date('Y-m-d H:i:s', strtotime('+24 hours'));
    $userName = trim(($user['first_name'] ?? '') . ' ' . ($user['last_name'] ?? ''));
    if (empty($userName)) {
        $userName = $user['username'] ?? 'User';
    }

    // Insert deletion request
    $requestId = dbInsert(
        "INSERT INTO account_deletion_requests (user_type, user_id, user_name, email, requested_at, scheduled_deletion_at, status) VALUES (?, ?, ?, ?, NOW(), ?, 'pending')",
        [$userType, $userId, $userName, $user['email'] ?? '', $deletionTime],
        'sisss'
    );

    if (!$requestId) {
        respondError('Failed to create deletion request');
    }

    // Log the request
    addActivityLog('Account Deletion Requested', "$userType #$userId ($userName) requested account deletion. Scheduled for: $deletionTime");

    // Create admin notification
    dbInsert(
        "INSERT INTO admin_notifications (type, title, message, related_id, created_at, is_read) VALUES (?, ?, ?, ?, NOW(), 0)",
        ['account_deletion', "Account Deletion Request: $userName", "A $userType has requested account deletion. Scheduled for $deletionTime.", $requestId],
        'sssi'
    );

    respondSuccess([
        'requestId' => $requestId,
        'scheduledDeletionAt' => $deletionTime
    ], 'Account deletion request submitted. Your account will be deleted in 24 hours.');
}

/**
 * Check deletion request status
 */
function handleCheckDeletionStatus() {
    $body = getJsonBody();
    $userType = $body['userType'] ?? '';
    $userId = $body['userId'] ?? null;

    if (!in_array($userType, ['teacher', 'parent'])) {
        respondError('Invalid user type');
    }

    if (!$userId) respondError('User ID required');

    $request = dbFetchOne(
        "SELECT * FROM account_deletion_requests WHERE user_type = ? AND user_id = ? AND status = 'pending' ORDER BY requested_at DESC LIMIT 1",
        [$userType, $userId],
        'si'
    );

    if ($request) {
        respondSuccess([
            'status' => $request['status'],
            'scheduledDeletionAt' => $request['scheduled_deletion_at'],
            'requestedAt' => $request['requested_at']
        ], 'Pending deletion request found');
    } else {
        respondSuccess(['status' => 'none'], 'No pending deletion request');
    }
}

/**
 * Cancel deletion request
 */
function handleCancelDeletionRequest() {
    $body = getJsonBody();
    $userType = $body['userType'] ?? '';
    $userId = $body['userId'] ?? null;

    if (!in_array($userType, ['teacher', 'parent'])) {
        respondError('Invalid user type');
    }

    if (!$userId) respondError('User ID required');

    // Check if there's a pending request
    $request = dbFetchOne(
        "SELECT * FROM account_deletion_requests WHERE user_type = ? AND user_id = ? AND status = 'pending' ORDER BY requested_at DESC LIMIT 1",
        [$userType, $userId],
        'si'
    );

    if (!$request) {
        respondError('No pending deletion request found');
    }

    // Update the request status to cancelled
    $updated = dbExecute(
        "UPDATE account_deletion_requests SET status = 'cancelled', processed_at = NOW() WHERE id = ?",
        [$request['id']],
        'i'
    );

    if ($updated === false) {
        respondError('Failed to cancel deletion request');
    }

    // Log the cancellation
    addActivityLog('Account Deletion Cancelled', "$userType #$userId cancelled their account deletion request");

    respondSuccess([], 'Account deletion request cancelled successfully');
}

?>