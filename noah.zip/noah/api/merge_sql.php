<?php
/**
 * SQL Merge Script - Safely merges data from SQL file into existing database
 * Skips CREATE TABLE statements and handles duplicate IDs
 */

require_once __DIR__ . '/db.php';

// Path to the SQL file
$sqlFile = __DIR__ . '/../if0_42680773_noh.sql';

// Check if file exists
if (!file_exists($sqlFile)) {
    die("SQL file not found: $sqlFile\n");
}

// Read the SQL file line by line to handle multi-line statements properly
$lines = file($sqlFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$currentStatement = '';
$inInsert = false;
$successCount = 0;
$errorCount = 0;
$skippedCount = 0;

echo "Starting SQL merge...\n";
echo "================================\n";

foreach ($lines as $line) {
    $trimmedLine = trim($line);
    
    // Skip comments
    if (preg_match('/^--/', $trimmedLine)) {
        continue;
    }
    
    // Skip SET, START TRANSACTION, COMMIT, ROLLBACK
    if (preg_match('/^(SET|START TRANSACTION|COMMIT|ROLLBACK)/i', $trimmedLine)) {
        continue;
    }
    
    // Skip CREATE TABLE, ALTER TABLE, DROP TABLE
    if (preg_match('/^(CREATE|ALTER|DROP)\s+TABLE/i', $trimmedLine)) {
        $skippedCount++;
        echo "Skipped: CREATE/ALTER/DROP TABLE\n";
        continue;
    }
    
    // Detect INSERT statement start
    if (preg_match('/^INSERT\s+INTO/i', $trimmedLine)) {
        $inInsert = true;
        $currentStatement = $trimmedLine;
        continue;
    }
    
    // Continue building INSERT statement
    if ($inInsert) {
        $currentStatement .= ' ' . $trimmedLine;
        
        // Check if statement ends with semicolon
        if (preg_match('/;$/', $trimmedLine)) {
            $inInsert = false;
            
            // Convert INSERT to INSERT IGNORE to handle duplicates
            $modifiedStatement = preg_replace('/^INSERT\s+INTO/i', 'INSERT IGNORE INTO', $currentStatement);
            
            try {
                dbExecute($modifiedStatement);
                $successCount++;
                echo "✓ Executed INSERT statement\n";
            } catch (Exception $e) {
                $errorCount++;
                echo "✗ Error: " . $e->getMessage() . "\n";
                echo "Statement: " . substr($currentStatement, 0, 150) . "...\n";
            }
            
            $currentStatement = '';
        }
    }
}

echo "================================\n";
echo "Merge complete!\n";
echo "Success: $successCount statements\n";
echo "Errors: $errorCount statements\n";
echo "Skipped: $skippedCount statements\n";
