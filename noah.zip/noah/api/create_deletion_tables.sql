-- Create account deletion requests table
CREATE TABLE IF NOT EXISTS account_deletion_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_type VARCHAR(20) NOT NULL, -- 'teacher' or 'parent'
    user_id INT NOT NULL,
    user_name VARCHAR(255) NOT NULL,
    email VARCHAR(255),
    requested_at DATETIME NOT NULL,
    scheduled_deletion_at DATETIME NOT NULL,
    status VARCHAR(20) DEFAULT 'pending', -- 'pending', 'completed', 'cancelled'
    processed_at DATETIME,
    processed_by INT,
    admin_notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user (user_type, user_id),
    INDEX idx_status (status),
    INDEX idx_scheduled (scheduled_deletion_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create admin notifications table
CREATE TABLE IF NOT EXISTS admin_notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    type VARCHAR(50) NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT,
    related_id INT,
    created_at DATETIME NOT NULL,
    is_read TINYINT(1) DEFAULT 0,
    read_at DATETIME,
    INDEX idx_type (type),
    INDEX idx_read (is_read),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
