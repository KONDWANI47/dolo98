<?php
/**
 * Payments API - Noah Christian Academy
 *
 * MySQL-based payment management.
 * Payments are LINKED TO registrations (the central point) via
 * registration_id. Payments can also reference student names.
 *
 * Endpoints:
 *   GET    api/payments.php                      → list all payments
 *   GET    api/payments.php?id=1                 → get single payment
 *   GET    api/payments.php?registrationId=1     → payments for a registration
 *   GET    api/payments.php?action=stats         → payment statistics
 *   POST   api/payments.php                      → create new payment
 *   PUT    api/payments.php?id=1                 → update payment
 *   DELETE api/payments.php?id=1                 → delete payment
 */

require_once __DIR__ . '/db.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: ' . 'GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, Content-Disposition');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$method = $_SERVER['REQUEST_METHOD'];
$id = $_REQUEST['id'] ?? null;
$registrationId = $_REQUEST['registrationId'] ?? null;
$action = $_REQUEST['action'] ?? '';

// ============================================================
// GET — List, filter, single item, stats
// ============================================================
if ($method === 'GET') {
    // Stats endpoint
    if ($action === 'stats') {
        $total = 0;
        $pending = 0;
        $paid = 0;
        $failed = 0;

        $rows = dbFetchAll("SELECT status, COUNT(*) as cnt, SUM(CASE WHEN status = 'Paid' THEN amount ELSE 0 END) as total_amount FROM payments GROUP BY status");
        foreach ($rows as $row) {
            $status = $row['status'] ?? 'Pending';
            $count = (int)$row['cnt'];
            if ($status === 'Paid') {
                $total += (float)($row['total_amount'] ?? 0);
                $paid += $count;
            } elseif ($status === 'Failed') {
                $failed += $count;
            } else {
                $pending += $count;
            }
        }

        respondSuccess([
            'totalAmount' => $total,
            'totalTransactions' => ($paid + $pending + $failed),
            'paid' => $paid,
            'pending' => $pending,
            'failed' => $failed
        ]);
    }

    // Single payment
    if ($id) {
        $payment = dbFetchOne("SELECT * FROM payments WHERE id = ?", [$id], 'i');
        if (!$payment) {
            respondError('Payment not found', 404);
        }
        respondSuccess(formatPayment($payment));
    }

    // Build query with filters
    $where = [];
    $params = [];
    $types = '';

    // Filter by registration_id (central point link)
    if ($registrationId) {
        $where[] = "registration_id = ?";
        $params[] = (int)$registrationId;
        $types .= 'i';
    }

    // Filter by status
    $status = $_REQUEST['status'] ?? null;
    if ($status) {
        $where[] = "status = ?";
        $params[] = $status;
        $types .= 's';
    }

    // Search
    $search = $_REQUEST['search'] ?? null;
    if ($search) {
        $where[] = "(payer_name LIKE ? OR student_name LIKE ? OR phone LIKE ?)";
        $searchParam = '%' . $search . '%';
        $params[] = $searchParam;
        $params[] = $searchParam;
        $params[] = $searchParam;
        $types .= 'sss';
    }

    $whereClause = empty($where) ? '' : 'WHERE ' . implode(' AND ', $where);
    $sql = "SELECT * FROM payments $whereClause ORDER BY created_at DESC";

    $rows = dbFetchAll($sql, $params, $types);
    $payments = array_map('formatPayment', $rows);

    respondSuccess(['items' => $payments, 'total' => count($payments)]);
}

// ============================================================
// POST — Create new payment (linked to registration)
// ============================================================
if ($method === 'POST') {
    // Handle multipart/form-data for file uploads
    if (isset($_FILES['paymentIdPhoto']) && $_FILES['paymentIdPhoto']['error'] === UPLOAD_ERR_OK) {
        // Handle file upload
        $uploadDir = __DIR__ . '/../uploads/payments/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        
        $file = $_FILES['paymentIdPhoto'];
        $fileName = time() . '_' . basename($file['name']);
        $targetPath = $uploadDir . $fileName;
        
        // Validate file type
        $allowedTypes = ['image/jpeg', 'image/png', 'image/jpg', 'image/gif', 'application/pdf'];
        if (!in_array($file['type'], $allowedTypes)) {
            respondError('Invalid file type. Only JPEG, PNG, GIF, and PDF files are allowed.');
        }
        
        // Validate file size (max 5MB)
        if ($file['size'] > 5 * 1024 * 1024) {
            respondError('File size too large. Maximum size is 5MB.');
        }
        
        if (move_uploaded_file($file['tmp_name'], $targetPath)) {
            $paymentProof = 'uploads/payments/' . $fileName;
        } else {
            respondError('Failed to upload file');
        }
    } else {
        $paymentProof = null;
    }
    
    // Get form data
    $payerName = trim($_POST['paymentStudentName'] ?? $_POST['payerName'] ?? $_POST['payer_name'] ?? '');
    $studentName = trim($_POST['paymentStudentName'] ?? $_POST['studentName'] ?? $_POST['student_name'] ?? '');
    $registrationId = $_POST['registrationId'] ?? $_POST['registration_id'] ?? null;
    $amount = $_POST['paymentAmount'] ?? $_POST['amount'] ?? 0;
    $paymentType = $_POST['paymentType'] ?? $_POST['payment_type'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $paymentMethod = $_POST['paymentMethod'] ?? $_POST['payment_method'] ?? '';
    $notes = $_POST['paymentNote'] ?? $_POST['notes'] ?? '';
    $status = $_POST['status'] ?? 'Pending';

    // If no payer name, use student name
    if (empty($payerName) && !empty($studentName)) {
        $payerName = $studentName;
    }

    if (empty($payerName) && empty($studentName)) {
        respondError('Student or payer name is required');
    }
    if ($amount <= 0) {
        respondError('Valid amount is required');
    }

    // If registrationId not provided, try to find by student name
    if (empty($registrationId) && !empty($studentName)) {
        $reg = dbFetchOne(
            "SELECT id FROM registrations WHERE student_name = ? LIMIT 1",
            [$studentName],
            's'
        );
        if ($reg) {
            $registrationId = $reg['id'];
        }
    }

    $id = dbInsert(
        "INSERT INTO payments (payer_name, student_name, registration_id, amount, payment_type, phone, payment_method, notes, status, payment_proof) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        [
            $payerName, $studentName, $registrationId ? (int)$registrationId : null,
            (float)$amount, $paymentType, $phone, $paymentMethod, $notes, $status, $paymentProof
        ],
        'ssisdsssss'
    );

    if ($id) {
        addActivityLog('New Payment', "$payerName - MK" . number_format((float)$amount, 2));
        respondSuccess(['id' => $id], 'Payment submitted successfully! We will process it shortly.');
    }
    respondError('Failed to submit payment');
}

// ============================================================
// PUT — Update payment
// ============================================================
if ($method === 'PUT') {
    if (!$id) {
        respondError('ID is required for update');
    }

    $body = getJsonBody();
    if (!$body) {
        respondError('Invalid request body');
    }

    $updatable = [
        'payerName' => 'payer_name', 'studentName' => 'student_name',
        'registrationId' => 'registration_id', 'amount' => 'amount',
        'paymentType' => 'payment_type', 'phone' => 'phone',
        'paymentMethod' => 'payment_method', 'notes' => 'notes',
        'status' => 'status'
    ];

    $fields = [];
    $params = [];
    $types = '';
    foreach ($updatable as $camel => $snake) {
        if (isset($body[$camel])) {
            $fields[] = "$snake = ?";
            $params[] = $body[$camel];
            $types .= 's';
        }
    }

    if (empty($fields)) {
        respondError('No fields to update');
    }

    $params[] = $id;
    $types .= 'i';

    $affected = dbExecute(
        "UPDATE payments SET " . implode(', ', $fields) . " WHERE id = ?",
        $params,
        $types
    );

    if ($affected === false) {
        respondError('Failed to update payment');
    }

    addActivityLog('Payment Updated', "Payment #$id updated");

    // Fetch and return updated payment
    $payment = dbFetchOne("SELECT * FROM payments WHERE id = ?", [$id], 'i');
    respondSuccess(formatPayment($payment), 'Payment updated successfully');
}

// ============================================================
// DELETE — Remove payment
// ============================================================
if ($method === 'DELETE') {
    if (!$id) {
        respondError('ID is required for deletion');
    }

    $found = dbFetchOne("SELECT id FROM payments WHERE id = ?", [$id], 'i');
    if (!$found) {
        respondError('Payment not found', 404);
    }

    $affected = dbExecute("DELETE FROM payments WHERE id = ?", [$id], 'i');
    if ($affected > 0) {
        addActivityLog('Payment Deleted', "Payment #$id deleted");
        respondSuccess([], 'Payment deleted successfully');
    }
    respondError('Failed to delete payment');
}

respondError('Method not allowed', 405);

// ============================================================
// Payment Gateway Functions
// ============================================================

// Airtel Money Payment
function initiateAirtelPayment($phone, $amount, $reference) {
    $apiKey = 'YOUR_AIRTEL_API_KEY';
    $apiUrl = 'https://openapi.airtel.africa/merchant/v1/payments';

    $payload = [
        'subscriber' => [
            'country' => 'MW',
            'currency' => 'MWK',
            'msisdn' => $phone
        ],
        'transaction' => [
            'amount' => $amount,
            'country' => 'MW',
            'currency' => 'MWK',
            'id' => $reference
        ]
    ];

    // Make API call using cURL
    $ch = curl_init($apiUrl);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $apiKey
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($ch);
    curl_close($ch);

    return json_decode($response, true);
}

// MPamba Payment
function initiateMPambaPayment($phone, $amount, $reference) {
    $apiKey = 'YOUR_MPAMBA_API_KEY';
    $apiUrl = 'https://api.mpamba.com/v1/payment';

    $payload = [
        'phone' => $phone,
        'amount' => $amount,
        'reference' => $reference,
        'callback_url' => 'http://noah98.gt.tc/api/payment-callback.php'
    ];

    $ch = curl_init($apiUrl);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $apiKey
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($ch);
    curl_close($ch);

    return json_decode($response, true);
}

// ============================================================
// Helper: Format payment row for API response
// ============================================================
function formatPayment($p) {
    return [
        'id' => (int)$p['id'],
        'registrationId' => $p['registration_id'] ?? null,
        'payerName' => $p['payer_name'] ?? '',
        'studentName' => $p['student_name'] ?? '',
        'amount' => (float)($p['amount'] ?? 0),
        'paymentType' => $p['payment_type'] ?? '',
        'phone' => $p['phone'] ?? '',
        'paymentMethod' => $p['payment_method'] ?? '',
        'notes' => $p['notes'] ?? '',
        'status' => $p['status'] ?? 'Pending',
        'createdAt' => $p['created_at'] ?? null,
        'updatedAt' => $p['updated_at'] ?? null,
        'paymentProof' => $p['payment_proof'] ?? null
    ];
}
