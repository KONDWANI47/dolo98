<?php
/**
 * Insert Default Certificate Templates
 * Creates professional pre-designed certificate templates
 */

require_once __DIR__ . '/db.php';

// Default templates with basic designs
$defaultTemplates = [
    [
        'name' => 'Academic Excellence',
        'description' => 'Classic academic achievement certificate with elegant border',
        'category' => 'Academic',
        'canvas_width' => 1123,
        'canvas_height' => 794,
        'unit' => 'px',
        'orientation' => 'landscape',
        'background_type' => 'solid',
        'background_color' => '#FFFFFF',
        'is_system_template' => 1,
        'is_public' => 1,
        'status' => 'active',
        'design_json' => json_encode([
            'version' => '5.3.1',
            'objects' => [
                [
                    'type' => 'rect',
                    'left' => 20,
                    'top' => 20,
                    'width' => 1083,
                    'height' => 754,
                    'fill' => '#085636',
                    'stroke' => '#085636',
                    'strokeWidth' => 5
                ],
                [
                    'type' => 'rect',
                    'left' => 30,
                    'top' => 30,
                    'width' => 1063,
                    'height' => 734,
                    'fill' => '#FFFFFF',
                    'stroke' => '#085636',
                    'strokeWidth' => 2
                ],
                [
                    'type' => 'i-text',
                    'left' => 561,
                    'top' => 100,
                    'originX' => 'center',
                    'originY' => 'center',
                    'text' => 'CERTIFICATE OF ACHIEVEMENT',
                    'fontSize' => 48,
                    'fontFamily' => 'Times New Roman',
                    'fill' => '#085636',
                    'fontWeight' => 'bold'
                ],
                [
                    'type' => 'i-text',
                    'left' => 561,
                    'top' => 200,
                    'originX' => 'center',
                    'originY' => 'center',
                    'text' => 'This certificate is proudly presented to',
                    'fontSize' => 24,
                    'fontFamily' => 'Arial',
                    'fill' => '#333333'
                ],
                [
                    'type' => 'i-text',
                    'left' => 561,
                    'top' => 280,
                    'originX' => 'center',
                    'originY' => 'center',
                    'text' => '{{student_name}}',
                    'fontSize' => 36,
                    'fontFamily' => 'Times New Roman',
                    'fill' => '#085636',
                    'fontWeight' => 'bold',
                    'data' => ['isDynamic' => true, 'fieldName' => 'student_name']
                ],
                [
                    'type' => 'i-text',
                    'left' => 561,
                    'top' => 360,
                    'originX' => 'center',
                    'originY' => 'center',
                    'text' => 'for outstanding performance in',
                    'fontSize' => 24,
                    'fontFamily' => 'Arial',
                    'fill' => '#333333'
                ],
                [
                    'type' => 'i-text',
                    'left' => 561,
                    'top' => 420,
                    'originX' => 'center',
                    'originY' => 'center',
                    'text' => '{{award_title}}',
                    'fontSize' => 32,
                    'fontFamily' => 'Times New Roman',
                    'fill' => '#085636',
                    'fontWeight' => 'bold',
                    'data' => ['isDynamic' => true, 'fieldName' => 'award_title']
                ],
                [
                    'type' => 'i-text',
                    'left' => 561,
                    'top' => 520,
                    'originX' => 'center',
                    'originY' => 'center',
                    'text' => 'Date: {{date}}',
                    'fontSize' => 18,
                    'fontFamily' => 'Arial',
                    'fill' => '#666666',
                    'data' => ['isDynamic' => true, 'fieldName' => 'date']
                ],
                [
                    'type' => 'i-text',
                    'left' => 561,
                    'top' => 560,
                    'originX' => 'center',
                    'originY' => 'center',
                    'text' => 'Certificate No: {{certificate_number}}',
                    'fontSize' => 16,
                    'fontFamily' => 'Arial',
                    'fill' => '#666666',
                    'data' => ['isDynamic' => true, 'fieldName' => 'certificate_number']
                ]
            ]
        ])
    ],
    [
        'name' => 'Graduation Certificate',
        'description' => 'Formal graduation certificate with classic design',
        'category' => 'Graduation',
        'canvas_width' => 1123,
        'canvas_height' => 794,
        'unit' => 'px',
        'orientation' => 'landscape',
        'background_type' => 'solid',
        'background_color' => '#FFFFFF',
        'is_system_template' => 1,
        'is_public' => 1,
        'status' => 'active',
        'design_json' => json_encode([
            'version' => '5.3.1',
            'objects' => [
                [
                    'type' => 'rect',
                    'left' => 0,
                    'top' => 0,
                    'width' => 1123,
                    'height' => 794,
                    'fill' => '#F5F5DC',
                    'stroke' => '#085636',
                    'strokeWidth' => 10
                ],
                [
                    'type' => 'rect',
                    'left' => 15,
                    'top' => 15,
                    'width' => 1093,
                    'height' => 764,
                    'fill' => '#FFFFFF',
                    'stroke' => '#085636',
                    'strokeWidth' => 3
                ],
                [
                    'type' => 'i-text',
                    'left' => 561,
                    'top' => 100,
                    'originX' => 'center',
                    'originY' => 'center',
                    'text' => 'GRADUATION CERTIFICATE',
                    'fontSize' => 52,
                    'fontFamily' => 'Times New Roman',
                    'fill' => '#085636',
                    'fontWeight' => 'bold'
                ],
                [
                    'type' => 'i-text',
                    'left' => 561,
                    'top' => 200,
                    'originX' => 'center',
                    'originY' => 'center',
                    'text' => 'This is to certify that',
                    'fontSize' => 24,
                    'fontFamily' => 'Arial',
                    'fill' => '#333333'
                ],
                [
                    'type' => 'i-text',
                    'left' => 561,
                    'top' => 280,
                    'originX' => 'center',
                    'originY' => 'center',
                    'text' => '{{student_name}}',
                    'fontSize' => 40,
                    'fontFamily' => 'Times New Roman',
                    'fill' => '#085636',
                    'fontWeight' => 'bold',
                    'data' => ['isDynamic' => true, 'fieldName' => 'student_name']
                ],
                [
                    'type' => 'i-text',
                    'left' => 561,
                    'top' => 360,
                    'originX' => 'center',
                    'originY' => 'center',
                    'text' => 'has successfully completed the requirements for',
                    'fontSize' => 24,
                    'fontFamily' => 'Arial',
                    'fill' => '#333333'
                ],
                [
                    'type' => 'i-text',
                    'left' => 561,
                    'top' => 420,
                    'originX' => 'center',
                    'originY' => 'center',
                    'text' => '{{award_title}}',
                    'fontSize' => 32,
                    'fontFamily' => 'Times New Roman',
                    'fill' => '#085636',
                    'fontWeight' => 'bold',
                    'data' => ['isDynamic' => true, 'fieldName' => 'award_title']
                ],
                [
                    'type' => 'i-text',
                    'left' => 561,
                    'top' => 520,
                    'originX' => 'center',
                    'originY' => 'center',
                    'text' => 'Awarded on {{date}}',
                    'fontSize' => 20,
                    'fontFamily' => 'Arial',
                    'fill' => '#666666',
                    'data' => ['isDynamic' => true, 'fieldName' => 'date']
                ]
            ]
        ])
    ],
    [
        'name' => 'Sports Achievement',
        'description' => 'Dynamic sports certificate with bold design',
        'category' => 'Sports',
        'canvas_width' => 1123,
        'canvas_height' => 794,
        'unit' => 'px',
        'orientation' => 'landscape',
        'background_type' => 'solid',
        'background_color' => '#FFFFFF',
        'is_system_template' => 1,
        'is_public' => 1,
        'status' => 'active',
        'design_json' => json_encode([
            'version' => '5.3.1',
            'objects' => [
                [
                    'type' => 'rect',
                    'left' => 0,
                    'top' => 0,
                    'width' => 1123,
                    'height' => 794,
                    'fill' => '#1E90FF',
                    'stroke' => '#1E90FF',
                    'strokeWidth' => 0
                ],
                [
                    'type' => 'rect',
                    'left' => 20,
                    'top' => 20,
                    'width' => 1083,
                    'height' => 754,
                    'fill' => '#FFFFFF',
                    'stroke' => '#1E90FF',
                    'strokeWidth' => 5
                ],
                [
                    'type' => 'i-text',
                    'left' => 561,
                    'top' => 100,
                    'originX' => 'center',
                    'originY' => 'center',
                    'text' => 'SPORTS ACHIEVEMENT',
                    'fontSize' => 48,
                    'fontFamily' => 'Arial Black',
                    'fill' => '#1E90FF',
                    'fontWeight' => 'bold'
                ],
                [
                    'type' => 'i-text',
                    'left' => 561,
                    'top' => 200,
                    'originX' => 'center',
                    'originY' => 'center',
                    'text' => 'Awarded to',
                    'fontSize' => 24,
                    'fontFamily' => 'Arial',
                    'fill' => '#333333'
                ],
                [
                    'type' => 'i-text',
                    'left' => 561,
                    'top' => 280,
                    'originX' => 'center',
                    'originY' => 'center',
                    'text' => '{{student_name}}',
                    'fontSize' => 36,
                    'fontFamily' => 'Arial Black',
                    'fill' => '#1E90FF',
                    'fontWeight' => 'bold',
                    'data' => ['isDynamic' => true, 'fieldName' => 'student_name']
                ],
                [
                    'type' => 'i-text',
                    'left' => 561,
                    'top' => 360,
                    'originX' => 'center',
                    'originY' => 'center',
                    'text' => 'for excellence in',
                    'fontSize' => 24,
                    'fontFamily' => 'Arial',
                    'fill' => '#333333'
                ],
                [
                    'type' => 'i-text',
                    'left' => 561,
                    'top' => 420,
                    'originX' => 'center',
                    'originY' => 'center',
                    'text' => '{{award_title}}',
                    'fontSize' => 32,
                    'fontFamily' => 'Arial Black',
                    'fill' => '#1E90FF',
                    'fontWeight' => 'bold',
                    'data' => ['isDynamic' => true, 'fieldName' => 'award_title']
                ],
                [
                    'type' => 'i-text',
                    'left' => 561,
                    'top' => 520,
                    'originX' => 'center',
                    'originY' => 'center',
                    'text' => '{{date}}',
                    'fontSize' => 20,
                    'fontFamily' => 'Arial',
                    'fill' => '#666666',
                    'data' => ['isDynamic' => true, 'fieldName' => 'date']
                ]
            ]
        ])
    ],
    [
        'name' => 'Appreciation Certificate',
        'description' => 'Warm appreciation certificate with elegant design',
        'category' => 'Appreciation',
        'canvas_width' => 1123,
        'canvas_height' => 794,
        'unit' => 'px',
        'orientation' => 'landscape',
        'background_type' => 'solid',
        'background_color' => '#FFFFFF',
        'is_system_template' => 1,
        'is_public' => 1,
        'status' => 'active',
        'design_json' => json_encode([
            'version' => '5.3.1',
            'objects' => [
                [
                    'type' => 'rect',
                    'left' => 0,
                    'top' => 0,
                    'width' => 1123,
                    'height' => 794,
                    'fill' => '#FFB6C1',
                    'stroke' => '#FF69B4',
                    'strokeWidth' => 0
                ],
                [
                    'type' => 'rect',
                    'left' => 20,
                    'top' => 20,
                    'width' => 1083,
                    'height' => 754,
                    'fill' => '#FFFFFF',
                    'stroke' => '#FF69B4',
                    'strokeWidth' => 5
                ],
                [
                    'type' => 'i-text',
                    'left' => 561,
                    'top' => 100,
                    'originX' => 'center',
                    'originY' => 'center',
                    'text' => 'CERTIFICATE OF APPRECIATION',
                    'fontSize' => 48,
                    'fontFamily' => 'Times New Roman',
                    'fill' => '#FF69B4',
                    'fontWeight' => 'bold'
                ],
                [
                    'type' => 'i-text',
                    'left' => 561,
                    'top' => 200,
                    'originX' => 'center',
                    'originY' => 'center',
                    'text' => 'With sincere appreciation to',
                    'fontSize' => 24,
                    'fontFamily' => 'Arial',
                    'fill' => '#333333'
                ],
                [
                    'type' => 'i-text',
                    'left' => 561,
                    'top' => 280,
                    'originX' => 'center',
                    'originY' => 'center',
                    'text' => '{{student_name}}',
                    'fontSize' => 36,
                    'fontFamily' => 'Times New Roman',
                    'fill' => '#FF69B4',
                    'fontWeight' => 'bold',
                    'data' => ['isDynamic' => true, 'fieldName' => 'student_name']
                ],
                [
                    'type' => 'i-text',
                    'left' => 561,
                    'top' => 360,
                    'originX' => 'center',
                    'originY' => 'center',
                    'text' => 'for outstanding contribution in',
                    'fontSize' => 24,
                    'fontFamily' => 'Arial',
                    'fill' => '#333333'
                ],
                [
                    'type' => 'i-text',
                    'left' => 561,
                    'top' => 420,
                    'originX' => 'center',
                    'originY' => 'center',
                    'text' => '{{award_title}}',
                    'fontSize' => 32,
                    'fontFamily' => 'Times New Roman',
                    'fill' => '#FF69B4',
                    'fontWeight' => 'bold',
                    'data' => ['isDynamic' => true, 'fieldName' => 'award_title']
                ],
                [
                    'type' => 'i-text',
                    'left' => 561,
                    'top' => 520,
                    'originX' => 'center',
                    'originY' => 'center',
                    'text' => '{{date}}',
                    'fontSize' => 20,
                    'fontFamily' => 'Arial',
                    'fill' => '#666666',
                    'data' => ['isDynamic' => true, 'fieldName' => 'date']
                ]
            ]
        ])
    ]
];

$conn = getDB();
$insertedCount = 0;

foreach ($defaultTemplates as $template) {
    // Check if template already exists
    $existing = dbFetchOne(
        "SELECT id FROM certificate_templates WHERE name = ? AND is_system_template = 1",
        [$template['name']]
    );

    if (!$existing) {
        $sql = "INSERT INTO certificate_templates (
            name, description, category, canvas_width, canvas_height, unit, orientation,
            background_type, background_color, design_json, preview_image,
            created_by, created_by_name, is_system_template, is_public, status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        $params = [
            $template['name'],
            $template['description'],
            $template['category'],
            $template['canvas_width'],
            $template['canvas_height'],
            $template['unit'],
            $template['orientation'],
            $template['background_type'],
            $template['background_color'],
            $template['design_json'],
            '',
            null,
            'System',
            $template['is_system_template'],
            $template['is_public'],
            $template['status']
        ];

        $templateId = dbInsert($sql, $params);
        if ($templateId > 0) {
            $insertedCount++;
            echo "Inserted template: " . $template['name'] . "\n";
        }
    } else {
        echo "Template already exists: " . $template['name'] . "\n";
    }
}

echo "\nInserted $insertedCount new templates.\n";
?>
