<?php
/**
 * Database Merge Script - Noah Christian Academy
 * Safely merges data from SQL file into existing database without creating duplicates
 * Handles duplicate IDs by using INSERT IGNORE or ON DUPLICATE KEY UPDATE
 */

require_once __DIR__ . '/db.php';

header('Content-Type: application/json');

$sqlFile = __DIR__ . '/../if0_42680773_noh.sql';

if (!file_exists($sqlFile)) {
    respondError('SQL file not found: ' . $sqlFile);
}

try {
    $conn = getDB();
    
    // Read SQL file
    $sqlContent = file_get_contents($sqlFile);
    
    // Parse SQL file to extract INSERT statements
    $insertStatements = [];
    $currentTable = null;
    $lines = explode("\n", $sqlContent);
    
    foreach ($lines as $line) {
        $line = trim($line);
        
        // Skip comments and empty lines
        if (empty($line) || strpos($line, '--') === 0 || strpos($line, '/*') === 0) {
            continue;
        }
        
        // Detect INSERT INTO statement
        if (preg_match('/^INSERT INTO `([^`]+)`/i', $line, $matches)) {
            $currentTable = $matches[1];
            if (!isset($insertStatements[$currentTable])) {
                $insertStatements[$currentTable] = [];
            }
            $insertStatements[$currentTable][] = $line;
        } elseif ($currentTable && !empty($line)) {
            // Continue multi-line INSERT statement
            $lastIndex = count($insertStatements[$currentTable]) - 1;
            $insertStatements[$currentTable][$lastIndex] .= "\n" . $line;
        }
    }
    
    $results = [];
    $totalInserted = 0;
    $totalSkipped = 0;
    $totalUpdated = 0;
    
    foreach ($insertStatements as $tableName => $statements) {
        // Check if table exists
        $tableExists = dbFetchOne("SHOW TABLES LIKE ?", [$tableName], 's');
        
        if (!$tableExists) {
            $results[$tableName] = [
                'status' => 'skipped',
                'reason' => 'Table does not exist in database',
                'records' => 0
            ];
            continue;
        }
        
        // Get table structure to find primary key
        $columns = dbFetchAll("SHOW COLUMNS FROM `{$tableName}`");
        $primaryKey = null;
        foreach ($columns as $col) {
            if ($col['Key'] === 'PRI') {
                $primaryKey = $col['Field'];
                break;
            }
        }
        
        $tableInserted = 0;
        $tableSkipped = 0;
        $tableUpdated = 0;
        
        foreach ($statements as $statement) {
            // Convert INSERT to INSERT IGNORE to skip duplicates
            $safeStatement = preg_replace(
                '/^INSERT INTO/i',
                'INSERT IGNORE INTO',
                $statement
            );
            
            $conn->query($safeStatement);
            
            if ($conn->affected_rows > 0) {
                $tableInserted += $conn->affected_rows;
            } else {
                // Check if it was a duplicate
                if ($conn->errno === 1062) {
                    $tableSkipped++;
                }
            }
        }
        
        $results[$tableName] = [
            'status' => 'success',
            'inserted' => $tableInserted,
            'skipped' => $tableSkipped,
            'updated' => $tableUpdated,
            'total' => $tableInserted + $tableSkipped + $tableUpdated
        ];
        
        $totalInserted += $tableInserted;
        $totalSkipped += $tableSkipped;
        $totalUpdated += $tableUpdated;
    }
    
    respondSuccess([
        'results' => $results,
        'summary' => [
            'tablesProcessed' => count($results),
            'totalInserted' => $totalInserted,
            'totalSkipped' => $totalSkipped,
            'totalUpdated' => $totalUpdated,
            'totalRecords' => $totalInserted + $totalSkipped + $totalUpdated
        ]
    ], 'Database merge completed successfully');
    
} catch (Exception $e) {
    respondError('Merge failed: ' . $e->getMessage(), 500);
}
