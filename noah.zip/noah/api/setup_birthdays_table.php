<?php
/**
 * Setup Birthdays Table
 * Creates the birthdays table for managing student and staff birthdays
 */

require_once 'db.php';

echo "<h2>Setting up Birthdays Table</h2>";

try {
    $conn = getDB();
    
    // Check if table exists
    $result = $conn->query("SHOW TABLES LIKE 'birthdays'");
    if ($result->num_rows > 0) {
        echo "<p>✓ birthdays table already exists</p>";
    } else {
        // Create birthdays table
        $sql = "CREATE TABLE `birthdays` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `name` varchar(255) NOT NULL,
            `type` enum('student','staff') NOT NULL DEFAULT 'student',
            `birthday` date NOT NULL,
            `class` varchar(100) DEFAULT NULL,
            `photo` varchar(255) DEFAULT NULL,
            `message` text DEFAULT NULL,
            `status` enum('active','inactive') DEFAULT 'active',
            `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
            `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
            PRIMARY KEY (`id`),
            KEY `type` (`type`),
            KEY `birthday` (`birthday`),
            KEY `status` (`status`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        
        if ($conn->query($sql)) {
            echo "<p>✓ birthdays table created successfully</p>";
        } else {
            echo "<p style='color:red'>✗ Failed to create birthdays table: " . $conn->error . "</p>";
        }
    }
    
    // Show table structure
    $columns = $conn->query("DESCRIBE birthdays");
    echo "<p>Table has " . $columns->num_rows . " columns</p>";
    
    echo "<p><strong>Setup complete!</strong></p>";
    
} catch (Exception $e) {
    echo "<p style='color:red'>Error: " . $e->getMessage() . "</p>";
}
?>
