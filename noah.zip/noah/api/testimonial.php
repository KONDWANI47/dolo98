<?php
/**
 * Testimonial API - Noah Christian Academy
 * Handles testimonial submission and retrieval
 */

// Suppress errors to prevent HTML output
error_reporting(0);
ini_set('display_errors', 0);

// Start output buffering to catch any stray output
ob_start();

// Safety net: always return JSON even on fatal errors
register_shutdown_function(function() {
    $error = error_get_last();
    if ($error && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        while (ob_get_level()) { ob_end_clean(); }
        http_response_code(500);
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Server error: ' . $error['message']]);
    }
});

require_once 'db.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    ob_end_clean();
    exit();
}

// Handle different actions
$action = $_GET['action'] ?? '';

switch ($action) {
    case 'get_approved':
        getApprovedTestimonials();
        break;
    default:
        submitTestimonial();
        break;
}

/**
 * Submit a new testimonial
 */
function submitTestimonial() {
    try {
        $body = getJsonBody();
        
        // Validate required fields
        $required = ['parentName', 'studentName', 'grade', 'yearsEnrolled', 'testimonial', 'rating'];
        foreach ($required as $field) {
            if (empty($body[$field])) {
                respondError("Field '$field' is required");
            }
        }
        
        // Sanitize and validate inputs
        $parentName = trim($body['parentName']);
        $studentName = trim($body['studentName']);
        $grade = trim($body['grade']);
        $yearsEnrolled = intval($body['yearsEnrolled']);
        $testimonial = trim($body['testimonial']);
        $rating = intval($body['rating']);
        $anonymous = isset($body['anonymous']) ? 1 : 0;
        
        // Validate rating
        if ($rating < 1 || $rating > 5) {
            respondError('Rating must be between 1 and 5');
        }
        
        // Validate years enrolled
        if ($yearsEnrolled < 1) {
            respondError('Years enrolled must be at least 1');
        }
        
        // Insert testimonial
        $sql = "INSERT INTO testimonials (parent_name, student_name, grade, years_enrolled, testimonial, rating, anonymous, status, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', NOW())";
        
        $testimonialId = dbInsert($sql, [
            $parentName,
            $studentName,
            $grade,
            $yearsEnrolled,
            $testimonial,
            $rating,
            $anonymous
        ], 'sssisii');
        
        if ($testimonialId > 0) {
            addActivityLog('testimonial_submitted', "New testimonial submitted by $parentName");
            respondSuccess(['testimonialId' => $testimonialId], 'Testimonial submitted successfully. It will be reviewed by admin.');
        } else {
            respondError('Failed to submit testimonial');
        }
    } catch (Exception $e) {
        respondError('Server error: ' . $e->getMessage());
    }
}

/**
 * Get approved testimonials for public display
 */
function getApprovedTestimonials() {
    try {
        $sql = "SELECT id, parent_name, student_name, grade, testimonial, rating, anonymous, created_at 
                FROM testimonials 
                WHERE status = 'approved' 
                ORDER BY created_at DESC 
                LIMIT 20";
        
        $testimonials = dbFetchAll($sql);
        
        respondSuccess($testimonials, 'Testimonials retrieved successfully');
    } catch (Exception $e) {
        respondError('Server error: ' . $e->getMessage());
    }
}

if (!function_exists('respondSuccess')) {
    function respondSuccess($data = [], $message = 'Success') {
        ob_end_clean();
        echo json_encode(['success' => true, 'message' => $message, 'data' => $data]);
        exit();
    }
}

if (!function_exists('respondError')) {
    function respondError($message, $code = 400) {
        ob_end_clean();
        http_response_code($code);
        echo json_encode(['success' => false, 'message' => $message]);
        exit();
    }
}
