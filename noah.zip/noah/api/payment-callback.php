<?php
/**
 * Payment Callback Handler - Noah Christian Academy
 * 
 * Handles payment callbacks from Airtel Money and MPamba
 * Updates payment status in database
 */

require_once __DIR__ . '/db.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Get callback data
$input = file_get_contents('php://input');
$data = json_decode($input, true);

if (!$data) {
    respondError('Invalid callback data', 400);
}


// Log callback for debugging
error_log('Payment Callback: ' . json_encode($data));

// Extract payment reference
$reference = $data['transaction']['id'] ?? $data['reference'] ?? $data['transaction_id'] ?? null;
$status = $data['status'] ?? $data['transaction']['status'] ?? null;
$amount = $data['transaction']['amount'] ?? $data['amount'] ?? null;

if (!$reference) {
    respondError('Missing payment reference', 400);
}

// Find payment by reference
$payment = dbFetchOne(
    "SELECT * FROM payments WHERE id = ? OR notes LIKE ? LIMIT 1",
    [$reference, "%$reference%"],
    'ss'
);

if (!$payment) {
    respondError('Payment not found', 404);
}

// Update payment status based on callback
$status = strtolower((string)$status);
$newStatus = 'Pending';
if ($status === 'success' || $status === 'completed' || $status === 'paid') {
    $newStatus = 'Paid';
} elseif ($status === 'failed' || $status === 'cancelled') {
    $newStatus = 'Failed';
}

// Update payment in database
$affected = dbExecute(
    "UPDATE payments SET status = ?, updated_at = NOW() WHERE id = ?",
    [$newStatus, $payment['id']],
    'si'
);

if ($affected > 0) {
    addActivityLog('Payment Callback', "Payment #{$payment['id']} status updated to $newStatus");
    respondSuccess([
        'payment_id' => $payment['id'],
        'status' => $newStatus,
        'reference' => $reference
    ], 'Payment status updated successfully');
}

respondError('Failed to update payment status', 500);

// NOTE: respondError(), respondSuccess() and addActivityLog() are already
// provided by db.php (required above). Re-declaring them here caused a
// fatal "Cannot redeclare" error that broke every payment callback.
