<?php
/**
 * Data Sync API - Noah Christian Academy
 *
 * Allows importing localStorage data to the MySQL database
 * and exporting server data back to localStorage
 */

require_once __DIR__ . '/db.php';

// ============================================================
// Handle import - receive data from client and save to MySQL
// ============================================================
function handleImport() {
    $body = getJsonBody();
    if (!$body) {
        respondError('Invalid request body');
    }

    $importType = $body['type'] ?? ''; // 'admin' or 'teacher'
    $importData = $body['data'] ?? null;

    if (empty($importType) || !$importData) {
        respondError('type and data are required');
    }

    $count = 0;

    switch ($importType) {
        case 'admin':
            // Import students
            if (isset($importData['students']) && is_array($importData['students'])) {
                foreach ($importData['students'] as $s) {
                    $existing = dbFetchOne("SELECT id FROM students WHERE first_name = ? AND last_name = ? AND parent_name = ?",
                        [$s['firstName'] ?? '', $s['lastName'] ?? '', $s['parentName'] ?? ''], 'sss');
                    if ($existing) {
                        dbExecute("UPDATE students SET grade = ?, phone = ?, status = ?, fees_status = ? WHERE id = ?",
                            [$s['grade'] ?? '', $s['phone'] ?? '', $s['status'] ?? 'Active', $s['feesStatus'] ?? 'Pending', $existing['id']], 'sssi');
                    } else {
                        dbInsert("INSERT INTO students (first_name, last_name, grade, parent_name, phone, email, address, status, fees_status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                            [$s['firstName'] ?? '', $s['lastName'] ?? '', $s['grade'] ?? '', $s['parentName'] ?? '', $s['phone'] ?? '', $s['email'] ?? '', $s['address'] ?? '', $s['status'] ?? 'Active', $s['feesStatus'] ?? 'Pending'], 'sssssssss');
                    }
                    $count++;
                }
            }

            // Import registrations
            if (isset($importData['registrations']) && is_array($importData['registrations'])) {
                foreach ($importData['registrations'] as $r) {
                    $existing = dbFetchOne("SELECT id FROM registrations WHERE student_name = ? AND parent_name = ?",
                        [$r['studentName'] ?? '', $r['parentName'] ?? ''], 'ss');
                    if ($existing) {
                        dbExecute("UPDATE registrations SET grade = ?, phone = ?, email = ?, status = ? WHERE id = ?",
                            [$r['grade'] ?? '', $r['phone'] ?? '', $r['email'] ?? '', $r['status'] ?? 'Pending', $existing['id']], 'ssssi');
                    } else {
                        dbInsert("INSERT INTO registrations (student_name, grade, parent_name, phone, email, address, dob, notes, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                            [$r['studentName'] ?? '', $r['grade'] ?? '', $r['parentName'] ?? '', $r['phone'] ?? '', $r['email'] ?? '', $r['address'] ?? '', $r['dateOfBirth'] ?? null, $r['notes'] ?? '', $r['status'] ?? 'Pending'], 'sssssssss');
                    }
                    $count++;
                }
            }

            // Import payments
            if (isset($importData['payments']) && is_array($importData['payments'])) {
                foreach ($importData['payments'] as $p) {
                    dbInsert("INSERT INTO payments (payer_name, student_name, amount, payment_type, phone, payment_method, notes, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                        [$p['payerName'] ?? '', $p['studentName'] ?? '', $p['amount'] ?? 0, $p['paymentType'] ?? '', $p['phone'] ?? '', $p['paymentMethod'] ?? '', $p['notes'] ?? '', $p['status'] ?? 'Pending'], 'ssdssss');
                    $count++;
                }
            }

            // Import events
            if (isset($importData['events']) && is_array($importData['events'])) {
                foreach ($importData['events'] as $e) {
                    dbInsert("INSERT INTO events (title, date, time, location, description, status) VALUES (?, ?, ?, ?, ?, ?)",
                        [$e['title'] ?? '', $e['date'] ?? null, $e['time'] ?? null, $e['location'] ?? '', $e['description'] ?? '', $e['status'] ?? 'Upcoming'], 'ssssss');
                    $count++;
                }
            }

            // Import messages
            if (isset($importData['messages']) && is_array($importData['messages'])) {
                foreach ($importData['messages'] as $m) {
                    dbInsert("INSERT INTO messages (name, email, subject, message) VALUES (?, ?, ?, ?)",
                        [$m['name'] ?? '', $m['email'] ?? '', $m['subject'] ?? '', $m['message'] ?? ''], 'ssss');
                    $count++;
                }
            }

            // Import settings
            if (isset($importData['settings']) && is_array($importData['settings'])) {
                foreach ($importData['settings'] as $key => $value) {
                    dbExecute("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?",
                        [$key, $value, $value], 'sss');
                    $count++;
                }
            }

            addActivityLog('Data Imported', "Admin data imported from localStorage ($count records)");
            respondSuccess(['count' => $count], 'Admin data imported successfully');
            break;

        case 'teacher':
            // Import assessments
            if (isset($importData['assessments']) && is_array($importData['assessments'])) {
                foreach ($importData['assessments'] as $a) {
                    dbInsert("INSERT INTO assessments (teacher_id, student_name, class_name, subject, type, score, date, remarks) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                        [$a['teacherId'] ?? 0, $a['studentName'] ?? '', $a['className'] ?? '', $a['subject'] ?? '', $a['type'] ?? 'Quiz', $a['score'] ?? 0, $a['date'] ?? null, $a['remarks'] ?? ''], 'isssssss');
                    $count++;
                }
            }

            // Import pending registrations
            if (isset($importData['pendingRegistrations']) && is_array($importData['pendingRegistrations'])) {
                foreach ($importData['pendingRegistrations'] as $r) {
                    dbInsert("INSERT INTO registrations (student_name, grade, parent_name, phone, email, address, notes, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'Pending')",
                        [$r['studentName'] ?? '', $r['grade'] ?? '', $r['parentName'] ?? '', $r['phone'] ?? '', $r['email'] ?? '', $r['address'] ?? '', $r['notes'] ?? ''], 'sssssss');
                    $count++;
                }
            }

            addActivityLog('Data Imported', "Teacher data imported from localStorage ($count records)");
            respondSuccess(['count' => $count], 'Teacher data imported successfully');
            break;

        default:
            respondError('Invalid import type. Must be "admin" or "teacher"');
    }
}

// ============================================================
// Handle export - send server data to client
// ============================================================
function handleExport() {
    $exportType = $_GET['type'] ?? ''; // 'admin' or 'teacher'

    if (empty($exportType)) {
        // Export all data
        $result = [
            'admin' => exportAdminData(),
            'teacher' => exportTeacherData()
        ];
        respondSuccess($result, 'All data exported');
    }

    switch ($exportType) {
        case 'admin':
            respondSuccess(exportAdminData(), 'Admin data exported');
            break;
        case 'teacher':
            respondSuccess(exportTeacherData(), 'Teacher data exported');
            break;
        default:
            respondError('Invalid export type. Must be "admin", "teacher", or empty for all');
    }
}

// ============================================================
// Export admin data from MySQL
// ============================================================
function exportAdminData() {
    $students = dbFetchAll("SELECT * FROM students ORDER BY id");
    $registrations = dbFetchAll("SELECT * FROM registrations ORDER BY id");
    $payments = dbFetchAll("SELECT * FROM payments ORDER BY id");
    $events = dbFetchAll("SELECT * FROM events ORDER BY id");
    $messages = dbFetchAll("SELECT * FROM messages ORDER BY id");
    $settings = dbFetchAll("SELECT setting_key, setting_value FROM settings");

    $settingsData = [];
    foreach ($settings as $row) {
        $settingsData[$row['setting_key']] = $row['setting_value'];
    }

    return [
        'students' => array_map(function($r) {
            return [
                'id' => $r['id'], 'firstName' => $r['first_name'], 'lastName' => $r['last_name'],
                'grade' => $r['grade'], 'parentName' => $r['parent_name'], 'phone' => $r['phone'],
                'email' => $r['email'], 'status' => $r['status'], 'feesStatus' => $r['fees_status'] ?? 'Pending',
                'createdAt' => $r['created_at'], 'updatedAt' => $r['updated_at']
            ];
        }, $students),
        'registrations' => array_map(function($r) {
            return [
                'id' => $r['id'], 'studentName' => $r['student_name'], 'grade' => $r['grade'],
                'parentName' => $r['parent_name'], 'phone' => $r['phone'], 'email' => $r['email'],
                'address' => $r['address'], 'dateOfBirth' => $r['dob'], 'notes' => $r['notes'],
                'status' => $r['status'], 'createdAt' => $r['created_at'], 'updatedAt' => $r['updated_at']
            ];
        }, $registrations),
        'payments' => array_map(function($r) {
            return [
                'id' => $r['id'], 'payerName' => $r['payer_name'], 'studentName' => $r['student_name'],
                'amount' => $r['amount'], 'paymentType' => $r['payment_type'], 'phone' => $r['phone'],
                'paymentMethod' => $r['payment_method'], 'notes' => $r['notes'], 'status' => $r['status'],
                'createdAt' => $r['created_at'], 'updatedAt' => $r['updated_at']
            ];
        }, $payments),
        'events' => $events,
        'messages' => $messages,
        'settings' => $settingsData
    ];
}

// ============================================================
// Export teacher data from MySQL
// ============================================================
function exportTeacherData() {
    $assessments = dbFetchAll("SELECT * FROM assessments ORDER BY created_at DESC LIMIT 200");

    return [
        'assessments' => array_map(function($r) {
            return [
                'id' => $r['id'], 'teacherId' => $r['teacher_id'], 'studentName' => $r['student_name'],
                'className' => $r['class_name'], 'subject' => $r['subject'], 'type' => $r['type'],
                'score' => $r['score'], 'date' => $r['date'], 'remarks' => $r['remarks'],
                'createdAt' => $r['created_at']
            ];
        }, $assessments)
    ];
}

// ============================================================
// Route requests
// ============================================================
$action = $_REQUEST['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'OPTIONS') {
    http_response_code(200);
    exit();
}

if ($method === 'GET') {
    handleExport();
} elseif ($method === 'POST') {
    switch ($action) {
        case 'import':
            handleImport();
            break;
        default:
            respondError('Unknown action', 404);
    }
} else {
    respondError('Method not allowed', 405);
}
