<?php
/**
 * Setup Visitor Tracking Tables
 * Run this file once to create the necessary database tables
 */

require_once 'db.php';

header('Content-Type: text/html; charset=utf-8');

echo "<h2>Setting up Visitor Tracking Tables</h2>";

try {
    $conn = getDB();
    
    // Create visitor_tracking table
    $createVisitorTable = "
    CREATE TABLE IF NOT EXISTS `visitor_tracking` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `session_id` varchar(100) NOT NULL,
      `ip_address` varchar(45) DEFAULT NULL,
      `city` varchar(100) DEFAULT NULL,
      `region` varchar(100) DEFAULT NULL,
      `country` varchar(100) DEFAULT NULL,
      `country_code` varchar(10) DEFAULT NULL,
      `latitude` decimal(10,8) DEFAULT NULL,
      `longitude` decimal(11,8) DEFAULT NULL,
      `postal_code` varchar(20) DEFAULT NULL,
      `isp` varchar(255) DEFAULT NULL,
      `timezone` varchar(50) DEFAULT NULL,
      `user_agent` text DEFAULT NULL,
      `referrer` varchar(500) DEFAULT NULL,
      `current_page` varchar(500) DEFAULT NULL,
      `first_visit` datetime NOT NULL,
      `last_activity` datetime NOT NULL,
      `page_views` int(11) DEFAULT 0,
      `last_action` varchar(50) DEFAULT NULL,
      `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
      `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (`id`),
      UNIQUE KEY `session_id` (`session_id`),
      KEY `ip_address` (`ip_address`),
      KEY `country` (`country`),
      KEY `city` (`city`),
      KEY `last_activity` (`last_activity`),
      KEY `first_visit` (`first_visit`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    if ($conn->query($createVisitorTable)) {
        echo "<p style='color: green;'>✓ visitor_tracking table created successfully</p>";
    } else {
        echo "<p style='color: red;'>✗ Error creating visitor_tracking table: " . $conn->error . "</p>";
    }
    
    // Create visitor_page_history table
    $createPageHistoryTable = "
    CREATE TABLE IF NOT EXISTS `visitor_page_history` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `session_id` varchar(100) NOT NULL,
      `url` varchar(500) DEFAULT NULL,
      `path` varchar(255) DEFAULT NULL,
      `title` varchar(255) DEFAULT NULL,
      `referrer` varchar(500) DEFAULT NULL,
      `visited_at` datetime NOT NULL,
      `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (`id`),
      KEY `session_id` (`session_id`),
      KEY `visited_at` (`visited_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    if ($conn->query($createPageHistoryTable)) {
        echo "<p style='color: green;'>✓ visitor_page_history table created successfully</p>";
    } else {
        echo "<p style='color: red;'>✗ Error creating visitor_page_history table: " . $conn->error . "</p>";
    }
    
    // Create indexes for better performance
    $createIndexes = [
        "CREATE INDEX IF NOT EXISTS idx_location_coords ON visitor_tracking (latitude, longitude)",
        "CREATE INDEX IF NOT EXISTS idx_country_city ON visitor_tracking (country, city)"
    ];
    
    foreach ($createIndexes as $indexSql) {
        if ($conn->query($indexSql)) {
            echo "<p style='color: green;'>✓ Index created successfully</p>";
        } else {
            echo "<p style='color: orange;'>⚠ Index creation note: " . $conn->error . "</p>";
        }
    }
    
    // Create analytics view
    $createView = "
    CREATE OR REPLACE VIEW visitor_analytics_view AS
    SELECT 
        DATE(first_visit) as visit_date,
        COUNT(*) as total_visitors,
        COUNT(DISTINCT ip_address) as unique_ips,
        COUNT(DISTINCT country) as unique_countries,
        COUNT(DISTINCT city) as unique_cities,
        SUM(page_views) as total_page_views
    FROM visitor_tracking
    GROUP BY DATE(first_visit)
    ORDER BY visit_date DESC";
    
    if ($conn->query($createView)) {
        echo "<p style='color: green;'>✓ visitor_analytics_view created successfully</p>";
    } else {
        echo "<p style='color: red;'>✗ Error creating analytics view: " . $conn->error . "</p>";
    }
    
    echo "<h3>Setup Complete!</h3>";
    echo "<p>Your visitor tracking system is now ready to use.</p>";
    echo "<p><a href='../admin/admin.html'>Go to Admin Dashboard</a></p>";
    
} catch (Exception $e) {
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
}
?>