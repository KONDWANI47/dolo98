<?php
/**
 * AI Tools System - Noah Christian Academy
 * Secure tool layer for AI to access school data
 * Prevents direct SQL injection and enforces permissions
 */

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/ai_service.php';

class AITools {
    private $userId;
    private $userRole;
    private $userClass;
    private $aiService;

    public function __construct($userId, $userRole, $userClass = null) {
        $this->userId = $userId;
        $this->userRole = $userRole;
        $this->userClass = $userClass;
        $this->aiService = new AIService();
    }

    /**
     * Tool: Search students
     */
    public function searchStudents($query, $limit = 20) {
        // Permission check
        if (!$this->canAccessStudentData()) {
            return $this->permissionDenied();
        }

        $query = trim($query);
        if (strlen($query) < 2) {
            return ['success' => false, 'message' => 'Query too short'];
        }

        // Build secure query with parameterization
        $sql = "SELECT id, first_name, last_name, class, gender, admission_number
                FROM students
                WHERE (first_name LIKE ? OR last_name LIKE ? OR admission_number LIKE ? OR class LIKE ?)
                AND status = 'active'
                LIMIT ?";

        $searchTerm = "%{$query}%";
        $params = [$searchTerm, $searchTerm, $searchTerm, $searchTerm, $limit];
        $results = dbFetchAll($sql, $params, 'ssssi');

        return [
            'success' => true,
            'data' => $results,
            'count' => count($results)
        ];
    }

    /**
     * Tool: Get student details
     */
    public function getStudent($studentId) {
        // Permission check
        if (!$this->canAccessStudentData()) {
            return $this->permissionDenied();
        }

        // Teachers can only access their assigned class students
        if ($this->userRole === 'teacher' && $this->userClass) {
            $student = dbFetchOne(
                "SELECT id, first_name, last_name, class, gender, admission_number, date_of_birth, parent_id
                 FROM students
                 WHERE id = ? AND class = ? AND status = 'active'
                 LIMIT 1",
                [$studentId, $this->userClass],
                'is'
            );
        } else {
            // Admin can access any student
            $student = dbFetchOne(
                "SELECT id, first_name, last_name, class, gender, admission_number, date_of_birth, parent_id
                 FROM students
                 WHERE id = ? AND status = 'active'
                 LIMIT 1",
                [$studentId],
                'i'
            );
        }

        if (!$student) {
            return ['success' => false, 'message' => 'Student not found or access denied'];
        }

        return ['success' => true, 'data' => $student];
    }

    /**
     * Tool: Get students by class
     */
    public function getStudentsByClass($class) {
        // Permission check
        if (!$this->canAccessStudentData()) {
            return $this->permissionDenied();
        }

        // Teachers can only access their assigned class
        if ($this->userRole === 'teacher' && $class !== $this->userClass) {
            return $this->permissionDenied();
        }

        $students = dbFetchAll(
            "SELECT id, first_name, last_name, class, gender, admission_number
             FROM students
             WHERE class = ? AND status = 'active'
             ORDER BY last_name, first_name",
            [$class],
            's'
        );

        return [
            'success' => true,
            'data' => $students,
            'count' => count($students)
        ];
    }

    /**
     * Tool: Get student attendance
     */
    public function getStudentAttendance($studentId, $term = null) {
        if (!$this->canAccessStudentData()) {
            return $this->permissionDenied();
        }

        $sql = "SELECT date, status, term
                FROM attendance
                WHERE student_id = ?";
        $params = [$studentId];
        $types = 'i';

        if ($term) {
            $sql .= " AND term = ?";
            $params[] = $term;
            $types .= 's';
        }

        $sql .= " ORDER BY date DESC";

        $attendance = dbFetchAll($sql, $params, $types);

        // Calculate attendance percentage
        $total = count($attendance);
        $present = 0;
        foreach ($attendance as $record) {
            if ($record['status'] === 'present') {
                $present++;
            }
        }
        $percentage = $total > 0 ? round(($present / $total) * 100, 1) : 0;

        return [
            'success' => true,
            'data' => $attendance,
            'summary' => [
                'total_days' => $total,
                'present_days' => $present,
                'percentage' => $percentage
            ]
        ];
    }

    /**
     * Tool: Get class attendance summary
     */
    public function getClassAttendance($class, $term = null) {
        if (!$this->canAccessStudentData()) {
            return $this->permissionDenied();
        }

        if ($this->userRole === 'teacher' && $class !== $this->userClass) {
            return $this->permissionDenied();
        }

        $sql = "SELECT s.id, s.first_name, s.last_name,
                COUNT(a.id) as total_days,
                SUM(CASE WHEN a.status = 'present' THEN 1 ELSE 0 END) as present_days
                FROM students s
                LEFT JOIN attendance a ON s.id = a.student_id";

        $params = [];
        $types = '';

        if ($term) {
            $sql .= " AND a.term = ?";
            $params[] = $term;
            $types .= 's';
        }

        $sql .= " WHERE s.class = ? AND s.status = 'active'
                GROUP BY s.id
                ORDER BY s.last_name, s.first_name";

        $params[] = $class;
        $types .= 's';

        $results = dbFetchAll($sql, $params, $types);

        // Calculate percentages
        foreach ($results as &$student) {
            $student['percentage'] = $student['total_days'] > 0
                ? round(($student['present_days'] / $student['total_days']) * 100, 1)
                : 0;
        }

        return [
            'success' => true,
            'data' => $results
        ];
    }

    /**
     * Tool: Get student results/assessments
     */
    public function getStudentResults($studentId, $subject = null) {
        if (!$this->canAccessStudentData()) {
            return $this->permissionDenied();
        }

        $sql = "SELECT id, subject, marks, max_marks, assessment_type, term, created_at
                FROM assessments
                WHERE student_id = ?";
        $params = [$studentId];
        $types = 'i';

        if ($subject) {
            $sql .= " AND subject = ?";
            $params[] = $subject;
            $types .= 's';
        }

        $sql .= " ORDER BY created_at DESC";

        $results = dbFetchAll($sql, $params, $types);

        // Calculate average
        $totalMarks = 0;
        $totalMax = 0;
        foreach ($results as $result) {
            $totalMarks += $result['marks'];
            $totalMax += $result['max_marks'];
        }
        $average = $totalMax > 0 ? round(($totalMarks / $totalMax) * 100, 1) : 0;

        return [
            'success' => true,
            'data' => $results,
            'summary' => [
                'total_assessments' => count($results),
                'average_percentage' => $average
            ]
        ];
    }

    /**
     * Tool: Get class results summary
     */
    public function getClassResults($class, $subject = null, $term = null) {
        if (!$this->canAccessStudentData()) {
            return $this->permissionDenied();
        }

        if ($this->userRole === 'teacher' && $class !== $this->userClass) {
            return $this->permissionDenied();
        }

        $sql = "SELECT s.id, s.first_name, s.last_name,
                a.subject, a.marks, a.max_marks, a.assessment_type, a.term
                FROM students s
                JOIN assessments a ON s.id = a.student_id
                WHERE s.class = ? AND s.status = 'active'";
        $params = [$class];
        $types = 's';

        if ($subject) {
            $sql .= " AND a.subject = ?";
            $params[] = $subject;
            $types .= 's';
        }

        if ($term) {
            $sql .= " AND a.term = ?";
            $params[] = $term;
            $types .= 's';
        }

        $results = dbFetchAll($sql, $params, $types);

        // Group by student and calculate averages
        $studentResults = [];
        foreach ($results as $result) {
            $studentId = $result['id'];
            if (!isset($studentResults[$studentId])) {
                $studentResults[$studentId] = [
                    'id' => $result['id'],
                    'first_name' => $result['first_name'],
                    'last_name' => $result['last_name'],
                    'total_marks' => 0,
                    'total_max' => 0,
                    'assessment_count' => 0
                ];
            }
            $studentResults[$studentId]['total_marks'] += $result['marks'];
            $studentResults[$studentId]['total_max'] += $result['max_marks'];
            $studentResults[$studentId]['assessment_count']++;
        }

        // Calculate percentages
        foreach ($studentResults as &$student) {
            $student['average'] = $student['total_max'] > 0
                ? round(($student['total_marks'] / $student['total_max']) * 100, 1)
                : 0;
        }

        // Sort by average
        usort($studentResults, function($a, $b) {
            return $b['average'] <=> $a['average'];
        });

        return [
            'success' => true,
            'data' => array_values($studentResults)
        ];
    }

    /**
     * Tool: Get fee balances (admin only)
     */
    public function getFeeBalances($studentId = null) {
        if ($this->userRole !== 'admin') {
            return $this->permissionDenied();
        }

        if ($studentId) {
            $balances = dbFetchAll(
                "SELECT p.id, p.student_id, s.first_name, s.last_name, s.class,
                        p.amount, p.amount_paid, p.status, p.term, p.due_date
                 FROM payments p
                 JOIN students s ON p.student_id = s.id
                 WHERE p.student_id = ? AND p.status != 'paid'
                 ORDER BY p.due_date ASC",
                [$studentId],
                'i'
            );
        } else {
            $balances = dbFetchAll(
                "SELECT p.id, p.student_id, s.first_name, s.last_name, s.class,
                        p.amount, p.amount_paid, p.status, p.term, p.due_date
                 FROM payments p
                 JOIN students s ON p.student_id = s.id
                 WHERE p.status != 'paid'
                 ORDER BY p.due_date ASC"
            );
        }

        // Calculate outstanding
        $totalOutstanding = 0;
        foreach ($balances as &$balance) {
            $balance['outstanding'] = $balance['amount'] - $balance['amount_paid'];
            $totalOutstanding += $balance['outstanding'];
        }

        return [
            'success' => true,
            'data' => $balances,
            'summary' => [
                'total_outstanding' => $totalOutstanding,
                'count' => count($balances)
            ]
        ];
    }

    /**
     * Tool: Get teachers (admin only)
     */
    public function getTeachers($limit = 50) {
        if ($this->userRole !== 'admin') {
            return $this->permissionDenied();
        }

        $teachers = dbFetchAll(
            "SELECT id, first_name, last_name, email, subject, assigned_class, phone, approved
             FROM teachers
             WHERE approved = 1
             LIMIT ?",
            [$limit],
            'i'
        );

        return [
            'success' => true,
            'data' => $teachers,
            'count' => count($teachers)
        ];
    }

    /**
     * Tool: Search teachers (admin only)
     */
    public function searchTeachers($query, $limit = 20) {
        if ($this->userRole !== 'admin') {
            return $this->permissionDenied();
        }

        $query = trim($query);
        if (strlen($query) < 2) {
            return ['success' => false, 'message' => 'Query too short'];
        }

        $searchTerm = "%{$query}%";
        $teachers = dbFetchAll(
            "SELECT id, first_name, last_name, email, subject, assigned_class, phone, approved
             FROM teachers
             WHERE (first_name LIKE ? OR last_name LIKE ? OR email LIKE ? OR subject LIKE ?)
             AND approved = 1
             LIMIT ?",
            [$searchTerm, $searchTerm, $searchTerm, $searchTerm, $limit],
            'ssssi'
        );

        return [
            'success' => true,
            'data' => $teachers,
            'count' => count($teachers)
        ];
    }

    /**
     * Tool: Get teacher profile
     */
    public function getTeacherProfile($teacherId) {
        if ($this->userRole === 'teacher' && $teacherId != $this->userId) {
            return $this->permissionDenied();
        }

        $teacher = dbFetchOne(
            "SELECT id, first_name, last_name, email, subject, assigned_class, phone,
                    qualifications, experience, bio
             FROM teachers
             WHERE id = ? AND approved = 1
             LIMIT 1",
            [$teacherId],
            'i'
        );

        if (!$teacher) {
            return ['success' => false, 'message' => 'Teacher not found'];
        }

        return ['success' => true, 'data' => $teacher];
    }

    /**
     * Tool: Get announcements
     */
    public function getAnnouncements($limit = 10) {
        $announcements = dbFetchAll(
            "SELECT id, title, content, target_audience, created_at
             FROM announcements
             ORDER BY created_at DESC
             LIMIT ?",
            [$limit],
            'i'
        );

        return [
            'success' => true,
            'data' => $announcements
        ];
    }

    /**
     * Tool: Get lesson plans
     */
    public function getLessonPlans($teacherId = null, $class = null, $subject = null) {
        if ($this->userRole === 'teacher' && $teacherId && $teacherId != $this->userId) {
            return $this->permissionDenied();
        }

        $sql = "SELECT id, title, subject, class, topic, term, date, objectives, activities
                FROM lesson_plans
                WHERE 1=1";
        $params = [];
        $types = '';

        if ($teacherId) {
            $sql .= " AND teacher_id = ?";
            $params[] = $teacherId;
            $types .= 'i';
        }

        if ($class) {
            $sql .= " AND class = ?";
            $params[] = $class;
            $types .= 's';
        }

        if ($subject) {
            $sql .= " AND subject = ?";
            $params[] = $subject;
            $types .= 's';
        }

        $sql .= " ORDER BY date DESC";

        $plans = dbFetchAll($sql, $params, $types);

        return [
            'success' => true,
            'data' => $plans,
            'count' => count($plans)
        ];
    }

    /**
     * Tool: Generate lesson plan using AI
     */
    public function generateLessonPlan($subject, $class, $topic, $duration = 45, $term = null) {
        if ($this->userRole !== 'teacher' && $this->userRole !== 'admin') {
            return $this->permissionDenied();
        }

        // Build prompt for AI
        $prompt = "Create a detailed lesson plan for the following:\n";
        $prompt .= "Subject: {$subject}\n";
        $prompt .= "Class: {$class}\n";
        $prompt .= "Topic: {$topic}\n";
        $prompt .= "Duration: {$duration} minutes\n";
        if ($term) $prompt .= "Term: {$term}\n";
        $prompt .= "\n";
        $prompt .= "Include:\n";
        $prompt .= "- Learning objectives (clear, measurable)\n";
        $prompt .= "- Required materials/resources\n";
        $prompt .= "- Teaching activities (step by step)\n";
        $prompt .= "- Assessment methods\n";
        $prompt .= "- Homework assignment\n";
        $prompt .= "\n";
        $prompt .= "Format the response as a structured lesson plan.";

        $messages = [
            ['role' => 'system', 'content' => 'You are an expert teacher and curriculum designer. Create detailed, practical lesson plans suitable for Malawian schools.'],
            ['role' => 'user', 'content' => $prompt]
        ];

        $response = $this->aiService->generateResponse($messages);

        if (!$response['success']) {
            return $response;
        }

        return [
            'success' => true,
            'lesson_plan' => $response['content'],
            'metadata' => [
                'subject' => $subject,
                'class' => $class,
                'topic' => $topic,
                'duration' => $duration,
                'term' => $term
            ]
        ];
    }

    /**
     * Tool: Save lesson plan to database
     */
    public function saveLessonPlan($planData) {
        if ($this->userRole !== 'teacher' && $this->userRole !== 'admin') {
            return $this->permissionDenied();
        }

        // Extract data
        $title = $planData['title'] ?? '';
        $subject = $planData['subject'] ?? '';
        $class = $planData['class'] ?? '';
        $topic = $planData['topic'] ?? '';
        $term = $planData['term'] ?? '';
        $date = $planData['date'] ?? date('Y-m-d');
        $objectives = $planData['objectives'] ?? '';
        $activities = $planData['activities'] ?? '';
        $resources = $planData['resources'] ?? '';
        $assessment = $planData['assessment'] ?? '';

        // Teachers can only save for their assigned class
        if ($this->userRole === 'teacher' && $class !== $this->userClass) {
            return $this->permissionDenied();
        }

        $id = dbInsert(
            "INSERT INTO lesson_plans (teacher_id, title, subject, class, topic, term, date, objectives, activities, resources, assessment)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            [$this->userId, $title, $subject, $class, $topic, $term, $date, $objectives, $activities, $resources, $assessment],
            'isssssssss'
        );

        if ($id > 0) {
            addActivityLog('Lesson Plan Created', "Teacher {$this->userId} created lesson plan for {$class} - {$subject}");
            return ['success' => true, 'id' => $id];
        }

        return ['success' => false, 'message' => 'Failed to save lesson plan'];
    }

    /**
     * Tool: Generate examination paper using AI
     */
    public function generateExam($subject, $class, $topics, $questionCount = 20, $difficulty = 'medium', $duration = 60) {
        if ($this->userRole !== 'teacher' && $this->userRole !== 'admin') {
            return $this->permissionDenied();
        }

        // Teachers can only generate for their assigned class
        if ($this->userRole === 'teacher' && $class !== $this->userClass) {
            return $this->permissionDenied();
        }

        // Build prompt for AI
        $prompt = "Create an examination paper for the following:\n";
        $prompt .= "Subject: {$subject}\n";
        $prompt .= "Class: {$class}\n";
        $prompt .= "Topics: {$topics}\n";
        $prompt .= "Number of questions: {$questionCount}\n";
        $prompt .= "Difficulty level: {$difficulty}\n";
        $prompt .= "Duration: {$duration} minutes\n";
        $prompt .= "\n";
        $prompt .= "Include a mix of:\n";
        $prompt .= "- Multiple choice questions (40%)\n";
        $prompt .= "- Short answer questions (30%)\n";
        $prompt .= "- Structured questions (30%)\n";
        $prompt .= "\n";
        $prompt .= "For each question, provide:\n";
        $prompt .= "- The question\n";
        $prompt .= "- Marks allocation\n";
        $prompt .= "- Expected answer/answer key\n";
        $prompt .= "\n";
        $prompt .= "Format as a complete examination paper with instructions.";

        $messages = [
            ['role' => 'system', 'content' => 'You are an expert examiner and curriculum specialist. Create examination papers suitable for Malawian schools following standard examination formats.'],
            ['role' => 'user', 'content' => $prompt]
        ];

        $response = $this->aiService->generateResponse($messages);

        if (!$response['success']) {
            return $response;
        }

        return [
            'success' => true,
            'exam_paper' => $response['content'],
            'metadata' => [
                'subject' => $subject,
                'class' => $class,
                'topics' => $topics,
                'question_count' => $questionCount,
                'difficulty' => $difficulty,
                'duration' => $duration
            ]
        ];
    }

    /**
     * Tool: Generate homework assignment using AI
     */
    public function generateHomework($subject, $class, $topic, $difficulty = 'medium') {
        if ($this->userRole !== 'teacher' && $this->userRole !== 'admin') {
            return $this->permissionDenied();
        }

        if ($this->userRole === 'teacher' && $class !== $this->userClass) {
            return $this->permissionDenied();
        }

        $prompt = "Create a homework assignment for:\n";
        $prompt .= "Subject: {$subject}\n";
        $prompt .= "Class: {$class}\n";
        $prompt .= "Topic: {$topic}\n";
        $prompt .= "Difficulty: {$difficulty}\n";
        $prompt .= "\n";
        $prompt .= "Include:\n";
        $prompt .= "- Clear instructions\n";
        $prompt .= "- 5-10 questions appropriate for the class level\n";
        $prompt .= "- Submission deadline suggestion\n";
        $prompt .= "- Expected time to complete\n";

        $messages = [
            ['role' => 'system', 'content' => 'You are an expert teacher. Create engaging and appropriate homework assignments.'],
            ['role' => 'user', 'content' => $prompt]
        ];

        $response = $this->aiService->generateResponse($messages);

        if (!$response['success']) {
            return $response;
        }

        return [
            'success' => true,
            'homework' => $response['content'],
            'metadata' => [
                'subject' => $subject,
                'class' => $class,
                'topic' => $topic,
                'difficulty' => $difficulty
            ]
        ];
    }

    /**
     * Tool: Generate performance report using AI
     */
    public function generatePerformanceReport($class, $term = null, $subject = null) {
        if (!$this->canAccessStudentData()) {
            return $this->permissionDenied();
        }

        if ($this->userRole === 'teacher' && $class !== $this->userClass) {
            return $this->permissionDenied();
        }

        // Get class results
        $resultsResult = $this->getClassResults($class, $subject, $term);
        if (!$resultsResult['success']) {
            return $resultsResult;
        }

        $students = $resultsResult['data'];

        // Get attendance data
        $attendanceResult = $this->getClassAttendance($class, $term);
        $attendanceData = $attendanceResult['success'] ? $attendanceResult['data'] : [];

        // Build prompt for AI
        $prompt = "Generate a detailed performance report for:\n";
        $prompt .= "Class: {$class}\n";
        if ($term) $prompt .= "Term: {$term}\n";
        if ($subject) $prompt .= "Subject: {$subject}\n";
        $prompt .= "\n";
        $prompt .= "Student Performance Data:\n";
        $prompt .= json_encode($students, JSON_PRETTY_PRINT);
        $prompt .= "\n\n";
        $prompt .= "Attendance Data:\n";
        $prompt .= json_encode($attendanceData, JSON_PRETTY_PRINT);
        $prompt .= "\n\n";
        $prompt .= "Generate a professional report including:\n";
        $prompt .= "- Executive summary\n";
        $prompt .= "- Key findings\n";
        $prompt .= "- Performance statistics (average, highest, lowest)\n";
        $prompt .= "- Attendance analysis\n";
        $prompt .= "- Students needing support\n";
        $prompt .= "- Top performers\n";
        $prompt .= "- Recommendations\n";
        $prompt .= "\n";
        $prompt .= "Format as a structured report with clear sections.";

        $messages = [
            ['role' => 'system', 'content' => 'You are an expert educational analyst. Generate detailed, actionable performance reports for school administrators and teachers.'],
            ['role' => 'user', 'content' => $prompt]
        ];

        $response = $this->aiService->generateResponse($messages);

        if (!$response['success']) {
            return $response;
        }

        return [
            'success' => true,
            'report' => $response['content'],
            'metadata' => [
                'class' => $class,
                'term' => $term,
                'subject' => $subject,
                'student_count' => count($students)
            ]
        ];
    }

    /**
     * Tool: Generate financial report (admin only)
     */
    public function generateFinancialReport($term = null) {
        if ($this->userRole !== 'admin') {
            return $this->permissionDenied();
        }

        // Get fee balances
        $feesResult = $this->getFeeBalances();
        if (!$feesResult['success']) {
            return $feesResult;
        }

        $feeData = $feesResult['data'];

        // Build prompt for AI
        $prompt = "Generate a financial report for:\n";
        if ($term) $prompt .= "Term: {$term}\n";
        $prompt .= "\n";
        $prompt .= "Fee Data:\n";
        $prompt .= json_encode($feeData, JSON_PRETTY_PRINT);
        $prompt .= "\n\n";
        $prompt .= "Generate a professional financial report including:\n";
        $prompt .= "- Executive summary\n";
        $prompt .= "- Total outstanding amount\n";
        $prompt .= "- Number of students with outstanding fees\n";
        $prompt .= "- Fee collection analysis\n";
        $prompt .= "- Overdue payments\n";
        $prompt .= "- Recommendations for fee collection\n";
        $prompt .= "\n";
        $prompt .= "Format as a structured report with clear sections.";

        $messages = [
            ['role' => 'system', 'content' => 'You are a financial analyst for educational institutions. Generate clear, actionable financial reports.'],
            ['role' => 'user', 'content' => $prompt]
        ];

        $response = $this->aiService->generateResponse($messages);

        if (!$response['success']) {
            return $response;
        }

        return [
            'success' => true,
            'report' => $response['content'],
            'metadata' => [
                'term' => $term,
                'total_outstanding' => $feesResult['summary']['total_outstanding'],
                'count' => $feesResult['summary']['count']
            ]
        ];
    }

    /**
     * Tool: Generate attendance report
     */
    public function generateAttendanceReport($class = null, $term = null) {
        if (!$this->canAccessStudentData()) {
            return $this->permissionDenied();
        }

        if ($this->userRole === 'teacher' && $class && $class !== $this->userClass) {
            return $this->permissionDenied();
        }

        // Get attendance data
        if ($class) {
            $attendanceResult = $this->getClassAttendance($class, $term);
        } else {
            // Admin can get school-wide attendance
            $attendanceResult = $this->getSchoolAttendance($term);
        }

        if (!$attendanceResult['success']) {
            return $attendanceResult;
        }

        $attendanceData = $attendanceResult['data'];

        // Build prompt for AI
        $prompt = "Generate an attendance report for:\n";
        if ($class) $prompt .= "Class: {$class}\n";
        if ($term) $prompt .= "Term: {$term}\n";
        $prompt .= "\n";
        $prompt .= "Attendance Data:\n";
        $prompt .= json_encode($attendanceData, JSON_PRETTY_PRINT);
        $prompt .= "\n\n";
        $prompt .= "Generate a professional attendance report including:\n";
        $prompt .= "- Executive summary\n";
        $prompt .= "- Overall attendance rate\n";
        $prompt .= "- Students with low attendance (below 75%)\n";
        $prompt .= "- Attendance trends\n";
        $prompt .= "- Days with highest absence\n";
        $prompt .= "- Recommendations\n";
        $prompt .= "\n";
        $prompt .= "Format as a structured report with clear sections.";

        $messages = [
            ['role' => 'system', 'content' => 'You are an educational analyst. Generate detailed attendance reports with actionable insights.'],
            ['role' => 'user', 'content' => $prompt]
        ];

        $response = $this->aiService->generateResponse($messages);

        if (!$response['success']) {
            return $response;
        }

        return [
            'success' => true,
            'report' => $response['content'],
            'metadata' => [
                'class' => $class,
                'term' => $term,
                'student_count' => count($attendanceData)
            ]
        ];
    }

    /**
     * Helper: Get school-wide attendance (admin only)
     */
    private function getSchoolAttendance($term = null) {
        if ($this->userRole !== 'admin') {
            return $this->permissionDenied();
        }

        $sql = "SELECT s.id, s.first_name, s.last_name, s.class,
                COUNT(a.id) as total_days,
                SUM(CASE WHEN a.status = 'present' THEN 1 ELSE 0 END) as present_days
                FROM students s
                LEFT JOIN attendance a ON s.id = a.student_id";

        $params = [];
        $types = '';

        if ($term) {
            $sql .= " AND a.term = ?";
            $params[] = $term;
            $types .= 's';
        }

        $sql .= " WHERE s.status = 'active'
                GROUP BY s.id
                ORDER BY s.class, s.last_name, s.first_name";

        $results = dbFetchAll($sql, $params, $types);

        foreach ($results as &$student) {
            $student['percentage'] = $student['total_days'] > 0
                ? round(($student['present_days'] / $student['total_days']) * 100, 1)
                : 0;
        }

        return [
            'success' => true,
            'data' => $results
        ];
    }

    /**
     * Permission check helper
     */
    private function canAccessStudentData() {
        // Admin and Teacher can access student data
        return in_array($this->userRole, ['admin', 'teacher']);
    }

    /**
     * Permission denied response
     */
    private function permissionDenied() {
        return [
            'success' => false,
            'message' => 'You do not have permission to access this data.'
        ];
    }
}
