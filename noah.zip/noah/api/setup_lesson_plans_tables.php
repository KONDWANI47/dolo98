<?php
/**
 * Setup Lesson Plans Tables
 * Run this script once to create the lesson plans database tables
 */

require_once __DIR__ . '/db.php';

$sql = "
-- Main lesson plans table
CREATE TABLE IF NOT EXISTS lesson_plans (
    id INT AUTO_INCREMENT PRIMARY KEY,
    teacher_id INT NOT NULL,
    academic_year VARCHAR(20) NOT NULL,
    term VARCHAR(20) NOT NULL,
    week VARCHAR(20) NOT NULL,
    grade_level VARCHAR(50) NOT NULL,
    class_name VARCHAR(50) NOT NULL,
    subject VARCHAR(100) NOT NULL,
    topic VARCHAR(255) NOT NULL,
    lesson_date DATE NOT NULL,
    start_time TIME NOT NULL,
    duration VARCHAR(50) NOT NULL,
    success_criteria TEXT,
    assessment TEXT,
    homework TEXT,
    reflection TEXT,
    what_went_well TEXT,
    challenges TEXT,
    learners_support TEXT,
    improvements TEXT,
    status ENUM('draft', 'published') DEFAULT 'draft',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (teacher_id) REFERENCES teachers(id) ON DELETE CASCADE,
    INDEX idx_teacher_id (teacher_id),
    INDEX idx_class (class_name),
    INDEX idx_subject (subject),
    INDEX idx_date (lesson_date),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Learning objectives table (dynamic rows)
CREATE TABLE IF NOT EXISTS lesson_objectives (
    id INT AUTO_INCREMENT PRIMARY KEY,
    lesson_plan_id INT NOT NULL,
    objective_text TEXT NOT NULL,
    display_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (lesson_plan_id) REFERENCES lesson_plans(id) ON DELETE CASCADE,
    INDEX idx_lesson_plan_id (lesson_plan_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Materials and resources table (dynamic rows)
CREATE TABLE IF NOT EXISTS lesson_materials (
    id INT AUTO_INCREMENT PRIMARY KEY,
    lesson_plan_id INT NOT NULL,
    material_type ENUM('textbook', 'teaching_material', 'equipment', 'other') DEFAULT 'other',
    material_name VARCHAR(255) NOT NULL,
    display_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (lesson_plan_id) REFERENCES lesson_plans(id) ON DELETE CASCADE,
    INDEX idx_lesson_plan_id (lesson_plan_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Lesson activities table (two-column: teacher and learner activities)
CREATE TABLE IF NOT EXISTS lesson_activities (
    id INT AUTO_INCREMENT PRIMARY KEY,
    lesson_plan_id INT NOT NULL,
    phase ENUM('introduction', 'step1', 'step2', 'step3', 'conclusion') NOT NULL,
    teacher_activity TEXT,
    learner_activity TEXT,
    display_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (lesson_plan_id) REFERENCES lesson_plans(id) ON DELETE CASCADE,
    INDEX idx_lesson_plan_id (lesson_plan_id),
    INDEX idx_phase (phase)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
";

try {
    $conn = getDB();

    // Execute multi-query
    if (mysqli_multi_query($conn, $sql)) {
        do {
            if ($result = mysqli_store_result($conn)) {
                mysqli_free_result($result);
            }
        } while (mysqli_more_results($conn) && mysqli_next_result($conn));

        echo json_encode([
            'success' => true,
            'message' => 'Lesson plans tables created successfully!'
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Error creating tables: ' . mysqli_error($conn)
        ]);
    }
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Exception: ' . $e->getMessage()
    ]);
}
