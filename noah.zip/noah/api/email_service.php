<?php
/**
 * Email delivery helper.
 *
 * Production: install Composer dependencies (`composer install`) so PHPMailer
 * is available and set SMTP_* environment variables.
 * Local fallback: PHP mail() can be used if XAMPP mail is configured.
 */
function sendApplicationEmail($to, $name, $subject, $body) {
    $to = trim((string)$to);
    if (!filter_var($to, FILTER_VALIDATE_EMAIL)) return false;

    $autoload = dirname(__DIR__) . '/vendor/autoload.php';
    if (is_file($autoload)) {
        require_once $autoload;
        if (class_exists('PHPMailer\\PHPMailer\\PHPMailer')) {
            try {
                $mail = new PHPMailer\PHPMailer\PHPMailer(true);
                $mail->isSMTP();
                $mail->Host = getenv('SMTP_HOST') ?: 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = getenv('SMTP_USERNAME') ?: '';
                $mail->Password = getenv('SMTP_PASSWORD') ?: '';
                $mail->SMTPSecure = getenv('SMTP_ENCRYPTION') ?: PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = (int)(getenv('SMTP_PORT') ?: 587);
                $mail->CharSet = 'UTF-8';
                $mail->setFrom(getenv('MAIL_FROM_ADDRESS') ?: $mail->Username, getenv('MAIL_FROM_NAME') ?: 'Noah Christian Academy');
                $mail->addAddress($to, $name ?: $to);
                $mail->Subject = $subject;
                $mail->Body = $body;
                $mail->isHTML(false);
                $mail->send();
                return true;
            } catch (Throwable $e) {
                error_log('PHPMailer error: ' . $e->getMessage());
            }
        }
    }

    // Fallback for local servers where mail() is configured.
    $from = getenv('MAIL_FROM_ADDRESS') ?: '';
    $headers = "MIME-Version: 1.0\r\nContent-Type: text/plain; charset=UTF-8\r\n";
    if ($from && filter_var($from, FILTER_VALIDATE_EMAIL)) {
        $headers .= "From: " . (getenv('MAIL_FROM_NAME') ?: 'Noah Christian Academy') . " <{$from}>\r\n";
    }
    return @mail($to, $subject, $body, $headers);
}

/**
 * Send an HTML email with one or more file attachments.
 *
 * Requires PHPMailer (Composer) because PHP's mail() cannot build MIME
 * attachments here. Returns false when delivery did not happen so callers can
 * report the failure instead of pretending the mail was sent.
 *
 * @param string $to          Recipient address
 * @param string $name        Recipient display name
 * @param string $subject     Subject line
 * @param string $htmlBody    HTML body
 * @param array  $attachments List of file paths, or [path, name] pairs
 * @return bool
 */
function sendApplicationEmailWithAttachment($to, $name, $subject, $htmlBody, $attachments = []) {
    $to = trim((string)$to);
    if (!filter_var($to, FILTER_VALIDATE_EMAIL)) return false;

    $autoload = dirname(__DIR__) . '/vendor/autoload.php';
    if (is_file($autoload)) {
        require_once $autoload;
        if (class_exists('PHPMailer\\PHPMailer\\PHPMailer')) {
            try {
                $mail = new PHPMailer\PHPMailer\PHPMailer(true);
                $mail->isSMTP();
                $mail->Host = getenv('SMTP_HOST') ?: 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = getenv('SMTP_USERNAME') ?: '';
                $mail->Password = getenv('SMTP_PASSWORD') ?: '';
                $mail->SMTPSecure = getenv('SMTP_ENCRYPTION') ?: PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = (int)(getenv('SMTP_PORT') ?: 587);
                $mail->CharSet = 'UTF-8';
                $mail->setFrom(getenv('MAIL_FROM_ADDRESS') ?: $mail->Username, getenv('MAIL_FROM_NAME') ?: 'Noah Christian Academy');
                $mail->addAddress($to, $name ?: $to);
                $mail->isHTML(true);
                $mail->Subject = $subject;
                $mail->Body = $htmlBody;
                $mail->AltBody = trim(strip_tags(preg_replace('/<br\s*\/?>/i', "\n", $htmlBody)));

                foreach ($attachments as $attachment) {
                    $path = is_array($attachment) ? ($attachment[0] ?? '') : $attachment;
                    $attachName = is_array($attachment) ? ($attachment[1] ?? '') : '';
                    if ($path && is_file($path)) {
                        $mail->addAttachment($path, $attachName);
                    }
                }

                $mail->send();
                return true;
            } catch (Throwable $e) {
                error_log('PHPMailer attachment error: ' . $e->getMessage());
            }
        }
    }

    error_log('sendApplicationEmailWithAttachment: PHPMailer unavailable, attachment email not sent to ' . $to);
    return false;
}
