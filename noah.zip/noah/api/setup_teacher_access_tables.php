<?php
/**
 * Setup Teacher Authorized Access Tables
 * Creates tables for managing authorized IP addresses and emails for teacher accounts
 */

require_once __DIR__ . '/db.php';

echo "Setting up teacher authorized access tables...\n";

$conn = getDB();

// Create teacher_authorized_ips table
$sql1 = "CREATE TABLE IF NOT EXISTS teacher_authorized_ips (
    id INT AUTO_INCREMENT PRIMARY KEY,
    teacher_id INT NOT NULL,
    ip_address VARCHAR(45) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (teacher_id) REFERENCES teachers(id) ON DELETE CASCADE,
    UNIQUE KEY unique_teacher_ip (teacher_id, ip_address)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

if ($conn->query($sql1)) {
    echo "✓ teacher_authorized_ips table created successfully\n";
} else {
    echo "✗ Failed to create teacher_authorized_ips table: " . $conn->error . "\n";
}

// Create teacher_authorized_emails table
$sql2 = "CREATE TABLE IF NOT EXISTS teacher_authorized_emails (
    id INT AUTO_INCREMENT PRIMARY KEY,
    teacher_id INT NOT NULL,
    email VARCHAR(255) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (teacher_id) REFERENCES teachers(id) ON DELETE CASCADE,
    UNIQUE KEY unique_teacher_email (teacher_id, email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

if ($conn->query($sql2)) {
    echo "✓ teacher_authorized_emails table created successfully\n";
} else {
    echo "✗ Failed to create teacher_authorized_emails table: " . $conn->error . "\n";
}

// Create teacher_login_logs table if it doesn't exist
$sql3 = "CREATE TABLE IF NOT EXISTS teacher_login_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    teacher_id INT NOT NULL,
    ip_address VARCHAR(45) NOT NULL,
    browser VARCHAR(100),
    os VARCHAR(100),
    device VARCHAR(50),
    user_agent TEXT,
    login_status ENUM('success', 'failed', 'blocked') DEFAULT 'success',
    login_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (teacher_id) REFERENCES teachers(id) ON DELETE CASCADE,
    INDEX idx_teacher_login (teacher_id, login_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

if ($conn->query($sql3)) {
    echo "✓ teacher_login_logs table created successfully\n";
} else {
    echo "✗ Failed to create teacher_login_logs table: " . $conn->error . "\n";
}

echo "\nSetup complete!\n";
