<?php
/**
 * PDF Receipt Generation API
 * Generates PDF receipts for payments
 */

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/email_service.php';

// Check if FPDF library exists
$fpdfPath = __DIR__ . '/../pdf_library/fpdf.php';
if (!file_exists($fpdfPath)) {
    error_log("FPDF library not found at: " . $fpdfPath);
    respondError('PDF library not found. Please contact administrator.', 500);
}
require_once $fpdfPath;

// Extend FPDF to add custom features
class CustomFPDF extends FPDF {
    // No rotation needed - using simpler watermark approach
}





header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$method = $_SERVER['REQUEST_METHOD'];
$id = $_REQUEST['id'] ?? null;
$action = $_REQUEST['action'] ?? '';

// GET - Generate PDF receipt for a payment
if ($method === 'GET') {
    if ($action === 'generate' && $id) {
        // Log for debugging
        error_log("Generating receipt for payment ID: " . $id);
        
        $result = generateReceiptPDF($id);
        
        error_log("Receipt generation result: " . json_encode($result));
        
        if ($result['success']) {
            respondSuccess($result['data'], $result['message']);
        } else {
            respondError($result['message'], $result['code'] ?? 400);
        }
    } else {
        respondError('Invalid action or missing payment ID. Action: ' . $action . ', ID: ' . $id);
    }
}

// POST - Send receipt via email / store a receipt PDF built in the browser
if ($method === 'POST') {
    $body = getJsonBody();

    if (($action === 'send_email' || $action === 'save_pdf') && $id) {
        $email = trim($body['email'] ?? '');
        $message = $body['message'] ?? '';
        // Receipt PDF produced in the browser so it keeps the admin's edits
        // (extra line items, notes, drawn signature).
        $receiptPdf = $body['receiptPdf'] ?? '';
        $filename = $body['filename'] ?? '';

        if ($action === 'save_pdf') {
            if (empty($receiptPdf)) respondError('No receipt PDF was provided');
            $saved = saveClientReceiptPdf($id, $receiptPdf, $filename);
            if (!$saved['success']) respondError($saved['message'] ?? 'Could not save the receipt PDF', 500);
            respondSuccess(['filename' => $saved['filename'], 'url' => $saved['url']], 'Receipt PDF saved');
        }

        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            respondError('A valid email address is required');
        }

        $result = $receiptPdf
            ? sendClientReceiptEmail($id, $email, $message, $receiptPdf, $filename)
            : sendReceiptEmail($id, $email, $message);

        if ($result['success']) {
            respondSuccess($result['data'], $result['message']);
        } else {
            respondError($result['message'], $result['code'] ?? 400);
        }
    } else {
        respondError('Invalid action or missing payment ID');
    }
}

/**
 * Store a base64 PDF produced by the browser under uploads/receipts/.
 */
function saveClientReceiptPdf($paymentId, $base64, $filename = '') {
    if (empty($base64)) {
        return ['success' => false, 'message' => 'No receipt PDF was provided'];
    }

    if (strpos($base64, 'base64,') !== false) {
        $base64 = substr($base64, strpos($base64, 'base64,') + 7);
    }

    $binary = base64_decode($base64, true);
    if ($binary === false || strlen($binary) < 100) {
        return ['success' => false, 'message' => 'The receipt PDF data is invalid'];
    }
    if (strncmp($binary, '%PDF', 4) !== 0) {
        return ['success' => false, 'message' => 'The uploaded receipt is not a PDF file'];
    }

    $uploadDir = __DIR__ . '/../uploads/receipts/';
    if (!is_dir($uploadDir) && !mkdir($uploadDir, 0755, true)) {
        return ['success' => false, 'message' => 'Failed to create the receipts directory'];
    }

    $safeName = preg_replace('/[^A-Za-z0-9_.-]/', '', (string)$filename);
    if ($safeName === '' || substr(strtolower($safeName), -4) !== '.pdf') {
        $safeName = 'receipt_' . (int)$paymentId . '_' . date('Ymd_His') . '.pdf';
    }

    $filepath = $uploadDir . $safeName;
    if (file_put_contents($filepath, $binary) === false) {
        return ['success' => false, 'message' => 'Could not write the receipt PDF to disk'];
    }

    return [
        'success' => true,
        'path' => $filepath,
        'filename' => $safeName,
        'url' => '../uploads/receipts/' . $safeName,
        'filesize' => filesize($filepath)
    ];
}

/**
 * Email a browser-generated receipt PDF as an attachment.
 */
function sendClientReceiptEmail($paymentId, $email, $message, $base64, $filename = '') {
    $payment = dbFetchOne("SELECT * FROM payments WHERE id = ?", [$paymentId], 'i');
    if (!$payment) {
        return ['success' => false, 'message' => 'Payment not found', 'code' => 404];
    }

    $saved = saveClientReceiptPdf($paymentId, $base64, $filename);
    if (!$saved['success']) {
        return ['success' => false, 'message' => $saved['message']];
    }

    $receiptNumber = 'REC-' . str_pad($payment['id'], 6, '0', STR_PAD_LEFT);
    $subject = 'Payment Receipt ' . $receiptNumber . ' - Noah Christian Academy';

    $sent = sendApplicationEmailWithAttachment(
        $email,
        $payment['payer_name'] ?? '',
        $subject,
        buildReceiptEmailBody($payment, $message),
        [[$saved['path'], $saved['filename']]]
    );

    if (!$sent) {
        return [
            'success' => false,
            'message' => 'The receipt PDF was created but the email could not be sent. Please check the SMTP settings in .env.',
            'code' => 500
        ];
    }

    addActivityLog('Receipt Email Sent', "Receipt $receiptNumber emailed to $email");

    return [
        'success' => true,
        'message' => 'Receipt emailed to ' . $email,
        'data' => [
            'email' => $email,
            'receiptNumber' => $receiptNumber,
            'filename' => $saved['filename'],
            'url' => $saved['url']
        ]
    ];
}

/**
 * Shared HTML body for receipt emails.
 */
function buildReceiptEmailBody($payment, $message = '') {
    $receiptNumber = 'REC-' . str_pad($payment['id'], 6, '0', STR_PAD_LEFT);
    $amount = 'MK ' . number_format((float)($payment['amount'] ?? 0), 2);

    return '
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: #085636; color: white; padding: 20px; text-align: center; }
                .content { padding: 20px; background: #f9f9f9; }
                .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h2>Payment Receipt</h2>
                    <p>Noah Christian Academy</p>
                </div>
                <div class="content">
                    <p>Dear Parent/Guardian,</p>
                    <p>Please find attached the payment receipt for the recent payment made to Noah Christian Academy.</p>
                    <p><strong>Payment Details:</strong></p>
                    <ul>
                        <li>Receipt Number: ' . $receiptNumber . '</li>
                        <li>Payer: ' . htmlspecialchars($payment['payer_name'] ?? '-') . '</li>
                        <li>Student: ' . htmlspecialchars($payment['student_name'] ?? '-') . '</li>
                        <li>Amount: ' . $amount . '</li>
                        <li>Payment Type: ' . htmlspecialchars($payment['payment_type'] ?? '-') . '</li>
                        <li>Date: ' . date('F j, Y', strtotime($payment['created_at'])) . '</li>
                    </ul>
                    ' . ($message ? '<p><strong>Message:</strong> ' . nl2br(htmlspecialchars($message)) . '</p>' : '') . '
                    <p>If you have any questions regarding this payment, please do not hesitate to contact us.</p>
                </div>
                <div class="footer">
                    <p>Noah Christian Academy<br>
                    P.O.BOX 30458, Area 24 PHA, Lilongwe, Malawi<br>
                    Tel: +265 999 635 561<br>
                    Email: noahchristianacademy2021@gmail.com</p>
                </div>
            </div>
        </body>
        </html>
    ';
}

respondError('Method not allowed', 405);

/**
 * Generate PDF receipt for a payment
 */
function generateReceiptPDF($paymentId) {
    try {
        error_log("Starting PDF generation for payment ID: " . $paymentId);
        
        // Validate payment ID
        if (!is_numeric($paymentId) || $paymentId <= 0) {
            error_log("Invalid payment ID: " . $paymentId);
            return ['success' => false, 'message' => 'Invalid payment ID', 'code' => 400];
        }
        
        // Get payment details
        $payment = dbFetchOne("SELECT * FROM payments WHERE id = ?", [$paymentId], 'i');
        
        error_log("Payment data: " . json_encode($payment));
        
        if (!$payment) {
            error_log("Payment not found for ID: " . $paymentId);
            return ['success' => false, 'message' => 'Payment not found', 'code' => 404];
        }
        
        // Create PDF
        try {
            $pdf = new CustomFPDF('P', 'mm', 'A4');
            $pdf->AddPage();
        } catch (Exception $pdfEx) {
            error_log("FPDF initialization error: " . $pdfEx->getMessage());
            return ['success' => false, 'message' => 'PDF library initialization failed: ' . $pdfEx->getMessage()];
        }
        
        // School information
        $schoolName = 'NOAH CHRISTIAN ACADEMY';
        $schoolAddress = 'P.O.BOX 30458, Area 24 PHA, Lilongwe, Malawi';
        $schoolPhone = '+265 999 608 570';
        $schoolEmail = 'noahchristianacademy2021@gmail.com';
        
        // Set simple white background
        $pdf->SetFillColor(255, 255, 255);
        $pdf->Rect(0, 0, 210, 297, 'F');
        
        // Add simple border
        $pdf->SetDrawColor(8, 86, 54);
        $pdf->SetLineWidth(1);
        $pdf->Rect(10, 10, 190, 277);
        
        // Initialize position
        $pdf->SetY(20);
        
        // Receipt Header - Green background
        $pdf->SetFillColor(8, 86, 54);
        $pdf->Rect(12, 12, 186, 40, 'F');
        
        // School name
        $pdf->SetY(18);
        $pdf->SetFont('Helvetica', 'B', 18);
        $pdf->SetTextColor(255, 255, 255);
        $pdf->Cell(0, 8, $schoolName, 0, 1, 'C');
        
        // School contact info
        $pdf->SetFont('Helvetica', '', 9);
        $pdf->SetTextColor(220, 230, 220);
        $pdf->Cell(0, 5, $schoolAddress, 0, 1, 'C');
        $pdf->Cell(0, 5, 'Phone: ' . $schoolPhone . ' | Email: ' . $schoolEmail, 0, 1, 'C');
        
        $pdf->Ln(10);
        
        // Receipt title
        $pdf->SetFont('Helvetica', 'B', 16);
        $pdf->SetTextColor(8, 86, 54);
        $pdf->Cell(0, 10, 'PAYMENT RECEIPT', 0, 1, 'C');
        
        // Receipt number and date
        $receiptNumber = 'REC-' . str_pad($payment['id'], 6, '0', STR_PAD_LEFT);
        $pdf->SetFont('Helvetica', 'B', 12);
        $pdf->Cell(0, 7, 'Receipt #: ' . $receiptNumber, 0, 1, 'C');
        
        $pdf->SetFont('Helvetica', '', 10);
        $pdf->SetTextColor(100, 100, 100);
        $pdf->Cell(0, 5, 'Date: ' . date('F j, Y', strtotime($payment['created_at'])), 0, 1, 'C');
        
        $pdf->Ln(5);
        
        // Draw line separator
        $pdf->SetDrawColor(8, 86, 54);
        $pdf->SetLineWidth(0.5);
        $pdf->Line(20, $pdf->GetY(), 190, $pdf->GetY());
        $pdf->Ln(10);
        
        // Payment details section
        $pdf->SetTextColor(0, 0, 0);
        $pdf->SetFont('Helvetica', 'B', 11);
        
        // Field labels and values
        $labelWidth = 40;
        $valueWidth = 60;
        $lineHeight = 8;
        
        // Row 1: Payer Name and Student Name
        $pdf->SetX(20);
        $pdf->Cell($labelWidth, $lineHeight, 'Payer Name:', 0, 0, 'L');
        $pdf->SetFont('Helvetica', '', 11);
        $pdf->Cell($valueWidth, $lineHeight, $payment['payer_name'] ?? '-', 0, 0, 'L');
        
        $pdf->SetFont('Helvetica', 'B', 11);
        $pdf->Cell(20, $lineHeight, '', 0, 0, 'L');
        $pdf->Cell($labelWidth, $lineHeight, 'Student Name:', 0, 0, 'L');
        $pdf->SetFont('Helvetica', '', 11);
        $pdf->Cell($valueWidth, $lineHeight, $payment['student_name'] ?? '-', 0, 1, 'L');
        
        // Row 2: Amount and Payment Type
        $pdf->SetX(20);
        $pdf->SetFont('Helvetica', 'B', 11);
        $pdf->Cell($labelWidth, $lineHeight, 'Amount (MK):', 0, 0, 'L');
        $pdf->SetFont('Helvetica', 'B', 11);
        $pdf->Cell($valueWidth, $lineHeight, number_format($payment['amount'], 2), 0, 0, 'L');
        
        $pdf->SetFont('Helvetica', 'B', 11);
        $pdf->Cell(20, $lineHeight, '', 0, 0, 'L');
        $pdf->Cell($labelWidth, $lineHeight, 'Payment Type:', 0, 0, 'L');
        $pdf->SetFont('Helvetica', '', 11);
        $pdf->Cell($valueWidth, $lineHeight, $payment['payment_type'] ?? '-', 0, 1, 'L');
        
        // Row 3: Payment Method and Phone
        $pdf->SetX(20);
        $pdf->SetFont('Helvetica', 'B', 11);
        $pdf->Cell($labelWidth, $lineHeight, 'Payment Method:', 0, 0, 'L');
        $pdf->SetFont('Helvetica', '', 11);
        $pdf->Cell($valueWidth, $lineHeight, $payment['payment_method'] ?? '-', 0, 0, 'L');
        
        $pdf->SetFont('Helvetica', 'B', 11);
        $pdf->Cell(20, $lineHeight, '', 0, 0, 'L');
        $pdf->Cell($labelWidth, $lineHeight, 'Phone:', 0, 0, 'L');
        $pdf->SetFont('Helvetica', '', 11);
        $pdf->Cell($valueWidth, $lineHeight, $payment['phone'] ?? '-', 0, 1, 'L');
        
        // Row 4: Status and Date
        $pdf->SetX(20);
        $pdf->SetFont('Helvetica', 'B', 11);
        $pdf->Cell($labelWidth, $lineHeight, 'Status:', 0, 0, 'L');
        
        // Status color
        $statusColor = ($payment['status'] === 'Paid' || $payment['status'] === 'paid') ? array(39, 174, 96) : 
                      (($payment['status'] === 'Pending' || $payment['status'] === 'pending') ? array(243, 156, 18) : array(231, 76, 60));
        $pdf->SetTextColor($statusColor[0], $statusColor[1], $statusColor[2]);
        $pdf->SetFont('Helvetica', 'B', 11);
        $pdf->Cell($valueWidth, $lineHeight, ucfirst($payment['status'] ?? 'Pending'), 0, 0, 'L');
        
        $pdf->SetTextColor(0, 0, 0);
        $pdf->SetFont('Helvetica', 'B', 11);
        $pdf->Cell(20, $lineHeight, '', 0, 0, 'L');
        $pdf->Cell($labelWidth, $lineHeight, 'Date:', 0, 0, 'L');
        $pdf->SetFont('Helvetica', '', 11);
        $pdf->Cell($valueWidth, $lineHeight, date('F j, Y', strtotime($payment['created_at'])), 0, 1, 'L');
        
        // Notes if present
        if (!empty($payment['notes'])) {
            $pdf->Ln(3);
            $pdf->SetX(20);
            $pdf->SetFont('Helvetica', 'B', 11);
            $pdf->Cell($labelWidth, $lineHeight, 'Notes:', 0, 0, 'L');
            $pdf->SetFont('Helvetica', '', 11);
            $pdf->Cell(140, $lineHeight, $payment['notes'], 0, 1, 'L');
        }
        
        $pdf->Ln(15);
        
        // Total amount box
        $pdf->SetFillColor(8, 86, 54);
        $pdf->SetDrawColor(8, 86, 54);
        $pdf->SetLineWidth(1);
        $pdf->Rect(20, $pdf->GetY(), 170, 15, 'FD');
        
        $pdf->SetTextColor(255, 255, 255);
        $pdf->SetFont('Helvetica', 'B', 14);
        $pdf->Cell(100, 15, 'TOTAL AMOUNT PAID', 0, 0, 'L');
        $pdf->Cell(70, 15, 'MK ' . number_format($payment['amount'], 2), 0, 1, 'R');
        $pdf->SetTextColor(0, 0, 0);
        
        $pdf->Ln(20);
        
        // Footer section
        $pdf->SetDrawColor(8, 86, 54);
        $pdf->SetLineWidth(0.5);
        $pdf->Line(20, $pdf->GetY(), 190, $pdf->GetY());
        $pdf->Ln(8);
        
        $pdf->SetFont('Helvetica', 'I', 10);
        $pdf->SetTextColor(100, 100, 100);
        $pdf->Cell(0, 6, 'Thank you for your payment!', 0, 1, 'C');
        $pdf->SetFont('Helvetica', 'I', 8);
        $pdf->Cell(0, 5, '© ' . date('Y') . ' ' . $schoolName . '. All rights reserved.', 0, 1, 'C');
        
        // Simple verification info
        $pdf->Ln(5);
        $pdf->SetFont('Helvetica', '', 7);
        $pdf->SetTextColor(150, 150, 150);
        $pdf->Cell(0, 4, 'Generated: ' . date('Y-m-d H:i:s') . ' | Ref: ' . $receiptNumber, 0, 1, 'C');
        
        // Generate PDF filename
        $filename = 'receipt_' . $receiptNumber . '_' . date('Y-m-d') . '.pdf';
        
        // Save PDF to file
        $uploadDir = __DIR__ . '/../uploads/receipts/';
        if (!is_dir($uploadDir)) {
            error_log("Creating upload directory: " . $uploadDir);
            if (!mkdir($uploadDir, 0755, true)) {
                error_log("Failed to create upload directory: " . $uploadDir);
                return ['success' => false, 'message' => 'Failed to create upload directory'];
            }
        }
        
        $filepath = $uploadDir . $filename;
        
        // Ensure the directory is writable
        if (!is_writable($uploadDir)) {
            error_log("Upload directory is not writable: " . $uploadDir);
            return ['success' => false, 'message' => 'Upload directory is not writable'];
        }
        
        error_log("Attempting to save PDF to: " . $filepath);
        $pdf->Output($filepath, 'F');
        error_log("PDF saved successfully");
        
        // Verify file was created and has content
        if (!file_exists($filepath)) {
            error_log("PDF file was not created: " . $filepath);
            return ['success' => false, 'message' => 'PDF file was not created'];
        }
        
        $filesize = filesize($filepath);
        if ($filesize < 100) {
            error_log("PDF file is too small (only " . $filesize . " bytes): " . $filepath);
            return ['success' => false, 'message' => 'PDF file creation failed - file is empty'];
        }
        
        // Return success with file URL (relative to the api directory)
        $fileUrl = '../uploads/receipts/' . $filename;
        
        return [
            'success' => true,
            'message' => 'PDF receipt generated successfully',
            'data' => [
                'filename' => $filename,
                'url' => $fileUrl,
                'path' => $filepath,
                'receiptNumber' => $receiptNumber,
                'filesize' => filesize($filepath)
            ]
        ];
        
    } catch (Exception $e) {
        error_log("PDF generation error: " . $e->getMessage());
        return ['success' => false, 'message' => 'Error generating PDF: ' . $e->getMessage()];
    }
}

/**
 * Send receipt via email
 */
function sendReceiptEmail($paymentId, $email, $message = '') {
    try {
        // Get payment details
        $payment = dbFetchOne("SELECT * FROM payments WHERE id = ?", [$paymentId], 'i');
        
        if (!$payment) {
            return ['success' => false, 'message' => 'Payment not found', 'code' => 404];
        }
        
        // Generate PDF
        $result = generateReceiptPDF($paymentId);
        if (!$result['success']) {
            return ['success' => false, 'message' => 'Failed to generate PDF for email'];
        }
        
        $pdfPath = $result['data']['path'];
        $pdfFilename = $result['data']['filename'];
        
        $subject = 'Payment Receipt ' . 'REC-' . str_pad($payment['id'], 6, '0', STR_PAD_LEFT) . ' - Noah Christian Academy';
        $body = buildReceiptEmailBody($payment, $message);

        // Deliver through the shared mailer (PHPMailer SMTP) with the PDF attached.
        $emailSent = sendApplicationEmailWithAttachment(
            $email,
            $payment['payer_name'] ?? '',
            $subject,
            $body,
            [[$pdfPath, $pdfFilename]]
        );

        if ($emailSent) {
            addActivityLog('Receipt Email Sent', "Receipt sent to $email for payment #$paymentId");
            return [
                'success' => true,
                'message' => 'Receipt sent successfully via email',
                'data' => [
                    'email' => $email,
                    'receiptNumber' => 'REC-' . str_pad($payment['id'], 6, '0', STR_PAD_LEFT),
                    'pdfFilename' => $pdfFilename
                ]
            ];
        } else {
            return ['success' => false, 'message' => 'Failed to send email. Please check the SMTP settings in .env.', 'code' => 500];
        }
        
    } catch (Exception $e) {
        return ['success' => false, 'message' => 'Error sending email: ' . $e->getMessage()];
    }
}


