<?php
/**
 * Visitor Tracking & Analytics API - Noah Christian Academy
 * Receives visitor data from tracker.js and provides analytics
 */

require_once __DIR__ . '/db.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$action = $_REQUEST['action'] ?? '';

switch ($action) {
    case 'track':
        handleTrackVisitor();
        break;
    case 'analytics':
        handleGetAnalytics();
        break;
    case 'recent':
        handleGetRecent();
        break;
    case 'clear':
        handleClearLogs();
        break;
    default:
        respondError('Unknown action', 404);
}

function handleTrackVisitor() {
    $body = getJsonBody();
    
    $data = [
        'ip_address' => $body['ip'] ?? $_SERVER['REMOTE_ADDR'] ?? '',
        'location' => $body['location'] ?? '',
        'browser' => $body['browser'] ?? '',
        'os' => $body['os'] ?? '',
        'device' => $body['device'] ?? '',
        'page' => $body['page'] ?? '',
        'referrer' => $body['referrer'] ?? '',
        'session_id' => $body['sessionId'] ?? ''
    ];
    
    $id = dbInsert(
        "INSERT INTO visitor_logs (ip_address, location, browser, os, device, page, referrer, session_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        [$data['ip_address'], $data['location'], $data['browser'], $data['os'], $data['device'], $data['page'], $data['referrer'], $data['session_id']],
        'ssssssss'
    );
    
    if ($id) {
        respondSuccess(['id' => $id], 'Visit tracked');
    }
    respondSuccess([], 'Logged'); // Don't error - tracker fires often
}

function handleGetAnalytics() {
    $conn = getDB();
    
    // Total visits
    $totalVisits = 0;
    $r = $conn->query("SELECT COUNT(*) as cnt FROM visitor_logs");
    if ($r) $totalVisits = $r->fetch_assoc()['cnt'];
    
    // Unique visitors (by IP)
    $uniqueIPs = 0;
    $r = $conn->query("SELECT COUNT(DISTINCT ip_address) as cnt FROM visitor_logs");
    if ($r) $uniqueIPs = $r->fetch_assoc()['cnt'];
    
    // Unique sessions
    $uniqueSessions = 0;
    $r = $conn->query("SELECT COUNT(DISTINCT session_id) as cnt FROM visitor_logs WHERE session_id != ''");
    if ($r) $uniqueSessions = $r->fetch_assoc()['cnt'];
    
    // Today's visits
    $todayVisits = 0;
    $r = $conn->query("SELECT COUNT(*) as cnt FROM visitor_logs WHERE DATE(created_at) = CURDATE()");
    if ($r) $todayVisits = $r->fetch_assoc()['cnt'];
    
    // Page views
    $pageViews = [];
    $r = $conn->query("SELECT page, COUNT(*) as cnt FROM visitor_logs GROUP BY page ORDER BY cnt DESC LIMIT 20");
    if ($r) {
        while ($row = $r->fetch_assoc()) {
            $pageViews[$row['page']] = (int)$row['cnt'];
        }
    }
    
    // Browser stats
    $browsers = [];
    $r = $conn->query("SELECT browser, COUNT(*) as cnt FROM visitor_logs WHERE browser != '' GROUP BY browser ORDER BY cnt DESC");
    if ($r) {
        while ($row = $r->fetch_assoc()) {
            $browsers[$row['browser']] = (int)$row['cnt'];
        }
    }
    
    // Device stats
    $devices = [];
    $r = $conn->query("SELECT device, COUNT(*) as cnt FROM visitor_logs WHERE device != '' GROUP BY device ORDER BY cnt DESC");
    if ($r) {
        while ($row = $r->fetch_assoc()) {
            $devices[$row['device']] = (int)$row['cnt'];
        }
    }
    
    // OS stats
    $osStats = [];
    $r = $conn->query("SELECT os, COUNT(*) as cnt FROM visitor_logs WHERE os != '' GROUP BY os ORDER BY cnt DESC");
    if ($r) {
        while ($row = $r->fetch_assoc()) {
            $osStats[$row['os']] = (int)$row['cnt'];
        }
    }
    
    // Visits last 7 days
    $last7Days = [];
    $r = $conn->query("SELECT DATE(created_at) as d, COUNT(*) as cnt FROM visitor_logs WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) GROUP BY DATE(created_at) ORDER BY d");
    if ($r) {
        while ($row = $r->fetch_assoc()) {
            $last7Days[] = ['date' => $row['d'], 'count' => (int)$row['cnt']];
        }
    }
    
    respondSuccess([
        'totalVisits' => $totalVisits,
        'uniqueVisitors' => $uniqueIPs,
        'uniqueSessions' => $uniqueSessions,
        'todayVisits' => $todayVisits,
        'pageViews' => $pageViews,
        'browsers' => $browsers,
        'devices' => $devices,
        'os' => $osStats,
        'last7Days' => $last7Days
    ]);
}

function handleGetRecent() {
    $limit = min((int)($_REQUEST['limit'] ?? 50), 200);
    $rows = dbFetchAll("SELECT * FROM visitor_logs ORDER BY created_at DESC LIMIT ?", [$limit], 'i');
    
    $logs = array_map(function($r) {
        return [
            'id' => $r['id'],
            'ip' => $r['ip_address'],
            'location' => $r['location'],
            'browser' => $r['browser'],
            'os' => $r['os'],
            'device' => $r['device'],
            'page' => $r['page'],
            'referrer' => $r['referrer'],
            'timestamp' => $r['created_at']
        ];
    }, $rows);
    
    respondSuccess(['items' => $logs, 'total' => count($logs)]);
}

function handleClearLogs() {
    $conn = getDB();
    $conn->query("TRUNCATE TABLE visitor_logs");
    addActivityLog('Logs Cleared', 'Visitor logs were cleared');
    respondSuccess([], 'Visitor logs cleared');
}

// Using respond functions from db.php