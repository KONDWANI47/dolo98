<?php
/**
 * Database Viewer API - Noah Christian Academy
 * Fetches all database tables and their data for display
 */

require_once __DIR__ . '/db.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$action = $_REQUEST['action'] ?? '';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    respondError('Method not allowed', 405);
}

switch ($action) {
    case 'tables':
        // Get all table names
        $tables = dbFetchAll("SHOW TABLES");
        $tableNames = array_map(function($row) {
            return array_values($row)[0];
        }, $tables);
        respondSuccess(['tables' => $tableNames]);
        break;
        
    case 'table_data':
        $tableName = $_GET['table'] ?? '';
        if (empty($tableName)) {
            respondError('Table name is required');
        }
        
        // Get table structure
        $columns = dbFetchAll("SHOW COLUMNS FROM `$tableName`");
        
        // Get table data (limit to 100 rows for performance)
        $data = dbFetchAll("SELECT * FROM `$tableName` LIMIT 100");
        
        // Get row count
        $countResult = dbFetchOne("SELECT COUNT(*) as count FROM `$tableName`");
        $totalRows = $countResult['count'] ?? 0;
        
        respondSuccess([
            'table' => $tableName,
            'columns' => $columns,
            'data' => $data,
            'totalRows' => $totalRows,
            'displayedRows' => count($data)
        ]);
        break;
        
    case 'all_tables_data':
        // Get all table names
        $tables = dbFetchAll("SHOW TABLES");
        $tableNames = array_map(function($row) {
            return array_values($row)[0];
        }, $tables);
        
        $allData = [];
        
        foreach ($tableNames as $tableName) {
            // Get table structure
            $columns = dbFetchAll("SHOW COLUMNS FROM `$tableName`");
            
            // Get table data (limit to 50 rows per table for performance)
            $data = dbFetchAll("SELECT * FROM `$tableName` LIMIT 50");
            
            // Get row count
            $countResult = dbFetchOne("SELECT COUNT(*) as count FROM `$tableName`");
            $totalRows = $countResult['count'] ?? 0;
            
            $allData[$tableName] = [
                'columns' => $columns,
                'data' => $data,
                'totalRows' => $totalRows,
                'displayedRows' => count($data)
            ];
        }
        
        respondSuccess(['tables' => $allData]);
        break;
        
    default:
        respondError('Unknown action', 404);
}
