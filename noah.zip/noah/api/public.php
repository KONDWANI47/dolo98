<?php
/**
 * Public API - Noah Christian Academy
 * Handles public form submissions (registration, payment, contact)
 * Also serves dynamic content for public pages
 */

// Include database connection and helper functions
require_once __DIR__ . '/db.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Support both direct POST and routed action parameter
$action = $_REQUEST['action'] ?? '';

// Also check if this is a GET request for public data
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    switch ($action) {
        case 'events':
            $rows = dbFetchAll(
                "SELECT * FROM events ORDER BY status ASC, date ASC LIMIT 10"
            );
            $items = array_map(function($r) {
                return [
                    'id' => $r['id'],
                    'title' => $r['title'],
                    'date' => $r['date'],
                    'time' => $r['time'],
                    'location' => $r['location'],
                    'description' => $r['description'],
                    'imageUrl' => $r['image_url'] ?? '',
                    'videoUrl' => $r['video_url'] ?? '',
                    'link' => $r['link'] ?? '',
                    'status' => $r['status'],
                    'createdAt' => $r['created_at']
                ];
            }, $rows);
            respondSuccess(['items' => $items]);
            break;
            
        case 'gallery':
            $rows = dbFetchAll(
                "SELECT * FROM gallery ORDER BY created_at DESC LIMIT 20"
            );
            $items = array_map(function($r) {
                return [
                    'id' => $r['id'],
                    'imageUrl' => $r['image_url'],
                    'videoUrl' => $r['video_url'] ?? '',
                    'mediaType' => $r['media_type'] ?? 'image',
                    'title' => $r['title'],
                    'category' => $r['category'],
                    'description' => $r['description'],
                    'createdAt' => $r['created_at']
                ];
            }, $rows);
            respondSuccess(['items' => $items]);
            break;
            
        case 'blog':
            $rows = dbFetchAll(
                "SELECT * FROM blog WHERE status = 'Published' ORDER BY created_at DESC LIMIT 10"
            );
            $items = array_map(function($r) {
                return [
                    'id' => $r['id'],
                    'title' => $r['title'],
                    'author' => $r['author'],
                    'category' => $r['category'],
                    'content' => $r['content'],
                    'image' => $r['image'],
                    'createdAt' => $r['created_at']
                ];
            }, $rows);
            respondSuccess(['items' => $items]);
            break;
            
        case 'team':
            $rows = dbFetchAll(
                "SELECT * FROM team_members WHERE status = 'Active' AND show_on_website = 1 ORDER BY sort_order ASC"
            );
            $items = array_map(function($r) {
                return [
                    'id' => $r['id'],
                    'firstName' => $r['first_name'],
                    'lastName' => $r['last_name'],
                    'role' => $r['role'],
                    'category' => $r['category'],
                    'imageUrl' => $r['image_url'],
                    'description' => $r['description'],
                    'sortOrder' => $r['sort_order']
                ];
            }, $rows);
            respondSuccess(['items' => $items]);
            break;
        case 'team_teachers':
            $rows = dbFetchAll(
                "SELECT * FROM teachers WHERE approved = 1 ORDER BY created_at ASC"
            );
            $items = array_map(function($r) {
                return [
                    'id' => $r['id'],
                    'firstName' => $r['first_name'],
                    'lastName' => $r['last_name'],
                    'email' => $r['email'],
                    'phone' => $r['phone'],
                    'subject' => $r['subject'],
                    'qualification' => $r['qualification'],
                    'classAssigned' => $r['class_assigned']
                ];
            }, $rows);
            respondSuccess(['items' => $items]);
            break;
            
        case 'footer':
            $rows = dbFetchAll(
                "SELECT content_key, content_value FROM site_content WHERE page_name = 'footer'"
            );
            $data = [];
            foreach ($rows as $r) {
                $data[$r['content_key']] = $r['content_value'];
            }
            respondSuccess($data);
            break;

        case 'org_chart':
            $rows = dbFetchAll(
                "SELECT content_key, content_value FROM site_content WHERE page_name = 'org_chart'"
            );
            $data = [];
            foreach ($rows as $r) {
                $data[$r['content_key']] = $r['content_value'];
            }
            respondSuccess($data);
            break;

        case 'birthdays':
            $rows = dbFetchAll(
                "SELECT * FROM birthdays WHERE status = 'active' ORDER BY MONTH(birthday), DAY(birthday) ASC"
            );
            $items = array_map(function($r) {
                return [
                    'id' => $r['id'],
                    'name' => $r['name'],
                    'type' => $r['type'],
                    'birthday' => $r['birthday'],
                    'class' => $r['class'],
                    'photo' => $r['photo'],
                    'message' => $r['message']
                ];
            }, $rows);
            respondSuccess($items);
            break;

        case 'vacancies':
            $rows = dbFetchAll(
                "SELECT * FROM vacancies WHERE status = 'Active' ORDER BY created_at DESC"
            );
            $items = array_map(function($r) {
                return [
                    'id' => $r['id'],
                    'title' => $r['title'],
                    'description' => $r['description'],
                    'requirements' => $r['requirements'],
                    'grade' => $r['grade'],
                    'responsibilities' => $r['responsibilities'],
                    'duties' => $r['duties'],
                    'contactEmail' => $r['contact_email'],
                    'location' => $r['location'],
                    'positionType' => $r['position_type'],
                    'salaryRange' => $r['salary_range'],
                    'applicationDeadline' => $r['application_deadline'],
                    'status' => $r['status'],
                    'createdAt' => $r['created_at']
                ];
            }, $rows);
            respondSuccess(['items' => $items]);
            break;

        case 'announcements':
            $rows = dbFetchAll(
                "SELECT * FROM announcements WHERE status = 'Published' ORDER BY pinned DESC, priority DESC, created_at DESC"
            );
            $items = array_map(function($r) {
                return [
                    'id' => $r['id'],
                    'title' => $r['title'],
                    'content' => $r['content'],
                    'priority' => $r['priority'],
                    'audience' => $r['target_audience'] ?? 'all',
                    'status' => $r['status'],
                    'pinned' => (bool)$r['pinned'],
                    'createdAt' => $r['created_at']
                ];
            }, $rows);
            respondSuccess(['items' => $items]);
            break;

        default:
            respondError('Unknown action', 404);
    }
    exit();
}

// POST handlers (form submissions)
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respondError('Method not allowed', 405);
}

switch ($action) {
    case 'register':
        handlePublicRegistration();
        break;
    case 'payment':
        handlePublicPayment();
        break;
    case 'contact':
        handlePublicContact();
        break;
    default:
        respondError('Unknown action', 404);
}

function handlePublicRegistration() {
    $body = getJsonBody();
    if (!$body) respondError('Invalid JSON body');
    
    $studentName = trim($body['studentName'] ?? $body['student_name'] ?? '');
    $grade = $body['grade'] ?? '';
    $parentName = trim($body['parentName'] ?? $body['parent_name'] ?? '');
    $phone = $body['phone'] ?? '';
    $email = $body['email'] ?? '';
    $address = $body['origin'] ?? $body['address'] ?? '';
    $dob = $body['dateOfBirth'] ?? $body['dob'] ?? null;
    $notes = $body['message'] ?? $body['notes'] ?? '';
    
    // Map grade values from form to database values
    $gradeMap = [
        'daycare' => 'Daycare',
        'grade1' => 'Standard 1',
        'grade2' => 'Standard 2',
        'grade3' => 'Standard 3',
        'grade4' => 'Standard 4',
        'grade5' => 'Standard 5',
        'grade6' => 'Standard 6',
        'grade7' => 'Standard 7',
        'grade8' => 'Standard 8',
        'grade9' => 'Form 1',
        'grade10' => 'Form 2',
        'grade11' => 'Form 3',
        'grade12' => 'Form 4'
    ];
    if (isset($gradeMap[$grade])) {
        $grade = $gradeMap[$grade];
    }
    
    if (empty($studentName)) respondError('Student name is required');
    if (empty($parentName)) respondError('Parent name is required');
    if (empty($phone) && empty($email)) respondError('Phone or email required');
    
    $id = dbInsert(
        "INSERT INTO registrations (student_name, grade, parent_name, phone, email, address, dob, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        [$studentName, $grade, $parentName, $phone, $email, $address, $dob, $notes],
        'ssssssss'
    );
    
    if ($id) {
        addActivityLog('New Registration', "$studentName registered for $grade");
        respondSuccess(['id' => $id], 'Registration submitted successfully! We will contact you soon.');
    }
    respondError('Failed to submit registration');
}

function handlePublicPayment() {
    $body = getJsonBody();
    
    $payerName = trim($body['payerName'] ?? $body['paymentStudentName'] ?? $body['payer_name'] ?? '');
    $studentName = trim($body['studentName'] ?? $body['paymentStudentName'] ?? $body['student_name'] ?? '');
    $amount = $body['amount'] ?? $body['paymentAmount'] ?? 0;
    $paymentType = $body['paymentType'] ?? $body['payment_type'] ?? '';
    $phone = $body['phone'] ?? '';
    $paymentMethod = $body['paymentMethod'] ?? $body['payment_method'] ?? '';
    $notes = $body['paymentNote'] ?? $body['notes'] ?? '';
    $grade = $body['paymentGrade'] ?? $body['grade'] ?? '';
    
    if (empty($payerName) && empty($studentName)) respondError('Student or payer name required');
    if ($amount <= 0) respondError('Valid amount required');
    
    $id = dbInsert(
        "INSERT INTO payments (payer_name, student_name, amount, payment_type, phone, payment_method, notes) VALUES (?, ?, ?, ?, ?, ?, ?)",
        [$payerName ?: $studentName, $studentName, $amount, $paymentType, $phone, $paymentMethod, $notes],
        'ssdssss'
    );
    
    if ($id) {
        addActivityLog('New Payment', ($payerName ?: $studentName) . ' - MK' . $amount);
        respondSuccess(['id' => $id], 'Payment submitted successfully! We will process it shortly.');
    }
    respondError('Failed to submit payment');
}

function handlePublicContact() {
    $body = getJsonBody();
    
    $name = trim($body['name'] ?? $body['contactName'] ?? '');
    $email = $body['email'] ?? $body['contactEmail'] ?? '';
    $subject = $body['subject'] ?? $body['contactSubject'] ?? '';
    $message = $body['message'] ?? $body['contactMessage'] ?? '';
    
    if (empty($name)) respondError('Name is required');
    if (empty($message)) respondError('Message is required');
    
    $id = dbInsert(
        "INSERT INTO messages (name, email, subject, message) VALUES (?, ?, ?, ?)",
        [$name, $email, $subject, $message], 'ssss'
    );
    
    if ($id) {
        respondSuccess(['id' => $id], 'Message sent successfully! We will respond soon.');
    }
    respondError('Failed to send message');
}
