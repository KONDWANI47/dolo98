<?php
/**
 * API Router - Noah Christian Academy
 * Routes requests to appropriate handlers
 */

// Suppress errors to prevent HTML error output from breaking JSON responses
error_reporting(0);
ini_set('display_errors', 0);

// Start output buffering to catch any stray output
ob_start();

require_once __DIR__ . '/db.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Security-Policy: script-src \'self\' \'unsafe-inline\' \'unsafe-eval\' https:;');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    ob_end_clean();
    exit();
}

$type = $_REQUEST['type'] ?? '';

switch ($type) {
    case 'auth':
        require __DIR__ . '/auth.php';
        break;
    case 'admin':
        require __DIR__ . '/admin.php';
        break;
    case 'teacher':
        require __DIR__ . '/teacher.php';
        break;
    case 'parent':
        require __DIR__ . '/parent.php';
        break;
    case 'visitors':
        require __DIR__ . '/visitors.php';
        break;
    case 'public':
        require __DIR__ . '/public.php';
        break;
    case 'collaboration':
        require __DIR__ . '/collaboration.php';
        break;
    case 'report_workflow':
        require __DIR__ . '/report_workflow.php';
        break;
    case 'visitor_tracking':
        require __DIR__ . '/visitor_tracking.php';
        break;
    case 'announcements':
        // Public announcements endpoint
        header('Content-Type: application/json');
        $rows = dbFetchAll(
            "SELECT * FROM announcements WHERE status = 'Published' AND (target_audience = 'all' OR target_audience = 'public') ORDER BY pinned DESC, created_at DESC LIMIT 5"
        );
        $announcements = array_map(function($r) {
            return [
                'id' => $r['id'],
                'title' => $r['title'],
                'content' => $r['content'],
                'priority' => $r['priority'],
                'pinned' => (bool)$r['pinned'],
                'createdAt' => $r['created_at']
            ];
        }, $rows);
        respondSuccess(['items' => $announcements, 'total' => count($announcements)]);
        break;
    case 'scheme_work':
        require __DIR__ . '/scheme_work.php';
        break;
    default:
        respondSuccess(['version' => '2.0'], 'NOH Academy API is running');
        break;
}