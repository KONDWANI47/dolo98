<?php
/**
 * Web Search Service - Noah Christian Academy
 * Integrates Google Custom Search API for web search capability
 */

class WebSearchService {
    private $apiKey;
    private $searchEngineId;
    private $baseUrl;

    public function __construct() {
        $this->apiKey = getenv('GOOGLE_SEARCH_API_KEY') ?: '';
        $this->searchEngineId = getenv('GOOGLE_SEARCH_ENGINE_ID') ?: '';
        $this->baseUrl = 'https://www.googleapis.com/customsearch/v1';
    }

    /**
     * Perform web search
     */
    public function search($query, $numResults = 5) {
        if (empty($this->apiKey) || empty($this->searchEngineId)) {
            return [
                'success' => false,
                'message' => 'Google Search API not configured. Please set GOOGLE_SEARCH_API_KEY and GOOGLE_SEARCH_ENGINE_ID in .env file.'
            ];
        }

        $url = $this->baseUrl . '?key=' . urlencode($this->apiKey)
             . '&cx=' . urlencode($this->searchEngineId)
             . '&q=' . urlencode($query)
             . '&num=' . $numResults;

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            return [
                'success' => false,
                'message' => 'CURL error: ' . $error
            ];
        }

        if ($httpCode >= 400) {
            $errorData = json_decode($response, true);
            return [
                'success' => false,
                'message' => $errorData['error']['message'] ?? "HTTP {$httpCode} error"
            ];
        }

        $data = json_decode($response, true);

        if (!isset($data['items'])) {
            return [
                'success' => false,
                'message' => 'No search results found'
            ];
        }

        $results = [];
        foreach ($data['items'] as $item) {
            $results[] = [
                'title' => $item['title'] ?? '',
                'link' => $item['link'] ?? '',
                'snippet' => $item['snippet'] ?? '',
                'displayLink' => $item['displayLink'] ?? ''
            ];
        }

        return [
            'success' => true,
            'query' => $query,
            'results' => $results,
            'total_results' => count($results)
        ];
    }

    /**
     * Check if web search is configured
     */
    public function isConfigured() {
        return !empty($this->apiKey) && !empty($this->searchEngineId);
    }
}
