<?php
require_once __DIR__ . '/db.php';
header('Content-Type: application/json');
$id = (int)($_GET['id'] ?? 0);
if (!$id) respondError('Application ID is required', 400);
try {
    $row = dbFetchOne("SELECT * FROM job_applications WHERE id = ?", [$id], 'i');
    if (!$row) respondError('Job application not found', 404);
    $documents = dbFetchAll("SELECT * FROM application_documents WHERE application_id = ? ORDER BY id DESC", [$id], 'i');
    echo json_encode(['success' => true, 'data' => $row, 'documents' => $documents, 'message' => 'Application loaded']); exit;
} catch (Throwable $e) {
    respondError('Failed to load application: ' . $e->getMessage(), 500);
}
