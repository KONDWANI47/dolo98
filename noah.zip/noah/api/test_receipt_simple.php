<?php
/**
 * Simple test for receipt generation
 */

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>Receipt Generation Test</h1>";

try {
    // Test database connection
    require_once __DIR__ . '/db.php';
    echo "<p>✓ Database connection successful</p>";
    
    // Test payment query
    $payment = dbFetchOne("SELECT * FROM payments LIMIT 1", [], '');
    if ($payment) {
        echo "<p>✓ Found payment: " . htmlspecialchars($payment['payer_name'] ?? 'Unknown') . " - MK" . number_format($payment['amount'] ?? 0, 2) . "</p>";
        echo "<pre>" . htmlspecialchars(json_encode($payment, JSON_PRETTY_PRINT)) . "</pre>";
    } else {
        echo "<p>✗ No payments found in database</p>";
    }
    
    // Test FPDF library
    require_once __DIR__ . '/../pdf_library/fpdf.php';
    $pdf = new FPDF('P', 'mm', 'A4');
    echo "<p>✓ FPDF library loaded successfully</p>";
    
    // Test directory creation
    $uploadDir = __DIR__ . '/../uploads/receipts/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
        echo "<p>✓ Created receipts directory</p>";
    } else {
        echo "<p>✓ Receipts directory exists</p>";
    }
    
    echo "<p><strong>All tests passed! The receipt generation system should work.</strong></p>";
    
} catch (Exception $e) {
    echo "<p>✗ Error: " . htmlspecialchars($e->getMessage()) . "</p>";
    echo "<pre>" . htmlspecialchars($e->getTraceAsString()) . "</pre>";
}
?>