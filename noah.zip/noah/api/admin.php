<?php
/**
 * Admin API Handler - Noah Christian Academy
 * Full CRUD for all collections using MySQL
 */

require_once __DIR__ . '/db.php';

// Auto-migration: add is_active column and parent_login_logs table
try {
    $conn = getDB();
    $colCheck = $conn->query("SHOW COLUMNS FROM parents LIKE 'is_active'");
    if ($colCheck && $colCheck->num_rows === 0) {
        $conn->query("ALTER TABLE parents ADD COLUMN is_active TINYINT(1) DEFAULT 1 AFTER approved");
    }
    $conn->query("CREATE TABLE IF NOT EXISTS parent_login_logs (
        id INT PRIMARY KEY AUTO_INCREMENT,
        parent_id INT NOT NULL,
        ip_address VARCHAR(50) DEFAULT '',
        location VARCHAR(255) DEFAULT '',
        browser VARCHAR(100) DEFAULT '',
        os VARCHAR(100) DEFAULT '',
        device VARCHAR(50) DEFAULT '',
        user_agent TEXT DEFAULT '',
        login_status VARCHAR(20) DEFAULT 'success',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_parent_id (parent_id),
        INDEX idx_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    
    // Create testimonials table if it doesn't exist
    $conn->query("CREATE TABLE IF NOT EXISTS testimonials (
        id INT PRIMARY KEY AUTO_INCREMENT,
        parent_name VARCHAR(200) NOT NULL,
        student_name VARCHAR(200) NOT NULL,
        grade VARCHAR(50) NOT NULL,
        years_enrolled INT NOT NULL,
        testimonial TEXT NOT NULL,
        rating INT NOT NULL,
        anonymous TINYINT(1) DEFAULT 0,
        status VARCHAR(20) DEFAULT 'pending',
        rejection_reason TEXT,
        approved_at TIMESTAMP NULL,
        rejected_at TIMESTAMP NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_status (status),
        INDEX idx_rating (rating),
        INDEX idx_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    // Create timetable_documents table if it doesn't exist
    $conn->query("CREATE TABLE IF NOT EXISTS timetable_documents (
        id INT PRIMARY KEY AUTO_INCREMENT,
        title VARCHAR(255) NOT NULL,
        class VARCHAR(100) DEFAULT '',
        term VARCHAR(50) NOT NULL,
        description TEXT,
        file_url VARCHAR(500) NOT NULL,
        file_name VARCHAR(255) NOT NULL,
        file_size INT DEFAULT 0,
        file_type VARCHAR(100) DEFAULT '',
        uploaded_by VARCHAR(255) DEFAULT 'Admin',
        target VARCHAR(20) DEFAULT 'teachers',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_class (class),
        INDEX idx_term (term),
        INDEX idx_target (target),
        INDEX idx_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    
    // Add target column if it doesn't exist
    $colCheck = $conn->query("SHOW COLUMNS FROM timetable_documents LIKE 'target'");
    if ($colCheck && $colCheck->num_rows === 0) {
        $conn->query("ALTER TABLE timetable_documents ADD COLUMN target VARCHAR(20) DEFAULT 'teachers' AFTER uploaded_by");
    }
    
    // Create users table if it doesn't exist
    $conn->query("CREATE TABLE IF NOT EXISTS users (
        id INT PRIMARY KEY AUTO_INCREMENT,
        first_name VARCHAR(100) NOT NULL,
        last_name VARCHAR(100) NOT NULL,
        email VARCHAR(150) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        role ENUM('admin', 'teacher', 'parent') NOT NULL DEFAULT 'parent',
        phone VARCHAR(20),
        status ENUM('active', 'inactive') DEFAULT 'active',
        notes TEXT,
        last_login TIMESTAMP NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_email (email),
        INDEX idx_role (role),
        INDEX idx_status (status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    
    // Create apis table if it doesn't exist
    $conn->query("CREATE TABLE IF NOT EXISTS apis (
        id INT PRIMARY KEY AUTO_INCREMENT,
        name VARCHAR(255) NOT NULL,
        type ENUM('payment', 'sms', 'email', 'other') NOT NULL DEFAULT 'other',
        provider VARCHAR(100) NOT NULL,
        endpoint VARCHAR(500) NOT NULL,
        api_key VARCHAR(255) NOT NULL,
        api_secret VARCHAR(255),
        headers TEXT,
        status ENUM('active', 'inactive') DEFAULT 'active',
        priority INT DEFAULT 1,
        description TEXT,
        last_used TIMESTAMP NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_type (type),
        INDEX idx_status (status),
        INDEX idx_provider (provider)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    // Create account_deletion_requests table if it doesn't exist
    $conn->query("CREATE TABLE IF NOT EXISTS account_deletion_requests (
        id INT PRIMARY KEY AUTO_INCREMENT,
        user_type ENUM('teacher', 'parent') NOT NULL,
        user_id INT NOT NULL,
        user_name VARCHAR(255) NOT NULL,
        email VARCHAR(255),
        requested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        scheduled_deletion_at TIMESTAMP NOT NULL,
        status ENUM('pending', 'cancelled', 'completed', 'rejected') DEFAULT 'pending',
        admin_notes TEXT,
        processed_at TIMESTAMP NULL,
        processed_by INT NULL,
        INDEX idx_status (status),
        INDEX idx_scheduled (scheduled_deletion_at),
        INDEX idx_user (user_type, user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    // Create admin_notifications table if it doesn't exist
    $conn->query("CREATE TABLE IF NOT EXISTS admin_notifications (
        id INT PRIMARY KEY AUTO_INCREMENT,
        type VARCHAR(50) NOT NULL,
        title VARCHAR(255) NOT NULL,
        message TEXT NOT NULL,
        related_id INT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        is_read TINYINT(1) DEFAULT 0,
        read_at TIMESTAMP NULL,
        INDEX idx_type (type),
        INDEX idx_read (is_read),
        INDEX idx_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    // Auto-seed new footer fields if missing
    $newFooterFields = [
        'phone' => '+265 999 608 570',
        'phone2' => '+265 999 693 134',
        'description' => 'Faith-led education with academic excellence and holistic learner development.',
        'schoolHours' => 'Monday - Friday: 7:30 AM - 4:00 PM | Saturday: 8:00 AM - 12:00 PM (Office Only)',
        'facebookUrl' => 'https://www.facebook.com',
        'tiktokUrl' => 'https://www.tiktok.com',
        'whatsappUrl' => 'https://wa.me/265999635561'
    ];
    foreach ($newFooterFields as $key => $val) {
        $conn->query("INSERT IGNORE INTO site_content (page_name, content_key, content_value) VALUES ('footer', '$key', '$val')");
    }

    // Auto-migration: add show_on_website column to team_members
    $colCheck2 = $conn->query("SHOW COLUMNS FROM team_members LIKE 'show_on_website'");
    if ($colCheck2 && $colCheck2->num_rows === 0) {
        $conn->query("ALTER TABLE team_members ADD COLUMN show_on_website TINYINT(1) DEFAULT 1 AFTER status");
    }
    
    // Auto-migration: add API columns to payments table
    $colCheck3 = $conn->query("SHOW COLUMNS FROM payments LIKE 'api_provider'");
    if ($colCheck3 && $colCheck3->num_rows === 0) {
        $conn->query("ALTER TABLE payments ADD COLUMN api_provider VARCHAR(100) AFTER payment_method");
    }
    $colCheck4 = $conn->query("SHOW COLUMNS FROM payments LIKE 'api_name'");
    if ($colCheck4 && $colCheck4->num_rows === 0) {
        $conn->query("ALTER TABLE payments ADD COLUMN api_name VARCHAR(255) AFTER api_provider");
    }

    // Create announcements table if it doesn't exist
    $conn->query("CREATE TABLE IF NOT EXISTS announcements (
        id INT PRIMARY KEY AUTO_INCREMENT,
        title VARCHAR(255) NOT NULL,
        content TEXT NOT NULL,
        priority ENUM('normal', 'important', 'urgent') DEFAULT 'normal',
        audience ENUM('all', 'teachers', 'parents') DEFAULT 'all',
        status ENUM('Published', 'Draft') DEFAULT 'Draft',
        pinned TINYINT(1) DEFAULT 0,
        created_by VARCHAR(100) DEFAULT 'admin',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_status (status),
        INDEX idx_priority (priority),
        INDEX idx_pinned (pinned),
        INDEX idx_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    // Auto-migration: add SMS delivery columns to notifications table
    $colCheck5 = $conn->query("SHOW COLUMNS FROM notifications LIKE 'delivery_sms'");
    if ($colCheck5 && $colCheck5->num_rows === 0) {
        $conn->query("ALTER TABLE notifications ADD COLUMN delivery_sms TINYINT(1) DEFAULT 0 AFTER delivery_email");
    }
    $colCheck6 = $conn->query("SHOW COLUMNS FROM notifications LIKE 'sms_recipients'");
    if ($colCheck6 && $colCheck6->num_rows === 0) {
        $conn->query("ALTER TABLE notifications ADD COLUMN sms_recipients TEXT AFTER email_recipients");
    }
    $colCheck7 = $conn->query("SHOW COLUMNS FROM notifications LIKE 'sms_api_id'");
    if ($colCheck7 && $colCheck7->num_rows === 0) {
        $conn->query("ALTER TABLE notifications ADD COLUMN sms_api_id INT AFTER sms_recipients");
    }

    // Create timetable table if it doesn't exist
    $conn->query("CREATE TABLE IF NOT EXISTS timetable (
        id INT PRIMARY KEY AUTO_INCREMENT,
        day VARCHAR(20) NOT NULL,
        time VARCHAR(50) NOT NULL,
        subject VARCHAR(100) NOT NULL,
        class_name VARCHAR(50) NOT NULL,
        teacher_id INT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_day_time (day, time),
        INDEX idx_class (class_name),
        INDEX idx_teacher (teacher_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    // Create teacher_files table if it doesn't exist
    $conn->query("CREATE TABLE IF NOT EXISTS teacher_files (
        id INT PRIMARY KEY AUTO_INCREMENT,
        title VARCHAR(255) NOT NULL,
        description TEXT,
        file_name VARCHAR(255) NOT NULL,
        file_path VARCHAR(500) NOT NULL,
        file_type VARCHAR(50) NOT NULL,
        file_size BIGINT NOT NULL,
        uploaded_by VARCHAR(100) NOT NULL,
        target_type ENUM('all', 'specific') DEFAULT 'all',
        target_teachers TEXT,
        priority ENUM('normal', 'high', 'urgent') DEFAULT 'normal',
        sent_at TIMESTAMP NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_created (created_at),
        INDEX idx_priority (priority),
        INDEX idx_target (target_type)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
} catch (\Exception $e) { /* silent */ }

// Safety net: always return JSON even on fatal errors
register_shutdown_function(function() {
    $error = error_get_last();
    if ($error && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        while (ob_get_level()) { ob_end_clean(); }
        http_response_code(500);
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Server error: ' . $error['message']]);
    }
});

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$method = $_SERVER['REQUEST_METHOD'];
$collection = $_REQUEST['collection'] ?? '';
$id = $_REQUEST['id'] ?? null;

// Special phone correction actions (handle before collection check)
$phoneAction = $_REQUEST['phone_action'] ?? '';
if ($phoneAction && $method === 'GET') {
    if ($phoneAction === 'get_registration_phones') {
        $rows = dbFetchAll("SELECT id, student_name, parent_name, phone, email, created_at FROM registrations ORDER BY created_at DESC");
        $mapped = array_map(function($r) {
            return [
                'id' => $r['id'],
                'studentName' => $r['student_name'],
                'parentName' => $r['parent_name'],
                'phone' => $r['phone'],
                'email' => $r['email'],
                'createdAt' => $r['created_at']
            ];
        }, $rows);
        respondSuccess(['items' => $mapped, 'total' => count($mapped)]);
    }
    
    if ($phoneAction === 'get_teacher_phones') {
        $rows = dbFetchAll("SELECT id, first_name, last_name, phone, email FROM teachers ORDER BY first_name, last_name");
        $mapped = array_map(function($r) {
            $firstName = $r['first_name'] ?? '';
            $lastName = $r['last_name'] ?? '';
            $name = trim($firstName . ' ' . $lastName);
            if (empty($name)) {
                $name = 'Unknown';
            }
            return [
                'id' => $r['id'],
                'firstName' => $firstName,
                'lastName' => $lastName,
                'name' => $name,
                'phone' => $r['phone'],
                'email' => $r['email']
            ];
        }, $rows);
        respondSuccess(['items' => $mapped, 'total' => count($mapped)]);
    }
    
    if ($phoneAction === 'get_parent_phones') {
        $rows = dbFetchAll("SELECT id, first_name, last_name, phone, email FROM parents ORDER BY first_name, last_name");
        $mapped = array_map(function($r) {
            $firstName = $r['first_name'] ?? '';
            $lastName = $r['last_name'] ?? '';
            $name = trim($firstName . ' ' . $lastName);
            if (empty($name)) {
                $name = 'Unknown';
            }
            return [
                'id' => $r['id'],
                'firstName' => $firstName,
                'lastName' => $lastName,
                'name' => $name,
                'phone' => $r['phone'],
                'email' => $r['email']
            ];
        }, $rows);
        respondSuccess(['items' => $mapped, 'total' => count($mapped)]);
    }
    
    if ($phoneAction === 'get_admin_phones') {
        $rows = dbFetchAll("SELECT id, first_name, last_name, phone, email FROM admins ORDER BY first_name, last_name");
        $mapped = array_map(function($r) {
            $firstName = $r['first_name'] ?? '';
            $lastName = $r['last_name'] ?? '';
            $name = trim($firstName . ' ' . $lastName);
            if (empty($name)) {
                $name = 'Unknown';
            }
            return [
                'id' => $r['id'],
                'firstName' => $firstName,
                'lastName' => $lastName,
                'name' => $name,
                'phone' => $r['phone'],
                'email' => $r['email']
            ];
        }, $rows);
        respondSuccess(['items' => $mapped, 'total' => count($mapped)]);
    }
    
    respondError('Unknown phone action: ' . $phoneAction);
}

if ($phoneAction && $method === 'POST') {
    $body = getJsonBody();
    
    if ($phoneAction === 'update_registration_phone') {
        $id = (int)($body['id'] ?? 0);
        $phone = trim($body['phone'] ?? '');
        
        if (!$id) respondError('Registration ID required');
        if (empty($phone)) respondError('Phone number required');
        
        $updated = dbExecute("UPDATE registrations SET phone = ? WHERE id = ?", [$phone, $id], 'si');
        if ($updated) {
            addActivityLog('Registration Phone Updated', "Phone updated for registration #$id");
            respondSuccess([], 'Phone number updated successfully');
        } else {
            respondError('Failed to update phone number');
        }
    }
    
    if ($phoneAction === 'update_teacher_phone') {
        $id = (int)($body['id'] ?? 0);
        $phone = trim($body['phone'] ?? '');
        
        if (!$id) respondError('Teacher ID required');
        if (empty($phone)) respondError('Phone number required');
        
        $updated = dbExecute("UPDATE teachers SET phone = ? WHERE id = ?", [$phone, $id], 'si');
        if ($updated) {
            addActivityLog('Teacher Phone Updated', "Phone updated for teacher #$id");
            respondSuccess([], 'Phone number updated successfully');
        } else {
            respondError('Failed to update phone number');
        }
    }
    
    if ($phoneAction === 'update_parent_phone') {
        $id = (int)($body['id'] ?? 0);
        $phone = trim($body['phone'] ?? '');
        
        if (!$id) respondError('Parent ID required');
        if (empty($phone)) respondError('Phone number required');
        
        $updated = dbExecute("UPDATE parents SET phone = ? WHERE id = ?", [$phone, $id], 'si');
        if ($updated) {
            addActivityLog('Parent Phone Updated', "Phone updated for parent #$id");
            respondSuccess([], 'Phone number updated successfully');
        } else {
            respondError('Failed to update phone number');
        }
    }
    
    if ($phoneAction === 'update_admin_phone') {
        $id = (int)($body['id'] ?? 0);
        $phone = trim($body['phone'] ?? '');
        
        if (!$id) respondError('Admin ID required');
        if (empty($phone)) respondError('Phone number required');
        
        $updated = dbExecute("UPDATE admins SET phone = ? WHERE id = ?", [$phone, $id], 'si');
        if ($updated) {
            addActivityLog('Admin Phone Updated', "Phone updated for admin #$id");
            respondSuccess([], 'Phone number updated successfully');
        } else {
            respondError('Failed to update phone number');
        }
    }
    
    respondError('Unknown phone action: ' . $phoneAction);
}

// Special timetable actions (handle before collection check)
$timetableAction = $_REQUEST['timetable_action'] ?? '';
if ($timetableAction && $method === 'POST') {
    if ($timetableAction === 'send_to_teachers') {
        // Get all teachers with their contact information
        $teachers = dbFetchAll("SELECT id, first_name, last_name, email FROM teachers");
        
        if (empty($teachers)) {
            respondError('No teachers found to send timetable to');
        }
        
        // Get the latest timetable document
        $latestDoc = dbFetchOne("SELECT * FROM timetable_documents ORDER BY created_at DESC LIMIT 1");
        
        if (!$latestDoc) {
            respondError('No timetable documents found to send');
        }
        
        // In a real implementation, this would send emails or notifications
        // For now, we'll just log the action and return success
        $teacherCount = count($teachers);
        addActivityLog('Timetable Sent to Teachers', "Timetable document '{$latestDoc['title']}' sent to {$teacherCount} teachers");
        
        respondSuccess([
            'teachers_notified' => $teacherCount,
            'document_title' => $latestDoc['title'],
            'document_url' => $latestDoc['file_url']
        ], "Timetable sent to {$teacherCount} teachers successfully");
    }
    
    respondError('Unknown timetable action: ' . $timetableAction);
}

// Allowed collections map to table names
$collectionMap = [
    'students' => 'students',
    'teachers' => 'teachers',
    'parents' => 'parents',
    'events' => 'events',
    'gallery' => 'gallery',
    'blog' => 'blog',
    'services' => 'services',
    'messages' => 'messages',
    'registrations' => 'registrations',
    'payments' => 'payments',
    'attendance' => 'attendance',
    'content' => 'site_content',
    'activity' => 'activity_log',
    'settings' => 'settings',
    'announcements' => 'announcements',
    'assessments' => 'assessments',
    'visitors' => 'visitor_logs',
    'teammembers' => 'team_members',
    'admins' => 'admins',
    'users' => 'users',
    'vacancies' => 'vacancies',
    'courses' => 'courses',
    'notifications' => 'notifications',
    'exams' => 'teacher_exams',
    'admin_sessions' => 'admin_sessions',
    'jobapplications' => 'job_applications',
    'library' => 'library',
    'timetable' => 'timetable',
    'timetable_documents' => 'timetable_documents',
    'sports' => 'sports_activities',
    'transport' => 'transport',
    'testimonials' => 'testimonials',
    'apis' => 'apis',
    'account_deletion_requests' => 'account_deletion_requests',
    'admin_notifications' => 'admin_notifications',
    'teacher_files' => 'teacher_files',
    'birthdays' => 'birthdays'
];

// Special teacher files action
$teacherFilesAction = $_REQUEST['teacher_files_action'] ?? '';
if ($teacherFilesAction && $method === 'GET') {
    if ($teacherFilesAction === 'get_all') {
        $rows = dbFetchAll("SELECT * FROM teacher_files ORDER BY created_at DESC LIMIT 100");
        $mapped = array_map(function($r) {
            return [
                'id' => $r['id'],
                'teacherId' => $r['teacher_id'] ?? null,
                'teacherName' => $r['teacher_name'] ?? $r['uploaded_by'] ?? 'Unknown',
                'title' => $r['title'],
                'category' => $r['category'] ?? 'general',
                'description' => $r['description'] ?? '',
                'fileUrl' => $r['file_url'] ?? $r['file_path'] ?? '',
                'fileName' => $r['file_name'],
                'fileSize' => $r['file_size'],
                'fileType' => $r['file_type'],
                'status' => $r['status'] ?? 'pending',
                'adminNotes' => $r['admin_notes'] ?? '',
                'createdAt' => $r['created_at']
            ];
        }, $rows);
        respondSuccess(['items' => $mapped, 'total' => count($mapped)]);
    }
    
    if ($teacherFilesAction === 'update_status') {
        $id = (int)($_REQUEST['id'] ?? 0);
        $status = trim($_REQUEST['status'] ?? 'pending');
        $adminNotes = trim($_REQUEST['admin_notes'] ?? '');
        
        if (!$id) respondError('File ID required');
        
        // Check if status column exists
        $conn = getDB();
        $colCheck = $conn->query("SHOW COLUMNS FROM teacher_files LIKE 'status'");
        if ($colCheck && $colCheck->num_rows > 0) {
            dbExecute("UPDATE teacher_files SET status = ?, admin_notes = ? WHERE id = ?", [$status, $adminNotes, $id], 'ssi');
            addActivityLog('Teacher File Status Updated', "File #$id status updated to $status");
            respondSuccess([], 'File status updated successfully');
        } else {
            respondError('Status column not found in teacher_files table');
        }
    }
    
    respondError('Unknown teacher files action: ' . $teacherFilesAction);
}

// Collections that are single-row (settings, site_content needs special handling)
$isSingleRow = ['settings'];

// Handle file uploads (gallery images, etc.)
if ($collection === 'upload') {
    if ($method !== 'POST') respondError('Method not allowed', 405);
    if (empty($_FILES['file'])) respondError('No file uploaded');

    $file = $_FILES['file'];
    $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    $maxSize = 5 * 1024 * 1024; // 5MB

    if (!in_array($file['type'], $allowedTypes)) {
        respondError('Invalid file type. Only JPG, PNG, GIF, and WebP are allowed.');
    }
    if ($file['size'] > $maxSize) {
        respondError('File too large. Maximum size is 5MB.');
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        respondError('Upload error: ' . $file['error']);
    }

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $safeExts = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    if (!in_array($ext, $safeExts)) $ext = 'jpg';

    $newName = uniqid('gallery_', true) . '.' . $ext;
    $uploadDir = __DIR__ . '/../uploads/';
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

    $dest = $uploadDir . $newName;
    if (!move_uploaded_file($file['tmp_name'], $dest)) {
        respondError('Failed to save uploaded file.');
    }

    $url = '../uploads/' . $newName;
    respondSuccess(['url' => $url, 'filename' => $newName], 'File uploaded successfully');
}

// Special parent management actions
$parentAction = $_REQUEST['parent_action'] ?? '';
if ($parentAction && $method === 'POST') {
    $body = getJsonBody();
    if ($parentAction === 'reset_password') {
        $parentId = (int)($_REQUEST['id'] ?? $body['id'] ?? 0);
        $newPassword = $body['password'] ?? 'parent123';
        if (!$parentId) respondError('Parent ID required');
        $hashed = password_hash($newPassword, PASSWORD_DEFAULT);
        dbExecute("UPDATE parents SET password = ? WHERE id = ?", [$hashed, $parentId], 'si');
        addActivityLog('Parent Password Reset', "Password reset for parent #$parentId");
        respondSuccess([], 'Password reset successfully');
    }
    if ($parentAction === 'toggle_active') {
        $parentId = (int)($_REQUEST['id'] ?? $body['id'] ?? 0);
        $isActive = (int)($body['isActive'] ?? 1);
        if (!$parentId) respondError('Parent ID required');
        dbExecute("UPDATE parents SET is_active = ? WHERE id = ?", [$isActive, $parentId], 'ii');
        $label = $isActive ? 'activated' : 'deactivated';
        addActivityLog('Parent ' . ucfirst($label), "Parent #$parentId $label");
        respondSuccess([], "Parent $label successfully");
    }
    if ($parentAction === 'login_history') {
        $parentId = (int)($_REQUEST['id'] ?? $body['id'] ?? 0);
        if (!$parentId) respondError('Parent ID required');
        $logs = dbFetchAll(
            "SELECT * FROM parent_login_logs WHERE parent_id = ? ORDER BY created_at DESC LIMIT 50",
            [$parentId], 'i'
        );
        $mapped = array_map(function($r) {
            return [
                'id' => $r['id'],
                'ipAddress' => $r['ip_address'],
                'location' => $r['location'],
                'browser' => $r['browser'],
                'os' => $r['os'],
                'device' => $r['device'],
                'userAgent' => $r['user_agent'],
                'loginStatus' => $r['login_status'],
                'createdAt' => $r['created_at']
            ];
        }, $logs);
        respondSuccess(['items' => $mapped, 'total' => count($mapped)]);
    }
    if ($parentAction === 'delete') {
        $parentId = (int)($_REQUEST['id'] ?? $body['id'] ?? 0);
        if (!$parentId) respondError('Parent ID required');
        
        // Get parent info for logging
        $parent = dbFetchOne("SELECT first_name, last_name FROM parents WHERE id = ?", [$parentId], 'i');
        if (!$parent) respondError('Parent not found');
        
        // Delete parent
        dbExecute("DELETE FROM parents WHERE id = ?", [$parentId], 'i');
        $parentName = trim(($parent['first_name'] ?? '') . ' ' . ($parent['last_name'] ?? ''));
        if (empty($parentName)) {
            $parentName = 'Parent ID ' . $parentId;
        }
        addActivityLog('Parent Deleted', "Parent '$parentName' deleted");
        respondSuccess([], 'Parent deleted successfully');
    }
    respondError('Unknown parent action: ' . $parentAction);
}

// Special teacher management actions
$teacherAction = $_REQUEST['teacher_action'] ?? '';
if ($teacherAction && $method === 'POST') {
    $body = getJsonBody();
    if ($teacherAction === 'reset_password') {
        $teacherId = (int)($_REQUEST['id'] ?? $body['id'] ?? 0);
        $newPassword = $body['password'] ?? 'teacher123';
        if (!$teacherId) respondError('Teacher ID required');
        $hashed = password_hash($newPassword, PASSWORD_DEFAULT);
        dbExecute("UPDATE teachers SET password = ? WHERE id = ?", [$hashed, $teacherId], 'si');
        addActivityLog('Teacher Password Reset', "Password reset for teacher #$teacherId");
        respondSuccess([], 'Password reset successfully');
    }
    if ($teacherAction === 'toggle_active') {
        $teacherId = (int)($_REQUEST['id'] ?? $body['id'] ?? 0);
        $isActive = (int)($body['isActive'] ?? 1);
        if (!$teacherId) respondError('Teacher ID required');
        
        // Check if is_active column exists, add if not
        $conn = getDB();
        $colCheck = $conn->query("SHOW COLUMNS FROM teachers LIKE 'is_active'");
        if ($colCheck && $colCheck->num_rows === 0) {
            $conn->query("ALTER TABLE teachers ADD COLUMN is_active TINYINT(1) DEFAULT 1 AFTER approved");
        }
        
        dbExecute("UPDATE teachers SET is_active = ? WHERE id = ?", [$isActive, $teacherId], 'ii');
        $label = $isActive ? 'activated' : 'deactivated';
        addActivityLog('Teacher ' . ucfirst($label), "Teacher #$teacherId $label");
        respondSuccess([], "Teacher $label successfully");
    }
    if ($teacherAction === 'delete') {
        $teacherId = (int)($_REQUEST['id'] ?? $body['id'] ?? 0);
        if (!$teacherId) respondError('Teacher ID required');
        
        // Get teacher info for logging
        $teacher = dbFetchOne("SELECT first_name, last_name FROM teachers WHERE id = ?", [$teacherId], 'i');
        if (!$teacher) respondError('Teacher not found');
        
        // Delete teacher
        dbExecute("DELETE FROM teachers WHERE id = ?", [$teacherId], 'i');
        addActivityLog('Teacher Deleted', "Teacher '{$teacher['first_name']} {$teacher['last_name']}' deleted");
        respondSuccess([], 'Teacher deleted successfully');
    }
    respondError('Unknown teacher action: ' . $teacherAction);
}

// Special timetable actions
$timetableAction = $_REQUEST['timetable_action'] ?? '';
if ($timetableAction && $method === 'POST') {
    if ($timetableAction === 'send_to_teachers') {
        $entries = dbFetchAll("SELECT * FROM timetable ORDER BY day, time");
        if (empty($entries)) respondError('No timetable entries');
        addActivityLog('Timetable Sent', 'Timetable sent to all teachers');
        respondSuccess(['count' => count($entries)], 'Timetable sent to teachers');
    }
}

// Special timetable document actions
$action = $_REQUEST['action'] ?? '';
if ($action === 'upload_timetable_document' && $method === 'POST') {
    if (empty($_FILES['file'])) respondError('No file uploaded');

    $file = $_FILES['file'];
    $title = trim($_POST['title'] ?? '');
    $class = trim($_POST['class'] ?? '');
    $term = trim($_POST['term'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $target = trim($_POST['target'] ?? 'teachers'); // Default to teachers

    if (empty($title) || empty($term)) respondError('Title and Term are required');

    // Validate file type
    $allowedTypes = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'];
    if (!in_array($file['type'], $allowedTypes)) {
        respondError('Invalid file type. Allowed: PDF, DOC, DOCX, XLS, XLSX');
    }

    // Validate file size (10MB max)
    if ($file['size'] > 10 * 1024 * 1024) {
        respondError('File too large. Maximum size is 10MB');
    }

    // Upload file
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $newName = 'timetable_' . uniqid() . '.' . $ext;
    $uploadDir = __DIR__ . '/../uploads/timetable/';
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

    $dest = $uploadDir . $newName;
    if (!move_uploaded_file($file['tmp_name'], $dest)) {
        respondError('Failed to save uploaded file');
    }

    $fileUrl = '../uploads/timetable/' . $newName;

    // Save to database
    $id = dbInsert(
        "INSERT INTO timetable_documents (title, class, term, description, file_url, file_name, file_size, file_type, target)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
        [$title, $class, $term, $description, $fileUrl, $file['name'], $file['size'], $file['type'], $target],
        'sssssssss'
    );

    if ($id) {
        addActivityLog('Timetable Document Uploaded', "Timetable document '$title' uploaded for $term");

        // Send notification based on target audience
        $recipients = [];
        if ($target === 'teachers' || $target === 'all') {
            $teachers = dbFetchAll("SELECT id, first_name, last_name FROM teachers WHERE approved = 1");
            $recipients = array_merge($recipients, $teachers);
        }
        if ($target === 'admins' || $target === 'all') {
            $admins = dbFetchAll("SELECT id, first_name, last_name FROM admins");
            $recipients = array_merge($recipients, $admins);
        }

        respondSuccess(['id' => $id, 'fileUrl' => $fileUrl, 'recipientsNotified' => count($recipients), 'target' => $target], 'Timetable document uploaded successfully');
    }
    respondError('Failed to save timetable document');
}

// Special teacher files actions
$teacherFileAction = $_REQUEST['teacher_file_action'] ?? '';
if ($teacherFileAction && $method === 'POST') {
    if ($teacherFileAction === 'upload') {
        if (empty($_FILES['teacherFile'])) respondError('No file uploaded');
        
        $file = $_FILES['teacherFile'];
        $title = trim($_POST['title'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $targetType = $_POST['targetType'] ?? 'all';
        $targetTeachers = $_POST['targetTeachers'] ?? '';
        $priority = $_POST['priority'] ?? 'normal';
        $uploadedBy = $_POST['uploadedBy'] ?? 'admin';
        
        if (empty($title)) respondError('File title is required');
        
        // Validate file type
        $allowedTypes = [
            'application/pdf',
            'application/vnd.ms-excel',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'application/msword',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'application/vnd.ms-powerpoint',
            'application/vnd.openxmlformats-officedocument.presentationml.presentation'
        ];
        $allowedExtensions = ['pdf', 'xlsx', 'xls', 'doc', 'docx', 'ppt', 'pptx'];
        $maxSize = 10 * 1024 * 1024; // 10MB
        
        if (!in_array($file['type'], $allowedTypes)) {
            respondError('Invalid file type. Only PDF, Excel, Word, and PowerPoint files are allowed.');
        }
        if ($file['size'] > $maxSize) {
            respondError('File too large. Maximum size is 10MB.');
        }
        if ($file['error'] !== UPLOAD_ERR_OK) {
            respondError('Upload error: ' . $file['error']);
        }
        
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, $allowedExtensions)) {
            respondError('Invalid file extension.');
        }
        
        // Create upload directory if it doesn't exist
        $uploadDir = __DIR__ . '/../uploads/teacher_files/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        
        // Generate unique filename
        $newName = 'teacher_file_' . uniqid() . '_' . time() . '.' . $ext;
        $dest = $uploadDir . $newName;
        
        if (!move_uploaded_file($file['tmp_name'], $dest)) {
            respondError('Failed to save uploaded file.');
        }
        
        // Determine file type category
        $fileTypeCategory = 'other';
        if ($ext === 'pdf') $fileTypeCategory = 'pdf';
        elseif (in_array($ext, ['xlsx', 'xls'])) $fileTypeCategory = 'excel';
        elseif (in_array($ext, ['doc', 'docx'])) $fileTypeCategory = 'word';
        elseif (in_array($ext, ['ppt', 'pptx'])) $fileTypeCategory = 'powerpoint';
        
        // Insert into database
        $conn = getDB();
        $stmt = $conn->prepare("INSERT INTO teacher_files (title, description, file_name, file_path, file_type, file_size, uploaded_by, target_type, target_teachers, priority, sent_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
        $stmt->bind_param('sssssissss', $title, $description, $file['name'], '../uploads/teacher_files/' . $newName, $fileTypeCategory, $file['size'], $uploadedBy, $targetType, $targetTeachers, $priority);
        
        if ($stmt->execute()) {
            $fileId = $conn->insert_id;
            addActivityLog('Teacher File Uploaded', "File '$title' uploaded for teachers");
            respondSuccess(['id' => $fileId, 'filePath' => '../uploads/teacher_files/' . $newName], 'File uploaded successfully');
        } else {
            respondError('Failed to save file record: ' . $conn->error);
        }
    }
    
    if ($teacherFileAction === 'delete') {
        $fileId = (int)($_REQUEST['id'] ?? 0);
        if (!$fileId) respondError('File ID required');
        
        // Get file info
        $file = dbFetchOne("SELECT * FROM teacher_files WHERE id = ?", [$fileId], 'i');
        if (!$file) respondError('File not found');
        
        // Delete physical file
        $filePath = __DIR__ . '/../uploads/teacher_files/' . basename($file['file_path']);
        if (file_exists($filePath)) {
            unlink($filePath);
        }
        
        // Delete from database
        dbExecute("DELETE FROM teacher_files WHERE id = ?", [$fileId], 'i');
        addActivityLog('Teacher File Deleted', "File '{$file['title']}' deleted");
        respondSuccess([], 'File deleted successfully');
    }
    
    respondError('Unknown teacher file action: ' . $teacherFileAction);
}

// Special account deletion actions
$deletionAction = $_REQUEST['deletion_action'] ?? '';
if ($deletionAction && $method === 'POST') {
    $body = getJsonBody();
    
    if ($deletionAction === 'approve') {
        $requestId = (int)($_REQUEST['id'] ?? $body['id'] ?? 0);
        if (!$requestId) respondError('Request ID required');
        
        $request = dbFetchOne("SELECT * FROM account_deletion_requests WHERE id = ?", [$requestId], 'i');
        if (!$request) respondError('Deletion request not found');
        if ($request['status'] !== 'pending') respondError('Request is not pending');
        
        // Update request status
        dbExecute(
            "UPDATE account_deletion_requests SET status = 'completed', processed_at = NOW(), processed_by = 1 WHERE id = ?",
            [$requestId], 'i'
        );
        
        // Delete the user account
        $table = $request['user_type'] === 'teacher' ? 'teachers' : 'parents';
        dbExecute("DELETE FROM $table WHERE id = ?", [$request['user_id']], 'i');
        
        // Mark notification as read
        dbExecute("UPDATE admin_notifications SET is_read = 1, read_at = NOW() WHERE related_id = ?", [$requestId], 'i');
        
        addActivityLog('Account Deletion Approved', "Deleted {$request['user_type']} account: {$request['user_name']} (ID: {$request['user_id']})");
        respondSuccess([], 'Account deleted successfully');
    }
    
    if ($deletionAction === 'reject') {
        $requestId = (int)($_REQUEST['id'] ?? $body['id'] ?? 0);
        $adminNotes = trim($body['adminNotes'] ?? '');
        if (!$requestId) respondError('Request ID required');
        
        $request = dbFetchOne("SELECT * FROM account_deletion_requests WHERE id = ?", [$requestId], 'i');
        if (!$request) respondError('Deletion request not found');
        if ($request['status'] !== 'pending') respondError('Request is not pending');
        
        // Update request status
        dbExecute(
            "UPDATE account_deletion_requests SET status = 'rejected', admin_notes = ?, processed_at = NOW(), processed_by = 1 WHERE id = ?",
            [$adminNotes, $requestId], 'si'
        );
        
        // Mark notification as read
        dbExecute("UPDATE admin_notifications SET is_read = 1, read_at = NOW() WHERE related_id = ?", [$requestId], 'i');
        
        addActivityLog('Account Deletion Rejected', "Rejected deletion request for {$request['user_type']}: {$request['user_name']}");
        respondSuccess([], 'Deletion request rejected');
    }
    
    if ($deletionAction === 'cancel') {
        $requestId = (int)($_REQUEST['id'] ?? $body['id'] ?? 0);
        if (!$requestId) respondError('Request ID required');
        
        $request = dbFetchOne("SELECT * FROM account_deletion_requests WHERE id = ?", [$requestId], 'i');
        if (!$request) respondError('Deletion request not found');
        if ($request['status'] !== 'pending') respondError('Request is not pending');
        
        // Update request status
        dbExecute(
            "UPDATE account_deletion_requests SET status = 'cancelled', processed_at = NOW() WHERE id = ?",
            [$requestId], 'i'
        );
        
        // Mark notification as read
        dbExecute("UPDATE admin_notifications SET is_read = 1, read_at = NOW() WHERE related_id = ?", [$requestId], 'i');
        
        addActivityLog('Account Deletion Cancelled', "Cancelled deletion request for {$request['user_type']}: {$request['user_name']}");
        respondSuccess([], 'Deletion request cancelled');
    }
    
    respondError('Unknown deletion action: ' . $deletionAction);
}

// Special API management actions
$apiAction = $_REQUEST['api_action'] ?? '';
if ($apiAction && $method === 'POST') {
    $body = getJsonBody();
    if ($apiAction === 'test') {
        $apiId = (int)($_REQUEST['id'] ?? $body['id'] ?? 0);
        if (!$apiId) respondError('API ID required');
        
        $api = dbFetchOne("SELECT * FROM apis WHERE id = ?", [$apiId], 'i');
        if (!$api) respondError('API not found');
        
        // Test the API connection (basic validation)
        $testResult = [
            'valid' => true,
            'message' => 'API configuration is valid',
            'endpoint' => $api['endpoint'],
            'provider' => $api['provider']
        ];
        
        // Update last_used timestamp
        dbExecute("UPDATE apis SET last_used = NOW() WHERE id = ?", [$apiId], 'i');
        
        addActivityLog('API Test', "Tested API: {$api['name']} ({$api['provider']})");
        respondSuccess($testResult, 'API test completed successfully');
    }
    
    if ($apiAction === 'send_sms') {
        $apiId = (int)($body['apiId'] ?? 0);
        $phoneNumbers = $body['phoneNumbers'] ?? [];
        $message = trim($body['message'] ?? '');
        
        if (!$apiId) respondError('API ID required');
        if (empty($phoneNumbers)) respondError('Phone numbers required');
        if (empty($message)) respondError('Message required');
        
        // Get the SMS API configuration
        $api = dbFetchOne("SELECT * FROM apis WHERE id = ? AND type = 'sms' AND status = 'active'", [$apiId], 'i');
        if (!$api) respondError('Active SMS API not found');
        
        // Send SMS to each phone number
        $results = [];
        $successCount = 0;
        $failureCount = 0;
        
        foreach ($phoneNumbers as $phone) {
            $phone = trim($phone);
            if (empty($phone)) continue;
            
            // Prepare the API request
            $endpoint = $api['endpoint'];
            $apiKey = $api['api_key'];
            $apiSecret = $api['api_secret'] ?? '';
            $headers = !empty($api['headers']) ? json_decode($api['headers'], true) : [];
            
            // Build request data based on provider
            $postData = [];
            switch (strtolower($api['provider'])) {
                case 'twilio':
                    $postData = [
                        'To' => $phone,
                        'From' => $apiKey,
                        'Body' => $message
                    ];
                    $endpoint .= '/Messages.json';
                    $authHeader = 'Basic ' . base64_encode($apiKey . ':' . $apiSecret);
                    $headers['Authorization'] = $authHeader;
                    break;
                case 'bulkSMS':
                case 'africastalking':
                default:
                    // Generic SMS API format
                    $postData = [
                        'api_key' => $apiKey,
                        'phone' => $phone,
                        'message' => $message
                    ];
                    if (!empty($apiSecret)) {
                        $postData['api_secret'] = $apiSecret;
                    }
                    break;
            }
            
            // Send the SMS via HTTP request
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $endpoint);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            
            // Set headers
            $headerArray = [];
            foreach ($headers as $key => $value) {
                $headerArray[] = "$key: $value";
            }
            if (!empty($headerArray)) {
                curl_setopt($ch, CURLOPT_HTTPHEADER, $headerArray);
            }
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $error = curl_error($ch);
            curl_close($ch);
            
            $result = [
                'phone' => $phone,
                'success' => ($httpCode >= 200 && $httpCode < 300),
                'httpCode' => $httpCode,
                'response' => $response,
                'error' => $error
            ];
            
            if ($result['success']) {
                $successCount++;
            } else {
                $failureCount++;
            }
            
            $results[] = $result;
        }
        
        // Update last_used timestamp
        dbExecute("UPDATE apis SET last_used = NOW() WHERE id = ?", [$apiId], 'i');
        
        addActivityLog('SMS Sent', "Sent SMS to $successCount recipients ($failureCount failed)");
        
        respondSuccess([
            'total' => count($results),
            'success' => $successCount,
            'failed' => $failureCount,
            'results' => $results
        ], "SMS sent to $successCount recipients");
    }
}

if (!isset($collectionMap[$collection])) {
    respondError('Invalid collection: ' . $collection, 404);
}

$table = $collectionMap[$collection];

switch ($method) {
    case 'GET':
        handleGet($collection, $table, $id);
        break;
    case 'POST':
        handlePost($collection, $table, $id);
        break;
    case 'PUT':
        handlePut($collection, $table, $id);
        break;
    case 'DELETE':
        handleDelete($collection, $table, $id);
        break;
    default:
        respondError('Method not allowed', 405);
}

// ============================================================
// GET
// ============================================================
function handleGet($collection, $table, $id) {
    if ($collection === 'settings') {
        $rows = dbFetchAll("SELECT setting_key, setting_value FROM settings");
        $data = [];
        foreach ($rows as $row) {
            $data[$row['setting_key']] = $row['setting_value'];
        }
        respondSuccess($data);
    }

    if ($collection === 'content') {
        $rows = dbFetchAll("SELECT page_name, content_key, content_value FROM site_content ORDER BY page_name, content_key");
        $data = [];
        foreach ($rows as $row) {
            $page = $row['page_name'];
            if (!isset($data[$page])) $data[$page] = [];
            $data[$page][$row['content_key']] = $row['content_value'];
        }
        respondSuccess($data);
    }

    if ($collection === 'activity') {
        $rows = dbFetchAll("SELECT * FROM activity_log ORDER BY created_at DESC LIMIT 100");
        respondSuccess(['items' => $rows, 'total' => count($rows)]);
    }

    if ($collection === 'visitors') {
        $rows = dbFetchAll("SELECT * FROM visitor_logs ORDER BY created_at DESC LIMIT 200");
        respondSuccess(['items' => $rows, 'total' => count($rows)]);
    }

    if ($collection === 'vacancies') {
        $rows = dbFetchAll("SELECT * FROM vacancies ORDER BY created_at DESC");
        $mapped = array_map(function($r) {
            return [
                'id' => $r['id'],
                'title' => $r['title'],
                'description' => $r['description'],
                'requirements' => $r['requirements'],
                'grade' => $r['grade'],
                'responsibilities' => $r['responsibilities'],
                'duties' => $r['duties'],
                'contact_email' => $r['contact_email'],
                'location' => $r['location'],
                'position_type' => $r['position_type'],
                'salary_range' => $r['salary_range'],
                'application_deadline' => $r['application_deadline'],
                'status' => $r['status'],
                'created_at' => $r['created_at'],
                'updated_at' => $r['updated_at']
            ];
        }, $rows);
        respondSuccess(['items' => $mapped, 'total' => count($mapped)]);
    }

    if ($collection === 'testimonials') {
        $action = $_REQUEST['action'] ?? '';
        
        if ($action === 'approve') {
            if (!$id) respondError('ID is required');
            $updated = dbExecute("UPDATE testimonials SET status = 'approved', approved_at = NOW() WHERE id = ?", [$id], 'i');
            if ($updated) {
                addActivityLog('Testimonial Approved', "Testimonial #$id approved");
                respondSuccess([], 'Testimonial approved successfully');
            } else {
                respondError('Failed to approve testimonial');
            }
        } elseif ($action === 'reject') {
            if (!$id) respondError('ID is required');
            $body = getJsonBody();
            $reason = $body['reason'] ?? 'No reason provided';
            $updated = dbExecute("UPDATE testimonials SET status = 'rejected', rejection_reason = ?, rejected_at = NOW() WHERE id = ?", [$reason, $id], 'si');
            if ($updated) {
                addActivityLog('Testimonial Rejected', "Testimonial #$id rejected: $reason");
                respondSuccess([], 'Testimonial rejected successfully');
            } else {
                respondError('Failed to reject testimonial');
            }
        } else {
            $status = $_REQUEST['status'] ?? '';
            $sql = "SELECT id, parent_name, student_name, grade, years_enrolled, testimonial, rating, anonymous, status, rejection_reason, created_at FROM testimonials";
            if (!empty($status)) {
                $sql .= " WHERE status = ?";
                $rows = dbFetchAll($sql, [$status], 's');
            } else {
                $sql .= " ORDER BY created_at DESC";
                $rows = dbFetchAll($sql);
            }
            respondSuccess($rows);
        }
    }

    if ($collection === 'users') {
        if ($id) {
            $row = dbFetchOne("SELECT * FROM users WHERE id = ?", [$id], 'i');
            if (!$row) respondError('User not found', 404);
            respondSuccess([
                'id' => $row['id'],
                'first_name' => $row['first_name'],
                'last_name' => $row['last_name'],
                'name' => $row['first_name'] . ' ' . $row['last_name'],
                'email' => $row['email'],
                'role' => $row['role'],
                'phone' => $row['phone'],
                'status' => $row['status'],
                'notes' => $row['notes'],
                'last_login' => $row['last_login'],
                'created_at' => $row['created_at']
            ]);
        }
        
        $action = $_REQUEST['action'] ?? '';
        
        if ($action === 'reset_password') {
            $newPassword = $_POST['password'] ?? '';
            if (empty($newPassword)) respondError('Password is required');
            
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
            $updated = dbExecute("UPDATE users SET password = ? WHERE id = ?", [$hashedPassword, $id], 'si');
            
            if ($updated) {
                respondSuccess(['message' => 'Password reset successfully']);
            } else {
                respondError('Failed to reset password');
            }
        }
        
        $rows = dbFetchAll("SELECT id, first_name, last_name, email, role, phone, status, notes, last_login, created_at FROM users ORDER BY created_at DESC");
        $mapped = array_map(function($r) {
            return [
                'id' => $r['id'],
                'first_name' => $r['first_name'],
                'last_name' => $r['last_name'],
                'name' => $r['first_name'] . ' ' . $r['last_name'],
                'email' => $r['email'],
                'role' => $r['role'],
                'phone' => $r['phone'],
                'status' => $r['status'],
                'notes' => $r['notes'],
                'last_login' => $r['last_login'],
                'created_at' => $r['created_at']
            ];
        }, $rows);
        respondSuccess(['items' => $mapped, 'total' => count($mapped)]);
    }

    if ($collection === 'announcements') {
        if ($id) {
            $row = dbFetchOne("SELECT * FROM announcements WHERE id = ?", [$id], 'i');
            if (!$row) respondError('Announcement not found', 404);
            respondSuccess([
                'id' => $row['id'],
                'title' => $row['title'],
                'content' => $row['content'],
                'priority' => $row['priority'],
                'targetAudience' => $row['target_audience'],
                'status' => $row['status'],
                'createdBy' => $row['created_by'],
                'pinned' => (bool)$row['pinned'],
                'createdAt' => $row['created_at']
            ]);
        }
        $rows = dbFetchAll("SELECT * FROM announcements ORDER BY pinned DESC, created_at DESC");
        $mapped = array_map(function($r) {
            return [
                'id' => $r['id'],
                'title' => $r['title'],
                'content' => $r['content'],
                'priority' => $r['priority'],
                'targetAudience' => $r['target_audience'],
                'status' => $r['status'],
                'createdBy' => $r['created_by'],
                'pinned' => (bool)$r['pinned'],
                'createdAt' => $r['created_at']
            ];
        }, $rows);
        respondSuccess(['items' => $mapped, 'total' => count($mapped)]);
    }

    if ($collection === 'notifications') {
        try {
            if ($id) {
                $row = dbFetchOne("SELECT * FROM notifications WHERE id = ?", [$id], 'i');
                if (!$row) respondError('Notification not found', 404);
                respondSuccess([
                    'id' => $row['id'],
                    'type' => $row['type'],
                    'title' => $row['title'],
                    'message' => $row['message'],
                    'icon' => $row['icon'],
                    'iconBg' => $row['icon_bg'],
                    'link' => $row['link'],
                    'linkLabel' => $row['link_label'],
                    'isRead' => (bool)$row['is_read'],
                    'priority' => $row['priority'],
                    'sourceType' => $row['source_type'],
                    'sourceId' => $row['source_id'],
                    'createdAt' => $row['created_at']
                ]);
            }
            $rows = dbFetchAll("SELECT * FROM notifications ORDER BY is_read ASC, created_at DESC");
            $mapped = array_map(function($r) {
                return [
                    'id' => $r['id'],
                    'type' => $r['type'],
                    'title' => $r['title'],
                    'message' => $r['message'],
                    'icon' => $r['icon'],
                    'iconBg' => $r['icon_bg'],
                    'link' => $r['link'],
                    'linkLabel' => $r['link_label'],
                    'isRead' => (bool)$r['is_read'],
                    'priority' => $r['priority'],
                    'sourceType' => $r['source_type'],
                    'sourceId' => $r['source_id'],
                    'createdAt' => $r['created_at']
                ];
            }, $rows);
            respondSuccess(['items' => $mapped, 'total' => count($mapped)]);
        } catch (Exception $e) {
            respondSuccess(['items' => [], 'total' => 0]);
        }
    }

    if ($collection === 'jobapplications') {
        try {
            if ($id) {
                $row = dbFetchOne("SELECT * FROM job_applications WHERE id = ?", [$id], 'i');
                if (!$row) respondError('Job application not found', 404);
                respondSuccess($row);
            }
            $rows = dbFetchAll("SELECT *, created_at AS applied_at FROM job_applications ORDER BY created_at DESC");
            respondSuccess(['items' => $rows, 'total' => count($rows)]);
        } catch (Exception $e) {
            respondSuccess(['items' => [], 'total' => 0]);
        }
    }

    if ($collection === 'account_deletion_requests') {
        try {
            if ($id) {
                $row = dbFetchOne("SELECT * FROM account_deletion_requests WHERE id = ?", [$id], 'i');
                if (!$row) respondError('Deletion request not found', 404);
                respondSuccess($row);
            }
            $rows = dbFetchAll("SELECT * FROM account_deletion_requests ORDER BY requested_at DESC");
            $mapped = array_map(function($r) {
                return [
                    'id' => $r['id'],
                    'user_type' => $r['user_type'],
                    'user_id' => $r['user_id'],
                    'user_name' => $r['user_name'],
                    'email' => $r['email'],
                    'requested_at' => $r['requested_at'],
                    'scheduled_deletion_at' => $r['scheduled_deletion_at'],
                    'status' => $r['status'],
                    'admin_notes' => $r['admin_notes'],
                    'processed_at' => $r['processed_at'],
                    'processed_by' => $r['processed_by']
                ];
            }, $rows);
            respondSuccess(['items' => $mapped, 'total' => count($mapped)]);
        } catch (Exception $e) {
            respondSuccess(['items' => [], 'total' => 0]);
        }
    }

    if ($collection === 'registrations') {
        try {
            if ($id) {
                $row = dbFetchOne("SELECT * FROM registrations WHERE id = ?", [$id], 'i');
                if (!$row) respondError('Registration not found', 404);
                respondSuccess($row);
            }
            $rows = dbFetchAll("SELECT * FROM registrations ORDER BY created_at DESC");
            $mapped = array_map(function($r) {
                return [
                    'id' => $r['id'],
                    'studentName' => $r['student_name'],
                    'grade' => $r['grade'],
                    'parentName' => $r['parent_name'],
                    'phone' => $r['phone'],
                    'email' => $r['email'],
                    'address' => $r['address'],
                    'dob' => $r['dob'],
                    'notes' => $r['notes'],
                    'status' => $r['status'] ?? 'Pending',
                    'createdAt' => $r['created_at']
                ];
            }, $rows);
            respondSuccess(['items' => $mapped, 'total' => count($mapped)]);
        } catch (Exception $e) {
            respondSuccess(['items' => [], 'total' => 0]);
        }
    }

    // Fetch single item or all items
    if ($id) {
        $row = dbFetchOne("SELECT * FROM $table WHERE id = ?", [$id], 'i');
        if (!$row) respondError('Item not found', 404);
        $rows = [$row];
    } else {
        $rows = dbFetchAll("SELECT * FROM $table ORDER BY id DESC");
    }

    // Map columns to match frontend expectations

    
    // Transform for frontend compatibility
    if ($collection === 'students') {
        $rows = array_map(function($r) {
            return [
                'id' => $r['id'],
                'firstName' => $r['first_name'],
                'lastName' => $r['last_name'],
                'gender' => $r['gender'],
                'grade' => $r['grade'],
                'dob' => $r['dob'],
                'parent' => $r['parent_name'],
                'phone' => $r['phone'],
                'address' => $r['address'],
                'emergencyContact' => $r['emergency_contact'],
                'emergencyPhone' => $r['emergency_phone'],
                'medicalInfo' => $r['medical_info'],
                'enrollmentDate' => $r['enrollment_date'],
                'status' => $r['status'],
                'feesStatus' => $r['fees_status'] ?? 'Pending',
                'createdAt' => $r['created_at']
            ];
        }, $rows);
    } elseif ($collection === 'teachers') {
        $rows = array_map(function($r) {
            return [
                'id' => $r['id'],
                'firstName' => $r['first_name'],
                'lastName' => $r['last_name'],
                'username' => $r['username'],
                'email' => $r['email'],
                'phone' => $r['phone'],
                'subject' => $r['subject'],
                'qualification' => $r['qualification'],
                'classAssigned' => $r['class_assigned'],
                'approved' => (bool)$r['approved'],
                'emailVerified' => isset($r['email_verified']) ? (bool)$r['email_verified'] : true,
                'isActive' => isset($r['is_active']) ? (bool)$r['is_active'] : true,
                'password' => $r['password'],
                'registrationCode' => $r['registration_code'],
                'codeExpiresAt' => $r['code_expires_at'],
                'createdIp' => $r['created_ip'] ?? 'N/A',
                'createdDevice' => $r['created_device'] ?? 'N/A',
                'createdAt' => $r['created_at'],
                'updatedAt' => $r['updated_at'],
                'dateOfEmployment' => $r['date_of_employment'] ?? '',
                'nationalId' => $r['national_id'] ?? '',
                'residentialAddress' => $r['residential_address'] ?? '',
                'nextOfKin' => $r['next_of_kin'] ?? '',
                'nextOfKinRelationship' => $r['next_of_kin_relationship'] ?? '',
                'nextOfKinPhone' => $r['next_of_kin_phone'] ?? ''
            ];
        }, $rows);
    } elseif ($collection === 'parents') {
        $rows = array_map(function($r) {
            return [
                'id' => $r['id'],
                'firstName' => $r['first_name'],
                'lastName' => $r['last_name'],
                'username' => $r['username'],
                'email' => $r['email'],
                'phone' => $r['phone'],
                'approved' => (bool)$r['approved'],
                'emailVerified' => isset($r['email_verified']) ? (bool)$r['email_verified'] : true,
                'isActive' => isset($r['is_active']) ? (bool)$r['is_active'] : true,
                'registrationCode' => $r['registration_code'] ?? '',
                'studentIds' => $r['student_ids'] ?? '',
                'createdAt' => $r['created_at']
            ];
        }, $rows);
    } elseif ($collection === 'events') {
        $rows = array_map(function($r) {
            return [
                'id' => $r['id'],
                'title' => $r['title'],
                'date' => $r['date'],
                'time' => $r['time'],
                'location' => $r['location'],
                'description' => $r['description'],
                'imageUrl' => $r['image_url'] ?? '',
                'videoUrl' => $r['video_url'] ?? '',
                'link' => $r['link'] ?? '',
                'status' => $r['status'],
                'createdAt' => $r['created_at']
            ];
        }, $rows);

    } elseif ($collection === 'gallery') {
        $rows = array_map(function($r) {
            return [
                'id' => $r['id'],
                'imageUrl' => $r['image_url'],
                'videoUrl' => $r['video_url'] ?? '',
                'mediaType' => $r['media_type'] ?? 'image',
                'title' => $r['title'],
                'category' => $r['category'],
                'description' => $r['description'],
                'createdAt' => $r['created_at']
            ];
        }, $rows);
    } elseif ($collection === 'blog') {
        $rows = array_map(function($r) {
            return [
                'id' => $r['id'],
                'title' => $r['title'],
                'author' => $r['author'],
                'category' => $r['category'],
                'content' => $r['content'],
                'image' => $r['image'],
                'status' => $r['status'],
                'createdAt' => $r['created_at']
            ];
        }, $rows);
    } elseif ($collection === 'services') {
        $rows = array_map(function($r) {
            return [
                'id' => $r['id'],
                'title' => $r['title'],
                'description' => $r['description'],
                'icon' => $r['icon'],
                'createdAt' => $r['created_at']
            ];
        }, $rows);
    } elseif ($collection === 'messages') {
        $rows = array_map(function($r) {
            return [
                'id' => $r['id'],
                'name' => $r['name'],
                'email' => $r['email'],
                'subject' => $r['subject'],
                'message' => $r['message'],
                'read' => (bool)$r['is_read'],
                'createdAt' => $r['created_at']
            ];
        }, $rows);
    } elseif ($collection === 'payments') {
        // Look up the contact email on the linked registration so the receipt
        // dialog can prefill the recipient address.
        $registrationEmails = [];
        foreach (dbFetchAll("SELECT id, email FROM registrations WHERE email IS NOT NULL AND email <> ''") as $regRow) {
            $registrationEmails[(int)$regRow['id']] = $regRow['email'];
        }

        $rows = array_map(function($r) use ($registrationEmails) {
            $registrationId = isset($r['registration_id']) && $r['registration_id'] !== null
                ? (int)$r['registration_id']
                : null;
            return [
                'id' => $r['id'],
                'payerName' => $r['payer_name'],
                'studentName' => $r['student_name'],
                'amount' => $r['amount'],
                'paymentType' => $r['payment_type'],
                'phone' => $r['phone'],
                'paymentMethod' => $r['payment_method'],
                'notes' => $r['notes'],
                'status' => $r['status'],
                'createdAt' => $r['created_at'],
                'registrationId' => $registrationId,
                'contactEmail' => $registrationId !== null && isset($registrationEmails[$registrationId])
                    ? $registrationEmails[$registrationId]
                    : ''
            ];
        }, $rows);
    } elseif ($collection === 'attendance') {
        $rows = array_map(function($r) {
            return [
                'id' => $r['id'],
                'registrationId' => $r['registration_id'],
                'studentName' => $r['student_name'],
                'studentClass' => $r['class_name'],
                'date' => $r['date'],
                'status' => $r['status'],
            ];
        }, $rows);
    } elseif ($collection === 'birthdays') {
        $rows = array_map(function($r) {
            return [
                'id' => $r['id'],
                'name' => $r['name'],
                'type' => $r['type'],
                'birthday' => $r['birthday'],
                'class' => $r['class'],
                'photo' => $r['photo'],
                'message' => $r['message'],
                'status' => $r['status'],
                'createdAt' => $r['created_at']
            ];
        }, $rows);
    } elseif ($collection === 'announcements') {
        $rows = array_map(function($r) {
            return [
                'id' => $r['id'],
                'title' => $r['title'],
                'content' => $r['content'],
                'priority' => $r['priority'],
                'targetAudience' => $r['target_audience'],
                'status' => $r['status'],
                'createdBy' => $r['created_by'],
                'pinned' => (bool)$r['pinned'],
                'createdAt' => $r['created_at']
            ];
        }, $rows);
    } elseif ($collection === 'courses') {
        $rows = array_map(function($r) {
            return [
                'id' => $r['id'],
                'title' => $r['title'],
                'code' => $r['code'],
                'description' => $r['description'],
                'gradeLevel' => $r['grade_level'],
                'credits' => $r['credits'],
                'teacherId' => $r['teacher_id'],
                'status' => $r['status'],
                'createdAt' => $r['created_at']
            ];
        }, $rows);
    } elseif ($collection === 'teammembers') {
        $rows = array_map(function($r) {
            return [
                'id' => $r['id'],
                'firstName' => $r['first_name'],
                'lastName' => $r['last_name'],
                'role' => $r['role'],
                'category' => $r['category'],
                'imageUrl' => $r['image_url'],
                'description' => $r['description'],
                'sortOrder' => $r['sort_order'],
                'status' => $r['status'],
                'showOnWebsite' => (int)($r['show_on_website'] ?? 1),
                'createdAt' => $r['created_at']
            ];
        }, $rows);
    } elseif ($collection === 'admins') {
        $rows = array_map(function($r) {
            return [
                'id' => $r['id'],
                'firstName' => $r['first_name'],
                'lastName' => $r['last_name'],
                'username' => $r['username'],
                'email' => $r['email'],
                'phone' => $r['phone'],
                'password' => $r['password'],
                'role' => $r['role'],
                'status' => $r['status'],
                'createdAt' => $r['created_at']
            ];
        }, $rows);
    } elseif ($collection === 'admin_sessions') {
        $rows = array_map(function($r) {
            return [
                'id' => $r['id'],
                'adminId' => $r['admin_id'],
                'username' => $r['username'],
                'displayName' => $r['display_name'],
                'ipAddress' => $r['ip_address'],
                'userAgent' => $r['user_agent'],
                'loginTime' => $r['login_time'],
                'lastActivity' => $r['last_activity'],
                'isActive' => (bool)$r['is_active'],
                'logoutTime' => $r['logout_time']
            ];
        }, $rows);
    } elseif ($collection === 'library') {
        $rows = array_map(function($r) {
            return [
                'id' => $r['id'],
                'title' => $r['title'],
                'author' => $r['author'],
                'isbn' => $r['isbn'],
                'publisher' => $r['publisher'],
                'year' => $r['year'],
                'pages' => $r['pages'],
                'category' => $r['category'],
                'language' => $r['language'],
                'tags' => $r['tags'],
                'copies' => $r['copies'],
                'available' => $r['available'],
                'location' => $r['location'],
                'status' => $r['status'],
                'borrower' => $r['borrower'],
                'borrowerType' => $r['borrower_type'],
                'borrowedDate' => $r['borrowed_date'],
                'dueDate' => $r['due_date'],
                'description' => $r['description'],
                'createdAt' => $r['created_at']
            ];
        }, $rows);
    } elseif ($collection === 'timetable') {
        $rows = array_map(function($r) {
            return [
                'id' => $r['id'],
                'day' => $r['day'],
                'time' => $r['time'],
                'endTime' => $r['end_time'],
                'duration' => $r['duration'],
                'period' => $r['period'],
                'className' => $r['class_name'],
                'subject' => $r['subject'],
                'subjectCode' => $r['subject_code'],
                'teacher' => $r['teacher'],
                'room' => $r['room'],
                'building' => $r['building'],
                'roomType' => $r['room_type'],
                'term' => $r['term'],
                'academicYear' => $r['academic_year'],
                'notes' => $r['notes'],
                'recurring' => (bool)$r['recurring'],
                'createdAt' => $r['created_at']
            ];
        }, $rows);
    } elseif ($collection === 'sports') {
        $rows = array_map(function($r) {
            return [
                'id' => $r['id'],
                'name' => $r['name'],
                'type' => $r['type'],
                'subCategory' => $r['sub_category'],
                'description' => $r['description'],
                'day' => $r['day'],
                'time' => $r['time'],
                'endTime' => $r['end_time'],
                'duration' => $r['duration'],
                'startDate' => $r['start_date'],
                'endDate' => $r['end_date'],
                'instructor' => $r['instructor'],
                'instructorPhone' => $r['instructor_phone'],
                'instructorEmail' => $r['instructor_email'],
                'location' => $r['location'],
                'minParticipants' => $r['min_participants'],
                'maxParticipants' => $r['max_participants'],
                'targetGroup' => $r['target_group'],
                'feeRequired' => $r['fee_required'],
                'feeAmount' => $r['fee_amount'],
                'equipment' => $r['equipment'],
                'requirements' => $r['requirements'],
                'status' => $r['status'],
                'participants' => $r['current_participants'],
                'createdAt' => $r['created_at']
            ];
        }, $rows);
    } elseif ($collection === 'transport') {
        $rows = array_map(function($r) {
            return [
                'id' => $r['id'],
                'vehicleNumber' => $r['vehicle_number'],
                'vehicleType' => $r['vehicle_type'],
                'makeModel' => $r['make_model'],
                'year' => $r['year'],
                'color' => $r['color'],
                'driverName' => $r['driver_name'],
                'driverPhone' => $r['driver_phone'],
                'driverLicense' => $r['driver_license'],
                'driverAddress' => $r['driver_address'],
                'route' => $r['route'],
                'routeDetails' => $r['route_details'],
                'morningTime' => $r['morning_time'],
                'afternoonTime' => $r['afternoon_time'],
                'capacity' => $r['capacity'],
                'assignedStudents' => $r['assigned_students'],
                'assignedClasses' => $r['assigned_classes'],
                'status' => $r['status'],
                'lastService' => $r['last_service'],
                'nextService' => $r['next_service'],
                'insuranceExpiry' => $r['insurance_expiry'],
                'maintenanceNotes' => $r['maintenance_notes'],
                'fuelType' => $r['fuel_type'],
                'emergencyContact' => $r['emergency_contact'],
                'notes' => $r['notes'],
                'createdAt' => $r['created_at']
            ];
        }, $rows);
    } elseif ($collection === 'vacancies') {
        $rows = array_map(function($r) {
            return [
                'id' => $r['id'],
                'title' => $r['title'],
                'description' => $r['description'],
                'requirements' => $r['requirements'],
                'grade' => $r['grade'],
                'responsibilities' => $r['responsibilities'],
                'duties' => $r['duties'],
                'contact_email' => $r['contact_email'],
                'location' => $r['location'],
                'position_type' => $r['position_type'],
                'salary_range' => $r['salary_range'],
                'application_deadline' => $r['application_deadline'],
                'status' => $r['status'],
                'created_at' => $r['created_at'],
                'updated_at' => $r['updated_at']
            ];
        }, $rows);
        respondSuccess(['items' => $rows, 'total' => count($rows)]);
    } elseif ($collection === 'exams') {
        $rows = array_map(function($r) {
            return [
                'id' => $r['id'],
                'subject' => $r['subject'],
                'grade' => $r['grade'],
                'term' => $r['term'],
                'year' => $r['year'],
                'examDate' => $r['exam_date'],
                'duration' => $r['duration'],
                'totalMarks' => $r['total_marks'],
                'passingMarks' => $r['passing_marks'],
                'instructions' => $r['instructions'],
                'fileUrl' => $r['file_url'],
                'status' => $r['status'],
                'createdAt' => $r['created_at']
            ];
        }, $rows);
    } elseif ($collection === 'apis') {
        $rows = array_map(function($r) {
            return [
                'id' => $r['id'],
                'name' => $r['name'],
                'type' => $r['type'],
                'provider' => $r['provider'],
                'endpoint' => $r['endpoint'],
                'api_key' => $r['api_key'],
                'api_secret' => $r['api_secret'],
                'headers' => $r['headers'],
                'status' => $r['status'],
                'priority' => $r['priority'],
                'description' => $r['description'],
                'last_used' => $r['last_used'],
                'created_at' => $r['created_at']
            ];
        }, $rows);
    } elseif ($collection === 'exams') {
        $rows = array_map(function($r) {
            return [
                'id' => $r['id'],
                'teacherId' => $r['teacher_id'],
                'teacherName' => $r['teacher_name'],
                'title' => $r['title'],
                'subject' => $r['subject'],
                'className' => $r['class_name'],
                'term' => $r['term'],
                'description' => $r['description'],
                'fileUrl' => $r['file_url'],
                'fileName' => $r['file_name'],
                'status' => $r['status'],
                'approvedBy' => $r['approved_by'],
                'approvedAt' => $r['approved_at'],
                'adminNotes' => $r['admin_notes'],
                'createdAt' => $r['created_at'],
                'updatedAt' => $r['updated_at']
            ];
        }, $rows);
    }

    if ($id) {
        respondSuccess($rows[0]);
    }
    respondSuccess(['items' => $rows, 'total' => count($rows)]);
}

// ============================================================
// POST (CREATE)

// ============================================================
function handlePost($collection, $table, $id) {
    // Handle file upload for admin profile photo
    if ($collection === 'settings' && isset($_FILES['profilePhoto'])) {
        $photoFile = $_FILES['profilePhoto'];
        
        // Validate file
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        $maxSize = 5 * 1024 * 1024; // 5MB
        
        if (!in_array($photoFile['type'], $allowedTypes)) {
            respondError('Invalid file type. Only JPG, PNG, GIF, and WebP are allowed.');
        }
        if ($photoFile['size'] > $maxSize) {
            respondError('File too large. Maximum size is 5MB.');
        }
        if ($photoFile['error'] !== UPLOAD_ERR_OK) {
            respondError('Upload error: ' . $photoFile['error']);
        }
        
        // Generate unique filename
        $ext = strtolower(pathinfo($photoFile['name'], PATHINFO_EXTENSION));
        $safeExts = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        if (!in_array($ext, $safeExts)) $ext = 'jpg';
        
        $adminId = $_POST['adminId'] ?? 1; // Default to admin ID 1 if not specified
        $newName = 'admin_' . $adminId . '_' . uniqid() . '.' . $ext;
        $uploadDir = __DIR__ . '/../uploads/admins/';
        
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        
        $dest = $uploadDir . $newName;
        if (!move_uploaded_file($photoFile['tmp_name'], $dest)) {
            respondError('Failed to save uploaded file.');
        }
        
        $photoUrl = '../uploads/admins/' . $newName;
        
        // Update admin profile photo in database
        dbExecute(
            "UPDATE admins SET profile_photo = ? WHERE id = ?",
            [$photoUrl, $adminId],
            'si'
        );
        
        // Update settings
        $username = $_POST['username'] ?? '';
        $displayName = $_POST['displayName'] ?? '';
        $email = $_POST['email'] ?? '';
        
        if ($username) {
            dbExecute("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?", ['username', $username, $username], 'sss');
        }
        if ($displayName) {
            dbExecute("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?", ['displayName', $displayName, $displayName], 'sss');
        }
        if ($email) {
            dbExecute("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?", ['email', $email, $email], 'sss');
        }
        
        addActivityLog('Profile Updated', 'Admin profile photo and settings updated');
        respondSuccess(['photoUrl' => $photoUrl], 'Profile updated successfully');
    }
    
    $body = getJsonBody();
    if (!$body) respondError('Invalid request body');

    if ($collection === 'settings') {
        foreach ($body as $key => $value) {
            dbExecute(
                "INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?",
                [$key, $value, $value],
                'sss'
            );
        }
        addActivityLog('Settings Updated', 'Admin settings were updated');
        respondSuccess([], 'Settings updated');
    }

    if ($collection === 'content') {
        $page = $body['page'] ?? '';
        $data = $body['data'] ?? [];
        if (empty($page)) respondError('Page name required');
        foreach ($data as $key => $value) {
            dbExecute(
                "INSERT INTO site_content (page_name, content_key, content_value) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE content_value = ?",
                [$page, $key, $value, $value],
                'ssss'
            );
        }
        addActivityLog('Content Updated', ucfirst($page) . ' page content updated');
        respondSuccess([], 'Content saved');
    }

    // Special: student registration from public form
    if ($collection === 'registrations') {
        $data = [
            'student_name' => $body['studentName'] ?? $body['student_name'] ?? '',
            'grade' => $body['grade'] ?? '',
            'parent_name' => $body['parentName'] ?? $body['parent_name'] ?? '',
            'phone' => $body['phone'] ?? '',
            'email' => $body['email'] ?? '',
            'address' => $body['address'] ?? '',
            'dob' => $body['dob'] ?? null,
            'notes' => $body['notes'] ?? $body['message'] ?? ''
        ];
        $id = dbInsert(
            "INSERT INTO registrations (student_name, grade, parent_name, phone, email, address, dob, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            [$data['student_name'], $data['grade'], $data['parent_name'], $data['phone'], $data['email'], $data['address'], $data['dob'], $data['notes']],
            'ssssssss'
        );
        if ($id) {
            addActivityLog('New Registration', $data['student_name'] . ' registered for ' . $data['grade']);
            respondSuccess(['id' => $id], 'Registration submitted successfully!');
        }
        respondError('Failed to save registration');
    }

    // Special: payments from public form
    if ($collection === 'payments') {
        $data = [
            'payer_name' => $body['payerName'] ?? $body['payer_name'] ?? '',
            'student_name' => $body['studentName'] ?? $body['student_name'] ?? '',
            'registration_id' => $body['registrationId'] ?? $body['registration_id'] ?? null,
            'amount' => $body['amount'] ?? 0,
            'payment_type' => $body['paymentType'] ?? $body['payment_type'] ?? '',
            'phone' => $body['phone'] ?? '',
            'payment_method' => $body['paymentMethod'] ?? $body['payment_method'] ?? '',
            'notes' => $body['notes'] ?? ''
        ];
        
        // Handle API payment method
        if (isset($body['api_id']) && !empty($body['api_id'])) {
            $apiId = (int)$body['api_id'];
            $api = dbFetchOne("SELECT * FROM apis WHERE id = ?", [$apiId], 'i');
            if ($api) {
                $data['payment_method'] = $api['name'] . ' (' . $api['provider'] . ')';
                $data['api_provider'] = $api['provider'];
                $data['api_name'] = $api['name'];
                
                // Update API last_used timestamp
                dbExecute("UPDATE apis SET last_used = NOW() WHERE id = ?", [$apiId], 'i');
            }
        }
        
        // Try to find registration_id by student name if not provided
        if (empty($data['registration_id']) && !empty($data['student_name'])) {
            $registration = dbFetchOne(
                "SELECT id FROM registrations WHERE student_name = ?",
                [$data['student_name']],
                's'
            );
            if ($registration) {
                $data['registration_id'] = $registration['id'];
            }
        }
        
        $id = dbInsert(
            "INSERT INTO payments (payer_name, student_name, registration_id, amount, payment_type, phone, payment_method, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            [$data['payer_name'], $data['student_name'], $data['registration_id'], $data['amount'], $data['payment_type'], $data['phone'], $data['payment_method'], $data['notes']],
            'ssidssss'
        );
        if ($id) {
            addActivityLog('New Payment', $data['payer_name'] . ' - MK' . $data['amount']);
            respondSuccess(['id' => $id], 'Payment submitted successfully!');
        }
        respondError('Failed to save payment');
    }

    // Special: messages from public contact form
    if ($collection === 'messages') {
        $data = [
            'name' => $body['name'] ?? '',
            'email' => $body['email'] ?? '',
            'subject' => $body['subject'] ?? '',
            'message' => $body['message'] ?? $body['content'] ?? ''
        ];
        // Check if using contact form field names
        if (empty($data['name']) && isset($body['contactName'])) $data['name'] = $body['contactName'];
        if (empty($data['email']) && isset($body['contactEmail'])) $data['email'] = $body['contactEmail'];
        if (empty($data['subject']) && isset($body['contactSubject'])) $data['subject'] = $body['contactSubject'];
        if (empty($data['message']) && isset($body['contactMessage'])) $data['message'] = $body['contactMessage'];

        if (empty($data['name'])) respondError('Name is required');
        $id = dbInsert(
            "INSERT INTO messages (name, email, subject, message) VALUES (?, ?, ?, ?)",
            [$data['name'], $data['email'], $data['subject'], $data['message']],
            'ssss'
        );
        if ($id) {
            addActivityLog('New Message', 'From: ' . $data['name']);
            respondSuccess(['id' => $id], 'Message sent successfully!');
        }
        respondError('Failed to save message');
    }

    // Standard collections
    $insertData = $body;
    
    // Map camelCase to snake_case for known collections
    if ($collection === 'users') {
        $insertData = [
            'first_name' => $body['first_name'] ?? '',
            'last_name' => $body['last_name'] ?? '',
            'email' => $body['email'] ?? '',
            'password' => password_hash($body['password'] ?? 'user123', PASSWORD_DEFAULT),
            'role' => $body['role'] ?? 'parent',
            'phone' => $body['phone'] ?? '',
            'status' => $body['status'] ?? 'active',
            'notes' => $body['notes'] ?? ''
        ];
        $sql = "INSERT INTO users (first_name, last_name, email, password, role, phone, status, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $types = 'ssssssss';
        $params = [$insertData['first_name'], $insertData['last_name'], $insertData['email'], $insertData['password'], $insertData['role'], $insertData['phone'], $insertData['status'], $insertData['notes']];
    } elseif ($collection === 'students') {
        $insertData = [
            'first_name' => $body['firstName'] ?? '',
            'last_name' => $body['lastName'] ?? '',
            'gender' => $body['gender'] ?? '',
            'grade' => $body['grade'] ?? '',
            'dob' => $body['dob'] ?? null,
            'parent_name' => $body['parent'] ?? $body['parentName'] ?? '',
            'phone' => $body['phone'] ?? '',
            'address' => $body['address'] ?? '',
            'emergency_contact' => $body['emergencyContact'] ?? '',
            'emergency_phone' => $body['emergencyPhone'] ?? '',
            'medical_info' => $body['medicalInfo'] ?? '',
            'enrollment_date' => $body['enrollmentDate'] ?? date('Y-m-d'),
            'status' => $body['status'] ?? 'Active'
        ];
        $sql = "INSERT INTO students (first_name, last_name, gender, grade, dob, parent_name, phone, address, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $types = 'sssssssss';
        $params = [$insertData['first_name'], $insertData['last_name'], $insertData['gender'], $insertData['grade'], $insertData['dob'], $insertData['parent_name'], $insertData['phone'], $insertData['address'], $insertData['status']];
    } elseif ($collection === 'teachers') {
        $insertData = [
            'first_name' => $body['firstName'] ?? '',
            'last_name' => $body['lastName'] ?? '',
            'username' => $body['username'] ?? '',
            'email' => $body['email'] ?? '',
            'phone' => $body['phone'] ?? '',
            'subject' => $body['subject'] ?? '',
            'qualification' => $body['qualification'] ?? '',
            'password' => $body['password'] ?? 'teacher123',
            'class_assigned' => $body['classAssigned'] ?? $body['class'] ?? '',
            'approved' => $body['approved'] ?? 1
        ];
        $sql = "INSERT INTO teachers (first_name, last_name, username, email, phone, subject, qualification, password, class_assigned, approved) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $types = 'sssssssssi';
        $params = [$insertData['first_name'], $insertData['last_name'], $insertData['username'], $insertData['email'], $insertData['phone'], $insertData['subject'], $insertData['qualification'], $insertData['password'], $insertData['class_assigned'], $insertData['approved']];
    } elseif ($collection === 'events') {
        $insertData = [
            'title' => $body['title'] ?? '',
            'date' => $body['date'] ?? null,
            'time' => $body['time'] ?? null,
            'location' => $body['location'] ?? '',
            'description' => $body['description'] ?? '',
            'image_url' => $body['imageUrl'] ?? $body['image_url'] ?? '',
            'video_url' => $body['videoUrl'] ?? $body['video_url'] ?? '',
            'link' => $body['link'] ?? '',
            'status' => $body['status'] ?? 'Upcoming'
        ];
        $sql = "INSERT INTO events (title, date, time, location, description, image_url, video_url, link, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $types = 'sssssssss';
        $params = [$insertData['title'], $insertData['date'], $insertData['time'], $insertData['location'], $insertData['description'], $insertData['image_url'], $insertData['video_url'], $insertData['link'], $insertData['status']];
    } elseif ($collection === 'gallery') {
        $insertData = [
            'image_url' => $body['imageUrl'] ?? $body['image_url'] ?? '',
            'video_url' => $body['videoUrl'] ?? $body['video_url'] ?? '',
            'media_type' => $body['mediaType'] ?? $body['media_type'] ?? 'image',
            'title' => $body['title'] ?? '',
            'category' => $body['category'] ?? 'Academic',
            'description' => $body['description'] ?? ''
        ];
        $sql = "INSERT INTO gallery (image_url, video_url, media_type, title, category, description) VALUES (?, ?, ?, ?, ?, ?)";
        $types = 'ssssss';
        $params = [$insertData['image_url'], $insertData['video_url'], $insertData['media_type'], $insertData['title'], $insertData['category'], $insertData['description']];
    } elseif ($collection === 'blog') {
        $insertData = [
            'title' => $body['title'] ?? '',
            'author' => $body['author'] ?? '',
            'category' => $body['category'] ?? 'General',
            'content' => $body['content'] ?? '',
            'image' => $body['image'] ?? '',
            'status' => $body['status'] ?? 'Draft'
        ];
        $sql = "INSERT INTO blog (title, author, category, content, image, status) VALUES (?, ?, ?, ?, ?, ?)";
        $types = 'ssssss';
        $params = [$insertData['title'], $insertData['author'], $insertData['category'], $insertData['content'], $insertData['image'], $insertData['status']];
    } elseif ($collection === 'services') {
        $insertData = [
            'title' => $body['title'] ?? '',
            'description' => $body['description'] ?? '',
            'icon' => $body['icon'] ?? 'fas fa-concierge-bell'
        ];
        $sql = "INSERT INTO services (title, description, icon) VALUES (?, ?, ?)";
        $types = 'sss';
        $params = [$insertData['title'], $insertData['description'], $insertData['icon']];
    } elseif ($collection === 'attendance') {
        $insertData = [
            'registration_id' => $body['registrationId'] ?? $body['registration_id'] ?? 0,
            'student_name' => $body['studentName'] ?? $body['student_name'] ?? '',
            'class_name' => $body['studentClass'] ?? $body['class_name'] ?? '',
            'date' => $body['date'] ?? date('Y-m-d'),
            'status' => $body['status'] ?? 'Present',
            'remarks' => $body['remarks'] ?? ''
        ];
        $sql = "INSERT INTO attendance (registration_id, student_name, class_name, date, status, remarks) VALUES (?, ?, ?, ?, ?, ?)";
        $types = 'isssss';
        $params = [$insertData['registration_id'], $insertData['student_name'], $insertData['class_name'], $insertData['date'], $insertData['status'], $insertData['remarks']];
    } elseif ($collection === 'birthdays') {
        $insertData = [
            'name' => $body['name'] ?? '',
            'type' => $body['type'] ?? 'student',
            'birthday' => $body['birthday'] ?? '',
            'class' => $body['class'] ?? '',
            'photo' => $body['photo'] ?? '',
            'message' => $body['message'] ?? '',
            'status' => $body['status'] ?? 'active'
        ];
        $sql = "INSERT INTO birthdays (name, type, birthday, class, photo, message, status) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $types = 'sssssss';
        $params = [$insertData['name'], $insertData['type'], $insertData['birthday'], $insertData['class'], $insertData['photo'], $insertData['message'], $insertData['status']];
    } elseif ($collection === 'assessments') {
        $insertData = [
            'teacher_id' => $body['teacherId'] ?? $body['teacher_id'] ?? 0,
            'registration_id' => $body['registrationId'] ?? $body['registration_id'] ?? 0,
            'student_name' => $body['studentName'] ?? $body['student_name'] ?? '',
            'class_name' => $body['className'] ?? $body['class_name'] ?? '',
            'subject' => $body['subject'] ?? '',
            'type' => $body['type'] ?? 'Quiz',
            'score' => $body['score'] ?? 0,
            'date' => $body['date'] ?? date('Y-m-d'),
            'remarks' => $body['remarks'] ?? ''
        ];
        $sql = "INSERT INTO assessments (teacher_id, registration_id, student_name, class_name, subject, type, score, date, remarks) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $types = 'iissssisss';
        $params = [$insertData['teacher_id'], $insertData['registration_id'], $insertData['student_name'], $insertData['class_name'], $insertData['subject'], $insertData['type'], $insertData['score'], $insertData['date'], $insertData['remarks']];
    } elseif ($collection === 'courses') {
        $insertData = [
            'title' => $body['title'] ?? '',
            'code' => $body['code'] ?? '',
            'description' => $body['description'] ?? '',
            'grade_level' => $body['gradeLevel'] ?? $body['grade_level'] ?? '',
            'credits' => $body['credits'] ?? 0,
            'teacher_id' => $body['teacherId'] ?? $body['teacher_id'] ?? null,
            'status' => $body['status'] ?? 'Active'
        ];
        $sql = "INSERT INTO courses (title, code, description, grade_level, credits, teacher_id, status) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $types = 'sssssis';
        $params = [$insertData['title'], $insertData['code'], $insertData['description'], $insertData['grade_level'], $insertData['credits'], $insertData['teacher_id'], $insertData['status']];
        $newId = dbInsert($sql, $params, $types);
        if ($newId) {
            addActivityLog('Course Created', "New course: {$insertData['title']}");
            respondSuccess(['id' => $newId], 'Course created successfully');
        }
        respondError('Failed to create course');
    } elseif ($collection === 'announcements') {
        $insertData = [
            'title' => $body['title'] ?? '',
            'content' => $body['content'] ?? '',
            'priority' => $body['priority'] ?? 'normal',
            'target_audience' => $body['targetAudience'] ?? $body['target_audience'] ?? 'all',
            'status' => $body['status'] ?? 'Published',
            'created_by' => $body['createdBy'] ?? 'Admin',
            'pinned' => $body['pinned'] ?? 0
        ];
        $sql = "INSERT INTO announcements (title, content, priority, target_audience, status, created_by, pinned) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $types = 'ssssssi';
        $params = [$insertData['title'], $insertData['content'], $insertData['priority'], $insertData['target_audience'], $insertData['status'], $insertData['created_by'], $insertData['pinned']];
    } elseif ($collection === 'admins') {
        $insertData = [
            'first_name' => $body['first_name'] ?? '',
            'last_name' => $body['last_name'] ?? '',
            'username' => $body['username'] ?? '',
            'email' => $body['email'] ?? '',
            'phone' => $body['phone'] ?? '',
            'password' => $body['password'] ?? 'admin123',
            'role' => $body['role'] ?? 'Admin',
            'status' => $body['status'] ?? 'Active'
        ];
        if (empty($insertData['first_name']) || empty($insertData['username']) || empty($insertData['password'])) {
            respondError('First name, username, and password are required');
        }
        // Check if username already exists
        $existing = dbFetchOne("SELECT id FROM admins WHERE username = ?", [$insertData['username']], 's');
        if ($existing) {
            respondError('Username already exists. Please choose a different username.');
        }
        // Hash password for security
        $hashedPassword = password_hash($insertData['password'], PASSWORD_DEFAULT);
        $sql = "INSERT INTO admins (first_name, last_name, username, email, phone, password, role, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $types = 'ssssssss';
        $params = [$insertData['first_name'], $insertData['last_name'], $insertData['username'], $insertData['email'], $insertData['phone'], $hashedPassword, $insertData['role'], $insertData['status']];
        $newId = dbInsert($sql, $params, $types);
        if ($newId) {
            addActivityLog('Admin Created', "New admin: {$insertData['username']}");
            respondSuccess(['id' => $newId], 'Admin created successfully');
        }
        respondError('Failed to create admin');
    } elseif ($collection === 'library') {
        $insertData = [
            'title' => $body['title'] ?? '',
            'author' => $body['author'] ?? '',
            'isbn' => $body['isbn'] ?? '',
            'publisher' => $body['publisher'] ?? '',
            'year' => $body['year'] ?? null,
            'pages' => $body['pages'] ?? null,
            'category' => $body['category'] ?? '',
            'language' => $body['language'] ?? 'English',
            'tags' => $body['tags'] ?? '',
            'copies' => (int)($body['copies'] ?? 1),
            'available' => (int)($body['available'] ?? $body['copies'] ?? 1),
            'location' => $body['location'] ?? '',
            'status' => $body['status'] ?? 'Available',
            'borrower' => $body['borrower'] ?? '',
            'borrower_type' => $body['borrowerType'] ?? '',
            'borrowed_date' => $body['borrowedDate'] ?? null,
            'due_date' => $body['dueDate'] ?? null,
            'description' => $body['description'] ?? ''
        ];
        if (empty($insertData['title']) || empty($insertData['author']) || empty($insertData['category'])) {
            respondError('Title, author, and category are required');
        }
        $sql = "INSERT INTO library (title, author, isbn, publisher, year, pages, category, language, tags, copies, available, location, status, borrower, borrower_type, borrowed_date, due_date, description) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $types = 'ssssiisssiisssssss';
        $params = [$insertData['title'], $insertData['author'], $insertData['isbn'], $insertData['publisher'], $insertData['year'], $insertData['pages'], $insertData['category'], $insertData['language'], $insertData['tags'], $insertData['copies'], $insertData['available'], $insertData['location'], $insertData['status'], $insertData['borrower'], $insertData['borrower_type'], $insertData['borrowed_date'], $insertData['due_date'], $insertData['description']];
        $newId = dbInsert($sql, $params, $types);
        if ($newId) {
            addActivityLog('Book Added', "New book: {$insertData['title']}");
            respondSuccess(['id' => $newId], 'Book added successfully');
        }
        respondError('Failed to add book');
    } elseif ($collection === 'timetable') {
        $insertData = [
            'day' => $body['day'] ?? '',
            'time' => $body['time'] ?? '',
            'end_time' => $body['endTime'] ?? '',
            'duration' => !empty($body['duration']) ? (int)$body['duration'] : null,
            'period' => $body['period'] ?? '',
            'class_name' => $body['className'] ?? '',
            'subject' => $body['subject'] ?? '',
            'subject_code' => $body['subjectCode'] ?? '',
            'teacher' => $body['teacher'] ?? '',
            'room' => $body['room'] ?? '',
            'building' => $body['building'] ?? '',
            'room_type' => $body['roomType'] ?? 'Classroom',
            'term' => $body['term'] ?? '',
            'academic_year' => $body['academicYear'] ?? '',
            'notes' => $body['notes'] ?? '',
            'recurring' => !empty($body['recurring']) ? 1 : 0
        ];
        if (empty($insertData['day']) || empty($insertData['time']) || empty($insertData['class_name']) || empty($insertData['subject'])) {
            respondError('Day, time, class, and subject are required');
        }
        $sql = "INSERT INTO timetable (day, time, end_time, duration, period, class_name, subject, subject_code, teacher, room, building, room_type, term, academic_year, notes, recurring) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $types = 'sssisssssssssssi';
        $params = [$insertData['day'], $insertData['time'], $insertData['end_time'], $insertData['duration'], $insertData['period'], $insertData['class_name'], $insertData['subject'], $insertData['subject_code'], $insertData['teacher'], $insertData['room'], $insertData['building'], $insertData['room_type'], $insertData['term'], $insertData['academic_year'], $insertData['notes'], $insertData['recurring']];
        $newId = dbInsert($sql, $params, $types);
        if ($newId) {
            addActivityLog('Schedule Added', "New schedule: {$insertData['class_name']} - {$insertData['subject']}");
            respondSuccess(['id' => $newId], 'Schedule added successfully');
        }
        respondError('Failed to add schedule');
    } elseif ($collection === 'sports') {
        $insertData = [
            'name' => $body['name'] ?? '',
            'type' => $body['type'] ?? '',
            'sub_category' => $body['subCategory'] ?? '',
            'description' => $body['description'] ?? '',
            'day' => $body['day'] ?? '',
            'time' => $body['time'] ?? '',
            'end_time' => $body['endTime'] ?? '',
            'duration' => !empty($body['duration']) ? (int)$body['duration'] : null,
            'start_date' => $body['startDate'] ?? null,
            'end_date' => $body['endDate'] ?? null,
            'instructor' => $body['instructor'] ?? '',
            'instructor_phone' => $body['instructorPhone'] ?? '',
            'instructor_email' => $body['instructorEmail'] ?? '',
            'location' => $body['location'] ?? '',
            'min_participants' => (int)($body['minParticipants'] ?? 0),
            'max_participants' => (int)($body['maxParticipants'] ?? 0),
            'target_group' => $body['targetGroup'] ?? '',
            'fee_required' => $body['feeRequired'] ?? 'No',
            'fee_amount' => (float)($body['feeAmount'] ?? 0),
            'equipment' => $body['equipment'] ?? '',
            'requirements' => $body['requirements'] ?? '',
            'status' => $body['status'] ?? 'Active',
            'current_participants' => (int)($body['currentParticipants'] ?? 0)
        ];
        if (empty($insertData['name']) || empty($insertData['type']) || empty($insertData['day']) || empty($insertData['time'])) {
            respondError('Name, type, day, and time are required');
        }
        $sql = "INSERT INTO sports_activities (name, type, sub_category, description, day, time, end_time, duration, start_date, end_date, instructor, instructor_phone, instructor_email, location, min_participants, max_participants, target_group, fee_required, fee_amount, equipment, requirements, status, current_participants) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $types = 'sssssssissssssiissdsssi';
        $params = [$insertData['name'], $insertData['type'], $insertData['sub_category'], $insertData['description'], $insertData['day'], $insertData['time'], $insertData['end_time'], $insertData['duration'], $insertData['start_date'], $insertData['end_date'], $insertData['instructor'], $insertData['instructor_phone'], $insertData['instructor_email'], $insertData['location'], $insertData['min_participants'], $insertData['max_participants'], $insertData['target_group'], $insertData['fee_required'], $insertData['fee_amount'], $insertData['equipment'], $insertData['requirements'], $insertData['status'], $insertData['current_participants']];
        $newId = dbInsert($sql, $params, $types);
        if ($newId) {
            addActivityLog('Activity Added', "New activity: {$insertData['name']}");
            respondSuccess(['id' => $newId], 'Activity added successfully');
        }
        respondError('Failed to add activity');
    } elseif ($collection === 'transport') {
        $insertData = [
            'vehicle_number' => $body['vehicleNumber'] ?? '',
            'vehicle_type' => $body['vehicleType'] ?? 'Bus',
            'make_model' => $body['makeModel'] ?? '',
            'year' => !empty($body['year']) ? (int)$body['year'] : null,
            'color' => $body['color'] ?? '',
            'driver_name' => $body['driverName'] ?? '',
            'driver_phone' => $body['driverPhone'] ?? '',
            'driver_license' => $body['driverLicense'] ?? '',
            'driver_address' => $body['driverAddress'] ?? '',
            'route' => $body['route'] ?? '',
            'route_details' => $body['routeDetails'] ?? '',
            'morning_time' => $body['morningTime'] ?? '',
            'afternoon_time' => $body['afternoonTime'] ?? '',
            'capacity' => (int)($body['capacity'] ?? 0),
            'assigned_students' => (int)($body['assignedStudents'] ?? 0),
            'assigned_classes' => $body['assignedClasses'] ?? '',
            'status' => $body['status'] ?? 'Active',
            'last_service' => $body['lastService'] ?? null,
            'next_service' => $body['nextService'] ?? null,
            'insurance_expiry' => $body['insuranceExpiry'] ?? null,
            'maintenance_notes' => $body['maintenanceNotes'] ?? '',
            'fuel_type' => $body['fuelType'] ?? 'Diesel',
            'emergency_contact' => $body['emergencyContact'] ?? '',
            'notes' => $body['notes'] ?? ''
        ];
        if (empty($insertData['vehicle_number']) || empty($insertData['driver_name']) || empty($insertData['driver_phone']) || empty($insertData['route']) || empty($insertData['capacity'])) {
            respondError('Vehicle number, driver name, phone, route, and capacity are required');
        }
        $sql = "INSERT INTO transport (vehicle_number, vehicle_type, make_model, year, color, driver_name, driver_phone, driver_license, driver_address, route, route_details, morning_time, afternoon_time, capacity, assigned_students, assigned_classes, status, last_service, next_service, insurance_expiry, maintenance_notes, fuel_type, emergency_contact, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $types = 'sssisssssssiiissssssssss';
        $params = [$insertData['vehicle_number'], $insertData['vehicle_type'], $insertData['make_model'], $insertData['year'], $insertData['color'], $insertData['driver_name'], $insertData['driver_phone'], $insertData['driver_license'], $insertData['driver_address'], $insertData['route'], $insertData['route_details'], $insertData['morning_time'], $insertData['afternoon_time'], $insertData['capacity'], $insertData['assigned_students'], $insertData['assigned_classes'], $insertData['status'], $insertData['last_service'], $insertData['next_service'], $insertData['insurance_expiry'], $insertData['maintenance_notes'], $insertData['fuel_type'], $insertData['emergency_contact'], $insertData['notes']];
        $newId = dbInsert($sql, $params, $types);
        if ($newId) {
            addActivityLog('Vehicle Added', "New vehicle: {$insertData['vehicle_number']}");
            respondSuccess(['id' => $newId], 'Vehicle added successfully');
        }
        respondError('Failed to add vehicle');
    } elseif ($collection === 'vacancies') {
        $insertData = [
            'title' => $body['title'] ?? '',
            'description' => $body['description'] ?? '',
            'requirements' => $body['requirements'] ?? '',
            'grade' => $body['grade'] ?? '',
            'responsibilities' => $body['responsibilities'] ?? '',
            'duties' => $body['duties'] ?? '',
            'contact_email' => $body['contactEmail'] ?? $body['contact_email'] ?? '',
            'location' => $body['location'] ?? '',
            'position_type' => $body['positionType'] ?? $body['position_type'] ?? 'Full-time',
            'salary_range' => $body['salaryRange'] ?? $body['salary_range'] ?? '',
            'application_deadline' => $body['applicationDeadline'] ?? $body['application_deadline'] ?? null,
            'status' => $body['status'] ?? 'Active'
        ];
        if (empty($insertData['title'])) {
            respondError('Title is required');
        }
        $sql = "INSERT INTO vacancies (title, description, requirements, grade, responsibilities, duties, contact_email, location, position_type, salary_range, application_deadline, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $types = 'ssssssssssss';
        $params = [$insertData['title'], $insertData['description'], $insertData['requirements'], $insertData['grade'], $insertData['responsibilities'], $insertData['duties'], $insertData['contact_email'], $insertData['location'], $insertData['position_type'], $insertData['salary_range'], $insertData['application_deadline'], $insertData['status']];
        $newId = dbInsert($sql, $params, $types);
        if ($newId) {
            addActivityLog('Vacancy Posted', "New vacancy: {$insertData['title']}");
            respondSuccess(['id' => $newId], 'Vacancy posted successfully');
        }
        respondError('Failed to post vacancy');
    } elseif ($collection === 'notifications') {
        $insertData = [
            'type' => $body['type'] ?? 'system',
            'title' => $body['title'] ?? '',
            'message' => $body['message'] ?? '',
            'icon' => $body['icon'] ?? 'fa-bell',
            'icon_bg' => $body['iconBg'] ?? $body['icon_bg'] ?? '#085636',
            'link' => $body['link'] ?? null,
            'link_label' => $body['linkLabel'] ?? $body['link_label'] ?? null,
            'is_read' => $body['isRead'] ?? $body['is_read'] ?? 0,
            'priority' => $body['priority'] ?? 'normal',
            'target_audience' => $body['targetAudience'] ?? $body['target_audience'] ?? 'admin',
            'source_type' => $body['sourceType'] ?? $body['source_type'] ?? null,
            'source_id' => $body['sourceId'] ?? $body['source_id'] ?? null,
            'delivery_teacher_portal' => isset($body['delivery']['teacherPortal']) ? ($body['delivery']['teacherPortal'] ? 1 : 0) : 0,
            'delivery_parent_portal' => isset($body['delivery']['parentPortal']) ? ($body['delivery']['parentPortal'] ? 1 : 0) : 0,
            'delivery_email' => isset($body['delivery']['email']) ? ($body['delivery']['email'] ? 1 : 0) : 0,
            'email_recipients' => isset($body['delivery']['emailRecipients']) ? $body['delivery']['emailRecipients'] : null,
            'delivery_sms' => isset($body['delivery']['sms']) ? ($body['delivery']['sms'] ? 1 : 0) : 0,
            'sms_recipients' => isset($body['delivery']['smsRecipients']) ? $body['delivery']['smsRecipients'] : null,
            'sms_api_id' => isset($body['delivery']['smsApiId']) ? (int)$body['delivery']['smsApiId'] : null
        ];
        if (empty($insertData['title'])) {
            respondError('Title is required');
        }
        $sql = "INSERT INTO notifications (type, title, message, icon, icon_bg, link, link_label, is_read, priority, target_audience, source_type, source_id, delivery_teacher_portal, delivery_parent_portal, delivery_email, email_recipients, delivery_sms, sms_recipients, sms_api_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $types = 'sssssssiissiiissisi';
        $params = [$insertData['type'], $insertData['title'], $insertData['message'], $insertData['icon'], $insertData['icon_bg'], $insertData['link'], $insertData['link_label'], $insertData['is_read'], $insertData['priority'], $insertData['target_audience'], $insertData['source_type'], $insertData['source_id'], $insertData['delivery_teacher_portal'], $insertData['delivery_parent_portal'], $insertData['delivery_email'], $insertData['email_recipients'], $insertData['delivery_sms'], $insertData['sms_recipients'], $insertData['sms_api_id']];
        $newId = dbInsert($sql, $params, $types);
        if ($newId) {
            addActivityLog('Notification Created', $insertData['title']);
            respondSuccess(['id' => $newId], 'Notification created successfully');
        }
        respondError('Failed to create notification');
    } elseif ($collection === 'parents') {
        $pwd = $body['password'] ?? 'parent123';
        if (strlen($pwd) < 255 && strpos($pwd, '$2y$') !== 0) {
            $pwd = password_hash($pwd, PASSWORD_DEFAULT);
        }
        $insertData = [
            'first_name' => $body['firstName'] ?? $body['first_name'] ?? '',
            'last_name' => $body['lastName'] ?? $body['last_name'] ?? '',
            'username' => $body['username'] ?? '',
            'email' => $body['email'] ?? '',
            'phone' => $body['phone'] ?? '',
            'password' => $pwd,
            'student_ids' => $body['studentIds'] ?? $body['student_ids'] ?? '',
            'approved' => $body['approved'] ?? 1,
            'is_active' => $body['isActive'] ?? $body['is_active'] ?? 1
        ];
        if (empty($insertData['first_name']) || empty($insertData['username'])) {
            respondError('First name and username are required');
        }
        $sql = "INSERT INTO parents (first_name, last_name, username, email, phone, password, student_ids, approved, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $types = 'sssssssii';
        $params = [$insertData['first_name'], $insertData['last_name'], $insertData['username'], $insertData['email'], $insertData['phone'], $insertData['password'], $insertData['student_ids'], $insertData['approved'], $insertData['is_active']];
    } elseif ($collection === 'teammembers') {
        $insertData = [
            'first_name' => $body['firstName'] ?? '',
            'last_name' => $body['lastName'] ?? '',
            'role' => $body['role'] ?? '',
            'category' => $body['category'] ?? 'Leadership',
            'image_url' => $body['imageUrl'] ?? '',
            'description' => $body['description'] ?? '',
            'sort_order' => $body['sortOrder'] ?? 0,
            'status' => $body['status'] ?? 'Active',
            'show_on_website' => $body['showOnWebsite'] ?? 1
        ];
        $sql = "INSERT INTO team_members (first_name, last_name, role, category, image_url, description, sort_order, status, show_on_website) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $types = 'sssssssis';
        $params = [$insertData['first_name'], $insertData['last_name'], $insertData['role'], $insertData['category'], $insertData['image_url'], $insertData['description'], $insertData['sort_order'], $insertData['status'], $insertData['show_on_website']];
    } elseif ($collection === 'apis') {
        $insertData = [
            'name' => $body['name'] ?? '',
            'type' => $body['type'] ?? 'other',
            'provider' => $body['provider'] ?? '',
            'endpoint' => $body['endpoint'] ?? '',
            'api_key' => $body['api_key'] ?? $body['apiKey'] ?? '',
            'api_secret' => $body['api_secret'] ?? $body['apiSecret'] ?? '',
            'headers' => $body['headers'] ?? '',
            'status' => $body['status'] ?? 'active',
            'priority' => $body['priority'] ?? 1,
            'description' => $body['description'] ?? ''
        ];
        if (empty($insertData['name']) || empty($insertData['provider']) || empty($insertData['endpoint']) || empty($insertData['api_key'])) {
            respondError('Name, provider, endpoint, and API key are required');
        }
        $sql = "INSERT INTO apis (name, type, provider, endpoint, api_key, api_secret, headers, status, priority, description) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $types = 'sssssssis';
        $params = [$insertData['name'], $insertData['type'], $insertData['provider'], $insertData['endpoint'], $insertData['api_key'], $insertData['api_secret'], $insertData['headers'], $insertData['status'], $insertData['priority'], $insertData['description']];
    } else {
        // Generic insert
        $columns = implode(', ', array_keys($body));
        $placeholders = implode(', ', array_fill(0, count($body), '?'));
        $values = array_values($body);
        $types = str_repeat('s', count($values));
        $sql = "INSERT INTO $table ($columns) VALUES ($placeholders)";
        $params = $values;
    }

    // Check for duplicate username/email before insert
    if (in_array($collection, ['teachers', 'admins', 'parents', 'users']) && isset($insertData['username']) && !empty($insertData['username'])) {
        $dupCheck = dbFetchOne(
            "SELECT id FROM $table WHERE username = ?",
            [$insertData['username']], 's'
        );
        if ($dupCheck) {
            respondError('A record with username "' . $insertData['username'] . '" already exists. Please choose a different username.');
        }
    }
    if (in_array($collection, ['teachers', 'admins', 'parents', 'users']) && isset($insertData['email']) && !empty($insertData['email'])) {
        $dupCheck = dbFetchOne(
            "SELECT id FROM $table WHERE email = ?",
            [$insertData['email']], 's'
        );
        if ($dupCheck) {
            respondError('A record with email "' . $insertData['email'] . '" already exists. Please use a different email.');
        }
    }

    $newId = dbInsert($sql, $params, $types);
    if ($newId) {
        $label = ucfirst(rtrim($collection, 's'));
        addActivityLog("$label Created", "New $label added (#$newId)");
        respondSuccess(['id' => $newId, 'insertId' => $newId], "$label created successfully");
    }
    respondError('Failed to create item');
}

// ============================================================
// PUT (UPDATE)
// ============================================================
function handlePut($collection, $table, $id) {
    if (!$id) respondError('ID is required for update');

    $body = getJsonBody();
    if (!$body) respondError('Invalid request body');

    if ($collection === 'settings') {
        foreach ($body as $key => $value) {
            dbExecute(
                "INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?",
                [$key, $value, $value], 'sss'
            );
        }
        addActivityLog('Settings Updated', 'Admin settings updated');
        respondSuccess([], 'Settings updated');
    }

    // Update testimonial status (approve/reject)
    if ($collection === 'testimonials' && isset($body['status'])) {
        $newStatus = $body['status'];
        $updateFields = "status = ?";
        $params = [$newStatus];
        $types = 's';
        
        if ($newStatus === 'approved') {
            $updateFields .= ", approved_at = NOW()";
            addActivityLog('Testimonial Approved', "Testimonial ID $id approved");
        } elseif ($newStatus === 'rejected') {
            $updateFields .= ", rejected_at = NOW()";
            if (isset($body['rejection_reason'])) {
                $updateFields .= ", rejection_reason = ?";
                $params[] = $body['rejection_reason'];
                $types .= 's';
            }
            addActivityLog('Testimonial Rejected', "Testimonial ID $id rejected");
        }
        
        $params[] = $id;
        $types .= 'i';
        
        $affected = dbExecute("UPDATE testimonials SET $updateFields WHERE id = ?", $params, $types);
        if ($affected > 0) {
            respondSuccess([], 'Testimonial updated successfully');
        } else {
            respondError('Failed to update testimonial');
        }
    }

    // Update registration status - auto-create student record when approved
    if ($collection === 'registrations' && isset($body['status'])) {
        $newStatus = $body['status'];
        dbExecute("UPDATE registrations SET status = ? WHERE id = ?", [$newStatus, $id], 'si');
        
        // Auto-create student record when registration is approved
        if ($newStatus === 'Approved') {
            $reg = dbFetchOne("SELECT * FROM registrations WHERE id = ?", [$id], 'i');
            if ($reg) {
                // Parse student name
                $nameParts = explode(' ', trim($reg['student_name']), 2);
                $firstName = $nameParts[0];
                $lastName = $nameParts[1] ?? '';
                
                // Check if student already exists with same name and parent
                $existing = dbFetchOne(
                    "SELECT id FROM students WHERE first_name = ? AND last_name = ? AND parent_name = ?",
                    [$firstName, $lastName, $reg['parent_name']],
                    'sss'
                );
                
                $studentId = null;
                if (!$existing) {
                    $studentId = dbInsert(
                        "INSERT INTO students (first_name, last_name, grade, parent_name, phone, address, dob, status, registration_id) VALUES (?, ?, ?, ?, ?, ?, ?, 'Active', ?)",
                        [$firstName, $lastName, $reg['grade'], $reg['parent_name'], $reg['phone'], $reg['address'], $reg['dob'], $id],
                        'sssssssi'
                    );
                    addActivityLog('Student Created', "$firstName $lastName auto-created from registration #$id");
                } else {
                    $studentId = $existing['id'];
                    // Update existing student to link to this registration
                    dbExecute(
                        "UPDATE students SET registration_id = ? WHERE id = ?",
                        [$id, $studentId],
                        'ii'
                    );
                    addActivityLog('Student Linked', "$firstName $lastName linked to registration #$id");
                }
                
                // Update registration with student_id
                if ($studentId) {
                    dbExecute(
                        "UPDATE registrations SET student_id = ? WHERE id = ?",
                        [$studentId, $id],
                        'ii'
                    );
                }
                
                // Link student to parent account if parent exists
                if ($studentId && !empty($reg['parent_name'])) {
                    $parent = dbFetchOne(
                        "SELECT id, student_ids FROM parents WHERE CONCAT(first_name, ' ', last_name) = ?",
                        [$reg['parent_name']], 's'
                    );
                    if ($parent) {
                        $currentIds = $parent['student_ids'] ?? '';
                        $idsArray = array_filter(array_map('trim', explode(',', $currentIds)), 'is_numeric');
                        if (!in_array($studentId, $idsArray)) {
                            $idsArray[] = $studentId;
                            $newIds = implode(',', $idsArray);
                            dbExecute("UPDATE parents SET student_ids = ? WHERE id = ?", [$newIds, $parent['id']], 'si');
                            addActivityLog('Student Linked', "$firstName $lastName linked to parent #{$parent['id']}");
                        }
                    }
                }
            }
        }
        
        addActivityLog('Registration Updated', "Registration #$id status: $newStatus");
        respondSuccess([], "Registration $newStatus successfully");
    }

    // Update payment - full edit or status only
    if ($collection === 'payments') {
        // If only status is provided, quick update
        if (isset($body['status']) && count($body) === 1) {
            dbExecute("UPDATE payments SET status = ? WHERE id = ?", [$body['status'], $id], 'si');
            addActivityLog('Payment Updated', "Payment #$id status: {$body['status']}");
            respondSuccess([], "Payment {$body['status']} successfully");
        }
        // Full payment edit
        $fields = [];
        $params = [];
        $types = '';
        $payMap = [
            'payerName' => 'payer_name', 'studentName' => 'student_name',
            'amount' => 'amount', 'paymentType' => 'payment_type',
            'paymentMethod' => 'payment_method', 'phone' => 'phone',
            'status' => 'status', 'notes' => 'notes'
        ];
        foreach ($payMap as $camel => $col) {
            if (isset($body[$camel])) {
                $fields[] = "$col = ?";
                $params[] = $body[$camel];
                $types .= 's';
            }
        }
        if (!empty($fields)) {
            $params[] = $id;
            $types .= 'i';
            dbExecute("UPDATE payments SET " . implode(', ', $fields) . " WHERE id = ?", $params, $types);
            addActivityLog('Payment Updated', "Payment #$id updated");
            respondSuccess([], 'Payment updated successfully');
        }
        respondSuccess([], 'No payment fields to update');
    }

    // Mark message as read
    if ($collection === 'messages' && isset($body['read'])) {
        dbExecute("UPDATE messages SET is_read = ? WHERE id = ?", [$body['read'] ? 1 : 0, $id], 'ii');
        respondSuccess([], 'Message updated');
    }

    // Map fields for standard collections
    $updateData = [];
    $knownMaps = [
        'students' => [
            'firstName' => 'first_name', 'lastName' => 'last_name', 'gender' => 'gender',
            'grade' => 'grade', 'dob' => 'dob', 'parent' => 'parent_name',
            'phone' => 'phone', 'address' => 'address', 'status' => 'status',
            'emergencyContact' => 'emergency_contact', 'emergencyPhone' => 'emergency_phone',
            'medicalInfo' => 'medical_info', 'enrollmentDate' => 'enrollment_date',
            'feesStatus' => 'fees_status'
        ],
        'teachers' => [
            'firstName' => 'first_name', 'lastName' => 'last_name', 'username' => 'username',
            'email' => 'email', 'phone' => 'phone', 'subject' => 'subject',
            'qualification' => 'qualification', 'classAssigned' => 'class_assigned',
            'approved' => 'approved', 'password' => 'password',
            'dateOfEmployment' => 'date_of_employment', 'nationalId' => 'national_id',
            'residentialAddress' => 'residential_address', 'nextOfKin' => 'next_of_kin',
            'nextOfKinRelationship' => 'next_of_kin_relationship', 'nextOfKinPhone' => 'next_of_kin_phone'
        ],
        'parents' => [
            'firstName' => 'first_name', 'lastName' => 'last_name', 'username' => 'username',
            'email' => 'email', 'phone' => 'phone', 'password' => 'password',
            'studentIds' => 'student_ids', 'approved' => 'approved', 'isActive' => 'is_active'
        ],
        'admins' => [
            'firstName' => 'first_name', 'lastName' => 'last_name', 'username' => 'username',
            'email' => 'email', 'phone' => 'phone', 'password' => 'password',
            'role' => 'role', 'status' => 'status'
        ],
        'users' => [
            'firstName' => 'first_name', 'lastName' => 'last_name',
            'email' => 'email', 'phone' => 'phone', 'password' => 'password',
            'role' => 'role', 'status' => 'status', 'notes' => 'notes'
        ],
        'events' => ['title' => 'title', 'date' => 'date', 'time' => 'time', 'location' => 'location', 'description' => 'description', 'imageUrl' => 'image_url', 'videoUrl' => 'video_url', 'link' => 'link', 'status' => 'status'],
        'gallery' => ['imageUrl' => 'image_url', 'videoUrl' => 'video_url', 'mediaType' => 'media_type', 'title' => 'title', 'category' => 'category', 'description' => 'description'],
        'vacancies' => [
            'title' => 'title', 'description' => 'description', 'requirements' => 'requirements',
            'location' => 'location', 'positionType' => 'position_type', 'salaryRange' => 'salary_range',
            'applicationDeadline' => 'application_deadline', 'status' => 'status'
        ],
        'blog' => ['title' => 'title', 'author' => 'author', 'category' => 'category', 'content' => 'content', 'image' => 'image', 'status' => 'status'],
        'services' => ['title' => 'title', 'description' => 'description', 'icon' => 'icon'],
        'attendance' => ['studentId' => 'student_id', 'studentName' => 'student_name', 'studentClass' => 'class_name', 'date' => 'date', 'status' => 'status', 'remarks' => 'remarks'],
        'birthdays' => ['name' => 'name', 'type' => 'type', 'birthday' => 'birthday', 'class' => 'class', 'photo' => 'photo', 'message' => 'message', 'status' => 'status'],
        'announcements' => ['title' => 'title', 'content' => 'content', 'priority' => 'priority', 'targetAudience' => 'target_audience', 'status' => 'status', 'pinned' => 'pinned', 'createdBy' => 'created_by'],
        'teammembers' => ['firstName' => 'first_name', 'lastName' => 'last_name', 'role' => 'role', 'category' => 'category', 'imageUrl' => 'image_url', 'description' => 'description', 'sortOrder' => 'sort_order', 'status' => 'status', 'showOnWebsite' => 'show_on_website'],
        'courses' => ['title' => 'title', 'code' => 'code', 'description' => 'description', 'gradeLevel' => 'grade_level', 'credits' => 'credits', 'teacherId' => 'teacher_id', 'status' => 'status'],
        'notifications' => ['type' => 'type', 'title' => 'title', 'message' => 'message', 'icon' => 'icon', 'iconBg' => 'icon_bg', 'link' => 'link', 'linkLabel' => 'link_label', 'isRead' => 'is_read', 'priority' => 'priority', 'targetAudience' => 'target_audience', 'sourceType' => 'source_type', 'sourceId' => 'source_id'],
        'exams' => ['status' => 'status', 'approvedBy' => 'approved_by', 'approvedAt' => 'approved_at', 'adminNotes' => 'admin_notes'],
        'library' => ['title' => 'title', 'author' => 'author', 'isbn' => 'isbn', 'publisher' => 'publisher', 'year' => 'year', 'pages' => 'pages', 'category' => 'category', 'language' => 'language', 'tags' => 'tags', 'copies' => 'copies', 'available' => 'available', 'location' => 'location', 'status' => 'status', 'borrower' => 'borrower', 'borrowerType' => 'borrower_type', 'borrowedDate' => 'borrowed_date', 'dueDate' => 'due_date', 'description' => 'description'],
        'timetable' => ['day' => 'day', 'time' => 'time', 'endTime' => 'end_time', 'duration' => 'duration', 'period' => 'period', 'className' => 'class_name', 'subject' => 'subject', 'subjectCode' => 'subject_code', 'teacher' => 'teacher', 'room' => 'room', 'building' => 'building', 'roomType' => 'room_type', 'term' => 'term', 'academicYear' => 'academic_year', 'notes' => 'notes', 'recurring' => 'recurring'],
        'sports' => ['name' => 'name', 'type' => 'type', 'subCategory' => 'sub_category', 'description' => 'description', 'day' => 'day', 'time' => 'time', 'endTime' => 'end_time', 'duration' => 'duration', 'startDate' => 'start_date', 'endDate' => 'end_date', 'instructor' => 'instructor', 'instructorPhone' => 'instructor_phone', 'instructorEmail' => 'instructor_email', 'location' => 'location', 'minParticipants' => 'min_participants', 'maxParticipants' => 'max_participants', 'targetGroup' => 'target_group', 'feeRequired' => 'fee_required', 'feeAmount' => 'fee_amount', 'equipment' => 'equipment', 'requirements' => 'requirements', 'status' => 'status', 'currentParticipants' => 'current_participants'],
        'transport' => ['vehicleNumber' => 'vehicle_number', 'vehicleType' => 'vehicle_type', 'makeModel' => 'make_model', 'year' => 'year', 'color' => 'color', 'driverName' => 'driver_name', 'driverPhone' => 'driver_phone', 'driverLicense' => 'driver_license', 'driverAddress' => 'driver_address', 'route' => 'route', 'routeDetails' => 'route_details', 'morningTime' => 'morning_time', 'afternoonTime' => 'afternoon_time', 'capacity' => 'capacity', 'assignedStudents' => 'assigned_students', 'assignedClasses' => 'assigned_classes', 'status' => 'status', 'lastService' => 'last_service', 'nextService' => 'next_service', 'insuranceExpiry' => 'insurance_expiry', 'maintenanceNotes' => 'maintenance_notes', 'fuelType' => 'fuel_type', 'emergencyContact' => 'emergency_contact', 'notes' => 'notes'],
        'apis' => ['name' => 'name', 'type' => 'type', 'provider' => 'provider', 'endpoint' => 'endpoint', 'apiKey' => 'api_key', 'apiSecret' => 'api_secret', 'headers' => 'headers', 'status' => 'status', 'priority' => 'priority', 'description' => 'description']
    ];


    if (isset($knownMaps[$collection])) {
        $map = $knownMaps[$collection];
        foreach ($map as $camel => $snake) {
            if (isset($body[$camel])) {
                $updateData[$snake] = $body[$camel];
            }
        }
        // Also accept snake_case directly (skip camelCase keys not in the map)
        foreach ($body as $key => $value) {
            if (!isset($map[$key]) && $key !== 'id' && $key === strtolower($key) && !preg_match('/[A-Z]/', $key)) {
                $updateData[$key] = $value;
            }
        }
    } else {
        foreach ($body as $key => $value) {
            if ($key !== 'id') $updateData[$key] = $value;
        }
    }

    if (empty($updateData)) {
        respondError('No fields to update');
    }

    // Hash password for parents/teachers/admins if being updated
    if (($collection === 'parents' || $collection === 'teachers' || $collection === 'admins') && isset($updateData['password'])) {
        $pwd = $updateData['password'];
        if (!empty($pwd) && strpos($pwd, '$2y$') !== 0) {
            $updateData['password'] = password_hash($pwd, PASSWORD_DEFAULT);
        }
    }

    // Check for duplicate username when updating admins
    if ($collection === 'admins' && isset($updateData['username'])) {
        $existing = dbFetchOne("SELECT id FROM admins WHERE username = ? AND id != ?", [$updateData['username'], $id], 'si');
        if ($existing) {
            respondError('Username already exists. Please choose a different username.');
        }
    }

    $sets = [];
    $params = [];
    $types = '';
    foreach ($updateData as $col => $val) {
        $sets[] = "$col = ?";
        $params[] = $val;
        $types .= 's';
    }
    $params[] = $id;
    $types .= 'i';

    $affected = dbExecute("UPDATE $table SET " . implode(', ', $sets) . " WHERE id = ?", $params, $types);
    if ($affected !== false) {
        $label = ucfirst(rtrim($collection, 's'));
        addActivityLog("$label Updated", "$label #$id updated");
        respondSuccess([], "$label updated successfully");
    }
    respondError('Failed to update item');
}

// ============================================================
// DELETE
// ============================================================
function handleDelete($collection, $table, $id) {
    if (!$id) respondError('ID is required for deletion');

    // Special handling for testimonials to check if it exists
    if ($collection === 'testimonials') {
        $testimonial = dbFetchOne("SELECT * FROM testimonials WHERE id = ?", [$id], 'i');
        if (!$testimonial) respondError('Testimonial not found', 404);
        
        $affected = dbExecute("DELETE FROM testimonials WHERE id = ?", [$id], 'i');
        if ($affected > 0) {
            addActivityLog('Testimonial Deleted', "Testimonial #$id deleted");
            respondSuccess([], 'Testimonial deleted successfully');
        }
        respondError('Failed to delete testimonial');
    }

    $affected = dbExecute("DELETE FROM $table WHERE id = ?", [$id], 'i');
    if ($affected > 0) {
        $label = ucfirst(rtrim($collection, 's'));
        addActivityLog("$label Deleted", "$label #$id deleted");
        respondSuccess([], "$label deleted successfully");
    }
    respondError('Item not found', 404);
}
?>