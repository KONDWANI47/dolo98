/**
 * VISITOR TRACKING SCRIPT - Noah Christian Academy
 * Tracks website visitors by IP address and location data
 */

(function() {
    'use strict';

    // Configuration
    // Determine correct API path based on current page location
    const path = window.location.pathname;
    let apiEndpoint = 'api/index.php';
    if (path.includes('/html/')) apiEndpoint = '../api/index.php';
    else if (path.includes('/dashboard/')) apiEndpoint = '../api/index.php';
    else if (path.includes('/admin/')) apiEndpoint = '../api/index.php';

    const CONFIG = {
        apiEndpoint: apiEndpoint,
        trackingEnabled: true,
        trackInterval: 30000, // 30 seconds
        sessionTimeout: 1800000 // 30 minutes
    };

    // Visitor data storage
    let visitorData = {
        sessionId: null,
        ip: null,
        location: null,
        firstVisit: null,
        lastActivity: null,
        pageViews: 0,
        pages: []
    };

    // Initialize tracking
    function initTracking() {
        try {
            // Generate or retrieve session ID
            visitorData.sessionId = getSessionId();
            visitorData.firstVisit = getFirstVisit();
            visitorData.lastActivity = new Date().toISOString();
            
            // Track current page
            trackPageView();
            
            // Get IP and location
            getVisitorLocation();
            
            // Set up activity tracking
            setupActivityTracking();
            
            // Set up periodic updates
            startPeriodicUpdates();
            
            console.log('Visitor tracking initialized');
        } catch (error) {
            console.error('Error initializing visitor tracking:', error);
        }
    }

    // Get or create session ID
    function getSessionId() {
        let sessionId = localStorage.getItem('nca_visitor_session');
        if (!sessionId) {
            sessionId = generateSessionId();
            localStorage.setItem('nca_visitor_session', sessionId);
        }
        return sessionId;
    }

    // Generate unique session ID
    function generateSessionId() {
        return 'visitor_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }

    // Get first visit timestamp
    function getFirstVisit() {
        let firstVisit = localStorage.getItem('nca_first_visit');
        if (!firstVisit) {
            firstVisit = new Date().toISOString();
            localStorage.setItem('nca_first_visit', firstVisit);
        }
        return firstVisit;
    }

    // Track page view
    function trackPageView() {
        const currentPage = {
            url: window.location.href,
            path: window.location.pathname,
            title: document.title,
            timestamp: new Date().toISOString(),
            referrer: document.referrer || 'Direct'
        };
        
        visitorData.pages.push(currentPage);
        visitorData.pageViews++;
        visitorData.lastActivity = new Date().toISOString();
        
        // Keep only last 50 pages to avoid excessive storage
        if (visitorData.pages.length > 50) {
            visitorData.pages = visitorData.pages.slice(-50);
        }
        
        // Send page view data to server
        sendVisitorData('page_view');
    }

    // Get visitor location using IP geolocation
    async function getVisitorLocation() {
        try {
            // Try multiple IP geolocation services for redundancy
            const services = [
                'https://ipapi.co/json/',
                'https://api.ipify.org?format=json',
                'https://ip.geolocation.io/ipgeo?apiKey=free'
            ];

            let locationData = null;

            for (const service of services) {
                try {
                    const response = await fetch(service);
                    const data = await response.json();
                    
                    if (data && (data.ip || data.latitude)) {
                        locationData = parseLocationData(data);
                        break;
                    }
                } catch (serviceError) {
                    console.warn('Failed to get location from service:', service, serviceError);
                    continue;
                }
            }

            if (locationData) {
                visitorData.ip = locationData.ip;
                visitorData.location = locationData;
                sendVisitorData('location_update');
            } else {
                // Fallback to basic IP detection
                visitorData.ip = await getBasicIP();
                sendVisitorData('location_update');
            }
        } catch (error) {
            console.error('Error getting visitor location:', error);
            // Still try to send basic data
            visitorData.ip = await getBasicIP();
            sendVisitorData('location_update');
        }
    }

    // Parse location data from different services
    function parseLocationData(data) {
        // Handle different API response formats
        return {
            ip: data.ip || data.ipAddress,
            city: data.city || data.city_name,
            region: data.region || data.region_name || data.state,
            country: data.country_name || data.country,
            countryCode: data.country_code || data.countryCode,
            latitude: data.latitude || data.lat,
            longitude: data.longitude || data.lon || data.lng,
            postal: data.postal || data.zip,
            isp: data.org || data.isp || data.asn,
            timezone: data.timezone,
            continent: data.continent
        };
    }

    // Get basic IP address
    async function getBasicIP() {
        try {
            const response = await fetch('https://api.ipify.org?format=json');
            const data = await response.json();
            return data.ip;
        } catch (error) {
            console.error('Error getting basic IP:', error);
            return 'Unknown';
        }
    }

    // Send visitor data to server
    async function sendVisitorData(action) {
        if (!CONFIG.trackingEnabled) return;

        try {
            const payload = {
                action: action,
                session_id: visitorData.sessionId,
                ip: visitorData.ip,
                location: visitorData.location,
                page_views: visitorData.pageViews,
                current_page: window.location.href,
                referrer: document.referrer || 'Direct',
                user_agent: navigator.userAgent,
                first_visit: visitorData.firstVisit,
                last_activity: visitorData.lastActivity,
                pages: visitorData.pages.slice(-10) // Send last 10 pages
            };

            const response = await fetch(`${CONFIG.apiEndpoint}?type=visitor_tracking&action=${action}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(payload)
            });

            if (response.ok) {
                const result = await response.json();
                if (result.success) {
                    console.log('Visitor data sent successfully');
                }
            }
        } catch (error) {
            console.error('Error sending visitor data:', error);
            // Store failed requests for retry
            storeFailedRequest(payload);
        }
    }

    // Store failed requests for retry
    function storeFailedRequest(payload) {
        let failedRequests = JSON.parse(localStorage.getItem('nca_failed_requests') || '[]');
        failedRequests.push({
            payload: payload,
            timestamp: new Date().toISOString()
        });
        
        // Keep only last 20 failed requests
        if (failedRequests.length > 20) {
            failedRequests = failedRequests.slice(-20);
        }
        
        localStorage.setItem('nca_failed_requests', JSON.stringify(failedRequests));
    }

    // Retry failed requests
    async function retryFailedRequests() {
        const failedRequests = JSON.parse(localStorage.getItem('nca_failed_requests') || '[]');
        if (failedRequests.length === 0) return;

        for (const request of failedRequests) {
            try {
                const response = await fetch(`${CONFIG.apiEndpoint}?type=visitor_tracking&action=${request.payload.action}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(request.payload)
                });

                if (response.ok) {
                    // Remove successful request from failed list
                    const index = failedRequests.indexOf(request);
                    if (index > -1) {
                        failedRequests.splice(index, 1);
                    }
                }
            } catch (error) {
                console.error('Retry failed:', error);
            }
        }

        localStorage.setItem('nca_failed_requests', JSON.stringify(failedRequests));
    }

    // Set up activity tracking
    function setupActivityTracking() {
        // Track mouse movements and clicks for engagement
        let activityTimeout;
        
        function recordActivity() {
            visitorData.lastActivity = new Date().toISOString();
            clearTimeout(activityTimeout);
            
            activityTimeout = setTimeout(() => {
                // Send activity update after 30 seconds of inactivity
                sendVisitorData('activity_update');
            }, 30000);
        }

        // Event listeners for activity tracking
        document.addEventListener('mousemove', recordActivity);
        document.addEventListener('click', recordActivity);
        document.addEventListener('scroll', recordActivity);
        document.addEventListener('keydown', recordActivity);

        // Track page visibility changes
        document.addEventListener('visibilitychange', () => {
            if (document.visibilityState === 'visible') {
                visitorData.lastActivity = new Date().toISOString();
                sendVisitorData('page_view');
            }
        });

        // Track page unload
        window.addEventListener('beforeunload', () => {
            sendVisitorData('session_end');
        });
    }

    // Start periodic updates
    function startPeriodicUpdates() {
        // Send location updates every 5 minutes
        setInterval(() => {
            visitorData.lastActivity = new Date().toISOString();
            sendVisitorData('heartbeat');
        }, CONFIG.trackInterval);

        // Retry failed requests every 2 minutes
        setInterval(retryFailedRequests, 120000);
    }

    // Get enhanced location details with address
    async function getEnhancedLocationDetails(lat, lng) {
        try {
            // Google Maps Geocoding API disabled - requires valid API key
            // To enable, add your Google Maps API key to localStorage with key 'nca_google_maps_api_key'
            const googleApiKey = localStorage.getItem('nca_google_maps_api_key');
            
            if (!googleApiKey) {
                console.warn('Google Maps API key not configured - enhanced location details disabled');
                return null;
            }

            const response = await fetch(
                `https://maps.googleapis.com/maps/api/geocode/json?latlng=${lat},${lng}&key=${googleApiKey}`
            );
            
            const data = await response.json();
            
            if (data.status === 'OK' && data.results.length > 0) {
                const result = data.results[0];
                return {
                    formatted_address: result.formatted_address,
                    address_components: result.address_components,
                    types: result.types
                };
            }
        } catch (error) {
            console.error('Error getting enhanced location details:', error);
        }
        
        return null;
    }

    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initTracking);
    } else {
        initTracking();
    }

    // Expose some functions globally for debugging
    window.VisitorTracker = {
        getData: () => visitorData,
        getSessionId: () => visitorData.sessionId,
        updateLocation: getVisitorLocation,
        getEnhancedLocation: getEnhancedLocationDetails
    };

})();