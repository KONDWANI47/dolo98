/**
 * ADMIN DASHBOARD SCRIPT - Noah Christian Academy
 * Complete Admin Panel using MySQL API backend
 */

const API_BASE = '../api/index.php';

// Initialize login and register form event listeners when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }
    
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', handleRegister);
    }
});

// ===== SAFE FETCH HELPER =====
async function safeFetch(response) {
    if (!response.ok) {
        const text = await response.text();
        try {
            return JSON.parse(text);
        } catch {
            return { success: false, message: `HTTP ${response.status}: ${text || 'No response body'}` };
        }
    }
    
    const text = await response.text();
    if (!text.trim()) {
        return { success: false, message: 'Empty response from server' };
    }
    
    try {
        return JSON.parse(text);
    } catch (parseErr) {
        return { success: false, message: 'Invalid JSON response from server' };
    }
}

// ===== DATA FETCHING =====
async function apiFetch(type, collection, method = 'GET', body = null, id = null) {
    let url = `${API_BASE}?type=${type}&collection=${collection}`;
    if (id) url += `&id=${id}`;
    
    const options = {
        method: method
    };
    
    // Handle FormData (file uploads) vs JSON
    if (body instanceof FormData) {
        // Don't set Content-Type header for FormData - browser sets it automatically with boundary
        options.body = body;
    } else if (body && (method === 'POST' || method === 'PUT')) {
        options.headers = { 'Content-Type': 'application/json' };
        options.body = JSON.stringify(body);
    } else {
        options.headers = { 'Content-Type': 'application/json' };
    }
    
    try {
        const response = await fetch(url, options);
        return await safeFetch(response);
    } catch (err) {
        console.error('API Error:', err);
        return { success: false, message: err.message };
    }
}

async function apiAuth(action, body) {
    try {
        console.log('API Auth Request:', { action, body });
        
        const response = await fetch(`${API_BASE}?type=auth&action=${action}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body)
        });
        
        console.log('API Response Status:', response.status);
        
        if (!response.ok) {
            const text = await response.text();
            console.error('API Error Response:', text);
            try {
                return JSON.parse(text);
            } catch {
                return { success: false, message: `HTTP ${response.status}: ${text || 'No response body'}` };
            }
        }
        
        const text = await response.text();
        console.log('API Response Text:', text);
        
        if (!text.trim()) {
            return { success: false, message: 'Empty response from server' };
        }
        
        const data = JSON.parse(text);
        console.log('API Parsed Response:', data);
        return data;
    } catch (err) {
        console.error('API Network Error:', err);
        return { success: false, message: err.message };
    }
}

async function apiTeacher(action, params = {}, body = null) {
    let url = `${API_BASE}?type=teacher&action=${action}`;
    for (const [k, v] of Object.entries(params)) {
        url += `&${k}=${encodeURIComponent(v)}`;
    }
    const options = {
        method: body ? 'POST' : 'GET',
        headers: { 'Content-Type': 'application/json' }
    };
    if (body) options.body = JSON.stringify(body);
    try {
        const response = await fetch(url, options);
        
        if (!response.ok) {
            const text = await response.text();
            try {
                return JSON.parse(text);
            } catch {
                return { success: false, message: `HTTP ${response.status}: ${text || 'No response body'}` };
            }
        }
        
        const text = await response.text();
        if (!text.trim()) {
            return { success: false, message: 'Empty response from server' };
        }
        
        return JSON.parse(text);
    } catch (err) {
        return { success: false, message: err.message };
    }
}

async function apiReportWorkflow(action, params = {}, body = null) {
    let url = `${API_BASE}?type=report_workflow&action=${action}`;
    for (const [k, v] of Object.entries(params)) {
        url += `&${k}=${encodeURIComponent(v)}`;
    }
    const options = {
        method: body ? 'POST' : 'GET',
        headers: { 'Content-Type': 'application/json' }
    };
    if (body) options.body = JSON.stringify(body);
    try {
        const response = await fetch(url, options);
        const text = await response.text();
        if (!text || text.trim() === '') {
            return { success: false, message: 'Server returned empty response' };
        }
        try {
            return JSON.parse(text);
        } catch (parseErr) {
            return { success: false, message: 'Invalid server response' };
        }
    } catch (err) {
        return { success: false, message: err.message };
    }
}

// ===== STATE =====
let currentUser = null;

// ===== ONBOARDING STATE =====
let adminOnboardingStep = 1;
const adminTotalOnboardingSteps = 5;
let adminOnboardingCompleted = false;

// ===== TOAST =====
function showToast(message, type = 'success') {
    const container = document.getElementById('toastContainer');
    if (!container) return;
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    const icons = { success: 'fa-check-circle', error: 'fa-times-circle', info: 'fa-info-circle', warning: 'fa-exclamation-triangle' };
    toast.innerHTML = `<i class="fas ${icons[type] || icons.info}"></i> ${message}`;
    container.appendChild(toast);
    setTimeout(() => {
        toast.classList.add('toast-removing');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// ===== SHOW PASSWORD TOGGLE =====
function togglePasswordVisibility(inputId, iconId) {
    const input = document.getElementById(inputId);
    const icon = document.getElementById(iconId);
    
    if (!input) {
        console.error('Password input not found with ID:', inputId);
        return;
    }
    
    if (!icon) {
        console.error('Password icon not found with ID:', iconId);
        // Still toggle the input even if icon is missing
        if (input.type === 'password') {
            input.type = 'text';
        } else {
            input.type = 'password';
        }
        return;
    }
    
    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        input.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}

// ===== SESSION PERSISTENCE =====
function saveAdminSession(userData, remember) {
    if (remember) {
        localStorage.setItem('noh_admin_session', JSON.stringify(userData));
    } else {
        sessionStorage.setItem('noh_admin_session', JSON.stringify(userData));
    }
}

function loadAdminSession() {
    // Check localStorage first (remember me), then sessionStorage
    let data = localStorage.getItem('noh_admin_session');
    if (data) return JSON.parse(data);
    data = sessionStorage.getItem('noh_admin_session');
    if (data) return JSON.parse(data);
    return null;
}

function clearAdminSession() {
    localStorage.removeItem('noh_admin_session');
    sessionStorage.removeItem('noh_admin_session');
}

// ===== AUTO LOGIN ON PAGE LOAD =====
async function autoLogin() {
    // Check for OAuth token in URL first
    const urlParams = new URLSearchParams(window.location.search);
    const oauthToken = urlParams.get('oauth_token');

    if (oauthToken) {
        // Exchange OAuth token for session
        const result = await apiAuth('oauth_exchange', { token: oauthToken });
        if (result.success && result.data) {
            currentUser = result.data;
            saveAdminSession(result.data, true);
            document.getElementById('loginScreen').style.display = 'none';
            document.getElementById('dashboardScreen').style.display = 'flex';
            document.getElementById('adminUserName').textContent = result.data.displayName || 'Admin';
            document.getElementById('dashboardUserName').textContent = result.data.displayName || 'Admin';

            loadAllSections();
            startClock();

            // Initialize onboarding for first-time users
            initializeAdminOnboarding();

            // Clean URL
            window.history.replaceState({}, document.title, window.location.pathname);
            return true;
        } else {
            const errorEl = document.getElementById('loginError');
            if (errorEl) {
                errorEl.textContent = result.message || 'Google login failed';
                errorEl.classList.add('show');
            }
            return false;
        }
    }

    const savedUser = loadAdminSession();
    if (savedUser && savedUser.username) {
        currentUser = savedUser;

        // Save for AI chat
        localStorage.setItem('admin_id', savedUser.id);
        localStorage.setItem('user_role', 'admin');

        document.getElementById('loginScreen').style.display = 'none';
        document.getElementById('dashboardScreen').style.display = 'flex';
        document.getElementById('adminUserName').textContent = savedUser.displayName || 'Admin';
        document.getElementById('dashboardUserName').textContent = savedUser.displayName || 'Admin';
        loadAllSections();
        startClock();

        // Initialize onboarding for first-time users
        initializeAdminOnboarding();

        return true;
    }
    return false;
}

// ===== TOGGLE AUTH FORMS =====
function toggleAuthForms(form) {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    
    if (form === 'register') {
        loginForm.style.display = 'none';
        registerForm.style.display = 'block';
        showRegStep1();
    } else {
        registerForm.style.display = 'none';
        loginForm.style.display = 'block';
    }
}

// ===== REGISTRATION STEP NAVIGATION =====
function showRegStep1() {
    document.getElementById('regStep1').style.display = 'block';
    document.getElementById('regStep2').style.display = 'none';
    document.getElementById('regStep3').style.display = 'none';
    const errorEl = document.getElementById('registerError');
    if (errorEl) {
        errorEl.classList.remove('show');
        errorEl.textContent = '';
    }
}

function showRegStep2() {
    const email = document.getElementById('regEmail').value.trim();
    const password = document.getElementById('regPassword').value;
    const errorEl = document.getElementById('registerError');
    
    // Validate step 1
    if (!email || !password) {
        if (errorEl) {
            errorEl.textContent = 'Please enter both email and password';
            errorEl.classList.add('show');
        }
        return;
    }
    if (!email.includes('@') || !email.includes('.')) {
        if (errorEl) {
            errorEl.textContent = 'Please enter a valid email address';
            errorEl.classList.add('show');
        }
        return;
    }
    if (password.length < 8) {
        if (errorEl) {
            errorEl.textContent = 'Password must be at least 8 characters';
            errorEl.classList.add('show');
        }
        return;
    }
    
    // Show step 2
    document.getElementById('regStep1').style.display = 'none';
    document.getElementById('regStep2').style.display = 'block';
    document.getElementById('regStep3').style.display = 'none';
    // Hide code display
    const codeDisplay = document.getElementById('regCodeDisplay');
    if (codeDisplay) {
        codeDisplay.style.display = 'none';
    }
    if (errorEl) {
        errorEl.classList.remove('show');
        errorEl.textContent = '';
    }
}

// ===== REGISTER =====
async function handleRegister(event) {
    if (event) {
        event.preventDefault();
    }

    const fullName = document.getElementById('regFullName')?.value.trim();
    const email = document.getElementById('regEmail')?.value.trim();
    const password = document.getElementById('regPassword')?.value.trim();
    const confirmPassword = document.getElementById('regConfirmPassword')?.value.trim();
    const errorEl = document.getElementById('registerError');

    // Split full name into first and last name
    let firstName = '';
    let lastName = '';
    if (fullName) {
        const nameParts = fullName.trim().split(/\s+/);
        firstName = nameParts[0] || '';
        lastName = nameParts.slice(1).join(' ') || '';
    }

    // Validation
    if (!firstName || !lastName || !email || !password || !confirmPassword) {
        if (errorEl) {
            errorEl.textContent = 'All fields are required';
            errorEl.classList.add('show');
        }
        return false;
    }

    if (password !== confirmPassword) {
        if (errorEl) {
            errorEl.textContent = 'Passwords do not match';
            errorEl.classList.add('show');
        }
        return false;
    }

    if (password.length < 8) {
        if (errorEl) {
            errorEl.textContent = 'Password must be at least 8 characters';
            errorEl.classList.add('show');
        }
        return false;
    }

    const result = await apiAuth('admin_register', {
        firstName,
        lastName,
        email,
        password
    });

    if (result.success) {
        if (result.requiresCode) {
            // Show verification code step
            showRegStep3();
            if (errorEl) {
                errorEl.classList.remove('show');
            }

            // Always show the code on screen (for now, since email might be flaky)
            if (result.code) {
                const codeDisplay = document.getElementById('regCodeDisplay');
                const codeValue = document.getElementById('regCodeValue');
                if (codeDisplay && codeValue) {
                    codeValue.textContent = result.code;
                    codeDisplay.style.display = 'block';
                }
                showToast('Your verification code is: ' + result.code, 'success');
            } else {
                showToast('Account created! Please enter the verification code sent to your email.', 'success');
            }
        } else {
            showToast('Account created successfully! You can now log in.', 'success');
            toggleAuthForms('login');
            document.getElementById('registerForm').reset();
            showRegStep1();
        }
    } else {
        if (errorEl) {
            errorEl.textContent = result.message || 'Registration failed';
            errorEl.classList.add('show');
        }
    }
}

function showRegStep3() {
    console.log('Showing Step 3');
    document.getElementById('regStep1').style.display = 'none';
    document.getElementById('regStep2').style.display = 'none';
    document.getElementById('regStep3').style.display = 'block';
}

async function verifyAdminCode() {
    const code = document.getElementById('regCode')?.value.trim().toUpperCase();
    const errorEl = document.getElementById('verifyError');

    if (!code) {
        if (errorEl) {
            errorEl.textContent = 'Please enter the verification code';
            errorEl.classList.add('show');
        }
        return;
    }

    const result = await apiAuth('verify_code', { code: code, type: 'admin' });

    if (result.success) {
        showToast('Account verified successfully! You can now log in.', 'success');
        toggleAuthForms('login');
        document.getElementById('registerForm').reset();
        showRegStep1();
        if (errorEl) {
            errorEl.classList.remove('show');
        }
    } else {
        if (errorEl) {
            errorEl.textContent = result.message || 'Invalid code';
            errorEl.classList.add('show');
        }
    }
}

// ===== LOGIN =====
async function handleLogin(event) {
    if (event) {
        event.preventDefault();
    }
    
    const username = document.getElementById('username')?.value.trim();
    const password = document.getElementById('password')?.value.trim();
    const errorEl = document.getElementById('loginError');
    const rememberMe = document.getElementById('rememberMe') ? document.getElementById('rememberMe').checked : false;
    
    if (!username || !password) {
        if (errorEl) {
            errorEl.textContent = 'Username and password are required';
            errorEl.classList.add('show');
        }
        return false;
    }
    
    const result = await apiAuth('admin_login', { username, password });
    
    if (result.success) {
        currentUser = result.data;
        saveAdminSession(result.data, rememberMe);

        // Save for AI chat
        localStorage.setItem('admin_id', result.data.id);
        localStorage.setItem('user_role', 'admin');

        document.getElementById('loginScreen').style.display = 'none';
        document.getElementById('dashboardScreen').style.display = 'flex';
        document.getElementById('adminUserName').textContent = result.data.displayName;
        document.getElementById('dashboardUserName').textContent = result.data.displayName;
        errorEl.classList.remove('show');

        // Check for default credentials warning
        checkDefaultCredentials();
        
        loadAllSections();
        startClock();
        
        // Initialize onboarding for first-time users
        initializeAdminOnboarding();
    } else {
        errorEl.textContent = result.message || 'Invalid username or password';
        errorEl.classList.add('show');
    }
    return false;
}

function handleLogout() {
    currentUser = null;
    clearAdminSession();

    // Clear AI chat session
    localStorage.removeItem('admin_id');
    localStorage.removeItem('user_role');

    document.getElementById('loginScreen').style.display = 'flex';
    document.getElementById('dashboardScreen').style.display = 'none';
    document.getElementById('userMenu').classList.remove('show');
}

// ===== CLOCK =====
function startClock() {
    function update() {
        const now = new Date();
        document.getElementById('currentDateTime').textContent = now.toLocaleString('en-US', {
            weekday: 'short', year: 'numeric', month: 'short', day: 'numeric',
            hour: '2-digit', minute: '2-digit', second: '2-digit'
        });
    }
    update();
    setInterval(update, 1000);
}

// ===== DEFAULT CREDENTIALS WARNING =====
function checkDefaultCredentials() {
    console.log('Checking default credentials for:', currentUser?.username);
    if (!currentUser) return;
    
    // Default credentials check
    const defaultUsername = 'admin';
    const defaultPassword = 'admin123';
    
    if (currentUser.username === defaultUsername) {
        console.log('Default credentials detected, showing warning');
        showDefaultCredentialsWarning();
    }
}

function showDefaultCredentialsWarning() {
    console.log('Showing default credentials warning');
    // Create warning banner if it doesn't exist
    let warningBanner = document.getElementById('defaultCredentialsWarning');
    if (!warningBanner) {
        warningBanner = document.createElement('div');
        warningBanner.id = 'defaultCredentialsWarning';
        warningBanner.style.cssText = `
            position: fixed;
            top: 60px;
            left: 0;
            right: 0;
            background: linear-gradient(135deg, #dc3545, #c82333);
            color: white;
            padding: 15px 20px;
            z-index: 9999;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 4px 15px rgba(220, 53, 69, 0.3);
            border-bottom: 3px solid #bd2130;
        `;
        
        warningBanner.innerHTML = `
            <div style="display: flex; align-items: center; gap: 15px;">
                <i class="fas fa-exclamation-triangle" style="font-size: 24px;"></i>
                <div>
                    <strong style="display: block; font-size: 16px; margin-bottom: 3px;">⚠️ Security Warning: Default Credentials in Use</strong>
                    <span style="font-size: 14px; opacity: 0.95;">You are using the default admin credentials. Please change your username and password immediately for security.</span>
                </div>
            </div>
            <div style="display: flex; gap: 10px;">
                <button onclick="showSection('settings')" style="background: rgba(255,255,255,0.2); color: white; border: 1px solid rgba(255,255,255,0.4); padding: 8px 16px; border-radius: 6px; cursor: pointer; font-size: 13px; font-weight: 600; transition: all 0.2s;">
                    <i class="fas fa-cog"></i> Change Now
                </button>
                <button onclick="dismissDefaultCredentialsWarning()" style="background: rgba(255,255,255,0.1); color: white; border: 1px solid rgba(255,255,255,0.3); padding: 8px 12px; border-radius: 6px; cursor: pointer; font-size: 16px; transition: all 0.2s;">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `;
        
        document.body.appendChild(warningBanner);
        
        // Add hover effects to buttons
        const buttons = warningBanner.querySelectorAll('button');
        buttons.forEach(btn => {
            btn.addEventListener('mouseenter', () => {
                btn.style.background = 'rgba(255,255,255,0.3)';
            });
            btn.addEventListener('mouseleave', () => {
                btn.style.background = 'rgba(255,255,255,0.1)';
            });
        });
    }
}

function dismissDefaultCredentialsWarning() {
    const warningBanner = document.getElementById('defaultCredentialsWarning');
    if (warningBanner) {
        warningBanner.style.transition = 'all 0.3s ease';
        warningBanner.style.opacity = '0';
        warningBanner.style.transform = 'translateY(-100%)';
        setTimeout(() => {
            warningBanner.remove();
        }, 300);
    }
}

// Export functions to window object
window.checkDefaultCredentials = checkDefaultCredentials;
window.showDefaultCredentialsWarning = showDefaultCredentialsWarning;
window.dismissDefaultCredentialsWarning = dismissDefaultCredentialsWarning;

// ===== SIDEBAR =====
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    sidebar.classList.toggle('open');
    
    // Close sidebar when clicking outside on mobile
    if (window.innerWidth <= 991 && sidebar.classList.contains('open')) {
        document.addEventListener('click', closeSidebarOnClickOutside);
    }
}

function closeSidebarOnClickOutside(e) {
    const sidebar = document.getElementById('sidebar');
    const toggleBtn = document.getElementById('sidebarToggle');
    
    if (sidebar && !sidebar.contains(e.target) && toggleBtn && !toggleBtn.contains(e.target)) {
        sidebar.classList.remove('open');
        document.removeEventListener('click', closeSidebarOnClickOutside);
    }
}

function toggleUserMenu() {
    document.getElementById('userMenu').classList.toggle('show');
}

document.addEventListener('click', function(e) {
    const menu = document.getElementById('userMenu');
    const btn = document.querySelector('.admin-user-dropdown button');
    if (menu && btn && !btn.contains(e.target) && !menu.contains(e.target)) {
        menu.classList.remove('show');
    }
    
    // Close sidebar on mobile when clicking outside
    const sidebar = document.getElementById('sidebar');
    if (sidebar && window.innerWidth <= 991 && sidebar.classList.contains('open')) {
        const toggleBtn = document.getElementById('sidebarToggle');
        if (!sidebar.contains(e.target) && toggleBtn && !toggleBtn.contains(e.target)) {
            sidebar.classList.remove('open');
        }
    }
});

// Close sidebar on window resize if switching to desktop
window.addEventListener('resize', function() {
    const sidebar = document.getElementById('sidebar');
    if (window.innerWidth > 991 && sidebar) {
        sidebar.classList.remove('open');
    }
});

// ===== USER MANAGEMENT =====
let usersData = [];

async function renderUsers() {
    const tbody = document.getElementById('usersTableBody');
    if (!tbody) return;

    try {
        const search = document.getElementById('userSearch')?.value.toLowerCase() || '';
        const roleFilter = document.getElementById('userRoleFilter')?.value || '';
        const statusFilter = document.getElementById('userStatusFilter')?.value || '';

        let url = API_BASE + '?type=admin&collection=users';
        const response = await fetch(url);
        const data = await safeFetch(response);

        if (data.success && data.data) {
            usersData = Array.isArray(data.data) ? data.data : [];
            
            // Filter users
            let filteredUsers = usersData.filter(user => {
                const matchesSearch = !search || 
                    user.name?.toLowerCase().includes(search) ||
                    user.email?.toLowerCase().includes(search);
                const matchesRole = !roleFilter || user.role === roleFilter;
                const matchesStatus = !statusFilter || user.status === statusFilter;
                return matchesSearch && matchesRole && matchesStatus;
            });

            if (filteredUsers.length === 0) {
                tbody.innerHTML = '<tr><td colspan="8" class="text-center text-muted">No users found.</td></tr>';
            } else {
                tbody.innerHTML = filteredUsers.map((user, index) => `
                    <tr>
                        <td>${index + 1}</td>
                        <td><strong>${user.name || 'N/A'}</strong></td>
                        <td>${user.email || 'N/A'}</td>
                        <td><span class="status-badge ${user.role === 'admin' ? 'priority-urgent' : user.role === 'teacher' ? 'priority-important' : 'priority-normal'}">${user.role || 'N/A'}</span></td>
                        <td><span class="status-badge ${user.status === 'active' ? 'active' : 'inactive'}">${user.status || 'N/A'}</span></td>
                        <td>${formatDate(user.created_at) || 'N/A'}</td>
                        <td>${formatDate(user.last_login) || 'Never'}</td>
                        <td>
                            <button class="admin-btn admin-btn-sm admin-btn-primary" onclick="editUser(${user.id})" title="Edit"><i class="fas fa-edit"></i></button>
                            <button class="admin-btn admin-btn-sm admin-btn-warning" onclick="resetUserPassword(${user.id})" title="Reset Password"><i class="fas fa-key"></i></button>
                            <button class="admin-btn admin-btn-sm admin-btn-danger" onclick="deleteUser(${user.id})" title="Delete"><i class="fas fa-trash"></i></button>
                        </td>
                    </tr>
                `).join('');
            }

            updateUserStats();
        } else {
            tbody.innerHTML = '<tr><td colspan="8" class="text-center text-muted">Error loading users.</td></tr>';
        }
    } catch (error) {
        console.error('Error rendering users:', error);
        tbody.innerHTML = '<tr><td colspan="8" class="text-center text-danger">Error loading users.</td></tr>';
    }
}

function updateUserStats() {
    const total = usersData.length;
    const active = usersData.filter(u => u.status === 'active').length;
    const inactive = usersData.filter(u => u.status === 'inactive').length;
    const admins = usersData.filter(u => u.role === 'admin').length;

    document.getElementById('totalUsersCount').textContent = total;
    document.getElementById('activeUsersCount').textContent = active;
    document.getElementById('inactiveUsersCount').textContent = inactive;
    document.getElementById('adminUsersCount').textContent = admins;
}

function openUserModal(userId = null) {
    const modal = document.getElementById('userModal');
    const title = document.getElementById('userModalTitle');
    const form = document.getElementById('userForm');

    form.reset();
    document.getElementById('userId').value = '';

    if (userId) {
        const user = usersData.find(u => u.id === userId);
        if (user) {
            title.innerHTML = '<i class="fas fa-edit"></i> Edit User';
            document.getElementById('userId').value = user.id;
            document.getElementById('userFirstName').value = user.first_name || '';
            document.getElementById('userLastName').value = user.last_name || '';
            document.getElementById('userEmail').value = user.email || '';
            document.getElementById('userRole').value = user.role || '';
            document.getElementById('userPassword').value = '';
            document.getElementById('userPassword').required = false;
            document.getElementById('userPhone').value = user.phone || '';
            document.getElementById('userStatus').value = user.status || 'active';
            document.getElementById('userNotes').value = user.notes || '';
        }
    } else {
        title.innerHTML = '<i class="fas fa-user-plus"></i> Add User';
        document.getElementById('userPassword').required = true;
        document.getElementById('userStatus').value = 'active';
    }

    openModal('userModal');
}

async function saveUser(event) {
    event.preventDefault();

    const userId = document.getElementById('userId').value;
    const userData = {
        first_name: document.getElementById('userFirstName').value,
        last_name: document.getElementById('userLastName').value,
        email: document.getElementById('userEmail').value,
        role: document.getElementById('userRole').value,
        phone: document.getElementById('userPhone').value,
        status: document.getElementById('userStatus').value,
        notes: document.getElementById('userNotes').value
    };

    const password = document.getElementById('userPassword').value;
    if (password) {
        userData.password = password;
    }

    try {
        let response;
        if (userId) {
            response = await fetch(`${API_BASE}?type=admin&collection=users&id=${userId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(userData)
            });
        } else {
            response = await fetch(`${API_BASE}?type=admin&collection=users`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(userData)
            });
        }

        const result = await safeFetch(response);

        if (result.success) {
            showToast(userId ? 'User updated successfully!' : 'User added successfully!', 'success');
            closeModal();
            renderUsers();
        } else {
            showToast(result.message || 'Failed to save user', 'error');
        }
    } catch (error) {
        console.error('Error saving user:', error);
        showToast('Error saving user', 'error');
    }

    return false;
}

function editUser(userId) {
    openUserModal(userId);
}

async function deleteUser(userId) {
    const user = usersData.find(u => u.id === userId);
    if (!user) return;

    if (!confirm(`Are you sure you want to delete user "${user.name}"? This action cannot be undone.`)) return;

    try {
        const response = await fetch(`${API_BASE}?type=admin&collection=users&id=${userId}`, {
            method: 'DELETE'
        });

        const result = await safeFetch(response);

        if (result.success) {
            showToast('User deleted successfully!', 'success');
            renderUsers();
        } else {
            showToast(result.message || 'Failed to delete user', 'error');
        }
    } catch (error) {
        console.error('Error deleting user:', error);
        showToast('Error deleting user', 'error');
    }
}

async function resetUserPassword(userId) {
    const user = usersData.find(u => u.id === userId);
    if (!user) return;

    const newPassword = prompt(`Enter new password for ${user.name}:`, 'user123');
    if (!newPassword || newPassword.length < 4) {
        showToast('Password must be at least 4 characters', 'error');
        return;
    }

    try {
        const response = await fetch(`${API_BASE}?type=admin&collection=users&action=reset_password&id=${userId}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ password: newPassword })
        });

        const result = await safeFetch(response);

        if (result.success) {
            showToast('Password reset successfully!', 'success');
        } else {
            showToast(result.message || 'Failed to reset password', 'error');
        }
    } catch (error) {
        console.error('Error resetting password:', error);
        showToast('Error resetting password', 'error');
    }
}

async function exportUsers() {
    try {
        const response = await fetch(API_BASE + '?type=admin&collection=users');
        const data = await safeFetch(response);

        if (!data.success || !data.data || data.data.length === 0) {
            showToast('No users to export', 'warning');
            return;
        }

        const users = data.data;
        const csvHeader = 'ID,Name,Email,Role,Phone,Status,Created,Last Login\n';
        const csvRows = users.map(u => 
            `${u.id},"${u.name}","${u.email}","${u.role}","${u.phone || ''}","${u.status}","${u.created_at}","${u.last_login || 'Never'}"`
        ).join('\n');

        downloadCSV(csvHeader + csvRows, 'users.csv');
        showToast('Users exported successfully', 'success');
    } catch (error) {
        console.error('Error exporting users:', error);
        showToast('Error exporting users', 'error');
    }
}

// ===== COLOR MANAGEMENT =====
const defaultColors = {
    primary: '#085636',
    primaryDark: '#1b5e20',
    accent: '#fff3a0',
    accentStrong: '#f1de6d',
    textLight: '#f6fff4',
    textDark: '#173423',
    surface: '#f7fbf8',
    surfaceStrong: '#eef7ef'
};

let currentColors = { ...defaultColors };

function loadColors() {
    const savedColors = localStorage.getItem('nca_color_scheme');
    if (savedColors) {
        try {
            currentColors = JSON.parse(savedColors);
        } catch (e) {
            currentColors = { ...defaultColors };
        }
    }
    applyColors();
    populateColorForm();
    renderColorPalette();
    renderColorPreview();
}

function applyColors() {
    const root = document.documentElement;
    root.style.setProperty('--primary', currentColors.primary);
    root.style.setProperty('--primary-dark', currentColors.primaryDark);
    root.style.setProperty('--accent', currentColors.accent);
    root.style.setProperty('--accent-strong', currentColors.accentStrong);
    root.style.setProperty('--text-light', currentColors.textLight);
    root.style.setProperty('--text-dark', currentColors.textDark);
    root.style.setProperty('--surface', currentColors.surface);
    root.style.setProperty('--surface-strong', currentColors.surfaceStrong);
}

function populateColorForm() {
    document.getElementById('primaryColor').value = currentColors.primary;
    document.getElementById('primaryColorText').value = currentColors.primary;
    document.getElementById('primaryDarkColor').value = currentColors.primaryDark;
    document.getElementById('primaryDarkColorText').value = currentColors.primaryDark;
    document.getElementById('accentColor').value = currentColors.accent;
    document.getElementById('accentColorText').value = currentColors.accent;
    document.getElementById('accentStrongColor').value = currentColors.accentStrong;
    document.getElementById('accentStrongColorText').value = currentColors.accentStrong;
    document.getElementById('textLightColor').value = currentColors.textLight;
    document.getElementById('textLightColorText').value = currentColors.textLight;
    document.getElementById('textDarkColor').value = currentColors.textDark;
    document.getElementById('textDarkColorText').value = currentColors.textDark;
    document.getElementById('surfaceColor').value = currentColors.surface;
    document.getElementById('surfaceColorText').value = currentColors.surface;
    document.getElementById('surfaceStrongColor').value = currentColors.surfaceStrong;
    document.getElementById('surfaceStrongColorText').value = currentColors.surfaceStrong;
}

function renderColorPalette() {
    const palette = document.getElementById('colorPalette');
    if (!palette) return;

    const colorNames = {
        primary: 'Primary',
        primaryDark: 'Primary Dark',
        accent: 'Accent',
        accentStrong: 'Accent Strong',
        textLight: 'Text Light',
        textDark: 'Text Dark',
        surface: 'Surface',
        surfaceStrong: 'Surface Strong'
    };

    palette.innerHTML = Object.entries(currentColors).map(([key, value]) => `
        <div class="color-palette-item" style="background: ${value}">
            <div class="color-swatch" style="background: ${value}"></div>
            <div class="color-name" style="color: ${getContrastColor(value)}">${colorNames[key]}</div>
            <div class="color-value">${value}</div>
        </div>
    `).join('');
}

function renderColorPreview() {
    const preview = document.getElementById('colorPreview');
    if (!preview) return;

    preview.innerHTML = `
        <div class="preview-component" style="background: ${currentColors.surface}">
            <div class="preview-header" style="color: ${currentColors.textDark}">Buttons</div>
            <button class="preview-button" style="background: ${currentColors.primary}; color: ${currentColors.textLight}">Primary Button</button>
            <button class="preview-button" style="background: ${currentColors.primaryDark}; color: ${currentColors.textLight}">Primary Dark</button>
            <button class="preview-button" style="background: ${currentColors.accent}; color: ${currentColors.textDark}">Accent</button>
        </div>
        
        <div class="preview-component" style="background: ${currentColors.surfaceStrong}">
            <div class="preview-header" style="color: ${currentColors.textDark}">Cards & Badges</div>
            <div class="preview-card" style="background: ${currentColors.surface}; border-color: ${currentColors.primary}">
                <p style="color: ${currentColors.textDark}">Sample card with content</p>
            </div>
            <span class="preview-badge" style="background: ${currentColors.primary}; color: ${currentColors.textLight}">Primary Badge</span>
            <span class="preview-badge" style="background: ${currentColors.accent}; color: ${currentColors.textDark}">Accent Badge</span>
        </div>
        
        <div class="preview-component" style="background: ${currentColors.primary}">
            <div class="preview-header" style="color: ${currentColors.textLight}">Dark Background</div>
            <p style="color: ${currentColors.textLight}">Text on dark background</p>
            <button class="preview-button" style="background: ${currentColors.accent}; color: ${currentColors.textDark}">Accent Button</button>
        </div>
        
        <div class="preview-component" style="background: ${currentColors.textDark}">
            <div class="preview-header" style="color: ${currentColors.textLight}">Text Colors</div>
            <p style="color: ${currentColors.textLight}">Light text on dark background</p>
            <p style="color: ${currentColors.accentStrong}">Accent text</p>
        </div>
    `;
}

function getContrastColor(hexcolor) {
    // Convert hex to RGB
    const r = parseInt(hexcolor.substr(1, 2), 16);
    const g = parseInt(hexcolor.substr(3, 2), 16);
    const b = parseInt(hexcolor.substr(5, 2), 16);
    
    // Calculate luminance
    const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
    
    return luminance > 0.5 ? '#000000' : '#ffffff';
}

function saveColors(event) {
    if (event) event.preventDefault();
    
    currentColors = {
        primary: document.getElementById('primaryColor').value,
        primaryDark: document.getElementById('primaryDarkColor').value,
        accent: document.getElementById('accentColor').value,
        accentStrong: document.getElementById('accentStrongColor').value,
        textLight: document.getElementById('textLightColor').value,
        textDark: document.getElementById('textDarkColor').value,
        surface: document.getElementById('surfaceColor').value,
        surfaceStrong: document.getElementById('surfaceStrongColor').value
    };
    
    localStorage.setItem('nca_color_scheme', JSON.stringify(currentColors));
    applyColors();
    renderColorPalette();
    renderColorPreview();
    showToast('Color scheme saved successfully!', 'success');
    return false;
}

function resetColors() {
    if (!confirm('Are you sure you want to reset all colors to default?')) return;
    
    currentColors = { ...defaultColors };
    localStorage.removeItem('nca_color_scheme');
    applyColors();
    populateColorForm();
    renderColorPalette();
    renderColorPreview();
    showToast('Colors reset to default', 'success');
}

// Sync color picker with text input
document.addEventListener('DOMContentLoaded', function() {
    const colorInputs = [
        { picker: 'primaryColor', text: 'primaryColorText' },
        { picker: 'primaryDarkColor', text: 'primaryDarkColorText' },
        { picker: 'accentColor', text: 'accentColorText' },
        { picker: 'accentStrongColor', text: 'accentStrongColorText' },
        { picker: 'textLightColor', text: 'textLightColorText' },
        { picker: 'textDarkColor', text: 'textDarkColorText' },
        { picker: 'surfaceColor', text: 'surfaceColorText' },
        { picker: 'surfaceStrongColor', text: 'surfaceStrongColorText' }
    ];
    
    colorInputs.forEach(({ picker, text }) => {
        const pickerEl = document.getElementById(picker);
        const textEl = document.getElementById(text);
        
        if (pickerEl && textEl) {
            pickerEl.addEventListener('input', function() {
                textEl.value = this.value;
            });
            
            textEl.addEventListener('input', function() {
                if (/^#[0-9A-Fa-f]{6}$/.test(this.value)) {
                    pickerEl.value = this.value;
                }
            });
        }
    });
});

// ===== SECTION NAVIGATION =====
function showSection(sectionName) {
    document.querySelectorAll('.admin-section').forEach(s => s.classList.remove('active'));
    document.querySelectorAll('.sidebar-link').forEach(l => l.classList.remove('active'));

    const section = document.getElementById('section-' + sectionName);
    if (section) section.classList.add('active');

    const links = document.querySelectorAll('.sidebar-link');
    links.forEach(l => {
        if (l.getAttribute('onclick') && l.getAttribute('onclick').includes(sectionName)) {
            l.classList.add('active');
        }
    });

    // Load heavy libraries dynamically when needed
    if (sectionName === 'overview' || sectionName === 'analytics') {
        if (typeof loadChartsLibrary === 'function') loadChartsLibrary();
    }
    if (sectionName === 'special') {
        if (typeof loadWordCloud === 'function') loadWordCloud();
    }

    // Refresh data
    if (sectionName === 'overview') updateStats();
    if (sectionName === 'students') {
        renderStudents();
        loadGenderClassBreakdown();
        loadAttendanceBreakdown();
        renderStudentsClassBreakdown(); // Load the new class breakdown view
    }
    if (sectionName === 'teachers') renderTeachers();
    if (sectionName === 'parents') renderParents();
    if (sectionName === 'events') renderEvents();
    if (sectionName === 'gallery') renderGallery();
    if (sectionName === 'blog') renderBlog();
    if (sectionName === 'teammembers') renderTeamMembers();
    if (sectionName === 'services') renderServices();
    if (sectionName === 'messages') renderMessages();
    if (sectionName === 'contracts') renderContracts();
    if (sectionName === 'registrations') renderRegistrations();
    if (sectionName === 'payments') { renderPayments(); }
    if (sectionName === 'attendance') { renderAttendance(); }
    if (sectionName === 'settings') loadSettings();
    if (sectionName === 'profile') loadProfile();
    if (sectionName === 'classsummary') renderClassSummary();
    if (sectionName === 'activity') renderActivityLog();
    if (sectionName === 'announcements') renderAnnouncements();
    if (sectionName === 'admins') renderAdmins();
    if (sectionName === 'analytics') renderAnalytics();
    if (sectionName === 'courses') { renderCourses(); renderCourseClassBreakdown(); }
    if (sectionName === 'vacancies') renderVacancies();
    if (sectionName === 'jobapplications') renderJobApplications();
    if (sectionName === 'Notification') renderNotifications();
    if (sectionName === 'exams') renderAdminExams();
    if (sectionName === 'content') switchContentTab('home', document.querySelector('.subject-tab'));
    if (sectionName === 'report_workflow') loadReportWorkflowSection();
    if (sectionName === 'class_breakdown') loadAdvancedClassBreakdown();
    if (sectionName === 'library') renderLibrary();
    if (sectionName === 'users') renderUsers();
    if (sectionName === 'colors') { renderColorPalette(); renderColorPreview(); }
    if (sectionName === 'testimonials') renderTestimonials();
    if (sectionName === 'timetable') { renderTimetable(); loadTimetableDocuments(); loadTeacherFiles(); }
    if (sectionName === 'teacher-files') loadTeacherFiles();
    if (sectionName === 'sports') renderSports();
    if (sectionName === 'transport') renderTransport();
    if (sectionName === 'phone_correction') initializePhoneCorrection();
    if (sectionName === 'account_deletion') loadDeletionRequests();
    if (sectionName === 'testimonials') renderTestimonials();
    if (sectionName === 'api') renderApis();
    if (sectionName === 'special') loadBirthdays();

    if (window.innerWidth <= 992) {
        document.getElementById('sidebar').classList.remove('open');
    }
}

// ===== FORMAT HELPERS =====
function formatDate(dateStr) {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    return d.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}

function formatDateTime(dateStr) {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    return d.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}

function getGrade(score) {
    if (score >= 80) return 'A';
    if (score >= 70) return 'B';
    if (score >= 60) return 'C';
    if (score >= 50) return 'D';
    return 'F';
}

// ===== OVERVIEW STATS =====
let globalData = { students: [], teachers: [], events: [], gallery: [], blog: [], services: [], messages: [], registrations: [], payments: [], attendance: [], activity: [], announcements: [], testimonials: [] };

async function updateStats() {
    console.log('Updating dashboard stats...');
    
    // Load all counts in parallel
    const results = await Promise.all([
        apiFetch('admin', 'students'),
        apiFetch('admin', 'teachers'),
        apiFetch('admin', 'events'),
        apiFetch('admin', 'gallery'),
        apiFetch('admin', 'blog'),
        apiFetch('admin', 'services'),
        apiFetch('admin', 'messages'),
        apiFetch('admin', 'registrations'),
        apiFetch('admin', 'payments'),
        apiFetch('admin', 'attendance'),
        apiFetch('admin', 'activity'),
        apiFetch('admin', 'announcements'),
        apiFetch('admin', 'testimonials')
    ]);
    
    console.log('API results:', results);
    
    const [students, teachers, events, gallery, blog, services, messages, registrations, payments, attendance, activity, announcements, testimonials] = results.map(r => {
        if (!r.success) {
            console.error('API fetch failed:', r.message);
            return [];
        }
        return r.data?.items || r.data || [];
    });
    
    globalData = { students, teachers, events, gallery, blog, services, messages, registrations, payments, attendance, activity, announcements, testimonials };
    
    console.log('Global data updated:', globalData);
    
    const pendingTeachers = teachers.filter(t => t.emailVerified === false).length;
    const pendingTestimonials = testimonials.filter(t => t.status && t.status.toLowerCase() === 'pending').length;
    const pendingRegistrations = registrations.filter(r => r.status && r.status.toLowerCase() === 'pending').length;
    
    // Update overview stats with error handling
    const elements = {
        statRegistrations: document.getElementById('statRegistrations'),
        statPayments: document.getElementById('statPayments'),
        statStudents: document.getElementById('statStudents'),
        statTeachers: document.getElementById('statTeachers'),
        statEvents: document.getElementById('statEvents'),
        statGallery: document.getElementById('statGallery'),
        statBlogs: document.getElementById('statBlogs'),
        statMessages: document.getElementById('statMessages')
    };
    
    if (elements.statRegistrations) elements.statRegistrations.textContent = pendingRegistrations;
    if (elements.statPayments) elements.statPayments.textContent = payments.filter(p => p.status && p.status.toLowerCase() === 'paid').length;
    if (elements.statStudents) elements.statStudents.textContent = students.length;
    if (elements.statTeachers) elements.statTeachers.textContent = teachers.length;
    if (elements.statEvents) elements.statEvents.textContent = events.filter(e => e.status && e.status.toLowerCase() === 'upcoming').length;
    if (elements.statGallery) elements.statGallery.textContent = gallery.length;
    if (elements.statBlogs) elements.statBlogs.textContent = blog.length;
    if (elements.statMessages) elements.statMessages.textContent = messages.length;
    
    // Show pending teacher badge
    const teacherBadge = document.getElementById('teacherPendingBadge');
    if (teacherBadge) {
        if (pendingTeachers > 0) {
            teacherBadge.textContent = pendingTeachers;
            teacherBadge.style.display = 'inline';
        } else {
            teacherBadge.style.display = 'none';
        }
    }
    
    // Show pending testimonial badge
    const testimonialBadge = document.getElementById('testimonialBadge');
    if (testimonialBadge) {
        if (pendingTestimonials > 0) {
            testimonialBadge.textContent = pendingTestimonials;
            testimonialBadge.style.display = 'inline';
        } else {
            testimonialBadge.style.display = 'none';
        }
    }
    
    // Update badges
    const msgBadge = document.getElementById('msgBadge');
    if (msgBadge) msgBadge.textContent = messages.length;
    
    const regBadge = document.getElementById('regBadge');
    if (regBadge) regBadge.textContent = registrations.filter(r => r.status && r.status.toLowerCase() === 'pending').length;
    
    const payBadge = document.getElementById('payBadge');
    if (payBadge) payBadge.textContent = payments.filter(p => p.status && p.status.toLowerCase() === 'pending').length;
    
    // Update job applications badge
    updateAppBadge();
    
    // Update testimonial badge
    updateTestimonialBadge();
    
    // Update recent activity
    const activityEl = document.getElementById('recentActivity');
    if (activityEl) {
        if (activity.length === 0) {
            activityEl.innerHTML = '<p class="text-muted">No recent activity.</p>';
        } else {
            activityEl.innerHTML = activity.slice(0, 10).map(a => `
                <div class="activity-item">
                    <strong>${a.action}</strong> - ${a.detail || ''}
                    <span class="activity-time">${formatDateTime(a.created_at || a.time)}</span>
                </div>
            `).join('');
        }
    }
}

// ===== STUDENTS =====
async function renderStudents() {
    const tbody = document.getElementById('studentsTableBody');
    const result = await apiFetch('admin', 'students');
    const students = result.success ? (result.data?.items || []) : [];
    
    if (students.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted">No students added yet.</td></tr>';
        return;
    }
    const searchTerm = (document.getElementById('studentSearch')?.value || '').toLowerCase();
    const gradeFilter = document.getElementById('studentGradeFilter')?.value || '';
    const filtered = students.filter(s => {
        const matchSearch = (s.firstName + ' ' + s.lastName + ' ' + (s.parent || '') + ' ' + (s.phone || '')).toLowerCase().includes(searchTerm);
        const matchGrade = !gradeFilter || s.grade === gradeFilter;
        return matchSearch && matchGrade;
    });
    if (filtered.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted">No matching students found.</td></tr>';
        return;
    }
    tbody.innerHTML = filtered.map(s => {
        const statusClass = (s.status || 'Active').toLowerCase();
        return `<tr>
            <td>${s.id}</td>
            <td><strong>${s.firstName} ${s.lastName}</strong></td>
            <td>${s.grade || '-'}</td>
            <td>${s.parent || '-'}</td>
            <td>${s.phone || '-'}</td>
            <td><span class="status-badge ${statusClass}">${s.status || 'Active'}</span></td>
            <td>
                <button class="admin-btn admin-btn-primary admin-btn-sm" onclick="editStudent(${s.id})" title="Edit"><i class="fas fa-edit"></i></button>
                <button class="admin-btn admin-btn-info admin-btn-sm" onclick="printTranscript(${s.id})" title="Print Transcript"><i class="fas fa-print"></i></button>
                <button class="admin-btn admin-btn-danger admin-btn-sm" onclick="confirmDelete('student', ${s.id}, '${s.firstName} ${s.lastName}')" title="Delete"><i class="fas fa-trash"></i></button>
            </td>
        </tr>`;
    }).join('');
}

function filterStudents() { renderStudents(); }

// ===== STUDENT CLASS BREAKDOWN VIEW =====
let currentStudentView = 'table'; // 'table' or 'breakdown'

function toggleStudentView() {
    currentStudentView = currentStudentView === 'table' ? 'breakdown' : 'table';
    
    const tableView = document.getElementById('studentsTableView');
    const breakdownView = document.getElementById('studentsClassBreakdownView');
    
    if (currentStudentView === 'table') {
        tableView.style.display = 'block';
        breakdownView.style.display = 'none';
        renderStudents();
    } else {
        tableView.style.display = 'none';
        breakdownView.style.display = 'block';
        renderStudentsClassBreakdown();
    }
}

async function renderStudentsClassBreakdown() {
    const tbody = document.getElementById('studentsClassBreakdownTableBody');
    const teacherFilter = document.getElementById('studentTeacherFilter').value;
    
    tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">Loading class breakdown...</td></tr>';
    
    try {
        // Fetch students and teacher assignments
        const [studentsResult, assignmentsResult] = await Promise.all([
            apiFetch('admin', 'students'),
            apiCollaboration('class_assignments', {})
        ]);
        
        const students = studentsResult.success ? (studentsResult.data?.items || []) : [];
        const assignments = assignmentsResult.success ? (assignmentsResult.data.items || []) : [];
        
        // Define class mappings
        const classMappings = {
            'daycare': 'Day Care',
            'nursery': 'Nursery/Baby',
            'reception': 'Receptionist',
            'std1': 'Standard 1',
            'std2': 'Standard 2',
            'std3': 'Standard 3',
            'std4': 'Standard 4',
            'std5': 'Standard 5',
            'std6': 'Standard 6',
            'std7': 'Standard 7',
            'std8': 'Standard 8',
            'form1': 'Form 1',
            'form2': 'Form 2',
            'form3': 'Form 3',
            'form4': 'Form 4'
        };
        
        // Calculate breakdown for each class
        const breakdown = Object.keys(classMappings).map(classId => {
            const className = classMappings[classId];
            const classStudents = students.filter(s => s.grade === className);
            const boys = classStudents.filter(s => s.gender === 'Male').length;
            const girls = classStudents.filter(s => s.gender === 'Female').length;
            const total = boys + girls;
            
            // Get assigned teachers for this class
            const classAssignments = assignments.filter(a => a.className === className);
            const teacherNames = classAssignments.map(a => a.teacherName).join(', ');
            
            return {
                classId,
                className,
                boys,
                girls,
                total,
                teacherNames,
                classAssignments
            };
        });
        
        // Filter by teacher if selected
        let filteredBreakdown = breakdown;
        if (teacherFilter) {
            filteredBreakdown = breakdown.filter(item => 
                item.teacherNames.includes(teacherFilter)
            );
        }
        
        // Render table
        tbody.innerHTML = filteredBreakdown.map(item => `
            <tr>
                <td><strong>${item.className}</strong></td>
                <td>${item.boys}</td>
                <td>${item.girls}</td>
                <td><strong>${item.total}</strong></td>
                <td class="teacher-assignments-cell">
                    ${item.teacherNames ? `<span class="teacher-names">${item.teacherNames}</span>` : '<span class="no-teachers">No teachers assigned</span>'}
                </td>
                <td>
                    <button class="admin-btn admin-btn-sm admin-btn-info" onclick="viewClassStudents('${item.className}')" title="View Students"><i class="fas fa-eye"></i> View</button>
                    <button class="admin-btn admin-btn-sm admin-btn-primary" onclick="openTeacherAssignmentModalForClass('${item.className}')" title="Assign Teacher"><i class="fas fa-user-plus"></i></button>
                </td>
            </tr>
        `).join('');
        
        // Load teacher filter options
        await loadTeacherFilterOptions();
        
    } catch (error) {
        console.error('Error loading students class breakdown:', error);
        tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">Error loading class breakdown.</td></tr>';
    }
}

async function loadTeacherFilterOptions() {
    try {
        const result = await apiCollaboration('class_assignments', {});
        if (result.success && result.data.items) {
            const assignments = result.data.items;
            const uniqueTeachers = [...new Set(assignments.map(a => a.teacherName))];
            
            const select = document.getElementById('studentTeacherFilter');
            const currentValue = select.value;
            
            select.innerHTML = '<option value="">All Teachers</option>';
            uniqueTeachers.forEach(teacherName => {
                select.innerHTML += `<option value="${teacherName}">${teacherName}</option>`;
            });
            
            select.value = currentValue;
        }
    } catch (error) {
        console.error('Error loading teacher filter options:', error);
    }
}

// ===== CLASS STUDENTS VIEW MODAL =====
let currentViewingClass = '';

async function viewClassStudents(className) {
    currentViewingClass = className;
    
    // Update modal title
    document.getElementById('classStudentsModalTitle').innerHTML = `<i class="fas fa-users"></i> ${className} - Students`;
    document.getElementById('classStudentsClassName').innerHTML = `<i class="fas fa-graduation-cap"></i> ${className}`;
    
    // Load students for this class
    const tbody = document.getElementById('classStudentsTableBody');
    tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted">Loading students...</td></tr>';
    
    try {
        const result = await apiFetch('admin', 'students');
        const students = result.success ? (result.data?.items || []) : [];
        
        // Filter students for this class
        const classStudents = students.filter(s => s.grade === className);
        
        if (classStudents.length === 0) {
            tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted">No students found in this class.</td></tr>';
        } else {
            tbody.innerHTML = classStudents.map(s => {
                const statusClass = (s.status || 'Active').toLowerCase();
                return `<tr>
                    <td>${s.id}</td>
                    <td><strong>${s.firstName} ${s.lastName}</strong></td>
                    <td><span class="status-badge ${s.gender === 'Male' ? 'active' : 'female'}">${s.gender || '-'}</span></td>
                    <td>${s.parent || '-'}</td>
                    <td>${s.phone || '-'}</td>
                    <td><span class="status-badge ${statusClass}">${s.status || 'Active'}</span></td>
                    <td>
                        <button class="admin-btn admin-btn-sm admin-btn-primary" onclick="editStudent(${s.id})" title="Edit"><i class="fas fa-edit"></i></button>
                        <button class="admin-btn admin-btn-sm admin-btn-info" onclick="printTranscript(${s.id})" title="Print Transcript"><i class="fas fa-print"></i></button>
                    </td>
                </tr>`;
            }).join('');
        }
        
        // Open modal
        document.getElementById('classStudentsModal').classList.add('show');
        
    } catch (error) {
        console.error('Error loading class students:', error);
        tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted">Error loading students.</td></tr>';
    }
}

function printClassStudents() {
    const className = currentViewingClass;
    const table = document.getElementById('classStudentsTable');
    
    // Create print content
    const printContent = `
        <html>
        <head>
            <title>${className} - Students</title>
            <style>
                body { font-family: Arial, sans-serif; padding: 20px; }
                h1 { color: #085636; text-align: center; }
                table { width: 100%; border-collapse: collapse; margin-top: 20px; }
                th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                th { background-color: #085636; color: white; }
                tr:nth-child(even) { background-color: #f2f2f2; }
                .header { text-align: center; margin-bottom: 20px; }
                .date { text-align: right; margin-bottom: 10px; }
            </style>
        </head>
        <body>
            <div class="header">
                <h1>Noah Christian Academy</h1>
                <h2>${className} - Student List</h2>
            </div>
            <div class="date">Generated: ${new Date().toLocaleDateString()}</div>
            ${table.outerHTML}
        </body>
        </html>
    `;
    
    // Open print window
    const printWindow = window.open('', '_blank');
    printWindow.document.write(printContent);
    printWindow.document.close();
    printWindow.print();
}

// ===== REGISTRATIONS =====
function openRegistrationModal() {
    document.getElementById('registrationModalTitle').innerHTML = '<i class="fas fa-user-plus"></i> New Student Registration';
    document.getElementById('registrationEditId').value = '';
    document.getElementById('registrationForm').reset();
    document.getElementById('regStatus').value = 'Pending';
    openModal('registrationModal');
}

async function saveRegistration(event) {
    event.preventDefault();
    const editId = document.getElementById('registrationEditId').value;
    
    // Combine first and last name for the API
    const firstName = document.getElementById('regFirstName').value.trim();
    const lastName = document.getElementById('regLastName').value.trim();
    const studentName = `${firstName} ${lastName}`;
    
    const data = {
        studentName: studentName,
        grade: document.getElementById('regGrade').value,
        parentName: document.getElementById('regParentName').value.trim(),
        phone: document.getElementById('regParentPhone').value.trim(),
        email: document.getElementById('regParentEmail')?.value?.trim() || '',
        address: document.getElementById('regAddress')?.value?.trim() || '',
        dateOfBirth: document.getElementById('regDob').value,
        notes: `Gender: ${document.getElementById('regGender').value}\nRelationship: ${document.getElementById('regRelationship').value}\nPrevious School: ${document.getElementById('regPreviousSchool')?.value?.trim() || 'N/A'}\nMedical Info: ${document.getElementById('regMedicalInfo')?.value?.trim() || 'N/A'}\nAdditional Notes: ${document.getElementById('regNotes')?.value?.trim() || 'N/A'}`,
        status: document.getElementById('regStatus').value
    };
    
    // Use the registrations API endpoint
    try {
        const response = await fetch('../api/registration.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        const result = await safeFetch(response);
        
        if (result.success) {
            showToast('Registration saved successfully!');
            closeModal();
            renderRegistrations();
            updateStats();
        } else {
            showToast(result.message || 'Failed to save registration', 'error');
        }
    } catch (error) {
        console.error('Error saving registration:', error);
        showToast('Error saving registration', 'error');
    }
    return false;
}

function openStudentModal() {
    document.getElementById('studentModalTitle').innerHTML = '<i class="fas fa-user-graduate"></i> Add Student';
    document.getElementById('studentEditId').value = '';
    document.getElementById('studentForm').reset();
    document.getElementById('studentStatus').value = 'Active';
    openModal('studentModal');
}

async function editStudent(id) {
    const result = await apiFetch('admin', 'students', 'GET', null, id);
    if (!result.success) { showToast('Student not found', 'error'); return; }
    const s = result.data;
    document.getElementById('studentModalTitle').innerHTML = '<i class="fas fa-user-graduate"></i> Edit Student';
    document.getElementById('studentEditId').value = id;
    document.getElementById('studentFirstName').value = s.firstName || '';
    document.getElementById('studentLastName').value = s.lastName || '';
    document.getElementById('studentGender').value = s.gender || '';
    document.getElementById('studentGrade').value = s.grade || '';
    document.getElementById('studentDob').value = s.dob || '';
    document.getElementById('studentParent').value = s.parent || '';
    document.getElementById('studentPhone').value = s.phone || '';
    document.getElementById('studentAddress').value = s.address || '';
    document.getElementById('studentEmergencyContact').value = s.emergencyContact || '';
    document.getElementById('studentEmergencyPhone').value = s.emergencyPhone || '';
    document.getElementById('studentMedicalInfo').value = s.medicalInfo || '';
    document.getElementById('studentStatus').value = s.status || 'Active';
    openModal('studentModal');
}

async function saveStudent(event) {
    event.preventDefault();
    const editId = document.getElementById('studentEditId').value;
    const data = {
        firstName: document.getElementById('studentFirstName').value.trim(),
        lastName: document.getElementById('studentLastName').value.trim(),
        gender: document.getElementById('studentGender').value,
        grade: document.getElementById('studentGrade').value,
        dob: document.getElementById('studentDob').value,
        parent: document.getElementById('studentParent').value.trim(),
        phone: document.getElementById('studentPhone').value.trim(),
        address: document.getElementById('studentAddress').value.trim(),
        emergencyContact: document.getElementById('studentEmergencyContact')?.value?.trim() || '',
        emergencyPhone: document.getElementById('studentEmergencyPhone')?.value?.trim() || '',
        medicalInfo: document.getElementById('studentMedicalInfo')?.value?.trim() || '',
        status: document.getElementById('studentStatus').value
    };
    if (editId) {
        const result = await apiFetch('admin', 'students', 'PUT', data, editId);
        if (result.success) showToast('Student updated successfully!');
        else showToast(result.message, 'error');
    } else {
        const result = await apiFetch('admin', 'students', 'POST', data);
        if (result.success) showToast('Student added successfully!');
        else showToast(result.message, 'error');
    }
    closeModal();
    renderStudents();
    updateStats();
    return false;
}

// ===== CLASS BREAKDOWN =====
async function loadGenderClassBreakdown() {
    const tbody = document.getElementById('classBreakdownTableBody');
    tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">Loading class breakdown...</td></tr>';
    
    try {
        // Fetch students to calculate breakdown
        const result = await apiFetch('admin', 'students');
        const students = result.success ? (result.data?.items || []) : [];
        
        // Define all classes
        const classes = [
            'Daycare', 'Standard 1', 'Standard 2', 'Standard 3', 'Standard 4',
            'Standard 5', 'Standard 6', 'Standard 7', 'Standard 8',
            'Form 1', 'Form 2', 'Form 3', 'Form 4'
        ];
        
        // Calculate breakdown for each class
        const breakdown = classes.map(className => {
            const classStudents = students.filter(s => s.grade === className);
            const boys = classStudents.filter(s => s.gender === 'Male').length;
            const girls = classStudents.filter(s => s.gender === 'Female').length;
            const total = boys + girls;
            
            return {
                class: className,
                boys,
                girls,
                total,
                status: total > 0 ? 'Active' : 'Empty'
            };
        });
        
        // Render table
        tbody.innerHTML = breakdown.map(item => `
            <tr>
                <td><strong>${item.class}</strong></td>
                <td><input type="number" class="form-control" id="boys_${item.class.replace(/\s/g, '')}" value="${item.boys}" min="0" style="width: 80px;"></td>
                <td><input type="number" class="form-control" id="girls_${item.class.replace(/\s/g, '')}" value="${item.girls}" min="0" style="width: 80px;"></td>
                <td><input type="number" class="form-control" id="total_${item.class.replace(/\s/g, '')}" value="${item.total}" min="0" readonly style="width: 80px; background: #f5f5f5;"></td>
                <td><span class="status-badge ${item.status === 'Active' ? 'active' : 'inactive'}">${item.status}</span></td>
                <td>
                    <button class="admin-btn admin-btn-sm admin-btn-primary" onclick="editClassBreakdown('${item.class}')"><i class="fas fa-edit"></i></button>
                </td>
            </tr>
        `).join('');
        
        showToast('Class breakdown loaded successfully!', 'success');
    } catch (error) {
        console.error('Error loading class breakdown:', error);
        tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">Error loading class breakdown.</td></tr>';
        showToast('Error loading class breakdown', 'error');
    }
}

async function approveClassBreakdown() {
    if (!confirm('Are you sure you want to approve and save the class breakdown data? This will update the student records.')) {
        return;
    }
    
    try {
        // Get all class breakdown data from the table
        const classes = [
            'Daycare', 'Standard 1', 'Standard 2', 'Standard 3', 'Standard 4',
            'Standard 5', 'Standard 6', 'Standard 7', 'Standard 8',
            'Form 1', 'Form 2', 'Form 3', 'Form 4'
        ];
        
        const breakdownData = classes.map(className => {
            const classId = className.replace(/\s/g, '');
            return {
                class: className,
                boys: parseInt(document.getElementById(`boys_${classId}`).value) || 0,
                girls: parseInt(document.getElementById(`girls_${classId}`).value) || 0,
                total: parseInt(document.getElementById(`total_${classId}`).value) || 0
            };
        });
        
        // Save breakdown data to API (you may need to create a new API endpoint for this)
        const result = await apiFetch('admin', 'class_breakdown', 'POST', { breakdown: breakdownData });
        
        if (result.success) {
            showToast('Class breakdown approved and saved successfully!', 'success');
            loadGenderClassBreakdown(); // Refresh the table
        } else {
            showToast(result.message || 'Failed to save class breakdown', 'error');
        }
    } catch (error) {
        console.error('Error approving class breakdown:', error);
        showToast('Error approving class breakdown', 'error');
    }
}

function editClassBreakdown(className) {
    const classId = className.replace(/\s/g, '');
    const boysInput = document.getElementById(`boys_${classId}`);
    const girlsInput = document.getElementById(`girls_${classId}`);
    
    boysInput.focus();
    showToast(`Editing ${className} breakdown`, 'info');
}

// ===== PRINT STUDENT INFO =====
async function printStudentInfo() {
    try {
        // Get student data from form
        const editId = document.getElementById('studentEditId').value;
        let studentData;
        
        if (editId) {
            // If editing existing student, fetch fresh data
            const result = await apiFetch('admin', 'students', 'GET', null, editId);
            if (!result.success) {
                showToast('Failed to fetch student data', 'error');
                return;
            }
            studentData = result.data;
        } else {
            // If adding new student, get data from form
            studentData = {
                firstName: document.getElementById('studentFirstName').value,
                lastName: document.getElementById('studentLastName').value,
                gender: document.getElementById('studentGender').value,
                grade: document.getElementById('studentGrade').value,
                dob: document.getElementById('studentDob').value,
                parent: document.getElementById('studentParent').value,
                phone: document.getElementById('studentPhone').value,
                address: document.getElementById('studentAddress').value,
                emergencyContact: document.getElementById('studentEmergencyContact').value,
                emergencyPhone: document.getElementById('studentEmergencyPhone').value,
                medicalInfo: document.getElementById('studentMedicalInfo').value,
                status: document.getElementById('studentStatus').value,
                id: 'PENDING'
            };
        }

        // Fetch school contact information
        const schoolInfo = await fetchSchoolInfo();

        // Generate printable HTML
        const printableHTML = generateStudentInfoHTML(studentData, schoolInfo);

        // Open in new window for printing
        const printWindow = window.open('', '_blank');
        printWindow.document.write(printableHTML);
        printWindow.document.close();
        
        // Wait for content to load then show print dialog
        printWindow.onload = function() {
            setTimeout(() => {
                printWindow.print();
            }, 250);
        };
    } catch (error) {
        console.error('Error printing student info:', error);
        showToast('Error printing student information', 'error');
    }
}

function generateStudentInfoHTML(student, schoolInfo) {
    const currentDate = new Date().toLocaleDateString();
    const barcodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${student.id}`;
    
    return `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Information - ${student.firstName} ${student.lastName}</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Arial', 'Times New Roman', serif;
            font-size: 12pt;
            line-height: 1.4;
            color: #333;
            background: white;
            padding: 20px;
        }
        
        .document-container {
            max-width: 800px;
            margin: 0 auto;
            border: 2px solid #1a5a1a;
            padding: 30px;
            background: white;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 3px solid #1a5a1a;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }
        
        .logo-section {
            text-align: center;
            flex: 1;
        }
        
        .logo {
            max-width: 100px;
            height: auto;
            margin-bottom: 10px;
        }
        
        .school-name {
            font-size: 18pt;
            font-weight: bold;
            color: #1a5a1a;
            margin-bottom: 5px;
        }
        
        .barcode-section {
            text-align: center;
            flex: 0 0 auto;
            margin-left: 20px;
        }
        
        .barcode {
            width: 120px;
            height: 120px;
            border: 2px solid #333;
            padding: 5px;
            background: white;
        }
        
        .barcode-label {
            font-size: 9pt;
            margin-top: 5px;
            color: #666;
        }
        
        .contact-info {
            background: #f5f5f5;
            padding: 15px;
            border-left: 4px solid #1a5a1a;
            margin-bottom: 25px;
        }
        
        .contact-row {
            display: flex;
            margin-bottom: 8px;
            align-items: center;
        }
        
        .contact-icon {
            width: 20px;
            text-align: center;
            margin-right: 10px;
            color: #1a5a1a;
        }
        
        .title {
            text-align: center;
            font-size: 16pt;
            font-weight: bold;
            margin: 25px 0;
            color: #1a5a1a;
            text-transform: uppercase;
            letter-spacing: 2px;
        }
        
        .student-info {
            margin: 20px 0;
        }
        
        .info-section {
            margin-bottom: 20px;
        }
        
        .section-title {
            font-size: 14pt;
            font-weight: bold;
            color: #1a5a1a;
            border-bottom: 2px solid #1a5a1a;
            padding-bottom: 5px;
            margin-bottom: 15px;
            background: #f9f9f9;
            padding: 8px;
        }
        
        .info-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }
        
        .info-item {
            display: flex;
            flex-direction: column;
        }
        
        .info-label {
            font-weight: bold;
            color: #1a5a1a;
            font-size: 10pt;
            margin-bottom: 3px;
        }
        
        .info-value {
            font-size: 11pt;
            color: #333;
        }
        
        .full-width {
            grid-column: 1 / -1;
        }
        
        .status-badge {
            display: inline-block;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 10pt;
            font-weight: bold;
            text-transform: uppercase;
        }
        
        .status-active {
            background: #d4edda;
            color: #155724;
        }
        
        .status-inactive {
            background: #f8d7da;
            color: #721c24;
        }
        
        .status-graduated {
            background: #cce5ff;
            color: #004085;
        }
        
        .status-transferred {
            background: #fff3cd;
            color: #856404;
        }
        
        .footer {
            margin-top: 40px;
            padding-top: 20px;
            border-top: 2px solid #1a5a1a;
            text-align: center;
            font-size: 10pt;
            color: #666;
        }
        
        .footer-row {
            margin-bottom: 5px;
        }
        
        @media print {
            body {
                padding: 0;
            }
            .document-container {
                border: none;
                padding: 0;
            }
        }
    </style>
</head>
<body>
    <div class="document-container">
        <div class="header">
            <div class="logo-section">
                <img src="../images/logo.jpg" alt="School Logo" class="logo" onerror="this.style.display='none'">
                <div class="school-name">${schoolInfo.description}</div>
            </div>
            <div class="barcode-section">
                <img src="${barcodeUrl}" alt="Barcode" class="barcode">
                <div class="barcode-label">ID: ${student.id}</div>
            </div>
        </div>
        
        <div class="contact-info">
            <div class="contact-row">
                <span class="contact-icon">📍</span>
                <span>${schoolInfo.address || 'Address not available'}</span>
            </div>
            <div class="contact-row">
                <span class="contact-icon">📞</span>
                <span>${schoolInfo.phone1 || ''} ${schoolInfo.phone2 ? '/ ' + schoolInfo.phone2 : ''}</span>
            </div>
            <div class="contact-row">
                <span class="contact-icon">✉️</span>
                <span>${schoolInfo.email || 'Email not available'}</span>
            </div>
            <div class="contact-row">
                <span class="contact-icon">🕐</span>
                <span>${schoolInfo.schoolHours || 'Hours not available'}</span>
            </div>
        </div>
        
        <div class="title">Student Information</div>
        
        <div class="student-info">
            <div class="info-section">
                <div class="section-title">Personal Information</div>
                <div class="info-grid">
                    <div class="info-item">
                        <div class="info-label">Full Name</div>
                        <div class="info-value">${student.firstName} ${student.lastName}</div>
                    </div>
                    <div class="info-item">
                        <div class="info-label">Student ID</div>
                        <div class="info-value">${student.id}</div>
                    </div>
                    <div class="info-item">
                        <div class="info-label">Gender</div>
                        <div class="info-value">${student.gender || 'N/A'}</div>
                    </div>
                    <div class="info-item">
                        <div class="info-label">Date of Birth</div>
                        <div class="info-value">${student.dob || 'N/A'}</div>
                    </div>
                    <div class="info-item">
                        <div class="info-label">Grade/Class</div>
                        <div class="info-value">${student.grade || 'N/A'}</div>
                    </div>
                    <div class="info-item">
                        <div class="info-label">Status</div>
                        <div class="info-value">
                            <span class="status-badge status-${(student.status || 'active').toLowerCase()}">${student.status || 'Active'}</span>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="info-section">
                <div class="section-title">Parent/Guardian Information</div>
                <div class="info-grid">
                    <div class="info-item">
                        <div class="info-label">Parent Name</div>
                        <div class="info-value">${student.parent || 'N/A'}</div>
                    </div>
                    <div class="info-item">
                        <div class="info-label">Phone</div>
                        <div class="info-value">${student.phone || 'N/A'}</div>
                    </div>
                    <div class="info-item full-width">
                        <div class="info-label">Address</div>
                        <div class="info-value">${student.address || 'N/A'}</div>
                    </div>
                </div>
            </div>
            
            ${student.emergencyContact ? `
            <div class="info-section">
                <div class="section-title">Emergency Contact</div>
                <div class="info-grid">
                    <div class="info-item">
                        <div class="info-label">Contact Name</div>
                        <div class="info-value">${student.emergencyContact}</div>
                    </div>
                    <div class="info-item">
                        <div class="info-label">Phone</div>
                        <div class="info-value">${student.emergencyPhone || 'N/A'}</div>
                    </div>
                </div>
            </div>
            ` : ''}
            
            ${student.medicalInfo ? `
            <div class="info-section">
                <div class="section-title">Medical Information</div>
                <div class="info-grid">
                    <div class="info-item full-width">
                        <div class="info-label">Medical Notes</div>
                        <div class="info-value">${student.medicalInfo}</div>
                    </div>
                </div>
            </div>
            ` : ''}
        </div>
        
        <div class="footer">
            <div class="footer-row"><strong>${schoolInfo.description}</strong></div>
            <div class="footer-row">Generated on: ${currentDate}</div>
            <div class="footer-row">Official Student Information Document</div>
            <div class="footer-row" style="margin-top: 10px; font-style: italic; color: #888;">
                💡 Tip: In the print dialog, select "Save as PDF" as the destination to save this document
            </div>
        </div>
    </div>
</body>
</html>
    `;
}

// ===== PRINT TRANSCRIPT =====
async function printTranscript(studentId) {
    try {
        // Fetch student data
        const studentResult = await apiFetch('admin', 'students', 'GET', null, studentId);
        if (!studentResult.success) {
            showToast('Failed to fetch student data', 'error');
            return;
        }
        const student = studentResult.data;

        // Fetch school contact information from content
        const schoolInfo = await fetchSchoolInfo();

        // Generate transcript HTML
        const transcriptHTML = generateTranscriptHTML(student, schoolInfo);

        // Open in new window for printing
        const printWindow = window.open('', '_blank');
        printWindow.document.write(transcriptHTML);
        printWindow.document.close();
        
        // Wait for content to load then show print dialog
        printWindow.onload = function() {
            setTimeout(() => {
                printWindow.print();
            }, 250);
        };
    } catch (error) {
        console.error('Error printing transcript:', error);
        showToast('Error printing transcript', 'error');
    }
}

async function fetchSchoolInfo() {
    try {
        // Try to fetch from site content API
        const result = await apiFetch('admin', 'content');
        if (result.success && result.data) {
            const content = result.data;
            return {
                description: content.footer_description || 'Noah Christian Academy',
                address: content.footer_address || '',
                phone1: content.footer_phone || '',
                phone2: content.footer_phone2 || '',
                email: content.footer_email || '',
                schoolHours: content.footer_schoolHours || ''
            };
        }
    } catch (error) {
        console.error('Error fetching school info:', error);
    }
    
    // Return default values if fetch fails
    return {
        description: 'Noah Christian Academy',
        address: '',
        phone1: '',
        phone2: '',
        email: '',
        schoolHours: ''
    };
}

function generateTranscriptHTML(student, schoolInfo) {
    const currentDate = new Date().toLocaleDateString();
    
    return `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Transcript - ${student.firstName} ${student.lastName}</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Arial', 'Times New Roman', serif;
            font-size: 12pt;
            line-height: 1.4;
            color: #333;
            background: white;
            padding: 20px;
        }
        
        .transcript-container {
            max-width: 800px;
            margin: 0 auto;
            border: 2px solid #333;
            padding: 30px;
        }
        
        .header {
            text-align: center;
            border-bottom: 2px solid #333;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }
        
        .logo {
            max-width: 120px;
            height: auto;
            margin-bottom: 15px;
        }
        
        .school-name {
            font-size: 24pt;
            font-weight: bold;
            margin-bottom: 10px;
            color: #1a5a1a;
        }
        
        .school-info {
            font-size: 11pt;
            margin-bottom: 5px;
        }
        
        .contact-info {
            font-size: 10pt;
            color: #555;
            margin-top: 10px;
        }
        
        .title {
            text-align: center;
            font-size: 18pt;
            font-weight: bold;
            margin: 30px 0;
            text-decoration: underline;
        }
        
        .student-info {
            margin: 20px 0;
            padding: 15px;
            background: #f5f5f5;
            border-left: 4px solid #1a5a1a;
        }
        
        .info-row {
            display: flex;
            margin-bottom: 8px;
        }
        
        .info-label {
            font-weight: bold;
            width: 150px;
            color: #1a5a1a;
        }
        
        .info-value {
            flex: 1;
        }
        
        .section {
            margin: 25px 0;
        }
        
        .section-title {
            font-size: 14pt;
            font-weight: bold;
            color: #1a5a1a;
            border-bottom: 1px solid #ccc;
            padding-bottom: 5px;
            margin-bottom: 15px;
        }
        
        .guidance-section {
            background: #f9f9f9;
            padding: 15px;
            border: 1px solid #ddd;
            margin-top: 20px;
        }
        
        .guidance-item {
            margin-bottom: 10px;
            padding-left: 20px;
            position: relative;
        }
        
        .guidance-item:before {
            content: "•";
            position: absolute;
            left: 0;
            color: #1a5a1a;
            font-weight: bold;
        }
        
        .footer {
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #ccc;
            text-align: center;
            font-size: 10pt;
            color: #666;
        }
        
        @media print {
            body {
                padding: 0;
            }
            .transcript-container {
                border: none;
                padding: 0;
            }
        }
    </style>
</head>
<body>
    <div class="transcript-container">
        <div class="header">
            <img src="../images/logo.jpg" alt="School Logo" class="logo" onerror="this.style.display='none'">
            <div class="school-name">${schoolInfo.description}</div>
            <div class="school-info">${schoolInfo.address || 'Address not available'}</div>
            <div class="contact-info">
                ${schoolInfo.phone1 ? `<div>Phone: ${schoolInfo.phone1} ${schoolInfo.phone2 ? '/ ' + schoolInfo.phone2 : ''}</div>` : ''}
                ${schoolInfo.email ? `<div>Email: ${schoolInfo.email}</div>` : ''}
                ${schoolInfo.schoolHours ? `<div>Hours: ${schoolInfo.schoolHours}</div>` : ''}
            </div>
        </div>
        
        <div class="title">STUDENT TRANSCRIPT</div>
        
        <div class="student-info">
            <div class="info-row">
                <div class="info-label">Student Name:</div>
                <div class="info-value">${student.firstName} ${student.lastName}</div>
            </div>
            <div class="info-row">
                <div class="info-label">Student ID:</div>
                <div class="info-value">${student.id}</div>
            </div>
            <div class="info-row">
                <div class="info-label">Gender:</div>
                <div class="info-value">${student.gender || 'N/A'}</div>
            </div>
            <div class="info-row">
                <div class="info-label">Grade/Class:</div>
                <div class="info-value">${student.grade || 'N/A'}</div>
            </div>
            <div class="info-row">
                <div class="info-label">Date of Birth:</div>
                <div class="info-value">${student.dob || 'N/A'}</div>
            </div>
            <div class="info-row">
                <div class="info-label">Status:</div>
                <div class="info-value">${student.status || 'Active'}</div>
            </div>
        </div>
        
        <div class="section">
            <div class="section-title">Parent/Guardian Information</div>
            <div class="student-info">
                <div class="info-row">
                    <div class="info-label">Parent Name:</div>
                    <div class="info-value">${student.parent || 'N/A'}</div>
                </div>
                <div class="info-row">
                    <div class="info-label">Phone:</div>
                    <div class="info-value">${student.phone || 'N/A'}</div>
                </div>
                <div class="info-row">
                    <div class="info-label">Address:</div>
                    <div class="info-value">${student.address || 'N/A'}</div>
                </div>
            </div>
        </div>
        
        ${student.emergencyContact ? `
        <div class="section">
            <div class="section-title">Emergency Contact</div>
            <div class="student-info">
                <div class="info-row">
                    <div class="info-label">Contact Name:</div>
                    <div class="info-value">${student.emergencyContact}</div>
                </div>
                <div class="info-row">
                    <div class="info-label">Phone:</div>
                    <div class="info-value">${student.emergencyPhone || 'N/A'}</div>
                </div>
            </div>
        </div>
        ` : ''}
        
        ${student.medicalInfo ? `
        <div class="section">
            <div class="section-title">Medical Information</div>
            <div class="student-info">
                <div class="info-row">
                    <div class="info-label">Medical Notes:</div>
                    <div class="info-value">${student.medicalInfo}</div>
                </div>
            </div>
        </div>
        ` : ''}
        
        <div class="guidance-section">
            <div class="section-title">Guidance & Notes</div>
            <div class="guidance-item">This transcript serves as official documentation of the student's enrollment status.</div>
            <div class="guidance-item">Please ensure all contact information is kept up to date with the school administration.</div>
            <div class="guidance-item">For any queries or corrections, please contact the school office immediately.</div>
            <div class="guidance-item">This document is valid only with the official school seal and signature.</div>
        </div>
        
        <div class="footer">
            <div>Date Generated: ${currentDate}</div>
            <div style="margin-top: 10px;">${schoolInfo.description} - Official Transcript</div>
            <div style="margin-top: 10px; font-style: italic; color: #888;">
                💡 Tip: In the print dialog, select "Save as PDF" as the destination to save this document
            </div>
        </div>
    </div>
</body>
</html>
    `;
}

// ===== CODE GENERATION =====
async function generateCode(type, id) {
    const label = type === 'teacher' ? 'Teacher' : 'Parent';
    if (!confirm(`Generate a registration code for this ${label}? The code will be sent to their email.`)) return;
    
    const result = await apiAuth('generate_code', { type, id });
    if (result.success) {
        const code = result.data?.code || 'N/A';
        const email = result.data?.email || 'N/A';
        showToast(`Code generated: ${code}. Sent to ${email}`, 'success');
        // Refresh the current section
        if (type === 'teacher') renderTeachers();
        else renderParents();
        updateStats();
    } else {
        showToast(result.message || 'Failed to generate code', 'error');
    }
}

async function resendCode(type, id) {
    const label = type === 'teacher' ? 'Teacher' : 'Parent';
    if (!confirm(`Resend a new registration code for this ${label}?`)) return;
    
    const result = await apiAuth('resend_code', { type, id });
    if (result.success) {
        const code = result.data?.code || 'N/A';
        const email = result.data?.email || 'N/A';
        showToast(`New code generated: ${code}. Sent to ${email}`, 'success');
        if (type === 'teacher') renderTeachers();
        else renderParents();
    } else {
        showToast(result.message || 'Failed to resend code', 'error');
    }
}

// ===== TEACHERS =====
async function renderTeachers() {
    const tbody = document.getElementById('teachersTableBody');
    const result = await apiFetch('admin', 'teachers');
    const teachers = result.success ? (result.data?.items || []) : [];
    if (teachers.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" class="text-center text-muted">No teachers added yet.</td></tr>';
        return;
    }
    tbody.innerHTML = teachers.map(t => {
        const active = t.isActive !== false;
        const verified = t.emailVerified !== false;
        const status = !active ? 'Deactivated' : (verified ? 'Email Verified' : 'Email Not Verified');
        const statusClass = !active ? 'pending' : (verified ? 'active' : 'pending');
        return `<tr>
            <td>${t.id}</td>
            <td><strong>${t.firstName} ${t.lastName}</strong></td>
            <td>${t.subject || '-'}</td>
            <td>${t.email || '-'}</td>
            <td>${t.phone || '-'}</td>
            <td><span class="status-badge ${statusClass}">${status}</span></td>
            <td>
                <button class="admin-btn admin-btn-primary admin-btn-sm" onclick="editTeacher(${t.id})" title="Edit"><i class="fas fa-edit"></i></button>
                ${active
                    ? `<button class="admin-btn admin-btn-warning admin-btn-sm" onclick="toggleTeacherActive(${t.id}, 0, '${t.firstName} ${t.lastName}')" title="Deactivate"><i class="fas fa-ban"></i></button>`
                    : `<button class="admin-btn admin-btn-success admin-btn-sm" onclick="toggleTeacherActive(${t.id}, 1, '${t.firstName} ${t.lastName}')" title="Activate"><i class="fas fa-check-circle"></i></button>`
                }
                <button class="admin-btn admin-btn-danger admin-btn-sm" onclick="confirmDelete('teacher', ${t.id}, '${t.firstName} ${t.lastName}')" title="Delete"><i class="fas fa-trash"></i></button>
            </td>
        </tr>`;
    }).join('');
}

async function refreshTeachers() {
    showToast('Refreshing teachers list...', 'info');
    await renderTeachers();
    showToast('Teachers list refreshed!', 'success');
}

async function sendBulkMessageToTeachers() {
    const result = await apiFetch('admin', 'teachers');
    const teachers = result.success ? (result.data?.items || []) : [];
    
    if (teachers.length === 0) {
        showToast('No teachers found to send message to.', 'error');
        return;
    }
    
    // Filter only approved teachers with phone numbers
    const teachersWithPhones = teachers.filter(t => t.approved && t.phone);
    
    if (teachersWithPhones.length === 0) {
        showToast('No approved teachers with phone numbers found.', 'error');
        return;
    }
    
    const message = prompt(`Send message to ${teachersWithPhones.length} teachers:\n\n${teachersWithPhones.map(t => `• ${t.firstName} ${t.lastName}: ${t.phone}`).join('\n')}\n\nEnter your message:`);
    
    if (!message || !message.trim()) {
        showToast('Message cancelled or empty.', 'info');
        return;
    }
    
    if (!confirm(`Send this message to all ${teachersWithPhones.length} teachers?\n\n"${message}"`)) {
        return;
    }
    
    // Collect all phone numbers
    const phoneNumbers = teachersWithPhones.map(t => t.phone).join(',');
    
    // In a real implementation, you would integrate with an SMS API here
    // For now, we'll simulate the send and show the phone numbers
    console.log('Sending message to teachers:', {
        phoneNumbers,
        message,
        count: teachersWithPhones.length
    });
    
    showToast(`Message sent to ${teachersWithPhones.length} teachers! (Phone numbers: ${phoneNumbers})`, 'success');
    
    // Optional: Log this action in the system
    // You could add this to a notifications or messages log
}

async function sendBulkMessageToParents() {
    const result = await apiFetch('admin', 'parents');
    const parents = result.success ? (result.data?.items || []) : [];
    
    if (parents.length === 0) {
        showToast('No parents found to send message to.', 'error');
        return;
    }
    
    // Filter only parents with phone numbers
    const parentsWithPhones = parents.filter(p => p.phone);
    
    if (parentsWithPhones.length === 0) {
        showToast('No parents with phone numbers found.', 'error');
        return;
    }
    
    const message = prompt(`Send message to ${parentsWithPhones.length} parents:\n\n${parentsWithPhones.map(p => `• ${p.firstName} ${p.lastName}: ${p.phone}`).join('\n')}\n\nEnter your message:`);
    
    if (!message || !message.trim()) {
        showToast('Message cancelled or empty.', 'info');
        return;
    }
    
    if (!confirm(`Send this message to all ${parentsWithPhones.length} parents?\n\n"${message}"`)) {
        return;
    }
    
    // Collect all phone numbers
    const phoneNumbers = parentsWithPhones.map(p => p.phone).join(',');
    
    // In a real implementation, you would integrate with an SMS API here
    // For now, we'll simulate the send and show the phone numbers
    console.log('Sending message to parents:', {
        phoneNumbers,
        message,
        count: parentsWithPhones.length
    });
    
    showToast(`Message sent to ${parentsWithPhones.length} parents! (Phone numbers: ${phoneNumbers})`, 'success');
    
    // Optional: Log this action in the system
    // You could add this to a notifications or messages log
}

async function approveTeacher(id) {
    const result = await apiFetch('admin', 'teachers', 'PUT', { approved: true, classAssigned: '' }, id);
    if (result.success) {
        showToast('Teacher approved!');
        renderTeachers();
        updateStats();
    } else showToast(result.message, 'error');
}

function openTeacherModal() {
    document.getElementById('teacherModalTitle').innerHTML = '<i class="fas fa-chalkboard-teacher"></i> Add Teacher';
    document.getElementById('teacherEditId').value = '';
    document.getElementById('teacherForm').reset();
    // Hide account and security tabs for new teachers
    document.getElementById('teacherTabAccount').style.display = 'none';
    document.getElementById('teacherTabSecurity').style.display = 'none';
    switchTeacherTab('info');
    openModal('teacherModal');
}

async function editTeacher(id) {
    const result = await apiFetch('admin', 'teachers', 'GET', null, id);
    if (!result.success) return;
    const t = result.data;
    
    // Store teacher data for security functions
    window.currentEditTeacher = t;
    
    document.getElementById('teacherModalTitle').innerHTML = '<i class="fas fa-chalkboard-teacher"></i> Edit Teacher';
    document.getElementById('teacherEditId').value = id;
    document.getElementById('teacherFirstName').value = t.firstName || '';
    document.getElementById('teacherLastName').value = t.lastName || '';
    document.getElementById('teacherUsername').value = t.username || '';
    document.getElementById('teacherEmail').value = t.email || '';
    document.getElementById('teacherPhone').value = t.phone || '';
    document.getElementById('teacherSubject').value = t.subject || '';
    document.getElementById('teacherQualification').value = t.qualification || '';
    document.getElementById('teacherClassAssigned').value = t.classAssigned || '';
    document.getElementById('teacherDateOfEmployment').value = t.dateOfEmployment || '';
    document.getElementById('teacherNationalId').value = t.nationalId || '';
    document.getElementById('teacherResidentialAddress').value = t.residentialAddress || '';
    document.getElementById('teacherNextOfKin').value = t.nextOfKin || '';
    document.getElementById('teacherNextOfKinRelationship').value = t.nextOfKinRelationship || '';
    document.getElementById('teacherNextOfKinPhone').value = t.nextOfKinPhone || '';

    
    // Show account and security tabs for existing teachers
    document.getElementById('teacherTabAccount').style.display = 'block';
    document.getElementById('teacherTabSecurity').style.display = 'block';
    
    // Populate account details
    document.getElementById('teacherCreatedAt').textContent = t.createdAt ? formatDateTime(t.createdAt) : 'N/A';
    document.getElementById('teacherUpdatedAt').textContent = t.updatedAt ? formatDateTime(t.updatedAt) : 'N/A';
    document.getElementById('teacherCreatedIp').textContent = t.createdIp || 'N/A';
    document.getElementById('teacherCreatedDevice').textContent = t.createdDevice || 'N/A';
    document.getElementById('teacherPasswordHash').textContent = t.password || 'N/A';
    
    // Update code status
    updateTeacherCodeStatus(t);
    
    switchTeacherTab('info');
    openModal('teacherModal');
}

function switchTeacherTab(tab) {
    // Hide all tab contents
    document.getElementById('teacherTabInfoContent').style.display = 'none';
    document.getElementById('teacherTabAccountContent').style.display = 'none';
    document.getElementById('teacherTabSecurityContent').style.display = 'none';
    
    // Reset all tab buttons
    document.querySelectorAll('.teacher-tab-btn').forEach(btn => {
        btn.style.borderBottom = 'none';
        btn.style.color = '#666';
    });
    
    // Show selected tab and highlight button
    document.getElementById('teacherTab' + tab.charAt(0).toUpperCase() + tab.slice(1) + 'Content').style.display = 'block';
    const activeBtn = document.getElementById('teacherTab' + tab.charAt(0).toUpperCase() + tab.slice(1));
    activeBtn.style.borderBottom = '3px solid #085636';
    activeBtn.style.color = '#085636';
}

function updateTeacherCodeStatus(teacher) {
    const statusDiv = document.getElementById('teacherCodeStatus');
    const genBtn = document.getElementById('teacherGenCodeBtn');
    const resendBtn = document.getElementById('teacherResendCodeBtn');
    
    if (teacher.approved) {
        statusDiv.innerHTML = '<p style="margin:0;color:#28a745;"><i class="fas fa-check-circle"></i> Teacher is approved. No code needed.</p>';
        genBtn.style.display = 'none';
        resendBtn.style.display = 'none';
    } else if (teacher.registrationCode) {
        const expires = teacher.codeExpiresAt ? formatDateTime(teacher.codeExpiresAt) : 'Unknown';
        const isExpired = teacher.codeExpiresAt && new Date(teacher.codeExpiresAt) < new Date();
        const statusColor = isExpired ? '#dc3545' : '#1976d2';
        const statusIcon = isExpired ? 'fa-times-circle' : 'fa-check-circle';
        
        statusDiv.innerHTML = `
            <div style="background:#fff;padding:12px;border-radius:6px;border-left:4px solid ${statusColor};">
                <p style="margin:0 0 5px 0;"><strong>Code:</strong> <code style="font-size:14px;background:#f5f5f5;padding:2px 8px;border-radius:3px;">${teacher.registrationCode}</code></p>
                <p style="margin:0;font-size:13px;color:#666;"><i class="fas ${statusIcon}" style="color:${statusColor};"></i> Expires: ${expires} ${isExpired ? '<span style="color:#dc3545;font-weight:600;">(EXPIRED)</span>' : ''}</p>
            </div>
        `;
        genBtn.style.display = 'none';
        resendBtn.style.display = 'inline-block';
    } else {
        statusDiv.innerHTML = '<p style="margin:0;color:#666;">No code generated yet.</p>';
        genBtn.style.display = 'inline-block';
        resendBtn.style.display = 'none';
    }
}

async function generateTeacherCode() {
    const id = document.getElementById('teacherEditId').value;
    if (!id) { showToast('Save the teacher first!', 'error'); return; }
    
    if (!confirm('Generate a registration code for this teacher?')) return;
    
    const result = await apiAuth('generate_code', { type: 'teacher', id });
    if (result.success) {
        const code = result.data?.code || 'N/A';
        const email = result.data?.email || 'N/A';
        showToast(`Code generated: ${code}. Sent to ${email}`, 'success');
        // Refresh teacher data
        await editTeacher(parseInt(id));
    } else {
        showToast(result.message || 'Failed to generate code', 'error');
    }
}

async function resendTeacherCode() {
    const id = document.getElementById('teacherEditId').value;
    if (!id) { showToast('Save the teacher first!', 'error'); return; }
    
    if (!confirm('Resend a new registration code for this teacher?')) return;
    
    const result = await apiAuth('resend_code', { type: 'teacher', id });
    if (result.success) {
        const code = result.data?.code || 'N/A';
        const email = result.data?.email || 'N/A';
        showToast(`New code generated: ${code}. Sent to ${email}`, 'success');
        await editTeacher(parseInt(id));
    } else {
        showToast(result.message || 'Failed to resend code', 'error');
    }
}

async function resetTeacherPassword() {
    const id = document.getElementById('teacherEditId').value;
    if (!id) { showToast('Save the teacher first!', 'error'); return; }
    
    const newPass = document.getElementById('teacherNewPassword').value;
    const confirmPass = document.getElementById('teacherConfirmPassword').value;
    
    if (!newPass || newPass.length < 4) {
        showToast('Password must be at least 4 characters!', 'error');
        return;
    }
    
    if (newPass !== confirmPass) {
        showToast('Passwords do not match!', 'error');
        return;
    }
    
    if (!confirm('Are you sure you want to reset this teacher\'s password?')) return;
    
    const result = await apiFetch('admin', 'teachers', 'PUT', { password: newPass }, id);
    if (result.success) {
        showToast('Password reset successfully!');
        document.getElementById('teacherNewPassword').value = '';
        document.getElementById('teacherConfirmPassword').value = '';
        await editTeacher(parseInt(id));
    } else {
        showToast(result.message || 'Failed to reset password', 'error');
    }
}

async function saveTeacher(event) {
    event.preventDefault();
    const editId = document.getElementById('teacherEditId').value;
    const data = {
        firstName: document.getElementById('teacherFirstName').value.trim(),
        lastName: document.getElementById('teacherLastName').value.trim(),
        subject: document.getElementById('teacherSubject').value.trim(),
        email: document.getElementById('teacherEmail').value.trim(),
        phone: document.getElementById('teacherPhone').value.trim(),
        qualification: document.getElementById('teacherQualification').value.trim(),
        username: document.getElementById('teacherUsername').value.trim(),
        classAssigned: document.getElementById('teacherClassAssigned')?.value?.trim() || '',
        dateOfEmployment: document.getElementById('teacherDateOfEmployment').value,
        nationalId: document.getElementById('teacherNationalId').value.trim(),
        residentialAddress: document.getElementById('teacherResidentialAddress').value.trim(),
        nextOfKin: document.getElementById('teacherNextOfKin').value.trim(),
        nextOfKinRelationship: document.getElementById('teacherNextOfKinRelationship').value.trim(),
        nextOfKinPhone: document.getElementById('teacherNextOfKinPhone').value.trim(),
        approved: 1
    };
    if (editId) {
        const result = await apiFetch('admin', 'teachers', 'PUT', data, editId);
        if (result.success) showToast('Teacher updated!');
        else showToast(result.message, 'error');
    } else {
        data.password = 'teacher123';
        const result = await apiFetch('admin', 'teachers', 'POST', data);
        if (result.success) showToast('Teacher added!');
        else showToast(result.message, 'error');
    }
    closeModal();
    renderTeachers();
    updateStats();
}

async function printTeacherDetails() {
    const result = await apiFetch('admin', 'teachers');
    const teachers = result.success ? (result.data?.items || []) : [];
    
    if (teachers.length === 0) {
        showToast('No teachers to print', 'error');
        return;
    }

    // Create print window
    const printWindow = window.open('', '_blank');
    const printDate = new Date().toLocaleDateString();
    
    // Generate print content
    let printContent = `
<!DOCTYPE html>
<html>
<head>
    <title>Teacher Details - Noah Christian Academy</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            color: #333;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 2px solid #085636;
            padding-bottom: 20px;
        }
        .logo {
            max-width: 150px;
            height: auto;
            margin-bottom: 10px;
        }
        .header h1 {
            color: #085636;
            margin: 10px 0;
            font-size: 24px;
        }
        .header p {
            color: #666;
            margin: 5px 0;
            font-size: 14px;
        }
        .contact-info {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-top: 10px;
            font-size: 12px;
            color: #555;
        }
        .contact-info span {
            display: flex;
            align-items: center;
            gap: 5px;
        }
        .teacher-card {
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            page-break-inside: avoid;
            background: #fff;
        }
        .teacher-card:last-child {
            margin-bottom: 0;
        }
        .teacher-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
            margin-bottom: 15px;
        }
        .teacher-name {
            font-size: 18px;
            font-weight: bold;
            color: #085636;
        }
        .teacher-id {
            background: #085636;
            color: white;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 12px;
        }
        .info-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
        }
        .info-item {
            margin-bottom: 8px;
        }
        .info-label {
            font-weight: 600;
            color: #555;
            font-size: 12px;
        }
        .info-value {
            color: #333;
            font-size: 13px;
        }
        .section-title {
            font-weight: bold;
            color: #085636;
            margin-top: 15px;
            margin-bottom: 10px;
            font-size: 14px;
            border-bottom: 1px solid #eee;
            padding-bottom: 5px;
        }
        .footer {
            text-align: center;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            font-size: 12px;
            color: #666;
        }
        @media print {
            body {
                print-color-adjust: exact;
                -webkit-print-color-adjust: exact;
            }
            .teacher-card {
                page-break-inside: avoid;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <img src="../images/logo.jpg" alt="Noah Christian Academy Logo" class="logo" onerror="this.style.display='none'">
        <h1>Noah Christian Academy</h1>
        <p>Teacher Details Report</p>
        <div class="contact-info">
            <span>📧 info@noahacademy.com</span>
            <span>📞 +265 999 123 456</span>
            <span>📍 Lilongwe, Malawi</span>
        </div>
        <p style="margin-top: 10px;">Generated on: ${printDate}</p>
    </div>
`;

    teachers.forEach((teacher, index) => {
        printContent += `
    <div class="teacher-card">
        <div class="teacher-header">
            <div class="teacher-name">${teacher.firstName} ${teacher.lastName}</div>
            <div class="teacher-id">ID: ${teacher.id}</div>
        </div>
        
        <div class="section-title">Personal Information</div>
        <div class="info-grid">
            <div class="info-item">
                <div class="info-label">Full Name:</div>
                <div class="info-value">${teacher.firstName} ${teacher.lastName}</div>
            </div>
            <div class="info-item">
                <div class="info-label">Username:</div>
                <div class="info-value">${teacher.username || '-'}</div>
            </div>
            <div class="info-item">
                <div class="info-label">National ID:</div>
                <div class="info-value">${teacher.nationalId || '-'}</div>
            </div>
            <div class="info-item">
                <div class="info-label">Date of Employment:</div>
                <div class="info-value">${teacher.dateOfEmployment || '-'}</div>
            </div>
        </div>
        
        <div class="section-title">Contact Information</div>
        <div class="info-grid">
            <div class="info-item">
                <div class="info-label">Email:</div>
                <div class="info-value">${teacher.email || '-'}</div>
            </div>
            <div class="info-item">
                <div class="info-label">Phone:</div>
                <div class="info-value">${teacher.phone || '-'}</div>
            </div>
            <div class="info-item">
                <div class="info-label">Residential Address:</div>
                <div class="info-value">${teacher.residentialAddress || '-'}</div>
            </div>
        </div>
        
        <div class="section-title">Professional Information</div>
        <div class="info-grid">
            <div class="info-item">
                <div class="info-label">Subject:</div>
                <div class="info-value">${teacher.subject || '-'}</div>
            </div>
            <div class="info-item">
                <div class="info-label">Qualification:</div>
                <div class="info-value">${teacher.qualification || '-'}</div>
            </div>
            <div class="info-item">
                <div class="info-label">Assigned Class:</div>
                <div class="info-value">${teacher.classAssigned || 'Not Assigned'}</div>
            </div>
            <div class="info-item">
                <div class="info-label">Status:</div>
                <div class="info-value">${teacher.approved ? 'Approved' : 'Pending'}</div>
            </div>
        </div>
        
        <div class="section-title">Next of Kin Information</div>
        <div class="info-grid">
            <div class="info-item">
                <div class="info-label">Next of Kin Name:</div>
                <div class="info-value">${teacher.nextOfKin || '-'}</div>
            </div>
            <div class="info-item">
                <div class="info-label">Relationship:</div>
                <div class="info-value">${teacher.nextOfKinRelationship || '-'}</div>
            </div>
            <div class="info-item">
                <div class="info-label">Next of Kin Phone:</div>
                <div class="info-value">${teacher.nextOfKinPhone || '-'}</div>
            </div>
        </div>
    </div>
`;
    });

    printContent += `
    <div class="footer">
        <p>Noah Christian Academy - Teacher Management System</p>
        <p>This document is confidential and intended for authorized use only.</p>
    </div>
</body>
</html>`;

    printWindow.document.write(printContent);
    printWindow.document.close();
    
    // Wait for content to load then print
    printWindow.onload = function() {
        printWindow.print();
    };
}

// ===== PARENTS =====
async function renderParents() {
    const tbody = document.getElementById('parentsTableBody');
    if (!tbody) return;
    const result = await apiFetch('admin', 'parents');
    const parents = result.success ? (result.data?.items || []) : [];
    if (parents.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" class="text-center text-muted">No parents added yet.</td></tr>';
        return;
    }
    tbody.innerHTML = parents.map(p => {
        const active = p.isActive !== false;
        const verified = p.emailVerified !== false;
        const name = (p.firstName || '') + ' ' + (p.lastName || '');
        const statusBadge = !active
            ? '<span class="status-badge" style="background:#fee2e2;color:#dc2626;">Deactivated</span>'
            : verified
                ? '<span class="status-badge active">Email Verified</span>'
                : '<span class="status-badge pending">Email Not Verified</span>';

        return `<tr>
            <td>${p.id}</td>
            <td><strong>${name}</strong></td>
            <td>${p.email || '-'}</td>
            <td>${p.phone || '-'}</td>
            <td>${statusBadge}</td>
            <td><span class="status-badge ${active ? 'active' : 'pending'}">${active ? 'Active' : 'Inactive'}</span></td>
            <td style="white-space:nowrap;">
                <button class="admin-btn admin-btn-primary admin-btn-sm" onclick="editParent(${p.id})" title="Edit"><i class="fas fa-edit"></i></button>
                <button class="admin-btn admin-btn-info admin-btn-sm" onclick="viewParentHistory(${p.id}, '${name.replace(/'/g, "\'")}')" title="Login History"><i class="fas fa-history"></i></button>
                <button class="admin-btn admin-btn-warning admin-btn-sm" onclick="openResetPassword(${p.id}, '${name.replace(/'/g, "\'")}')" title="Reset Password"><i class="fas fa-key"></i></button>
                ${active
                    ? `<button class="admin-btn admin-btn-danger admin-btn-sm" onclick="toggleParentActive(${p.id}, 0, '${name.replace(/'/g, "\'")}')" title="Deactivate"><i class="fas fa-ban"></i></button>`
                    : `<button class="admin-btn admin-btn-success admin-btn-sm" onclick="toggleParentActive(${p.id}, 1, '${name.replace(/'/g, "\'")}')" title="Activate"><i class="fas fa-check-circle"></i></button>`
                }
                <button class="admin-btn admin-btn-danger admin-btn-sm" onclick="confirmDeleteParent(${p.id}, '${name.replace(/'/g, "\'")}')" title="Delete"><i class="fas fa-trash"></i></button>
            </td>
        </tr>`;
    }).join('');
}

async function approveParent(id) {
    const result = await apiFetch('admin', 'parents', 'PUT', { approved: true }, id);
    if (result.success) {
        showToast('Parent approved!');
        renderParents();
        updateStats();
    } else showToast(result.message, 'error');
}

async function toggleParentActive(id, isActive, name) {
    const action = isActive ? 'activate' : 'deactivate';
    if (!confirm(`Are you sure you want to ${action} ${name}?`)) return;
    try {
        const resp = await fetch(`${API_BASE}?type=admin&collection=parents&parent_action=toggle_active`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: id, isActive: isActive })
        });
        const data = await resp.json();
        if (data.success) {
            showToast(`Parent ${action}d successfully!`);
            renderParents();
        } else showToast(data.message, 'error');
    } catch (e) { showToast('Error: ' + e.message, 'error'); }
}

async function confirmDeleteParent(id, name) {
    if (!confirm(`Are you sure you want to delete parent "${name}"? This action cannot be undone.`)) return;
    try {
        const resp = await fetch(`${API_BASE}?type=admin&collection=parents&parent_action=delete`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: id })
        });
        const data = await resp.json();
        if (data.success) {
            showToast('Parent deleted successfully!');
            renderParents();
            updateStats();
        } else showToast(data.message, 'error');
    } catch (e) { showToast('Error: ' + e.message, 'error'); }
}

async function toggleTeacherActive(id, isActive, name) {
    const action = isActive ? 'activate' : 'deactivate';
    if (!confirm(`Are you sure you want to ${action} ${name}?`)) return;
    try {
        const resp = await fetch(`${API_BASE}?type=admin&collection=teachers&teacher_action=toggle_active`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: id, isActive: isActive })
        });
        const data = await resp.json();
        if (data.success) {
            showToast(`Teacher ${action}d successfully!`);
            renderTeachers();
        } else showToast(data.message, 'error');
    } catch (e) { showToast('Error: ' + e.message, 'error'); }
}

function openResetPassword(id, name) {
    document.getElementById('parentResetId').value = id;
    document.getElementById('parentResetName').textContent = name;
    document.getElementById('parentNewPassword').value = 'parent123';
    openModal('parentResetModal');
}

async function doResetParentPassword(event) {
    event.preventDefault();
    const id = document.getElementById('parentResetId').value;
    const password = document.getElementById('parentNewPassword').value.trim();
    if (!password || password.length < 4) { showToast('Password must be at least 4 characters', 'error'); return false; }
    try {
        const resp = await fetch(`${API_BASE}?type=admin&collection=parents&parent_action=reset_password`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: id, password: password })
        });
        const data = await resp.json();
        if (data.success) {
            showToast('Password reset successfully!');
            closeModal();
        } else showToast(data.message, 'error');
    } catch (e) { showToast('Error: ' + e.message, 'error'); }
    return false;
}

async function viewParentHistory(id, name) {
    document.getElementById('parentHistoryName').textContent = name;
    document.getElementById('parentHistoryBody').innerHTML = '<tr><td colspan="6" class="text-center text-muted">Loading...</td></tr>';
    document.getElementById('parentHistorySummary').innerHTML = '';
    openModal('parentHistoryModal');
    try {
        const resp = await fetch(`${API_BASE}?type=admin&collection=parents&parent_action=login_history`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: id })
        });
        const data = await resp.json();
        const logs = data.success ? (data.data?.items || []) : [];
        if (logs.length === 0) {
            document.getElementById('parentHistoryBody').innerHTML = '<tr><td colspan="6" class="text-center text-muted">No login history found.</td></tr>';
            return;
        }
        // Summary stats
        const devices = {};
        const browsers = {};
        const ips = new Set();
        logs.forEach(l => {
            devices[l.device] = (devices[l.device] || 0) + 1;
            browsers[l.browser] = (browsers[l.browser] || 0) + 1;
            ips.add(l.ipAddress);
        });
        document.getElementById('parentHistorySummary').innerHTML = `
            <div style="background: linear-gradient(135deg, #e8f5e9, #c8e6c9); border-radius:12px; padding:16px; text-align:center; border: 2px solid #4caf50; box-shadow: 0 2px 8px rgba(76, 175, 80, 0.2);">
                <div style="font-size:2rem; font-weight:700; color:#2e7d32;">${logs.length}</div>
                <div style="font-size:13px; color:#1b5e20; font-weight:600;">Total Logins</div>
            </div>
            <div style="background: linear-gradient(135deg, #e3f2fd, #bbdefb); border-radius:12px; padding:16px; text-align:center; border: 2px solid #2196f3; box-shadow: 0 2px 8px rgba(33, 150, 243, 0.2);">
                <div style="font-size:2rem; font-weight:700; color:#1565c0;">${ips.size}</div>
                <div style="font-size:13px; color:#0d47a1; font-weight:600;">Unique IPs</div>
            </div>
            <div style="background: linear-gradient(135deg, #fff3e0, #ffe0b2); border-radius:12px; padding:16px; text-align:center; border: 2px solid #ff9800; box-shadow: 0 2px 8px rgba(255, 152, 0, 0.2);">
                <div style="font-size:2rem; font-weight:700; color:#e65100;">${Object.keys(devices).length}</div>
                <div style="font-size:13px; color:#bf360c; font-weight:600;">Devices Used</div>
            </div>
            <div style="background: linear-gradient(135deg, #fce4ec, #f8bbd9); border-radius:12px; padding:16px; text-align:center; border: 2px solid #e91e63; box-shadow: 0 2px 8px rgba(233, 30, 99, 0.2);">
                <div style="font-size:1.2rem; font-weight:700; color:#ad1457; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${Object.keys(browsers).join(', ')}</div>
                <div style="font-size:13px; color:#880e4f; font-weight:600;">Browsers</div>
            </div>
        `;
        document.getElementById('parentHistoryBody').innerHTML = logs.map(l => {
            const statusColor = l.loginStatus === 'success' ? '#16a34a' : l.loginStatus === 'failed' ? '#dc2626' : '#9333ea';
            const statusBg = l.loginStatus === 'success' ? '#dcfce7' : l.loginStatus === 'failed' ? '#fee2e2' : '#f3e8ff';
            const statusIcon = l.loginStatus === 'success' ? 'fa-check-circle' : l.loginStatus === 'failed' ? 'fa-times-circle' : 'fa-question-circle';
            return `<tr style="border-bottom: 1px solid #e0e0e0;">
                <td style="padding: 12px 8px; color: #333; font-weight: 500;">${l.createdAt}</td>
                <td style="padding: 12px 8px;"><code style="background:#e3f2fd; color:#1565c0; padding:4px 8px; border-radius:6px; font-weight:600;">${l.ipAddress || '-'}</code></td>
                <td style="padding: 12px 8px; color: #333;"><i class="fas fa-${l.device === 'Mobile' ? 'mobile-alt' : l.device === 'Tablet' ? 'tablet-alt' : 'desktop'}" style="color: #085636; margin-right: 6px;"></i> ${l.device || '-'}</td>
                <td style="padding: 12px 8px; color: #333;">${l.browser || '-'}</td>
                <td style="padding: 12px 8px; color: #333;">${l.os || '-'}</td>
                <td style="padding: 12px 8px;"><span style="background:${statusBg}; color:${statusColor}; padding:4px 10px; border-radius:20px; font-size:11px; font-weight:700; border: 1px solid ${statusColor};"><i class="fas ${statusIcon}"></i> ${l.loginStatus}</span></td>
            </tr>`;
        }).join('');
    } catch (e) {
        document.getElementById('parentHistoryBody').innerHTML = '<tr><td colspan="6" class="text-center" style="color:red;">Error loading history</td></tr>';
    }
}

function openParentModal() {
    document.getElementById('parentModalTitle').innerHTML = '<i class="fas fa-user-tie"></i> Add Parent';
    document.getElementById('parentEditId').value = '';
    document.getElementById('parentForm').reset();
    openModal('parentModal');
}

async function editParent(id) {
    const result = await apiFetch('admin', 'parents', 'GET', null, id);
    if (!result.success) return;
    const p = result.data;
    document.getElementById('parentModalTitle').innerHTML = '<i class="fas fa-user-tie"></i> Edit Parent';
    document.getElementById('parentEditId').value = id;
    document.getElementById('parentFirstName').value = p.firstName || '';
    document.getElementById('parentLastName').value = p.lastName || '';
    document.getElementById('parentEmail').value = p.email || '';
    document.getElementById('parentPhone').value = p.phone || '';
    document.getElementById('parentUsername').value = p.username || '';
    document.getElementById('parentStudentIds').value = p.studentIds || '';
    openModal('parentModal');
}

async function saveParent(event) {
    event.preventDefault();
    const editId = document.getElementById('parentEditId').value;
    const data = {
        firstName: document.getElementById('parentFirstName').value.trim(),
        lastName: document.getElementById('parentLastName').value.trim(),
        email: document.getElementById('parentEmail').value.trim(),
        phone: document.getElementById('parentPhone').value.trim(),
        username: document.getElementById('parentUsername').value.trim(),
        studentIds: document.getElementById('parentStudentIds').value.trim(),
        approved: parseInt(document.getElementById('parentApproved').value) || 0
    };
    if (editId) {
        const pwd = document.getElementById('parentPassword').value;
        if (pwd) data.password = pwd;
        const result = await apiFetch('admin', 'parents', 'PUT', data, editId);
        if (result.success) showToast('Parent updated!');
        else showToast(result.message, 'error');
    } else {
        data.password = document.getElementById('parentPassword').value || 'parent123';
        const result = await apiFetch('admin', 'parents', 'POST', data);
        if (result.success) showToast('Parent added!');
        else showToast(result.message, 'error');
    }
    closeModal();
    renderParents();
}

function openCourseModal() {
    document.getElementById('courseModalTitle').innerHTML = '<i class="fas fa-book"></i> Add Course';
    document.getElementById('courseEditId').value = '';
    document.getElementById('courseForm').reset();
    document.getElementById('teacherInfoCard').style.display = 'none';
    loadTeachersForCourse();
    openModal('courseModal');
}

let courseTeachersList = [];

async function loadTeachersForCourse() {
    const result = await apiFetch('admin', 'teachers', 'GET');
    if (result.success && result.data) {
        courseTeachersList = (result.data?.items || []).filter(t => t.approved);
        const select = document.getElementById('courseTeacherId');
        select.innerHTML = '<option value="">-- Select Teacher --</option>';
        courseTeachersList.forEach(t => {
            const cls = t.classAssigned || 'No Class';
            const subj = t.subject || 'No Subject';
            select.innerHTML += `<option value="${t.id}">${t.firstName} ${t.lastName} — ${subj} (${cls})</option>`;
        });
    }
}

function onTeacherSelected() {
    const select = document.getElementById('courseTeacherId');
    const teacherId = parseInt(select.value);
    const card = document.getElementById('teacherInfoCard');

    if (!teacherId) {
        card.style.display = 'none';
        return;
    }

    const t = courseTeachersList.find(x => x.id === teacherId);
    if (!t) { card.style.display = 'none'; return; }

    // Fill teacher info card
    document.getElementById('tiName').textContent = t.firstName + ' ' + t.lastName;
    document.getElementById('tiSubject').textContent = t.subject || 'Not set';
    document.getElementById('tiClass').textContent = t.classAssigned || 'Not assigned';
    document.getElementById('tiQualification').textContent = t.qualification || 'N/A';
    document.getElementById('tiEmail').textContent = t.email || 'N/A';
    document.getElementById('tiPhone').textContent = t.phone || 'N/A';
    card.style.display = 'block';

    // Auto-fill grade level from teacher's assigned class
    if (t.classAssigned) {
        const gradeSelect = document.getElementById('courseGradeLevel');
        if (gradeSelect) {
            gradeSelect.value = t.classAssigned;
        }
    }

    // Auto-fill course title with teacher's subject if creating new
    const editId = document.getElementById('courseEditId').value;
    if (!editId && t.subject) {
        const titleField = document.getElementById('courseTitle');
        if (titleField && !titleField.value.trim()) {
            titleField.value = t.subject;
        }
    }
}

async function editCourse(id) {
    const result = await apiFetch('admin', 'courses', 'GET', null, id);
    if (!result.success) return;
    const c = result.data;
    document.getElementById('courseModalTitle').innerHTML = '<i class="fas fa-book"></i> Edit Course';
    document.getElementById('courseEditId').value = id;
    document.getElementById('courseCode').value = c.code || '';
    document.getElementById('courseTitle').value = c.title || '';
    document.getElementById('courseDescription').value = c.description || '';
    document.getElementById('courseGradeLevel').value = c.gradeLevel || '';
    document.getElementById('courseCredits').value = c.credits || 3;
    document.getElementById('courseStatus').value = c.status || 'Active';
    await loadTeachersForCourse();
    document.getElementById('courseTeacherId').value = c.teacherId || '';
    onTeacherSelected();
    openModal('courseModal');
}

async function saveCourse(event) {
    event.preventDefault();
    const editId = document.getElementById('courseEditId').value;
    const data = {
        code: document.getElementById('courseCode').value.trim(),
        title: document.getElementById('courseTitle').value.trim(),
        description: document.getElementById('courseDescription').value.trim(),
        gradeLevel: document.getElementById('courseGradeLevel').value,
        credits: parseInt(document.getElementById('courseCredits').value) || 0,
        teacherId: document.getElementById('courseTeacherId').value || null,
        status: document.getElementById('courseStatus').value
    };
    if (editId) {
        const result = await apiFetch('admin', 'courses', 'PUT', data, editId);
        if (result.success) showToast('Course updated!');
        else showToast(result.message, 'error');
    } else {
        const result = await apiFetch('admin', 'courses', 'POST', data);
        if (result.success) showToast('Course added!');
        else showToast(result.message, 'error');
    }
    closeModal();
    renderCourses();
}

async function deleteCourse(id) {
    if (!confirm('Are you sure you want to delete this course?')) return;
    const result = await apiFetch('admin', 'courses', 'DELETE', null, id);
    if (result.success) {
        showToast('Course deleted!');
        renderCourses();
    } else {
        showToast(result.message, 'error');
    }
}

async function renderCourses() {
    const result = await apiFetch('admin', 'courses', 'GET');
    const tbody = document.getElementById('coursesTableBody');
    if (!tbody) return;

    const courses = result.success ? (result.data?.items || []) : [];
    
    if (courses.length === 0) {
        tbody.innerHTML = '<tr><td colspan="10" class="text-center text-muted">No courses added yet.</td></tr>';
        return;
    }

    // Apply filters
    const gradeFilter = document.getElementById('courseGradeFilter') ? document.getElementById('courseGradeFilter').value : '';
    const statusFilter = document.getElementById('courseStatusFilter') ? document.getElementById('courseStatusFilter').value : '';
    let filtered = courses;
    if (gradeFilter) filtered = filtered.filter(c => c.gradeLevel === gradeFilter);
    if (statusFilter) filtered = filtered.filter(c => c.status === statusFilter);

    // Fetch teachers to map IDs to details
    let teacherMap = {};
    const teacherResult = await apiFetch('admin', 'teachers', 'GET');
    if (teacherResult.success && teacherResult.data) {
        (teacherResult.data?.items || []).forEach(t => {
            teacherMap[t.id] = {
                name: t.firstName + ' ' + t.lastName,
                subject: t.subject || '-',
                classAssigned: t.classAssigned || '-'
            };
        });
    }

    if (filtered.length === 0) {
        tbody.innerHTML = '<tr><td colspan="10" class="text-center text-muted">No courses match this filter.</td></tr>';
        return;
    }

    tbody.innerHTML = filtered.map(c => {
        const t = c.teacherId && teacherMap[c.teacherId] ? teacherMap[c.teacherId] : null;
        return `<tr>
            <td>${c.id}</td>
            <td><code>${c.code || '-'}</code></td>
            <td><strong>${c.title}</strong></td>
            <td>${c.gradeLevel || '-'}</td>
            <td>${c.credits || 0}</td>
            <td>${t ? `<span class="badge badge-info">${t.name}</span>` : '<span class="text-muted">Unassigned</span>'}</td>
            <td>${t ? t.subject : '-'}</td>
            <td>${t ? `<span class="badge badge-secondary">${t.classAssigned}</span>` : '-'}</td>
            <td><span class="badge ${c.status === 'Active' ? 'badge-success' : 'badge-secondary'}">${c.status}</span></td>
            <td>
                <button class="admin-btn admin-btn-sm admin-btn-primary" onclick="editCourse(${c.id})"><i class="fas fa-edit"></i></button>
                <button class="admin-btn admin-btn-sm admin-btn-danger" onclick="deleteCourse(${c.id})"><i class="fas fa-trash"></i></button>
            </td>
        </tr>`;
    }).join('');
}

// ===== CLASS BREAKDOWN FOR COURSES SECTION =====
async function renderCourseClassBreakdown() {
    const container = document.getElementById('classBreakdownContainerSimple');
    if (!container) return;

    container.innerHTML = `
        <div class="text-center text-muted" style="padding: 40px;">
            <i class="fas fa-spinner fa-spin" style="font-size: 48px; margin-bottom: 16px;"></i>
            <h4>Loading Class Breakdown...</h4>
        </div>
    `;

    try {
        // Fetch students data
        const studentsResult = await apiFetch('admin', 'students', 'GET');
        const students = studentsResult.success ? (studentsResult.data?.items || []) : [];

        // Fetch payments data to determine paid status
        const paymentsResult = await apiFetch('admin', 'payments', 'GET');
        const payments = paymentsResult.success ? (paymentsResult.data?.items || []) : [];

        // Fetch courses data
        const coursesResult = await apiFetch('admin', 'courses', 'GET');
        const courses = coursesResult.success ? (coursesResult.data?.items || []) : [];

        // Create a map of paid students
        const paidStudents = new Set();
        payments.forEach(payment => {
            if (payment.studentName) {
                paidStudents.add(payment.studentName.trim().toLowerCase());
            }
        });

        // Define class categories as requested
        const categories = {
            'Early Childhood Development': ['Daycare', 'Baby', 'Middle', 'Reception'],
            'Primary School': ['Standard 1', 'Standard 2', 'Standard 3', 'Standard 4', 'Standard 5', 'Standard 6', 'Standard 7', 'Standard 8'],
            'Secondary School': ['Form 1', 'Form 2', 'Form 3', 'Form 4']
        };

        if (students.length === 0) {
            container.innerHTML = `
                <div class="text-center text-muted" style="padding: 40px;">
                    <i class="fas fa-users" style="font-size: 48px; margin-bottom: 16px;"></i>
                    <h4>No Students Found</h4>
                    <p>There are no students to display in the class breakdown.</p>
                </div>
            `;
            return;
        }

        let html = '<div class="admin-card"><div class="admin-card-body">';
        
        // Create card layout
        html += `
            <div style="margin-bottom: 24px;">
                <h3 style="color: #085636; margin-bottom: 16px;"><i class="fas fa-chart-bar"></i> Class Breakdown by Student Enrollment</h3>
                <div class="class-breakdown-grid">
        `;

        let grandTotal = 0;
        let grandTotalBoys = 0;
        let grandTotalGirls = 0;
        let grandTotalPaid = 0;
        let grandTotalUnpaid = 0;

        // Process each category
        for (const [categoryName, classes] of Object.entries(categories)) {
            let categoryTotal = 0;
            let categoryBoys = 0;
            let categoryGirls = 0;
            let categoryPaid = 0;
            let categoryUnpaid = 0;

            // Calculate category totals and create cards for each class
            for (const className of classes) {
                const classStudents = students.filter(s => s.grade === className);
                const classBoys = classStudents.filter(s => s.gender === 'Male').length;
                const classGirls = classStudents.filter(s => s.gender === 'Female').length;
                const classTotal = classStudents.length;
                
                // Count paid students
                let classPaid = 0;
                classStudents.forEach(student => {
                    const studentName = `${student.firstName} ${student.lastName}`.trim().toLowerCase();
                    if (paidStudents.has(studentName)) {
                        classPaid++;
                    }
                });
                const classUnpaid = classTotal - classPaid;

                categoryTotal += classTotal;
                categoryBoys += classBoys;
                categoryGirls += classGirls;
                categoryPaid += classPaid;
                categoryUnpaid += classUnpaid;

                // Create student list for the card
                const studentList = classStudents.map((student, index) => `
                    <div style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid #eee;">
                        <div style="width:24px;height:24px;background:#085636;color:white;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:600;">
                            ${index + 1}
                        </div>
                        <div style="flex:1;">
                            <div style="font-weight:600;font-size:13px;">${student.firstName} ${student.lastName}</div>
                            <div style="font-size:11px;color:#666;">${student.parent || 'No parent info'}</div>
                        </div>
                        <div style="font-size:11px;color:${student.gender === 'Male' ? '#3498db' : '#e74c3c'};font-weight:600;">
                            ${student.gender}
                        </div>
                    </div>
                `).join('');

                // Get courses for this class
                const classCourses = courses.filter(c => c.gradeLevel === className);
                const courseList = classCourses.map(course => `
                    <div style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid #eee;">
                        <div style="width:24px;height:24px;background:#6c5ce7;color:white;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:600;">
                            <i class="fas fa-book"></i>
                        </div>
                        <div style="flex:1;">
                            <div style="font-weight:600;font-size:13px;">${course.title}</div>
                            <div style="font-size:11px;color:#666;">Code: ${course.code || 'N/A'} | Credits: ${course.credits || 0}</div>
                        </div>
                        <span class="status-badge ${course.status === 'Active' ? 'active' : 'pending'}" style="font-size:10px;">${course.status}</span>
                    </div>
                `).join('');

                // Create card for this class
                const feeTotal = classPaid + classUnpaid;
                const feePaidPercent = feeTotal > 0 ? Math.round((classPaid / feeTotal) * 100) : 0;
                const feePendingPercent = feeTotal > 0 ? Math.round((classUnpaid / feeTotal) * 100) : 0;

                html += `
                    <div class="class-breakdown-card">
                        <div class="class-breakdown-header">
                            <div class="class-breakdown-title">
                                <i class="fas fa-graduation-cap"></i>
                                ${className}
                            </div>
                            <span class="status-badge ${classTotal > 0 ? 'active' : 'pending'}">${classTotal} Students</span>
                        </div>
                        
                        <div class="class-breakdown-stats">
                            <div class="class-breakdown-stat male">
                                <div class="class-breakdown-stat-value">${classBoys}</div>
                                <div class="class-breakdown-stat-label">Male</div>
                            </div>
                            <div class="class-breakdown-stat female">
                                <div class="class-breakdown-stat-value">${classGirls}</div>
                                <div class="class-breakdown-stat-label">Female</div>
                            </div>
                            <div class="class-breakdown-stat total">
                                <div class="class-breakdown-stat-value">${classTotal}</div>
                                <div class="class-breakdown-stat-label">Total</div>
                            </div>
                        </div>
                        
                        <div class="class-breakdown-fee-status">
                            <div class="class-breakdown-fee-title">Fee Status</div>
                            <div class="class-breakdown-fee-bar">
                                <div class="class-breakdown-fee-paid" style="width: ${feePaidPercent}%"></div>
                                <div class="class-breakdown-fee-pending" style="width: ${feePendingPercent}%"></div>
                            </div>
                            <div class="class-breakdown-fee-legend">
                                <div class="class-breakdown-legend-item">
                                    <div class="class-breakdown-legend-dot paid"></div>
                                    <span>Paid (${classPaid})</span>
                                </div>
                                <div class="class-breakdown-legend-item">
                                    <div class="class-breakdown-legend-dot pending"></div>
                                    <span>Pending (${classUnpaid})</span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="class-breakdown-teachers">
                            <div style="font-size:13px;font-weight:600;color:#085636;margin-bottom:8px;">
                                <i class="fas fa-user-graduate"></i> Students in Class
                            </div>
                            <div style="max-height:200px;overflow-y:auto;padding-right:5px;">
                                ${studentList || '<div style="color:#999;font-size:12px;">No students enrolled</div>'}
                            </div>
                        </div>
                        
                        <div class="class-breakdown-teachers" style="margin-top:12px;">
                            <div style="font-size:13px;font-weight:600;color:#6c5ce7;margin-bottom:8px;">
                                <i class="fas fa-book"></i> Courses in Class
                            </div>
                            <div style="max-height:200px;overflow-y:auto;padding-right:5px;">
                                ${courseList || '<div style="color:#999;font-size:12px;">No courses assigned</div>'}
                            </div>
                        </div>
                        
                        <div style="margin-top:16px;display:flex;gap:8px;">
                            <button class="admin-btn admin-btn-primary admin-btn-sm" onclick="viewCourseClassStudents('${className}')" style="flex:1;">
                                <i class="fas fa-users"></i> View
                            </button>
                            <button class="admin-btn admin-btn-success admin-btn-sm" onclick="exportCourseClassData('${className}')" style="flex:1;">
                                <i class="fas fa-download"></i> Export
                            </button>
                        </div>
                    </div>
                `;
            }

            grandTotal += categoryTotal;
            grandTotalBoys += categoryBoys;
            grandTotalGirls += categoryGirls;
            grandTotalPaid += categoryPaid;
            grandTotalUnpaid += categoryUnpaid;
        }

        // Add grand total summary card
        html += `
            <div class="class-breakdown-card" style="background: linear-gradient(135deg, #085636, #0a6b47); color: white;">
                <div class="class-breakdown-header">
                    <div class="class-breakdown-title" style="color: white;">
                        <i class="fas fa-chart-pie"></i>
                        Grand Total
                    </div>
                    <span class="status-badge active" style="background: rgba(255,255,255,0.2); color: white;">${grandTotal} Students</span>
                </div>
                
                <div class="class-breakdown-stats">
                    <div class="class-breakdown-stat male" style="color: white;">
                        <div class="class-breakdown-stat-value" style="color: white;">${grandTotalBoys}</div>
                        <div class="class-breakdown-stat-label" style="color: rgba(255,255,255,0.8);">Male</div>
                    </div>
                    <div class="class-breakdown-stat female" style="color: white;">
                        <div class="class-breakdown-stat-value" style="color: white;">${grandTotalGirls}</div>
                        <div class="class-breakdown-stat-label" style="color: rgba(255,255,255,0.8);">Female</div>
                    </div>
                    <div class="class-breakdown-stat total" style="color: white;">
                        <div class="class-breakdown-stat-value" style="color: white;">${grandTotal}</div>
                        <div class="class-breakdown-stat-label" style="color: rgba(255,255,255,0.8);">Total</div>
                    </div>
                </div>
                
                <div style="margin-top:16px;padding:12px;background:rgba(255,255,255,0.1);border-radius:8px;">
                    <div style="display:flex;justify-content:space-between;margin-bottom:8px;">
                        <span style="font-size:13px;font-weight:600;">Paid Fees:</span>
                        <span style="font-size:13px;font-weight:600;">${grandTotalPaid}</span>
                    </div>
                    <div style="display:flex;justify-content:space-between;">
                        <span style="font-size:13px;font-weight:600;">Pending Fees:</span>
                        <span style="font-size:13px;font-weight:600;">${grandTotalUnpaid}</span>
                    </div>
                </div>
            </div>
        `;

        html += `
                </div>
            </div>
        </div>
        `;

        // Add course breakdown section
        html += `
            <div style="margin-top: 40px;">
                <h3 style="color: #6c5ce7; margin-bottom: 16px;"><i class="fas fa-book"></i> Courses by Class</h3>
                <div class="class-breakdown-grid">
        `;

        // Process each category for courses
        for (const [categoryName, classes] of Object.entries(categories)) {
            for (const className of classes) {
                const classCourses = courses.filter(c => c.gradeLevel === className);
                
                if (classCourses.length === 0) continue;

                const courseCount = classCourses.length;
                const activeCourses = classCourses.filter(c => c.status === 'Active').length;
                const totalCredits = classCourses.reduce((sum, c) => sum + (c.credits || 0), 0);

                // Create course list for the card
                const courseList = classCourses.map((course, index) => `
                    <div style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid #eee;">
                        <div style="width:24px;height:24px;background:#6c5ce7;color:white;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:600;">
                            ${index + 1}
                        </div>
                        <div style="flex:1;">
                            <div style="font-weight:600;font-size:13px;">${course.title}</div>
                            <div style="font-size:11px;color:#666;">Code: ${course.code || 'N/A'} | Credits: ${course.credits || 0}</div>
                        </div>
                        <span class="status-badge ${course.status === 'Active' ? 'active' : 'pending'}" style="font-size:10px;">${course.status}</span>
                    </div>
                `).join('');

                html += `
                    <div class="class-breakdown-card" style="border-left: 4px solid #6c5ce7;">
                        <div class="class-breakdown-header">
                            <div class="class-breakdown-title" style="color: #6c5ce7;">
                                <i class="fas fa-book"></i>
                                ${className}
                            </div>
                            <span class="status-badge ${courseCount > 0 ? 'active' : 'pending'}" style="background: #6c5ce7; color: white;">${courseCount} Courses</span>
                        </div>
                        
                        <div class="class-breakdown-stats">
                            <div class="class-breakdown-stat" style="background: #f0f0ff;">
                                <div class="class-breakdown-stat-value" style="color: #6c5ce7;">${activeCourses}</div>
                                <div class="class-breakdown-stat-label">Active</div>
                            </div>
                            <div class="class-breakdown-stat" style="background: #f0f0ff;">
                                <div class="class-breakdown-stat-value" style="color: #6c5ce7;">${courseCount - activeCourses}</div>
                                <div class="class-breakdown-stat-label">Inactive</div>
                            </div>
                            <div class="class-breakdown-stat" style="background: #f0f0ff;">
                                <div class="class-breakdown-stat-value" style="color: #6c5ce7;">${totalCredits}</div>
                                <div class="class-breakdown-stat-label">Credits</div>
                            </div>
                        </div>
                        
                        <div class="class-breakdown-teachers">
                            <div style="font-size:13px;font-weight:600;color:#6c5ce7;margin-bottom:8px;">
                                <i class="fas fa-list"></i> Course List
                            </div>
                            <div style="max-height:300px;overflow-y:auto;padding-right:5px;">
                                ${courseList}
                            </div>
                        </div>
                        
                        <div style="margin-top:16px;display:flex;gap:8px;">
                            <button class="admin-btn admin-btn-primary admin-btn-sm" onclick="showSection('courses')" style="flex:1; background: #6c5ce7; border-color: #6c5ce7;">
                                <i class="fas fa-plus"></i> Add Course
                            </button>
                            <button class="admin-btn admin-btn-success admin-btn-sm" onclick="showSection('courses')" style="flex:1; background: #6c5ce7; border-color: #6c5ce7;">
                                <i class="fas fa-edit"></i> Manage
                            </button>
                        </div>
                    </div>
                `;
            }
        }

        html += `
                </div>
            </div>
        </div>
        `;

        container.innerHTML = html;
    } catch (error) {
        console.error('Error loading class breakdown:', error);
        container.innerHTML = `
            <div class="text-center text-muted" style="padding: 40px;">
                <i class="fas fa-exclamation-triangle" style="font-size: 48px; margin-bottom: 16px; color: #e74c3c;"></i>
                <h4>Error Loading Data</h4>
                <p>Failed to load class breakdown. Please try again.</p>
                <button class="admin-btn admin-btn-primary" onclick="renderCourseClassBreakdown()">
                    <i class="fas fa-redo"></i> Retry
                </button>
            </div>
        `;
    }
}

function refreshClassBreakdown() {
    renderCourseClassBreakdown();
}

function viewCourseClassStudents(className) {
    // Navigate to students section with filter
    showSection('students');
    setTimeout(() => {
        const filter = document.getElementById('studentGradeFilter');
        if (filter) {
            filter.value = className;
            filterStudents();
        }
        // Scroll to the students table to ensure it's visible
        const studentsTable = document.getElementById('studentsTable');
        if (studentsTable) {
            studentsTable.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }, 300);
}

async function exportCourseClassData(className) {
    try {
        showToast(`Exporting data for ${className}...`, 'info');
        
        // Fetch students data
        const studentsResult = await apiFetch('admin', 'students', 'GET');
        const students = studentsResult.success ? (studentsResult.data?.items || []) : [];
        
        // Filter students for the specific class
        const classStudents = students.filter(s => s.grade === className);
        
        if (classStudents.length === 0) {
            showToast(`No students found in ${className}`, 'error');
            return;
        }
        
        // Create CSV content
        const headers = ['Student ID', 'First Name', 'Last Name', 'Gender', 'Grade', 'Parent/Guardian', 'Contact Number', 'Address', 'Date of Birth'];
        const csvRows = [headers.join(',')];
        
        classStudents.forEach(student => {
            const row = [
                student.id || '',
                `"${(student.firstName || '').replace(/"/g, '""')}"`,
                `"${(student.lastName || '').replace(/"/g, '""')}"`,
                student.gender || '',
                `"${(student.grade || '').replace(/"/g, '""')}"`,
                `"${(student.parent || '').replace(/"/g, '""')}"`,
                `"${(student.parentPhone || student.contactNumber || '').replace(/"/g, '""')}"`,
                `"${(student.address || '').replace(/"/g, '""')}"`,
                `"${(student.dateOfBirth || '').replace(/"/g, '""')}"`
            ];
            csvRows.push(row.join(','));
        });
        
        // Create and download the CSV file
        const csvContent = csvRows.join('\n');
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        
        link.setAttribute('href', url);
        link.setAttribute('download', `${className.replace(/\s+/g, '_')}_students_${new Date().toISOString().split('T')[0]}.csv`);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        showToast(`Successfully exported ${classStudents.length} students from ${className}`, 'success');
    } catch (error) {
        console.error('Error exporting class data:', error);
        showToast('Error exporting class data', 'error');
    }
}

// ===== EVENTS =====
async function renderEvents() {
    const grid = document.getElementById('eventsCardsGrid');
    const result = await apiFetch('admin', 'events');
    const events = result.success ? (result.data?.items || []) : [];
    if (events.length === 0) {
        grid.innerHTML = '<p class="text-center text-muted" style="grid-column:1/-1;">No events added yet.</p>';
        return;
    }
    events.sort((a, b) => new Date(a.date) - new Date(b.date));
    grid.innerHTML = events.map(e => {
        const statusClass = (e.status || 'Upcoming').toLowerCase();
        let img = e.imageUrl || e.image_url || '';
        
        // Fix event image paths if they don't include uploads/ prefix
        if (img && !img.startsWith('http') && !img.startsWith('data:') && !img.startsWith('../') && !img.startsWith('/') && !img.startsWith('uploads/')) {
            img = '../uploads/' + img;
        } else if (img && img.startsWith('uploads/')) {
            // Fix paths that already have uploads/ but not the parent directory
            img = '../' + img;
        }
        
        const desc = e.description || '';
        const location = e.location || '';
        const time = e.time || '';
        const dateStr = formatDate(e.date);
        const link = e.link || '';
        return `<div class="event-admin-card">
            ${img ? '<div class="eac-image"><img src="' + img + '" alt="' + e.title + '" onerror="this.parentElement.style.display=\'none\'"><span class="eac-status status-badge ' + statusClass + '">' + (e.status || 'Upcoming') + '</span></div>' : '<div class="eac-no-image"><i class="fas fa-calendar-alt"></i><span class="eac-status status-badge ' + statusClass + '">' + (e.status || 'Upcoming') + '</span></div>'}
            <div class="eac-body">
                <h4 class="eac-title">${e.title}</h4>
                <div class="eac-meta">
                    <span class="eac-meta-item"><i class="fas fa-calendar-day"></i> ${dateStr}</span>
                    ${time ? '<span class="eac-meta-item"><i class="fas fa-clock"></i> ' + time + '</span>' : ''}
                    ${location ? '<span class="eac-meta-item"><i class="fas fa-map-marker-alt"></i> ' + location + '</span>' : ''}
                </div>
                ${desc ? '<p class="eac-desc">' + desc + '</p>' : ''}
                ${link ? '<a href="' + link + '" target="_blank" class="eac-link"><i class="fas fa-external-link-alt"></i> More info</a>' : ''}
                <div class="eac-actions">
                    <button class="admin-btn admin-btn-primary admin-btn-sm" onclick="editEvent(${e.id})" title="Edit"><i class="fas fa-edit"></i> Edit</button>
                    <button class="admin-btn admin-btn-danger admin-btn-sm" onclick="confirmDelete('event', ${e.id}, '${e.title}')" title="Delete"><i class="fas fa-trash"></i> Delete</button>
                </div>
            </div>
        </div>`;
    }).join('');
}

let eventSelectedFile = null;

function handleEventFileSelect(input) {
    const file = input.files[0];
    if (!file) return;
    processEventFile(file);
}

function handleEventDrop(event) {
    const file = event.dataTransfer.files[0];
    if (!file) return;
    processEventFile(file);
}

function processEventFile(file) {
    const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    const label = document.getElementById('eventFileLabel');
    const statusEl = document.getElementById('eventUploadStatus');

    if (!allowedTypes.includes(file.type)) {
        showToast('Invalid file type. Only JPG, PNG, GIF, and WebP are allowed.', 'error');
        return;
    }
    if (file.size > 5 * 1024 * 1024) {
        showToast('File too large. Maximum size is 5MB.', 'error');
        return;
    }

    eventSelectedFile = file;
    const sizeMB = (file.size / 1024 / 1024).toFixed(1);
    label.innerHTML = '<i class="fas fa-check-circle" style="color:#085636;margin-right:4px;"></i>' + file.name + ' <span style="color:#94a3b8;font-weight:400;">(' + sizeMB + 'MB)</span>';
    statusEl.innerHTML = '<i class="fas fa-info-circle" style="color:#085636;"></i> Image ready — click Save to upload';
}

function openEventModal() {
    document.getElementById('eventModalTitle').innerHTML = '<i class="fas fa-calendar-alt"></i> Add Event';
    document.getElementById('eventEditId').value = '';
    document.getElementById('eventForm').reset();
    document.getElementById('eventStatus').value = 'Upcoming';
    document.getElementById('eventImageUrl').value = '';
    document.getElementById('eventVideoUrl').value = '';
    document.getElementById('eventLink').value = '';
    // Reset drop zone
    eventSelectedFile = null;
    if (document.getElementById('eventFileInput')) document.getElementById('eventFileInput').value = '';
    const label = document.getElementById('eventFileLabel');
    if (label) label.innerHTML = 'Click or drag image here';
    if (document.getElementById('eventUploadStatus')) document.getElementById('eventUploadStatus').textContent = '';
    openModal('eventModal');
}

async function editEvent(id) {
    const result = await apiFetch('admin', 'events', 'GET', null, id);
    if (!result.success) return;
    const e = result.data;
    document.getElementById('eventModalTitle').innerHTML = '<i class="fas fa-calendar-alt"></i> Edit Event';
    document.getElementById('eventEditId').value = id;
    document.getElementById('eventTitle').value = e.title || '';
    document.getElementById('eventDate').value = e.date || '';
    document.getElementById('eventTime').value = e.time || '';
    document.getElementById('eventLocation').value = e.location || '';
    document.getElementById('eventDescription').value = e.description || '';
    const existingImageUrl = e.imageUrl || e.image_url || '';
    document.getElementById('eventImageUrl').value = existingImageUrl;
    document.getElementById('eventVideoUrl').value = e.videoUrl || e.video_url || '';
    document.getElementById('eventLink').value = e.link || '';
    document.getElementById('eventStatus').value = e.status || 'Upcoming';
    // Reset file state, show existing image
    eventSelectedFile = null;
    if (document.getElementById('eventFileInput')) document.getElementById('eventFileInput').value = '';
    const label = document.getElementById('eventFileLabel');
    if (label && existingImageUrl) {
        const fileName = existingImageUrl.split('/').pop() || 'Current image';
        label.innerHTML = '<i class="fas fa-image" style="color:#085636;margin-right:4px;"></i>' + fileName + ' <span style="color:#94a3b8;font-weight:400;">(current)</span>';
    }
    if (document.getElementById('eventUploadStatus')) document.getElementById('eventUploadStatus').textContent = '';
    openModal('eventModal');
}

async function saveEvent(event) {
    event.preventDefault();
    const editId = document.getElementById('eventEditId').value;
    const data = {
        title: document.getElementById('eventTitle').value.trim(),
        date: document.getElementById('eventDate').value,
        time: document.getElementById('eventTime').value,
        location: document.getElementById('eventLocation').value.trim(),
        description: document.getElementById('eventDescription').value.trim(),
        videoUrl: document.getElementById('eventVideoUrl').value.trim(),
        link: document.getElementById('eventLink').value.trim(),
        status: document.getElementById('eventStatus').value
    };
    // Upload file first if selected
    if (eventSelectedFile) {
        const statusEl = document.getElementById('eventUploadStatus');
        statusEl.innerHTML = '<i class="fas fa-spinner fa-spin" style="color:#085636;"></i> Uploading image...';
        try {
            data.imageUrl = await uploadGalleryFile(eventSelectedFile);
            statusEl.innerHTML = '<i class="fas fa-check-circle" style="color:#085636;"></i> Uploaded! Saving...';
        } catch (err) {
            statusEl.innerHTML = '<i class="fas fa-exclamation-circle" style="color:#ef4444;"></i> Upload failed';
            showToast('Image upload failed: ' + err.message, 'error');
            return false;
        }
    } else {
        data.imageUrl = document.getElementById('eventImageUrl').value.trim();
    }
    if (editId) {
        const result = await apiFetch('admin', 'events', 'PUT', data, editId);
        if (result.success) showToast('Event updated!');
        else showToast(result.message, 'error');
    } else {
        const result = await apiFetch('admin', 'events', 'POST', data);
        if (result.success) showToast('Event added!');
        else showToast(result.message, 'error');
    }
    eventSelectedFile = null;
    closeModal();
    renderEvents();
    updateStats();
    return false;
}

// ===== GALLERY =====
async function renderGallery() {
    const container = document.getElementById('galleryGridAdmin');
    const filterEl = document.getElementById('galleryCategoryFilter');
    const filterVal = filterEl ? filterEl.value : '';
    const result = await apiFetch('admin', 'gallery');
    let items = result.success ? (result.data?.items || []) : [];
    
    if (filterVal) {
        items = items.filter(i => i.category === filterVal);
    }

    const countEl = document.getElementById('galleryCount');
    if (countEl) countEl.textContent = items.length + ' item' + (items.length !== 1 ? 's' : '');

    if (items.length === 0) {
        container.innerHTML = '<div style="text-align:center;padding:40px;"><i class="fas fa-images" style="font-size:3rem;color:#d1d5db;margin-bottom:12px;"></i><p class="text-muted">No gallery items' + (filterVal ? ' in this category' : ' added yet') + '.</p></div>';
        return;
    }
    container.innerHTML = items.map(img => {
        const isVideo = (img.mediaType || img.media_type) === 'video';
        let thumb = img.imageUrl || img.image_url || '../images/pic.jpg';
        
        // Fix gallery image paths if they don't include uploads/ prefix
        if (thumb && !thumb.startsWith('http') && !thumb.startsWith('data:') && !thumb.startsWith('../') && !thumb.startsWith('/') && !thumb.startsWith('uploads/')) {
            thumb = '../uploads/' + thumb;
        } else if (thumb && thumb.startsWith('uploads/')) {
            // Fix paths that already have uploads/ but not the parent directory
            thumb = '../' + thumb;
        }
        
        const mediaBadge = isVideo ? '<div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:40px;height:40px;background:rgba(0,0,0,0.6);border-radius:50%;display:flex;align-items:center;justify-content:center;"><i class="fas fa-play" style="color:#fff;font-size:0.9rem;margin-left:2px;"></i></div>' : '';
        const typeBadge = isVideo ? '<span style="display:inline-block;background:#ede9fe;color:#7c3aed;font-size:0.65rem;padding:2px 6px;border-radius:8px;font-weight:600;margin-left:4px;"><i class="fas fa-video"></i></span>' : '';
        return `
        <div class="gallery-admin-item" style="position:relative;border-radius:12px;overflow:hidden;box-shadow:0 2px 12px rgba(0,0,0,0.08);transition:transform 0.2s,box-shadow 0.2s;" onmouseover="this.style.transform='translateY(-3px)';this.style.boxShadow='0 8px 24px rgba(0,0,0,0.12)'" onmouseout="this.style.transform='';this.style.boxShadow='0 2px 12px rgba(0,0,0,0.08)'">
            <div style="position:relative;">
                <img src="${isVideo && !thumb ? '../images/pic.jpg' : thumb}" alt="${img.title}" onerror="this.src='../images/pic.jpg'" style="width:100%;height:180px;object-fit:cover;display:block;">
                ${mediaBadge}
            </div>
            <div style="padding:10px 12px;background:#fff;">
                <h4 style="margin:0 0 4px;font-size:0.85rem;color:#1f2937;display:flex;align-items:center;">${img.title}${typeBadge}</h4>
                <span style="display:inline-block;background:#e8f5e9;color:#085636;font-size:0.7rem;padding:2px 8px;border-radius:10px;font-weight:600;">${img.category || 'Other'}</span>
            </div>
            <div class="gallery-admin-actions" style="position:absolute;top:8px;right:8px;display:flex;gap:4px;">
                <button onclick="editGalleryItem(${img.id})" title="Edit" style="background:#fff;border:none;width:30px;height:30px;border-radius:50%;cursor:pointer;box-shadow:0 2px 6px rgba(0,0,0,0.2);display:flex;align-items:center;justify-content:center;"><i class="fas fa-pencil-alt" style="font-size:0.75rem;color:#085636;"></i></button>
                <button onclick="confirmDelete('gallery', ${img.id}, '${img.title.replace(/'/g, "\\'")}')" title="Delete" style="background:#fff;border:none;width:30px;height:30px;border-radius:50%;cursor:pointer;box-shadow:0 2px 6px rgba(0,0,0,0.2);display:flex;align-items:center;justify-content:center;"><i class="fas fa-trash" style="font-size:0.75rem;color:#ef4444;"></i></button>
            </div>
        </div>
        `;
    }).join('');
}

let gallerySelectedFile = null; // holds the File object before save

function previewGalleryImage(url) {
    const img = document.getElementById('galleryPreviewImg');
    const placeholder = document.getElementById('galleryPreviewPlaceholder');
    const videoPreview = document.getElementById('galleryPreviewVideo');
    videoPreview.style.display = 'none';
    if (url && (url.startsWith('http') || url.startsWith('../') || url.startsWith('/') || url.startsWith('data:') || url instanceof Blob)) {
        img.src = (url instanceof Blob) ? URL.createObjectURL(url) : url;
        img.style.display = 'block';
        placeholder.style.display = 'none';
        img.onerror = function() {
            img.style.display = 'none';
            placeholder.style.display = 'block';
        };
    } else {
        img.style.display = 'none';
        placeholder.style.display = 'block';
    }
}

function handleGalleryFileSelect(input) {
    const file = input.files[0];
    if (!file) return;
    processGalleryFile(file);
}

function handleGalleryDrop(event) {
    const file = event.dataTransfer.files[0];
    if (!file) return;
    processGalleryFile(file);
}

function processGalleryFile(file) {
    const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    const label = document.getElementById('galleryFileLabel');
    const statusEl = document.getElementById('galleryUploadStatus');

    if (!allowedTypes.includes(file.type)) {
        showToast('Invalid file type. Only JPG, PNG, GIF, and WebP are allowed.', 'error');
        return;
    }
    if (file.size > 5 * 1024 * 1024) {
        showToast('File too large. Maximum size is 5MB.', 'error');
        return;
    }

    gallerySelectedFile = file;
    // Show file name in drop zone
    const sizeMB = (file.size / 1024 / 1024).toFixed(1);
    label.innerHTML = '<i class="fas fa-check-circle" style="color:#085636;margin-right:4px;"></i>' + file.name + ' <span style="color:#94a3b8;font-weight:400;">(' + sizeMB + 'MB)</span>';
    statusEl.innerHTML = '<i class="fas fa-info-circle" style="color:#085636;"></i> Image ready — click Save to upload';
    // Show preview in the modal preview area
    previewGalleryImage(file);
}

async function uploadGalleryFile(file) {
    const formData = new FormData();
    formData.append('file', file);
    const response = await fetch(`${API_BASE}?type=admin&collection=upload`, {
        method: 'POST',
        body: formData
    });
    const result = await safeFetch(response);
    if (result.success && result.data?.url) {
        return result.data.url;
    }
    throw new Error(result.message || 'Upload failed');
}

function previewGalleryVideo(url) {
    const img = document.getElementById('galleryPreviewImg');
    const placeholder = document.getElementById('galleryPreviewPlaceholder');
    const videoPreview = document.getElementById('galleryPreviewVideo');
    const frame = document.getElementById('galleryVideoFrame');
    img.style.display = 'none';
    if (!url) {
        videoPreview.style.display = 'none';
        placeholder.style.display = 'block';
        return;
    }
    const embedUrl = getVideoEmbedUrl(url);
    if (embedUrl) {
        frame.src = embedUrl;
        videoPreview.style.display = 'block';
        placeholder.style.display = 'none';
    } else {
        videoPreview.style.display = 'none';
        placeholder.style.display = 'block';
    }
}

function getVideoEmbedUrl(url) {
    if (!url) return '';
    // YouTube
    let match = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([a-zA-Z0-9_-]+)/);
    if (match) return 'https://www.youtube.com/embed/' + match[1];
    // Vimeo
    match = url.match(/vimeo\.com\/(\d+)/);
    if (match) return 'https://player.vimeo.com/video/' + match[1];
    // Direct video
    if (url.match(/\.(mp4|webm|ogg)$/i)) return url;
    return '';
}

function switchGalleryTab(type) {
    document.getElementById('galleryMediaType').value = type;
    const tabPic = document.getElementById('tabPicture');
    const tabVid = document.getElementById('tabVideo');
    const imgField = document.getElementById('galleryImageField');
    const vidField = document.getElementById('galleryVideoField');
    const thumbField = document.getElementById('galleryThumbField');
    if (type === 'image') {
        tabPic.style.background = '#085636';
        tabPic.style.color = '#fff';
        tabPic.style.borderBottom = '3px solid #085636';
        tabVid.style.background = '#f9fafb';
        tabVid.style.color = '#6b7280';
        tabVid.style.borderBottom = '3px solid transparent';
        imgField.style.display = 'block';
        vidField.style.display = 'none';
        thumbField.style.display = 'none';
    } else {
        tabVid.style.background = '#fff';
        tabVid.style.color = '#7c3aed';
        tabVid.style.borderBottom = '3px solid #7c3aed';
        tabPic.style.background = '#f9fafb';
        tabPic.style.color = '#6b7280';
        tabPic.style.borderBottom = '3px solid transparent';
        imgField.style.display = 'none';
        vidField.style.display = 'block';
        thumbField.style.display = 'block';
    }
    // Reset previews
    document.getElementById('galleryPreviewImg').style.display = 'none';
    document.getElementById('galleryPreviewVideo').style.display = 'none';
    document.getElementById('galleryPreviewPlaceholder').style.display = 'block';
}

function openGalleryModal() {
    document.getElementById('galleryModalTitle').innerHTML = '<i class="fas fa-images" style="margin-right:10px;"></i>Add to Gallery';
    document.getElementById('galleryEditId').value = '';
    document.getElementById('galleryForm').reset();
    document.getElementById('galleryCategory').value = 'Academic';
    document.getElementById('galleryMediaType').value = 'image';
    document.getElementById('galleryImageUrl').value = '';
    if (document.getElementById('galleryVideoUrl')) document.getElementById('galleryVideoUrl').value = '';
    if (document.getElementById('galleryThumbUrl')) document.getElementById('galleryThumbUrl').value = '';
    if (document.getElementById('galleryFileInput')) document.getElementById('galleryFileInput').value = '';
    // Reset drop zone label
    const label = document.getElementById('galleryFileLabel');
    if (label) label.innerHTML = 'Click or drag image here';
    if (document.getElementById('galleryUploadStatus')) document.getElementById('galleryUploadStatus').textContent = '';
    gallerySelectedFile = null;
    switchGalleryTab('image');
    openModal('galleryModal');
}

async function editGalleryItem(id) {
    const result = await apiFetch('admin', 'gallery', 'GET', null, id);
    if (!result.success) return;
    const item = result.data;
    document.getElementById('galleryModalTitle').innerHTML = '<i class="fas fa-images" style="margin-right:10px;"></i>Edit Gallery Item';
    document.getElementById('galleryEditId').value = id;
    const existingImageUrl = item.imageUrl || item.image_url || '';
    document.getElementById('galleryImageUrl').value = existingImageUrl;
    document.getElementById('galleryTitle').value = item.title || '';
    document.getElementById('galleryCategory').value = item.category || 'Academic';
    document.getElementById('galleryDescription').value = item.description || '';
    const mediaType = item.mediaType || item.media_type || 'image';
    document.getElementById('galleryMediaType').value = mediaType;
    if (document.getElementById('galleryVideoUrl')) document.getElementById('galleryVideoUrl').value = item.videoUrl || item.video_url || '';
    if (document.getElementById('galleryThumbUrl')) document.getElementById('galleryThumbUrl').value = existingImageUrl;
    // Reset file state
    gallerySelectedFile = null;
    if (document.getElementById('galleryFileInput')) document.getElementById('galleryFileInput').value = '';
    // Show existing image in drop zone
    const label = document.getElementById('galleryFileLabel');
    if (label && mediaType === 'image' && existingImageUrl) {
        const fileName = existingImageUrl.split('/').pop() || 'Current image';
        label.innerHTML = '<i class="fas fa-image" style="color:#085636;margin-right:4px;"></i>' + fileName + ' <span style="color:#94a3b8;font-weight:400;">(current)</span>';
    }
    switchGalleryTab(mediaType);
    if (mediaType === 'image') {
        previewGalleryImage(existingImageUrl);
    } else {
        previewGalleryVideo(item.videoUrl || item.video_url || '');
    }
    openModal('galleryModal');
}

async function saveGalleryItem(event) {
    event.preventDefault();
    const editId = document.getElementById('galleryEditId').value;
    const mediaType = document.getElementById('galleryMediaType').value;
    const data = {
        title: document.getElementById('galleryTitle').value.trim(),
        category: document.getElementById('galleryCategory').value,
        description: document.getElementById('galleryDescription').value.trim(),
        mediaType: mediaType
    };
    if (mediaType === 'video') {
        data.videoUrl = document.getElementById('galleryVideoUrl').value.trim();
        data.imageUrl = document.getElementById('galleryThumbUrl').value.trim() || '';
    } else {
        // If a file is selected, upload it first
        if (gallerySelectedFile) {
            const statusEl = document.getElementById('galleryUploadStatus');
            statusEl.innerHTML = '<i class="fas fa-spinner fa-spin" style="color:#085636;"></i> Uploading image...';
            try {
                data.imageUrl = await uploadGalleryFile(gallerySelectedFile);
                statusEl.innerHTML = '<i class="fas fa-check-circle" style="color:#085636;"></i> Uploaded! Saving...';
            } catch (err) {
                statusEl.innerHTML = '<i class="fas fa-exclamation-circle" style="color:#ef4444;"></i> Upload failed';
                showToast('Image upload failed: ' + err.message, 'error');
                return false;
            }
        } else {
            data.imageUrl = document.getElementById('galleryImageUrl').value.trim();
        }
        data.videoUrl = '';
    }
    if (mediaType === 'image' && !data.imageUrl) {
        showToast('Please select an image to upload', 'error');
        return false;
    }
    if (mediaType === 'video' && !data.videoUrl) {
        showToast('Please provide a video URL', 'error');
        return false;
    }
    if (editId) {
        const result = await apiFetch('admin', 'gallery', 'PUT', data, editId);
        if (result.success) showToast('Gallery item updated!');
        else showToast(result.message, 'error');
    } else {
        const result = await apiFetch('admin', 'gallery', 'POST', data);
        if (result.success) showToast('Gallery item added!');
        else showToast(result.message, 'error');
    }
    gallerySelectedFile = null;
    closeModal();
    renderGallery();
    updateStats();
    return false;
}

// ===== BLOG =====
async function renderBlog() {
    const tbody = document.getElementById('blogTableBody');
    const result = await apiFetch('admin', 'blog');
    const posts = result.success ? (result.data?.items || []) : [];
    if (posts.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" class="text-center text-muted">No blog posts yet.</td></tr>';
        return;
    }
    posts.sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));
    tbody.innerHTML = posts.map(p => {
        const statusClass = (p.status || 'Draft').toLowerCase();
        return `<tr>
            <td><strong>${p.title}</strong></td>
            <td>${p.author || '-'}</td>
            <td>${formatDate(p.createdAt)}</td>
            <td><span class="status-badge ${statusClass}">${p.status || 'Draft'}</span></td>
            <td>
                <button class="admin-btn admin-btn-primary admin-btn-sm" onclick="editBlogPost(${p.id})"><i class="fas fa-edit"></i></button>
                <button class="admin-btn admin-btn-danger admin-btn-sm" onclick="confirmDelete('blog', ${p.id}, '${p.title}')"><i class="fas fa-trash"></i></button>
            </td>
        </tr>`;
    }).join('');
}

function openBlogModal() {
    document.getElementById('blogModalTitle').innerHTML = '<i class="fas fa-blog"></i> New Blog Post';
    document.getElementById('blogEditId').value = '';
    document.getElementById('blogForm').reset();
    document.getElementById('blogStatus').value = 'Published';
    document.getElementById('blogCategory').value = 'General';
    openModal('blogModal');
}

async function editBlogPost(id) {
    const result = await apiFetch('admin', 'blog', 'GET', null, id);
    if (!result.success) return;
    const p = result.data;
    document.getElementById('blogModalTitle').innerHTML = '<i class="fas fa-blog"></i> Edit Blog Post';
    document.getElementById('blogEditId').value = id;
    document.getElementById('blogTitle').value = p.title || '';
    document.getElementById('blogAuthor').value = p.author || '';
    document.getElementById('blogCategory').value = p.category || 'General';
    document.getElementById('blogContent').value = p.content || '';
    document.getElementById('blogImage').value = p.image || '';
    document.getElementById('blogStatus').value = p.status || 'Draft';
    openModal('blogModal');
}

async function saveBlogPost(event) {
    event.preventDefault();
    const editId = document.getElementById('blogEditId').value;
    const data = {
        title: document.getElementById('blogTitle').value.trim(),
        author: document.getElementById('blogAuthor').value.trim(),
        category: document.getElementById('blogCategory').value,
        content: document.getElementById('blogContent').value.trim(),
        image: document.getElementById('blogImage').value.trim(),
        status: document.getElementById('blogStatus').value
    };
    if (editId) {
        const result = await apiFetch('admin', 'blog', 'PUT', data, editId);
        if (result.success) showToast('Blog post updated!');
        else showToast(result.message, 'error');
    } else {
        const result = await apiFetch('admin', 'blog', 'POST', data);
        if (result.success) showToast('Blog post created!');
        else showToast(result.message, 'error');
    }
    closeModal();
    renderBlog();
    updateStats();
    return false;
}

// ===== SERVICES =====
async function renderServices() {
    const tbody = document.getElementById('servicesTableBody');
    const result = await apiFetch('admin', 'services');
    const services = result.success ? (result.data?.items || []) : [];
    if (services.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" class="text-center text-muted">No services added yet.</td></tr>';
        return;
    }
    tbody.innerHTML = services.map(s => `<tr>
        <td><strong>${s.title}</strong></td>
        <td>${(s.description || '').substring(0, 80)}${(s.description || '').length > 80 ? '...' : ''}</td>
        <td><i class="${s.icon || 'fas fa-concierge-bell'}"></i></td>
        <td>
            <button class="admin-btn admin-btn-primary admin-btn-sm" onclick="editService(${s.id})"><i class="fas fa-edit"></i></button>
            <button class="admin-btn admin-btn-danger admin-btn-sm" onclick="confirmDelete('service', ${s.id}, '${s.title}')"><i class="fas fa-trash"></i></button>
        </td>
    </tr>`).join('');
}

function openServiceModal() {
    document.getElementById('serviceModalTitle').innerHTML = '<i class="fas fa-concierge-bell"></i> Add Service';
    document.getElementById('serviceEditId').value = '';
    document.getElementById('serviceForm').reset();
    openModal('serviceModal');
}

async function editService(id) {
    const result = await apiFetch('admin', 'services', 'GET', null, id);
    if (!result.success) return;
    const s = result.data;
    document.getElementById('serviceModalTitle').innerHTML = '<i class="fas fa-concierge-bell"></i> Edit Service';
    document.getElementById('serviceEditId').value = id;
    document.getElementById('serviceTitle').value = s.title || '';
    document.getElementById('serviceDescription').value = s.description || '';
    document.getElementById('serviceIcon').value = s.icon || '';
    openModal('serviceModal');
}

async function saveService(event) {
    event.preventDefault();
    const editId = document.getElementById('serviceEditId').value;
    const data = {
        title: document.getElementById('serviceTitle').value.trim(),
        description: document.getElementById('serviceDescription').value.trim(),
        icon: document.getElementById('serviceIcon').value.trim()
    };
    if (editId) {
        const result = await apiFetch('admin', 'services', 'PUT', data, editId);
        if (result.success) showToast('Service updated!');
        else showToast(result.message, 'error');
    } else {
        const result = await apiFetch('admin', 'services', 'POST', data);
        if (result.success) showToast('Service added!');
        else showToast(result.message, 'error');
    }
    closeModal();
    renderServices();
    updateStats();
    return false;
}

// ===== TEAM MEMBERS =====
async function renderTeamMembers() {
    const tbody = document.getElementById('teamMembersTableBody');
    if (!tbody) return;

    // Load org chart position data
    loadOrgChart();

    const result = await apiFetch('admin', 'teammembers');
    const members = result.success ? (result.data?.items || []) : [];

    // Update org chart boxes with member counts
    updateOrgChart(members);

    if (members.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" class="text-center text-muted">No team members added yet.</td></tr>';
        return;
    }
    members.sort((a, b) => (a.sortOrder || 0) - (b.sortOrder || 0));
    tbody.innerHTML = members.map(m => {
        const statusClass = (m.status || 'Active').toLowerCase();
        const visible = m.showOnWebsite !== 0;
        let thumb = m.imageUrl || '../images/pic.jpg';
        
        // Fix team member image paths if they don't include uploads/ prefix
        if (thumb && !thumb.startsWith('http') && !thumb.startsWith('data:') && !thumb.startsWith('../') && !thumb.startsWith('/') && !thumb.startsWith('uploads/')) {
            thumb = '../uploads/' + thumb;
        } else if (thumb && thumb.startsWith('uploads/')) {
            // Fix paths that already have uploads/ but not the parent directory
            thumb = '../' + thumb;
        }
        
        return `<tr>
            <td>${m.id}</td>
            <td style="display:flex;align-items:center;gap:10px;"><img src="${thumb}" style="width:36px;height:36px;border-radius:50%;object-fit:cover;border:2px solid #085636;flex-shrink:0;" onerror="this.src='../images/pic.jpg'"><strong>${m.firstName} ${m.lastName}</strong></td>
            <td>${m.role || '-'}</td>
            <td>${m.category || '-'}</td>
            <td>${m.sortOrder || 0}</td>
            <td><span class="status-badge ${statusClass}">${m.status || 'Active'}</span></td>
            <td><span class="status-badge ${visible ? 'active' : 'inactive'}"><i class="fas fa-${visible ? 'eye' : 'eye-slash'}"></i> ${visible ? 'Visible' : 'Hidden'}</span></td>
            <td>
                <button class="admin-btn admin-btn-primary admin-btn-sm" onclick="editTeamMember(${m.id})" title="Edit"><i class="fas fa-edit"></i></button>
                <button class="admin-btn admin-btn-danger admin-btn-sm" onclick="confirmDelete('teammember', ${m.id}, '${m.firstName} ${m.lastName}')" title="Delete"><i class="fas fa-trash"></i></button>
            </td>
        </tr>`;
    }).join('');
}

// Update org-chart boxes with member counts based on category
function updateOrgChart(members) {
    const container = document.getElementById('orgChartContainer');
    if (!container) return;

    // Count members by category
    const counts = {
        Trustees: 0,
        Accountant: 0,
        Principal: 0,
        Leadership: 0,
        Leadership: 0,
        Teachers: 0,
        Staff: 0,
        Administration: 0
    };
    members.forEach(m => {
        if (counts[m.category] !== undefined) {
            counts[m.category]++;
        }
    });

    // Map org-chart boxes to categories
    const boxMap = {
        'trustees': { label: 'TRUSTEES', count: null },
        'board': { label: 'BOARD OF DIRECTORS (BoT)', count: null },
        'principal': { label: 'Operation (Principal)', count: counts.Leadership > 0 ? counts.Leadership : null },
        'accountant': { label: 'Accountant', count: null },
        'headteacher': { label: 'Head Teacher', count: null },
        'hr': { label: 'Human Resource', count: counts.Administration > 0 ? counts.Administration : null },
        'bursar': { label: 'Bursar', count: null },
        'deputy': { label: 'Deputy Head Teacher', count: null },
        'languages': { label: 'Languages', count: null },
        'seniorhead': { label: 'Senior Head', count: null },
        'preschool': { label: 'Pre-School, Nursery, Kindergarten', count: null },
        'classteacher': { label: 'Class Teacher', count: null },
        'sciencehead': { label: 'Science Head', count: null },
        'teachers': { label: 'Teachers', count: counts.Teachers > 0 ? counts.Teachers : null },
        'prefects': { label: 'Prefects', count: counts.Staff > 0 ? counts.Staff : null },
        'learners': { label: 'Learners', count: null }
    };

    // Update each box
    Object.keys(boxMap).forEach(key => {
        const box = container.querySelector(`[data-org="${key}"]`);
        if (!box) return;
        const info = boxMap[key];
        // Remove existing badge
        const existingBadge = box.querySelector('.member-count');
        if (existingBadge) existingBadge.remove();
        // Add count badge if applicable
        if (info.count !== null && info.count > 0) {
            const badge = document.createElement('span');
            badge.className = 'member-count';
            badge.textContent = info.count + ' member' + (info.count > 1 ? 's' : '');
            box.appendChild(badge);
        }
    });
}

// ===== ORG CHART POSITION MANAGEMENT =====
const ORG_POSITIONS = ['trustees', 'board', 'principal', 'accountant', 'headteacher', 'hr', 'bursar', 'deputy', 'languages', 'seniorhead', 'preschool', 'classteacher', 'sciencehead', 'teachers', 'prefects', 'learners'];

const ORG_DEFAULT_TITLES = {
  trustees: 'TRUSTEES',
  board: 'BOARD OF DIRECTORS (BoT)',
  principal: 'Operation (Principal)',
  accountant: 'Accountant',
  headteacher: 'Head Teacher',
  hr: 'Human Resource',
  bursar: 'Bursar',
  deputy: 'Deputy Head Teacher',
  languages: 'Languages',
  seniorhead: 'Senior Head',
  preschool: 'Pre-School, Nursery, Kindergarten',
  classteacher: 'Class Teacher',
  sciencehead: 'Science Head',
  teachers: 'Teachers',
  prefects: 'Prefects',
  learners: 'Learners'
};

async function loadOrgChart() {
    try {
        const result = await apiFetch('admin', 'content');
        if (!result.success) return;
        const orgData = result.data?.org_chart || {};
        ORG_POSITIONS.forEach(key => {
            // Person name
            const display = document.getElementById('org_display_' + key);
            const input = document.getElementById('org_input_' + key);
            if (display && orgData[key]) display.textContent = orgData[key];
            if (input && orgData[key]) input.value = orgData[key];
            // Position title
            const titleKey = 'title_' + key;
            const titleEl = document.getElementById('org_title_' + key);
            const titleInput = document.getElementById('org_title_input_' + key);
            const titleVal = orgData[titleKey] || ORG_DEFAULT_TITLES[key] || '';
            if (titleEl && titleVal) titleEl.textContent = titleVal;
            if (titleInput && titleVal) titleInput.value = titleVal;
        });
    } catch (e) {
        console.log('Could not load org chart data');
    }
}

async function saveOrgTitle(key) {
    const input = document.getElementById('org_title_input_' + key);
    if (!input) return;
    const value = input.value.trim();
    if (!value) {
        showToast('Please enter a title', 'error');
        return;
    }
    try {
        const result = await apiFetch('admin', 'content', 'POST', {
            page: 'org_chart',
            data: { ['title_' + key]: value }
        });
        if (result.success) {
            const titleEl = document.getElementById('org_title_' + key);
            if (titleEl) titleEl.textContent = value;
            showToast('Title updated!');
        } else {
            showToast(result.message || 'Failed to save', 'error');
        }
    } catch (e) {
        showToast('Error saving title', 'error');
    }
}

async function saveOrgPosition(key) {
    const input = document.getElementById('org_input_' + key);
    if (!input) return;
    const value = input.value.trim();
    if (!value) {
        showToast('Please enter a name', 'error');
        return;
    }
    try {
        const result = await apiFetch('admin', 'content', 'POST', {
            page: 'org_chart',
            data: { [key]: value }
        });
        if (result.success) {
            const display = document.getElementById('org_display_' + key);
            if (display) display.textContent = value;
            showToast('Position updated!');
        } else {
            showToast(result.message || 'Failed to save', 'error');
        }
    } catch (e) {
        showToast('Error saving position', 'error');
    }
}

let tmSelectedFile = null;

function handleTmImageSelect(input) {
    const file = input.files?.[0];
    if (!file) return;
    const maxMB = 5;
    if (file.size > maxMB * 1024 * 1024) {
        document.getElementById('tmUploadStatus').innerHTML = '<i class="fas fa-exclamation-circle" style="color:#ef4444;"></i> File too large (max ' + maxMB + 'MB)';
        input.value = '';
        return;
    }
    tmSelectedFile = file;
    const sizeMB = (file.size / 1024 / 1024).toFixed(1);
    document.getElementById('tmFileLabel').textContent = file.name + ' (' + sizeMB + 'MB)';
    document.getElementById('tmUploadStatus').innerHTML = '<i class="fas fa-check-circle" style="color:#085636;"></i> Ready — will upload when you save';
    // Show preview
    const reader = new FileReader();
    reader.onload = function(e) {
        const preview = document.getElementById('tmImagePreview');
        preview.src = e.target.result;
        preview.style.display = 'block';
    };
    reader.readAsDataURL(file);
}

function previewTmUrl() {
    const url = document.getElementById('tmImageUrl').value.trim();
    if (!url) return;
    const preview = document.getElementById('tmImagePreview');
    preview.src = url;
    preview.style.display = 'block';
    preview.onerror = function() { preview.style.display = 'none'; };
}

function resetTmImage() {
    tmSelectedFile = null;
    const preview = document.getElementById('tmImagePreview');
    preview.src = '';
    preview.style.display = 'none';
    const fileInput = document.getElementById('tmImageFile');
    if (fileInput) fileInput.value = '';
    const label = document.getElementById('tmFileLabel');
    if (label) label.textContent = 'Click to upload photo (JPG, PNG, WebP \u2014 max 5MB)';
    const status = document.getElementById('tmUploadStatus');
    if (status) status.innerHTML = '';
}

function openTeamMemberModal() {
    document.getElementById('teamMemberModalTitle').innerHTML = '<i class="fas fa-users"></i> Add Team Member';
    document.getElementById('teamMemberEditId').value = '';
    document.getElementById('teamMemberForm').reset();
    document.getElementById('tmCategory').value = 'Leadership';
    document.getElementById('tmStatus').value = 'Active';
    document.getElementById('tmSortOrder').value = '0';
    document.getElementById('tmShowOnWebsite').checked = true;
    resetTmImage();
    openModal('teamMemberModal');
}

async function editTeamMember(id) {
    const result = await apiFetch('admin', 'teammembers', 'GET', null, id);
    if (!result.success) return;
    const m = result.data;
    document.getElementById('teamMemberModalTitle').innerHTML = '<i class="fas fa-users"></i> Edit Team Member';
    document.getElementById('teamMemberEditId').value = id;
    document.getElementById('tmFirstName').value = m.firstName || '';
    document.getElementById('tmLastName').value = m.lastName || '';
    document.getElementById('tmRole').value = m.role || '';
    document.getElementById('tmCategory').value = m.category || 'Leadership';
    document.getElementById('tmImageUrl').value = m.imageUrl || '';
    document.getElementById('tmDescription').value = m.description || '';
    document.getElementById('tmSortOrder').value = m.sortOrder || 0;
    document.getElementById('tmStatus').value = m.status || 'Active';
    document.getElementById('tmShowOnWebsite').checked = m.showOnWebsite !== 0;
    resetTmImage();
    // Show existing image preview
    if (m.imageUrl) {
        const preview = document.getElementById('tmImagePreview');
        preview.src = m.imageUrl;
        preview.style.display = 'block';
        preview.onerror = function() { preview.style.display = 'none'; };
    }
    openModal('teamMemberModal');
}

async function saveTeamMember(event) {
    event.preventDefault();
    const editId = document.getElementById('teamMemberEditId').value;
    const statusEl = document.getElementById('tmUploadStatus');
    // Upload image file if one was selected
    let imageUrl = document.getElementById('tmImageUrl').value.trim();
    if (tmSelectedFile) {
        statusEl.innerHTML = '<i class="fas fa-spinner fa-spin" style="color:#085636;"></i> Uploading image...';
        try {
            const formData = new FormData();
            formData.append('file', tmSelectedFile);
            const uploadRes = await fetch(`${API_BASE}?type=admin&collection=upload`, { method: 'POST', body: formData });
            const uploadResult = await uploadRes.json();
            if (uploadResult.success && uploadResult.data?.url) {
                imageUrl = uploadResult.data.url;
                document.getElementById('tmImageUrl').value = imageUrl;
                statusEl.innerHTML = '<i class="fas fa-check-circle" style="color:#085636;"></i> Uploaded! Saving...';
            } else {
                statusEl.innerHTML = '<i class="fas fa-exclamation-circle" style="color:#ef4444;"></i> Upload failed: ' + (uploadResult.message || '');
                showToast('Image upload failed', 'error');
                return false;
            }
        } catch (err) {
            statusEl.innerHTML = '<i class="fas fa-exclamation-circle" style="color:#ef4444;"></i> Upload error';
            showToast('Image upload error: ' + err.message, 'error');
            return false;
        }
    }
    const data = {
        firstName: document.getElementById('tmFirstName').value.trim(),
        lastName: document.getElementById('tmLastName').value.trim(),
        role: document.getElementById('tmRole').value.trim(),
        category: document.getElementById('tmCategory').value,
        imageUrl: imageUrl,
        description: document.getElementById('tmDescription').value.trim(),
        sortOrder: parseInt(document.getElementById('tmSortOrder').value) || 0,
        status: document.getElementById('tmStatus').value,
        showOnWebsite: document.getElementById('tmShowOnWebsite').checked ? 1 : 0
    };
    if (editId) {
        const result = await apiFetch('admin', 'teammembers', 'PUT', data, editId);
        if (result.success) showToast('Team member updated!');
        else showToast(result.message, 'error');
    } else {
        const result = await apiFetch('admin', 'teammembers', 'POST', data);
        if (result.success) showToast('Team member added!');
        else showToast(result.message, 'error');
    }
    closeModal();
    renderTeamMembers();
    updateStats();
    return false;
}

// ===== ADMIN MESSAGING FUNCTIONS =====
async function viewMessage(messageId) {
    try {
        const result = await apiFetch('admin', 'messages', 'GET', null, messageId);
        if (!result.success || !result.data) {
            showToast('Failed to load message', 'error');
            return;
        }
        
        const message = result.data;
        
        // Create a modal to view the message
        const modalHtml = `
            <div id="messageViewModal" class="admin-modal" style="display:flex;">
                <div class="admin-modal-content" style="max-width:600px;">
                    <div class="admin-modal-header">
                        <h3><i class="fas fa-envelope"></i> Message Details</h3>
                        <button class="admin-modal-close" onclick="closeMessageViewModal()">&times;</button>
                    </div>
                    <div class="admin-modal-body">
                        <div class="form-group">
                            <label>From</label>
                            <div class="form-value">${message.sender || 'N/A'}</div>
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <div class="form-value">${message.email || 'N/A'}</div>
                        </div>
                        <div class="form-group">
                            <label>Subject</label>
                            <div class="form-value">${message.subject || 'N/A'}</div>
                        </div>
                        <div class="form-group">
                            <label>Date</label>
                            <div class="form-value">${formatDate(message.date)}</div>
                        </div>
                        <div class="form-group">
                            <label>Message</label>
                            <div class="form-value" style="white-space: pre-wrap;">${message.content || 'No content'}</div>
                        </div>
                    </div>
                    <div class="admin-modal-footer">
                        <button class="admin-btn admin-btn-secondary" onclick="closeMessageViewModal()">Close</button>
                        <button class="admin-btn admin-btn-primary" onclick="replyToMessageFromAdmin(${message.id})"><i class="fas fa-reply"></i> Reply</button>
                    </div>
                </div>
            </div>
        `;
        
        const existingModal = document.getElementById('messageViewModal');
        if (existingModal) {
            existingModal.remove();
        }
        
        document.body.insertAdjacentHTML('beforeend', modalHtml);
        
        // Mark as read
        await apiFetch('admin', 'messages', 'PUT', { status: 'read' }, messageId);
        renderMessages();
        
    } catch (error) {
        console.error('Error viewing message:', error);
        showToast('Error viewing message', 'error');
    }
}

function closeMessageViewModal() {
    const modal = document.getElementById('messageViewModal');
    if (modal) {
        modal.remove();
    }
}

async function replyToMessageFromAdmin(messageId) {
    try {
        const result = await apiFetch('admin', 'messages', 'GET', null, messageId);
        if (!result.success || !result.data) {
            showToast('Failed to load message', 'error');
            return;
        }
        
        const message = result.data;
        closeMessageViewModal();
        
        // Open a new message modal with reply details
        openSendMessageModal();
        
        // Pre-fill the form
        const recipientSelect = document.getElementById('adminMessageRecipient');
        const subjectInput = document.getElementById('adminMessageSubject');
        const contentTextarea = document.getElementById('adminMessageContent');
        
        // Set recipient based on original sender
        if (message.sender) {
            for (let i = 0; i < recipientSelect.options.length; i++) {
                if (recipientSelect.options[i].text.includes(message.sender)) {
                    recipientSelect.selectedIndex = i;
                    break;
                }
            }
        }
        
        subjectInput.value = `Re: ${message.subject || ''}`;
        contentTextarea.value = `\n\n--- Original Message ---\nFrom: ${message.sender}\nDate: ${formatDate(message.date)}\n\n${message.content || ''}`;
        
    } catch (error) {
        console.error('Error replying to message:', error);
        showToast('Error replying to message', 'error');
    }
}

// ===== ADMIN MESSAGING FUNCTIONS =====
async function openSendMessageModal() {
    // Create send message modal for admin
    const modalHtml = `
        <div id="adminSendMessageModal" class="admin-modal" style="display:flex;">
            <div class="admin-modal-content" style="max-width:600px;">
                <div class="admin-modal-header">
                    <h3><i class="fas fa-paper-plane"></i> Send Message</h3>
                    <button class="admin-modal-close" onclick="closeAdminSendMessageModal()">&times;</button>
                </div>
                <form id="adminMessageForm" onsubmit="return sendAdminMessage(event)">
                    <div class="admin-modal-body">
                        <div class="form-group">
                            <label>Recipient *</label>
                            <select id="adminMessageRecipient" class="form-control" required>
                                <option value="">Select Recipient</option>
                                <option value="All Teachers">All Teachers</option>
                                <option value="All Parents">All Parents</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Subject *</label>
                            <input type="text" id="adminMessageSubject" class="form-control" placeholder="Message subject" required>
                        </div>
                        <div class="form-group">
                            <label>Message *</label>
                            <textarea id="adminMessageContent" class="form-control" rows="5" placeholder="Write your message..." required></textarea>
                        </div>
                        <div class="form-group">
                            <label>Priority</label>
                            <select id="adminMessagePriority" class="form-control">
                                <option value="Normal">Normal</option>
                                <option value="Important">Important</option>
                                <option value="Urgent">Urgent</option>
                            </select>
                        </div>
                    </div>
                    <div class="admin-modal-footer">
                        <button type="button" class="admin-btn admin-btn-secondary" onclick="closeAdminSendMessageModal()">Cancel</button>
                        <button type="submit" class="admin-btn admin-btn-primary"><i class="fas fa-paper-plane"></i> Send</button>
                    </div>
                </form>
            </div>
        </div>
    `;
    
    const existingModal = document.getElementById('adminSendMessageModal');
    if (existingModal) {
        existingModal.remove();
    }
    
    document.body.insertAdjacentHTML('beforeend', modalHtml);
    
    // Load teachers and parents for recipient selection
    await loadMessageRecipients();
}

async function loadMessageRecipients() {
    try {
        // Load teachers
        const teachersResult = await apiFetch('admin', 'teachers');
        if (teachersResult.success) {
            const teachers = Array.isArray(teachersResult.data) ? teachersResult.data : (teachersResult.data.items || []);
            const recipientSelect = document.getElementById('adminMessageRecipient');
            
            teachers.forEach(t => {
                if (t.approved) {
                    recipientSelect.innerHTML += `<option value="Teacher: ${t.firstName} ${t.lastName}">${t.firstName} ${t.lastName} (Teacher)</option>`;
                }
            });
        }
        
        // Load parents could be added similarly
    } catch (error) {
        console.error('Error loading message recipients:', error);
    }
}

function closeAdminSendMessageModal() {
    const modal = document.getElementById('adminSendMessageModal');
    if (modal) {
        modal.remove();
    }
}

async function sendAdminMessage(event) {
    event.preventDefault();
    
    const data = {
        recipient: document.getElementById('adminMessageRecipient').value,
        subject: document.getElementById('adminMessageSubject').value.trim(),
        content: document.getElementById('adminMessageContent').value.trim(),
        priority: document.getElementById('adminMessagePriority').value,
        sender: 'Admin',
        senderId: 1, // Admin ID
        date: new Date().toISOString(),
        status: 'sent'
    };
    
    try {
        const result = await apiFetch('admin', 'messages', 'POST', data);
        if (result.success) {
            showToast('Message sent successfully!');
            closeAdminSendMessageModal();
            renderMessages();
        } else {
            showToast(result.message || 'Failed to send message', 'error');
        }
    } catch (error) {
        console.error('Error sending message:', error);
        showToast('Error sending message', 'error');
    }
    
    return false;
}

// ===== MESSAGES =====
async function renderMessages() {
    const tbody = document.getElementById('messagesTableBody');
    const result = await apiFetch('admin', 'messages');
    const messages = result.success ? (result.data?.items || []) : [];
    if (messages.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted" style="color: #085636">No messages yet.</td></tr>';
        return;
    }
    messages.sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));
    tbody.innerHTML = messages.map(m => {
        const isRead = m.read ? 'read' : 'unread';
        return `<tr style="${m.read ? '' : 'font-weight: bold; background: #f0f7ff; color: #0887'}">
            <td>${m.name || '-'}</td>
            <td>${m.email || '-'}</td>
            <td>${m.subject || '-'}</td>
            <td>${formatDateTime(m.createdAt)}</td>
            <td><span class="status-badge ${isRead}">${m.read ? 'Read' : 'New'}</span></td>
            <td>
                <button class="admin-btn admin-btn-info admin-btn-sm" onclick="viewMessage(${m.id})"><i class="fas fa-eye"></i></button>
                <button class="admin-btn admin-btn-danger admin-btn-sm" onclick="confirmDelete('message', ${m.id}, '${m.subject || 'message'}')"><i class="fas fa-trash"></i></button>
            </td>
        </tr>`;
    }).join('');
}

async function viewMessage(id) {
    const result = await apiFetch('admin', 'messages', 'GET', null, id);
    if (!result.success) return;
    const msg = result.data;
    // Mark as read
    if (!msg.read) {
        await apiFetch('admin', 'messages', 'PUT', { read: true }, id);
        renderMessages();
        updateStats();
    }
    const body = document.getElementById('messageViewBody');
    body.innerHTML = `
        <div style="margin-bottom:15px; color: #333"><strong>From:</strong> ${msg.name} (${msg.email})</div>
        <div style="margin-bottom:15px; color: #333"><strong>Subject:</strong> ${msg.subject || 'No Subject'}</div>
        <div style="margin-bottom:15px; color: #333"><strong>Date:</strong> ${formatDateTime(msg.createdAt)}</div>
        <div style="padding:15px; background:#f8f9fa; border-radius:6px; white-space:pre-wrap; color: #333">${msg.message || 'No content'}</div>
        <div style="margin-top:15px;">
            <button class="admin-btn admin-btn-primary" onclick="openSendMessageModal()">Reply</button>
        </div>
    `;
    openModal('messageViewModal');
}

// ===== SETTINGS =====
async function loadSettings() {
    const result = await apiFetch('admin', 'settings');
    if (!result.success) return;
    const settings = result.data || {};
    document.getElementById('profileUsername').value = settings.username || '';
    document.getElementById('profileDisplayName').value = settings.displayName || '';
    document.getElementById('profileEmail').value = settings.email || '';
    
    // Show current profile photo if exists
    if (currentUser && currentUser.profilePhoto) {
        showProfilePhotoPreview(currentUser.profilePhoto);
    }
}

function showProfilePhotoPreview(photoUrl) {
    const preview = document.getElementById('profilePhotoPreview');
    if (preview && photoUrl) {
        preview.innerHTML = `
            <img src="${photoUrl}" alt="Profile Photo" style="max-width: 150px; max-height: 150px; border-radius: 8px; border: 2px solid #085636;">
        `;
    }
}

// Handle photo file selection for preview
document.addEventListener('DOMContentLoaded', function() {
    const photoInput = document.getElementById('profilePhoto');
    if (photoInput) {
        photoInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    showProfilePhotoPreview(e.target.result);
                };
                reader.readAsDataURL(file);
            }
        });
    }
});

async function updateProfile(event) {
    event.preventDefault();
    
    const formData = new FormData();
    formData.append('username', document.getElementById('profileUsername').value.trim());
    formData.append('displayName', document.getElementById('profileDisplayName').value.trim());
    formData.append('email', document.getElementById('profileEmail').value.trim());
    formData.append('adminId', currentUser.id || 1);
    
    // Handle profile photo upload
    const photoInput = document.getElementById('profilePhoto');
    if (photoInput.files && photoInput.files[0]) {
        formData.append('profilePhoto', photoInput.files[0]);
    }
    
    const result = await apiFetch('admin', 'settings', 'POST', formData);
    if (result.success) {
        // Update currentUser object
        if (currentUser) {
            currentUser.username = document.getElementById('profileUsername').value.trim();
            currentUser.displayName = document.getElementById('profileDisplayName').value.trim();
            currentUser.email = document.getElementById('profileEmail').value.trim();
            // Update photo URL if returned
            if (result.data && result.data.photoUrl) {
                currentUser.profilePhoto = result.data.photoUrl;
            }
            // Save updated session
            const sessionData = localStorage.getItem('noh_admin_session') || sessionStorage.getItem('noh_admin_session');
            if (sessionData) {
                const isLocalStorage = !!localStorage.getItem('noh_admin_session');
                if (isLocalStorage) {
                    localStorage.setItem('noh_admin_session', JSON.stringify(currentUser));
                } else {
                    sessionStorage.setItem('noh_admin_session', JSON.stringify(currentUser));
                }
            }
        }
        // Update UI
        document.getElementById('adminUserName').textContent = document.getElementById('profileDisplayName').value.trim();
        document.getElementById('dashboardUserName').textContent = document.getElementById('profileDisplayName').value.trim();
        // Refresh profile view
        loadProfile();
        showToast('Profile updated successfully!');
    } else showToast(result.message, 'error');
    return false;
}

// Make admin messaging functions globally available
window.openSendMessageModal = openSendMessageModal;
window.closeAdminSendMessageModal = closeAdminSendMessageModal;
window.sendAdminMessage = sendAdminMessage;
window.loadMessageRecipients = loadMessageRecipients;
window.viewMessage = viewMessage;
window.closeMessageViewModal = closeMessageViewModal;
window.replyToMessageFromAdmin = replyToMessageFromAdmin;
window.renderContracts = renderContracts;
window.viewContract = viewContract;
window.closeContractViewModal = closeContractViewModal;
window.approveContract = approveContract;
window.rejectContract = rejectContract;
window.deleteContract = deleteContract;

function getContractStatus(expiryDate) {
    if (!expiryDate) return { text: 'No Expiry', class: 'active' };
    
    const today = new Date();
    const expiry = new Date(expiryDate);
    const daysUntilExpiry = Math.ceil((expiry - today) / (1000 * 60 * 60 * 24));
    
    if (daysUntilExpiry < 0) {
        return { text: 'Expired', class: 'inactive' };
    } else if (daysUntilExpiry <= 30) {
        return { text: 'Expiring Soon', class: 'pending' };
    } else {
        return { text: 'Active', class: 'active' };
    }
}

// ===== CONTRACT MANAGEMENT =====
async function renderContracts() {
    const tbody = document.getElementById('contractsTableBody');
    const statusFilter = document.getElementById('contractStatusFilter')?.value || '';
    
    try {
        // Temporary fallback - API endpoint not implemented yet
        tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted">Contract management feature is not yet implemented.</td></tr>';
        return;
        
        const result = await apiFetch('admin', 'teacher_contracts');
        const contracts = result.success ? (result.data?.items || result.data || []) : [];
        
        // Filter by status if selected
        let filteredContracts = contracts;
        if (statusFilter) {
            filteredContracts = contracts.filter(c => c.status === statusFilter);
        }
        
        if (filteredContracts.length === 0) {
            tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted">No contracts found.</td></tr>';
            return;
        }
        
        // Fetch teachers to get names
        const teachersResult = await apiFetch('admin', 'teachers');
        const teachers = teachersResult.success ? (teachersResult.data?.items || teachersResult.data || []) : [];
        
        tbody.innerHTML = filteredContracts.map(c => {
            const teacher = teachers.find(t => t.id === c.teacherId);
            const teacherName = teacher ? `${teacher.firstName} ${teacher.lastName}` : 'Unknown Teacher';
            const expiryStatus = getContractStatus(c.expiryDate);
            
            return `
            <tr>
                <td><strong>${c.title || 'Untitled Contract'}</strong></td>
                <td>${teacherName}</td>
                <td><span class="status-badge active">${c.type || 'Employment Contract'}</span></td>
                <td>${c.class || 'N/A'}</td>
                <td>${formatDate(c.expiryDate) || 'N/A'}</td>
                <td>
                    <span class="status-badge ${getContractStatusClass(c.status)}">${c.status || 'Pending'}</span>
                </td>
                <td>
                    <button class="admin-btn admin-btn-sm admin-btn-info" onclick="viewContract(${c.id})" title="View"><i class="fas fa-eye"></i></button>
                    ${c.status === 'Pending' ? `
                        <button class="admin-btn admin-btn-sm admin-btn-success" onclick="approveContract(${c.id})" title="Approve"><i class="fas fa-check"></i></button>
                        <button class="admin-btn admin-btn-sm admin-btn-danger" onclick="rejectContract(${c.id})" title="Reject"><i class="fas fa-times"></i></button>
                    ` : ''}
                    <button class="admin-btn admin-btn-sm admin-btn-danger" onclick="deleteContract(${c.id})" title="Delete"><i class="fas fa-trash"></i></button>
                </td>
            </tr>
        `}).join('');
        
        // Update badge count for pending contracts
        const pendingCount = contracts.filter(c => c.status === 'Pending').length;
        const badge = document.getElementById('contractBadge');
        if (badge) {
            badge.textContent = pendingCount;
            badge.style.display = pendingCount > 0 ? 'inline-block' : 'none';
        }
        
    } catch (error) {
        console.error('Error loading contracts:', error);
        tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted">Error loading contracts.</td></tr>';
    }
}

function getContractStatusClass(status) {
    switch(status?.toLowerCase()) {
        case 'approved': return 'active';
        case 'rejected': return 'inactive';
        case 'pending': return 'pending';
        default: return 'active';
    }
}

async function viewContract(contractId) {
    try {
        const result = await apiFetch('admin', 'teacher_contracts', 'GET', null, contractId);
        if (!result.success || !result.data) {
            showToast('Failed to load contract', 'error');
            return;
        }
        
        const contract = result.data;
        
        // Fetch teacher info
        const teachersResult = await apiFetch('admin', 'teachers');
        const teachers = teachersResult.success ? (teachersResult.data?.items || teachersResult.data || []) : [];
        const teacher = teachers.find(t => t.id === contract.teacherId);
        const teacherName = teacher ? `${teacher.firstName} ${teacher.lastName}` : 'Unknown Teacher';
        
        const expiryStatus = getContractStatus(contract.expiryDate);
        
        // Create modal to view contract
        const modalHtml = `
            <div id="contractViewModal" class="admin-modal" style="display:flex;">
                <div class="admin-modal-content" style="max-width:700px;">
                    <div class="admin-modal-header">
                        <h3><i class="fas fa-file-contract"></i> Contract Details</h3>
                        <button class="admin-modal-close" onclick="closeContractViewModal()">&times;</button>
                    </div>
                    <div class="admin-modal-body">
                        <div class="form-group">
                            <label>Contract Title</label>
                            <div class="form-value">${contract.title || 'N/A'}</div>
                        </div>
                        <div class="form-group">
                            <label>Submitted By</label>
                            <div class="form-value">${teacherName}</div>
                        </div>
                        <div class="form-group">
                            <label>Contract Type</label>
                            <div class="form-value">${contract.type || 'Employment Contract'}</div>
                        </div>
                        <div class="form-group">
                            <label>Class</label>
                            <div class="form-value">${contract.class || 'N/A'}</div>
                        </div>
                        <div class="form-group">
                            <label>Description</label>
                            <div class="form-value">${contract.description || 'No description'}</div>
                        </div>
                        <div class="form-group">
                            <label>Expiry Date</label>
                            <div class="form-value">${formatDate(contract.expiryDate) || 'N/A'}</div>
                        </div>
                        <div class="form-group">
                            <label>Contract Status</label>
                            <div class="form-value"><span class="status-badge ${expiryStatus.class}">${expiryStatus.text}</span></div>
                        </div>
                        <div class="form-group">
                            <label>Approval Status</label>
                            <div class="form-value"><span class="status-badge ${getContractStatusClass(contract.status)}">${contract.status || 'Pending'}</span></div>
                        </div>
                        <div class="form-group">
                            <label>Contract File</label>
                            <div class="form-value">${contract.fileName || 'N/A'}</div>
                        </div>
                        <div class="form-group">
                            <label>Submitted Date</label>
                            <div class="form-value">${formatDate(contract.uploadDate) || 'N/A'}</div>
                        </div>
                    </div>
                    <div class="admin-modal-footer">
                        <button class="admin-btn admin-btn-secondary" onclick="closeContractViewModal()">Close</button>
                        ${contract.status === 'Pending' ? `
                            <button class="admin-btn admin-btn-success" onclick="approveContract(${contract.id})"><i class="fas fa-check"></i> Approve</button>
                            <button class="admin-btn admin-btn-danger" onclick="rejectContract(${contract.id})"><i class="fas fa-times"></i> Reject</button>
                        ` : ''}
                    </div>
                </div>
            </div>
        `;
        
        const existingModal = document.getElementById('contractViewModal');
        if (existingModal) {
            existingModal.remove();
        }
        
        document.body.insertAdjacentHTML('beforeend', modalHtml);
        
    } catch (error) {
        console.error('Error viewing contract:', error);
        showToast('Error viewing contract', 'error');
    }
}

function closeContractViewModal() {
    const modal = document.getElementById('contractViewModal');
    if (modal) {
        modal.remove();
    }
}

async function approveContract(contractId) {
    if (!confirm('Are you sure you want to approve this contract?')) return;
    
    try {
        const result = await apiFetch('admin', 'teacher_contracts', 'PUT', { status: 'Approved' }, contractId);
        if (result.success) {
            showToast('Contract approved successfully!');
            closeContractViewModal();
            renderContracts();
        } else {
            showToast(result.message || 'Failed to approve contract', 'error');
        }
    } catch (error) {
        console.error('Error approving contract:', error);
        showToast('Error approving contract', 'error');
    }
}

async function rejectContract(contractId) {
    const reason = prompt('Please provide a reason for rejecting this contract:');
    if (!reason) return;
    
    try {
        const result = await apiFetch('admin', 'teacher_contracts', 'PUT', { 
            status: 'Rejected',
            rejectionReason: reason
        }, contractId);
        if (result.success) {
            showToast('Contract rejected successfully!');
            closeContractViewModal();
            renderContracts();
        } else {
            showToast(result.message || 'Failed to reject contract', 'error');
        }
    } catch (error) {
        console.error('Error rejecting contract:', error);
        showToast('Error rejecting contract', 'error');
    }
}

async function deleteContract(contractId) {
    if (!confirm('Are you sure you want to delete this contract?')) return;
    
    try {
        const result = await apiFetch('admin', 'teacher_contracts', 'DELETE', null, contractId);
        if (result.success) {
            showToast('Contract deleted successfully!');
            renderContracts();
        } else {
            showToast(result.message || 'Failed to delete contract', 'error');
        }
    } catch (error) {
        console.error('Error deleting contract:', error);
        showToast('Error deleting contract', 'error');
    }
}

async function changePassword(event) {
    event.preventDefault();
    const current = document.getElementById('currentPassword').value;
    const newPass = document.getElementById('newPassword').value;
    const confirm = document.getElementById('confirmPassword').value;
    if (newPass.length < 4) { showToast('Password must be at least 4 characters!', 'error'); return false; }
    if (newPass !== confirm) { showToast('Passwords do not match!', 'error'); return false; }
    const result = await apiAuth('change_password', { currentPassword: current, newPassword: newPass, type: 'admin' });
    if (result.success) {
        showToast('Password changed successfully!');
        document.getElementById('passwordForm').reset();
    } else showToast(result.message, 'error');
    return false;
}

// ===== PROFILE =====
function loadProfile() {
    if (currentUser) {
        document.getElementById('profileViewName').textContent = currentUser.displayName || 'Admin';
        document.getElementById('profileViewUsername').textContent = currentUser.username || 'admin';

// ===== CONTINUED FROM ABOVE =====
        document.getElementById('profileViewEmail').textContent = currentUser.email || 'admin@nca.edu';
    }
    if (currentUser) {
        document.getElementById('passwordFormUsername').value = currentUser.email || currentUser.username;
    }
}

// ===== MODAL FUNCTIONS =====
function openModal(id) {
    const modal = document.getElementById(id);
    if (modal) {
        modal.classList.add('show');
        modal.style.display = 'flex';
        document.body.style.overflow = 'hidden';
    }
}

function closeModal() {
    document.querySelectorAll('.modal-overlay, .admin-modal-overlay, .admin-modal').forEach(m => {
        m.classList.remove('show');
        m.style.display = 'none';
    });
    document.body.style.overflow = 'auto';
}

// Close modals on overlay click
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('modal-overlay')) {
        closeModal();
    }
});

// Close modals on ESC
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeModal();
    }
});

// ===== DELETE CONFIRMATION =====
async function confirmDelete(type, id, name) {
    if (!confirm(`Are you sure you want to delete this ${type}? (${name})`)) return;
    // Map singular type to collection name (most just add 's', some are irregular)
    const collectionMap = {
        'student': 'students', 'teacher': 'teachers', 'parent': 'parents',
        'event': 'events', 'gallery': 'gallery', 'blog': 'blog',
        'service': 'services', 'teammember': 'teammembers', 'message': 'messages',
        'registration': 'registrations', 'payment': 'payments',
        'attendance': 'attendance', 'announcement': 'announcements'
    };
    const collection = collectionMap[type] || type + 's';
    const result = await apiFetch('admin', collection, 'DELETE', null, id);
    if (result.success) {
        showToast(`${name} deleted successfully!`);
        // Refresh the current section
        const activeSection = document.querySelector('.admin-section.active');
        if (activeSection) {
            const sectionName = activeSection.id.replace('section-', '');
            if (sectionName === 'overview') updateStats();
            else if (sectionName === 'students') renderStudents();
            else if (sectionName === 'teachers') renderTeachers();
            else if (sectionName === 'parents') renderParents();
            else if (sectionName === 'events') renderEvents();
            else if (sectionName === 'gallery') renderGallery();
            else if (sectionName === 'blog') renderBlog();
            else if (sectionName === 'teammembers') renderTeamMembers();
            else if (sectionName === 'services') renderServices();
            else if (sectionName === 'messages') renderMessages();
            else if (sectionName === 'contracts') renderContracts();
            else if (sectionName === 'registrations') renderRegistrations();
            else if (sectionName === 'payments') renderPayments();
            else if (sectionName === 'attendance') renderAttendance();
            else if (sectionName === 'activity') renderActivityLog();
            else if (sectionName === 'announcements') renderAnnouncements();
        }
    } else {
        showToast(result.message || 'Delete failed', 'error');
    }
}

// ===== REGISTRATIONS =====
async function renderRegistrations() {
    const tbody = document.getElementById('registrationsTableBody');
    if (!tbody) return;
    const result = await apiFetch('admin', 'registrations');
    const registrations = result.success ? (result.data?.items || []) : [];
    if (registrations.length === 0) {
        tbody.innerHTML = '<tr><td colspan="9" class="text-center text-muted">No registrations yet.</td></tr>';
        return;
    }
    const searchTerm = (document.getElementById('regSearch')?.value || '').toLowerCase();
    const statusFilter = document.getElementById('regStatusFilter')?.value || '';
    const filtered = registrations.filter(r => {
        const matchSearch = (r.studentName + ' ' + (r.parentName || '') + ' ' + (r.phone || '')).toLowerCase().includes(searchTerm);
        const matchStatus = !statusFilter || (r.status && r.status.toLowerCase() === statusFilter.toLowerCase());
        return matchSearch && matchStatus;
    });
    if (filtered.length === 0) {
        tbody.innerHTML = '<tr><td colspan="9" class="text-center text-muted">No matching registrations.</td></tr>';
        return;
    }
    tbody.innerHTML = filtered.map((r, index) => {
        const status = r.status || 'Pending';
        const statusClass = status.toLowerCase();
        const createdDate = r.createdAt ? new Date(r.createdAt).toLocaleDateString('en-GB') : '-';
        const isPending = status.toLowerCase() === 'pending';
        return `<tr>
            <td>${index + 1}</td>
            <td><strong>${r.studentName}</strong></td>
            <td>${r.grade || '-'}</td>
            <td>${r.parentName || '-'}</td>
            <td>${r.phone || '-'}</td>
            <td>${r.email || '-'}</td>
            <td>${createdDate}</td>
            <td><span class="status-badge ${statusClass}">${status}</span></td>
            <td>
                ${isPending ? `
                    <button class="admin-btn admin-btn-success admin-btn-sm" onclick="updateRegistrationStatus(${r.id}, 'Approved')"><i class="fas fa-check"></i></button>
                    <button class="admin-btn admin-btn-danger admin-btn-sm" onclick="updateRegistrationStatus(${r.id}, 'Rejected')"><i class="fas fa-times"></i></button>
                ` : ''}
                <button class="admin-btn admin-btn-info admin-btn-sm" onclick="viewRegistration(${r.id})"><i class="fas fa-eye"></i></button>
                <button class="admin-btn admin-btn-danger admin-btn-sm" onclick="confirmDelete('registration', ${r.id}, '${r.studentName}')"><i class="fas fa-trash"></i></button>
            </td>
        </tr>`;
    }).join('');
}

async function updateRegistrationStatus(id, status) {
    const result = await apiFetch('admin', 'registrations', 'PUT', { status }, id);
    if (result.success) {
        showToast(`Registration ${status}!`);
        renderRegistrations();
        updateStats();
    } else showToast(result.message, 'error');
}

async function viewRegistration(id) {
    const result = await apiFetch('admin', 'registrations', 'GET', null, id);
    if (!result.success) return;
    const r = result.data;
    const body = document.getElementById('messageViewBody');
    body.innerHTML = `
        <div style="margin-bottom:15px"><strong>Student Name:</strong> ${r.studentName}</div>
        <div style="margin-bottom:15px"><strong>Grade:</strong> ${r.grade || '-'}</div>
        <div style="margin-bottom:15px"><strong>Parent/Guardian:</strong> ${r.parentName || '-'}</div>
        <div style="margin-bottom:15px"><strong>Phone:</strong> ${r.phone || '-'}</div>
        <div style="margin-bottom:15px"><strong>Email:</strong> ${r.email || '-'}</div>
        <div style="margin-bottom:15px"><strong>Address:</strong> ${r.address || '-'}</div>
        <div style="margin-bottom:15px"><strong>DOB:</strong> ${r.dob || '-'}</div>
        ${r.idPhoto ? `
            <div style="margin-bottom:15px">
                <strong>ID Photo:</strong><br>
                <img src="../${r.idPhoto}" alt="ID Photo" style="max-width: 150px; max-height: 150px; border: 2px solid #085636; border-radius: 8px; margin-top: 5px;">
            </div>
        ` : ''}
        <div style="margin-bottom:15px"><strong>Notes:</strong> ${r.notes || '-'}</div>
        <div style="margin-bottom:15px"><strong>Status:</strong> ${r.status}</div>
        <div style="margin-bottom:15px"><strong>Date:</strong> ${formatDateTime(r.createdAt)}</div>
    `;
    openModal('messageViewModal');
}

function exportRegistrations() {
    // Export current filtered data as CSV
    const table = document.getElementById('registrationsTable');
    if (!table) return;
    let csv = 'ID,Student Name,Grade,Parent,Phone,Email,Date,Status\n';
    const rows = table.querySelectorAll('tbody tr');
    rows.forEach(row => {
        const cols = row.querySelectorAll('td');
        if (cols.length >= 8) {
            csv += `${cols[0].textContent},${cols[1].textContent},${cols[2].textContent},${cols[3].textContent},${cols[4].textContent},${cols[5].textContent},${cols[6].textContent},${cols[7].textContent}\n`;
        }
    });
    downloadCSV(csv, 'registrations.csv');
}

// ===== PAYMENTS =====
async function renderPayments() {
    const tbody = document.getElementById('paymentsTableBody');
    if (!tbody) return;
    const result = await apiFetch('admin', 'payments');
    const payments = result.success ? (result.data?.items || []) : [];

    // Also load unpaid students
    renderUnpaidStudents(payments);

    // Load class breakdown
    renderPaymentClassBreakdown(payments);

    if (payments.length === 0) {
        tbody.innerHTML = '<tr><td colspan="9" class="text-center text-muted">No payments recorded yet.</td></tr>';
        document.getElementById('payTotal').textContent = 'MK 0';
        document.getElementById('payCount').textContent = '0';
        document.getElementById('payPending').textContent = '0';
        return;
    }
    const searchTerm = (document.getElementById('paySearch')?.value || '').toLowerCase();
    const statusFilter = document.getElementById('payStatusFilter')?.value || '';
    const filtered = payments.filter(p => {
        const matchSearch = (p.payerName + ' ' + (p.studentName || '')).toLowerCase().includes(searchTerm);
        const matchStatus = !statusFilter || p.status === statusFilter;
        return matchSearch && matchStatus;
    });
    if (filtered.length === 0) {
        tbody.innerHTML = '<tr><td colspan="9" class="text-center text-muted">No matching payments.</td></tr>';
        return;
    }
    // Update stats
    const totalCollected = filtered.filter(p => p.status === 'Paid').reduce((sum, p) => sum + parseFloat(p.amount || 0), 0);
    document.getElementById('payTotal').textContent = 'MK ' + totalCollected.toLocaleString();
    document.getElementById('payCount').textContent = filtered.length;
    document.getElementById('payPending').textContent = filtered.filter(p => p.status === 'Pending').length;

    tbody.innerHTML = filtered.map(p => {
        const statusClass = (p.status || 'Pending').toLowerCase();
        return `<tr>
            <td>${p.id}</td>
            <td style="color: #0885636;"><strong>${p.payerName || '-'}</strong></td>
            <td >${p.studentName || '-'}</td>
            <td>MK ${parseFloat(p.amount || 0).toLocaleString()}</td>
            <td>${p.paymentType || '-'}</td>
            <td>${p.paymentMethod || '-'}</td>
            <td>${formatDate(p.createdAt)}</td>
            <td><span class="status-badge ${statusClass}">${p.status || 'Pending'}</span></td>
            <td>
                <button class="admin-btn admin-btn-info admin-btn-sm" onclick="viewPayment(${p.id})" title="View"><i class="fas fa-eye"></i></button>
                ${p.status === 'Pending' ? `
                    <button class="admin-btn admin-btn-success admin-btn-sm" onclick="updatePaymentStatus(${p.id}, 'Paid')" title="Mark Paid"><i class="fas fa-check"></i></button>
                ` : ''}
                <button class="admin-btn admin-btn-warning admin-btn-sm" onclick="editPayment(${p.id})" title="Edit"><i class="fas fa-edit"></i></button>
                ${p.status === 'Paid' ? `
                    <button class="admin-btn admin-btn-info admin-btn-sm" onclick="printReceipt(${p.id})" title="Print Receipt"><i class="fas fa-print"></i></button>
                ` : ''}
                <button class="admin-btn admin-btn-danger admin-btn-sm" onclick="confirmDelete('payment', ${p.id}, 'Payment #${p.id}')" title="Delete"><i class="fas fa-trash"></i></button>
            </td>
        </tr>`;
    }).join('');
}

// ===== PAYMENT RECEIPT (PRINT) =====
// School details printed at the top of every receipt.
const RECEIPT_SCHOOL = {
    name: 'Noah Christian Academy',
    logo: '../images/logo.jpg',
    email: 'noahchristianacademy2021@gmail.com',
    phones: ['+265 999 635 561', '+265 999 693 234'],
    location: 'P.O.BOX 30458, Area 24 PHA, Lilongwe, Malawi',
    website: 'https://nca.10001mb.com/',
    // Optional QR code image exported from Canva. Drop the export here and the
    // receipt uses it; when the file is missing a QR code is generated instead.
    qrImage: '../images/receipt-qr.png'
};

let currentReceiptPayment = null;
let currentReceiptQrUrl = '';
let receiptDraft = null;

const RECEIPT_STYLES = `
.receipt-doc { width: 100%; max-width: 780px; margin: 0 auto; background: #fff; color: #1f2937; font-family: 'Segoe UI', Arial, sans-serif; border: 1px solid #d7e2dc; border-radius: 10px; overflow: hidden; }
.receipt-doc * { box-sizing: border-box; }
.receipt-doc .r-head { display: flex; align-items: flex-start; gap: 18px; padding: 20px 24px; background: linear-gradient(135deg, #085636, #0a7a4e); color: #fff; }
.receipt-doc .r-logo { width: 74px; height: 74px; object-fit: contain; background: #fff; border-radius: 50%; padding: 6px; flex: none; }
.receipt-doc .r-head-info { flex: 1; min-width: 0; }
.receipt-doc .r-school { font-size: 20px; font-weight: 700; letter-spacing: .4px; margin: 0 0 8px; text-transform: uppercase; }
.receipt-doc .r-meta { display: flex; align-items: center; gap: 8px; font-size: 12.5px; line-height: 1.75; }
.receipt-doc .r-meta svg { width: 13px; height: 13px; fill: #a7f3d0; flex: none; }
.receipt-doc .r-title { align-self: center; flex: none; }
.receipt-doc .r-title h2 { margin: 0; font-size: 14px; letter-spacing: 2px; text-transform: uppercase; border: 2px solid rgba(255,255,255,.6); border-radius: 6px; padding: 8px 12px; }
.receipt-doc .r-body { padding: 22px 24px; }
.receipt-doc .r-row { display: flex; justify-content: space-between; gap: 16px; flex-wrap: wrap; font-size: 12.5px; color: #4b5563; border-bottom: 1px dashed #cfe0d7; padding-bottom: 10px; margin-bottom: 18px; }
.receipt-doc .r-row strong { color: #085636; }
.receipt-doc .r-main { display: flex; gap: 22px; align-items: flex-start; }
.receipt-doc .r-qr { flex: none; width: 150px; text-align: center; }
.receipt-doc .r-qr img { width: 140px; height: 140px; object-fit: contain; border: 1px solid #d7e2dc; border-radius: 8px; padding: 6px; background: #fff; }
.receipt-doc .r-qr span { display: block; font-size: 10.5px; color: #6b7280; margin-top: 6px; }
.receipt-doc .r-table { flex: 1; min-width: 0; width: 100%; border-collapse: collapse; font-size: 13px; }
.receipt-doc .r-table td { padding: 7px 0; border-bottom: 1px solid #eef2f0; vertical-align: top; }
.receipt-doc .r-table td:first-child { width: 42%; color: #6b7280; }
.receipt-doc .r-table td:last-child { font-weight: 600; color: #111827; text-align: right; }
.receipt-doc .r-total { display: flex; justify-content: space-between; align-items: center; margin-top: 18px; padding: 12px 16px; background: #f0f7f3; border-left: 4px solid #085636; border-radius: 6px; font-size: 14px; }
.receipt-doc .r-total strong { font-size: 18px; color: #085636; }
.receipt-doc .r-badge { display: inline-block; padding: 3px 10px; border-radius: 20px; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: .5px; }
.receipt-doc .r-status-paid { background: #e6f7ee; color: #1e7a45; }
.receipt-doc .r-status-pending { background: #fff5e5; color: #a86a00; }
.receipt-doc .r-status-failed { background: #fdeaea; color: #b3261e; }
.receipt-doc .r-notes { margin-top: 16px; font-size: 12.5px; color: #4b5563; }
.receipt-doc .r-notes h4 { margin: 0 0 4px; font-size: 11px; text-transform: uppercase; letter-spacing: .5px; color: #085636; }
.receipt-doc .r-foot { padding: 14px 24px; border-top: 1px solid #e5e7eb; background: #f9fafb; text-align: center; font-size: 11px; color: #6b7280; line-height: 1.7; }
.receipt-doc .r-accent { height: 6px; background: linear-gradient(90deg, #085636 0%, #1eae72 55%, #f1c40f 100%); }
.receipt-doc .r-title span { display: block; text-align: right; font-size: 11px; margin-top: 6px; letter-spacing: 1px; opacity: .9; }
.receipt-doc .r-items { width: 100%; border-collapse: collapse; margin-top: 18px; font-size: 13px; }
.receipt-doc .r-items thead th { background: #f0f7f3; color: #085636; text-align: left; font-size: 11px; text-transform: uppercase; letter-spacing: .5px; padding: 8px 10px; border-bottom: 1px solid #d7e2dc; }
.receipt-doc .r-items thead th:last-child { text-align: right; }
.receipt-doc .r-items tbody td { padding: 9px 10px; border-bottom: 1px solid #eef2f0; color: #374151; }
.receipt-doc .r-items tbody td:last-child { text-align: right; font-variant-numeric: tabular-nums; }
.receipt-doc .r-items tfoot td { padding: 11px 10px; font-weight: 700; color: #085636; border-top: 2px solid #085636; text-transform: uppercase; letter-spacing: .4px; font-size: 12px; }
.receipt-doc .r-items tfoot td:last-child { text-align: right; font-size: 16px; }
.receipt-doc .r-notes div { white-space: normal; }
.receipt-doc .r-sign { display: flex; gap: 40px; margin-top: 26px; }
.receipt-doc .r-sign-box { flex: 1; text-align: center; font-size: 11px; color: #6b7280; }
.receipt-doc .r-sign-img { max-height: 56px; max-width: 100%; object-fit: contain; display: block; margin: 0 auto 2px; }
.receipt-doc .r-sign-space { height: 56px; }
.receipt-doc .r-sign-line { border-bottom: 1px solid #9db7ab; height: 1px; margin-bottom: 6px; }
.receipt-doc .r-terms { margin-top: 20px; padding: 10px 12px; background: #f9fafb; border: 1px dashed #d7e2dc; border-radius: 6px; font-size: 11.5px; color: #6b7280; }
.receipt-doc .r-foot div + div { margin-top: 3px; }
@media print { .receipt-doc { border: none; border-radius: 0; max-width: none; } }
`;

function receiptEscape(value) {
    return String(value === null || value === undefined ? '' : value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function receiptAssetUrl(path) {
    try {
        return new URL(path, window.location.href).href;
    } catch (e) {
        return path;
    }
}

// Load the bundled QR generator on demand (mirrors the other lazy loaders).
function loadQrLibrary(callback) {
    if (window.QRCode) { callback(); return; }
    const script = document.createElement('script');
    script.src = '../assets/js/qrcode.min.js';
    script.onload = function() { callback(); };
    script.onerror = function() { callback(); };
    document.head.appendChild(script);
}

function generateQrDataUrl(text) {
    return new Promise(function(resolve) {
        loadQrLibrary(function() {
            if (typeof QRCode === 'undefined') { resolve(''); return; }
            const holder = document.createElement('div');
            holder.style.cssText = 'position:absolute;left:-9999px;top:0;';
            document.body.appendChild(holder);
            let url = '';
            try {
                new QRCode(holder, {
                    text: text,
                    width: 200,
                    height: 200,
                    colorDark: '#085636',
                    colorLight: '#ffffff',
                    correctLevel: QRCode.CorrectLevel ? QRCode.CorrectLevel.M : 0
                });
                const canvas = holder.querySelector('canvas');
                if (canvas) url = canvas.toDataURL('image/png');
                else {
                    const img = holder.querySelector('img');
                    if (img) url = img.src || '';
                }
            } catch (err) {
                console.error('QR generation failed:', err);
                url = '';
            }
            holder.remove();
            resolve(url);
        });
    });
}

// Uses the Canva-exported QR image when it exists, otherwise generates one.
async function resolveReceiptQr() {
    const canva = await new Promise(function(resolve) {
        const probe = new Image();
        probe.onload = function() { resolve(receiptAssetUrl(RECEIPT_SCHOOL.qrImage)); };
        probe.onerror = function() { resolve(''); };
        probe.src = RECEIPT_SCHOOL.qrImage;
    });
    if (canva) return canva;
    return generateQrDataUrl(RECEIPT_SCHOOL.website);
}

function receiptSchoolInfo() {
    return {
        name: RECEIPT_SCHOOL.name,
        logo: receiptAssetUrl(RECEIPT_SCHOOL.logo),
        email: RECEIPT_SCHOOL.email,
        phones: RECEIPT_SCHOOL.phones.slice(),
        location: RECEIPT_SCHOOL.location,
        website: RECEIPT_SCHOOL.website
    };
}

// Builds the receipt markup. Pure: pass in the payment, QR url and school info.
function receiptItemsTotalOf(items) {
    return (items || []).reduce(function(sum, item) {
        return sum + (parseFloat(item && item.amount) || 0);
    }, 0);
}

function receiptMultiline(value) {
    return receiptEscape(value).replace(/\r?\n/g, '<br>');
}

// Formats a receipt date. Date-only values (YYYY-MM-DD, what the date input
// returns) are formatted from their own parts, because new Date('2026-10-02')
// is parsed as UTC midnight and can display a day earlier.
function formatReceiptDate(value) {
    if (!value) return '-';
    const raw = String(value).trim();

    const dateOnly = /^(\d{4})-(\d{2})-(\d{2})$/.exec(raw);
    if (dateOnly) {
        const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        const monthIndex = parseInt(dateOnly[2], 10) - 1;
        if (monthIndex >= 0 && monthIndex < 12) {
            return months[monthIndex] + ' ' + parseInt(dateOnly[3], 10) + ', ' + dateOnly[1];
        }
        return raw;
    }

    const d = new Date(raw.replace(' ', 'T'));
    if (isNaN(d.getTime())) return raw;
    return d.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}

// Builds the receipt markup from an editable receipt object.
// Pure: pass in the receipt, QR url and school info.
function buildReceiptBody(receipt, qrUrl, school) {
    const r = receipt || {};
    const info = school || receiptSchoolInfo();
    const esc = receiptEscape;
    const items = Array.isArray(r.items) ? r.items : [];
    const total = receiptItemsTotalOf(items);
    const status = r.status || 'Pending';
    const statusClass = 'r-status-' + status.toLowerCase();
    const itemsHtml = items.length
        ? items.map(function(item) {
            return '<tr><td>' + esc(item.description || '-') + '</td><td>' +
                (parseFloat(item.amount) || 0).toLocaleString() + '</td></tr>';
        }).join('')
        : '<tr><td>-</td><td>0</td></tr>';
    const iconMail = '<svg viewBox="0 0 512 512"><path d="M464 64H48C21.49 64 0 85.49 0 112v288c0 26.51 21.49 48 48 48h416c26.51 0 48-21.49 48-48V112c0-26.51-21.49-48-48-48zm0 48v40.8c-22.4 18.3-58.4 46.8-138.8 109.4-17.3 13.6-46.6 43.1-69.2 42.8-22.6.3-51.9-29.2-69.2-42.8C106.4 199.6 70.4 171.1 48 152.8V112h416zM48 400V214.9c22.9 18.7 55.5 44.9 90.1 72.2C168.4 311.3 204.1 352 256 352c51.6 0 87.1-40.4 117.9-64.6 34.5-27.1 67.2-53.4 90.1-72.2V400H48z"/></svg>';
    const iconPhone = '<svg viewBox="0 0 512 512"><path d="M511.2 387l-23.25 100.8c-3.266 14.25-15.79 24.22-30.46 24.22C205.2 512 0 306.8 0 54.5c0-14.66 9.969-27.2 24.22-30.45l100.8-23.25C139.7-2.602 154.7 5.018 160.8 18.92l46.52 108.5c5.438 12.78 1.77 27.67-8.98 36.45L144.5 207.1c33.98 69.5 91.04 126.6 160.6 160.6l43.32-53.87c8.781-10.74 23.67-14.43 36.44-8.99l108.5 46.52C507.3 357.3 514.9 372.3 511.2 387z"/></svg>';
    const iconPin = '<svg viewBox="0 0 384 512"><path d="M172.3 501.7C27 291 0 269.4 0 192 0 86 86 0 192 0s192 86 192 192c0 77.4-27 99-172.3 309.7-9.9 14.2-29.5 14.3-39.4 0zM192 272c44.2 0 80-35.8 80-80s-35.8-80-80-80-80 35.8-80 80 35.8 80 80 80z"/></svg>';

    return `
<div class="receipt-doc">
    <div class="r-accent"></div>
    <div class="r-head">
        <img class="r-logo" src="${esc(info.logo)}" alt="School logo" onerror="this.style.visibility='hidden'">
        <div class="r-head-info">
            <h1 class="r-school">${esc(info.name)}</h1>
            <div class="r-meta">${iconMail}<span>${esc(info.email)}</span></div>
            <div class="r-meta">${iconPhone}<span>${esc((info.phones || []).join(' / '))}</span></div>
            <div class="r-meta">${iconPin}<span>${esc(info.location)}</span></div>
        </div>
        <div class="r-title">
            <h2>Payment Receipt</h2>
            <span>${esc(r.receiptNo || '')}</span>
        </div>
    </div>
    <div class="r-body">
        <div class="r-row">
            <span>Receipt No: <strong>${esc(r.receiptNo || '-')}</strong></span>
            <span>Date Issued: <strong>${esc(formatReceiptDate(r.date))}</strong></span>
        </div>
        <div class="r-main">
            ${qrUrl ? `
            <div class="r-qr">
                <img src="${esc(qrUrl)}" alt="Receipt QR code">
                <span>Scan to verify</span>
            </div>` : ''}
            <table class="r-table">
                <tr><td>Payer Name</td><td>${esc(r.payerName || '-')}</td></tr>
                <tr><td>Student</td><td>${esc(r.studentName || '-')}</td></tr>
                <tr><td>Contact Phone</td><td>${esc(r.phone || '-')}</td></tr>
                <tr><td>Payment Type</td><td>${esc(r.paymentType || '-')}</td></tr>
                <tr><td>Payment Method</td><td>${esc(r.paymentMethod || '-')}</td></tr>
                <tr><td>Status</td><td><span class="r-badge ${esc(statusClass)}">${esc(status)}</span></td></tr>
            </table>
        </div>
        <table class="r-items">
            <thead>
                <tr><th>Description</th><th>Amount (MK)</th></tr>
            </thead>
            <tbody>${itemsHtml}</tbody>
            <tfoot>
                <tr><td>Total Paid</td><td>MK ${total.toLocaleString()}</td></tr>
            </tfoot>
        </table>
        ${r.notes ? `<div class="r-notes"><h4>Notes</h4><div>${receiptMultiline(r.notes)}</div></div>` : ''}
        <div class="r-sign">
            <div class="r-sign-box">
                <div class="r-sign-space"></div>
                <div class="r-sign-line"></div>
                <span>Parent / Guardian Signature</span>
            </div>
            <div class="r-sign-box">
                ${r.signatureData
                    ? `<img class="r-sign-img" src="${esc(r.signatureData)}" alt="Authorised signature">`
                    : `<div class="r-sign-space"></div>`}
                <div class="r-sign-line"></div>
                <span>${esc(r.signedBy || 'Authorised Signature')} &middot; Admin</span>
            </div>
        </div>
        ${r.terms ? `<div class="r-terms">${receiptMultiline(r.terms)}</div>` : ''}
    </div>
    <div class="r-foot">
        <div>This is a computer-generated receipt issued by ${esc(info.name)}.</div>
        <div>Generated on ${esc(formatDateTime(new Date().toISOString()) || '-')} &nbsp;|&nbsp; Ref: ${esc(r.receiptNo || '-')}</div>
    </div>
</div>`;
}

function buildReceiptDocument(payment, qrUrl, school) {
    return `<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Payment Receipt</title>
    <style>
        body { margin: 0; padding: 24px; background: #fff; }
        @page { margin: 12mm; }
        ${RECEIPT_STYLES}
    </style>
</head>
<body>
${buildReceiptBody(payment, qrUrl, school)}
</body>
</html>`;
}

async function printReceipt(id) {
    const preview = document.getElementById('printReceiptPreview');
    const result = await apiFetch('admin', 'payments', 'GET', null, id);
    if (!result.success || !result.data) {
        showToast(result.message || 'Failed to load payment data', 'error');
        return;
    }

    currentReceiptPayment = result.data;
    receiptDraft = receiptFromPayment(result.data);
    currentReceiptQrUrl = '';
    if (preview) preview.innerHTML = '<p class="text-center text-muted" style="margin:40px 0;">Generating receipt...</p>';
    openModal('printReceiptModal');
    renderReceiptEditor();

    try {
        currentReceiptQrUrl = await resolveReceiptQr();
        refreshReceiptPreview();
    } catch (err) {
        console.error('Receipt QR failed:', err);
    }
}

function printReceiptDocument() {
    if (!receiptDraft) {
        showToast('No receipt loaded to print', 'warning');
        return;
    }

    const html = buildReceiptDocument(receiptDraft, currentReceiptQrUrl, receiptSchoolInfo());
    const frame = document.createElement('iframe');
    frame.setAttribute('aria-hidden', 'true');
    frame.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;visibility:hidden;';
    document.body.appendChild(frame);

    const doc = frame.contentWindow.document;
    doc.open();
    doc.write(html);
    doc.close();

    let printed = false;
    const printOnce = function() {
        if (printed) return;
        printed = true;
        try {
            frame.contentWindow.focus();
            frame.contentWindow.print();
        } catch (err) {
            console.error('Print failed:', err);
            showToast('Could not open the print dialog', 'error');
        }
        setTimeout(function() { frame.remove(); }, 2000);
    };

    const images = Array.prototype.slice.call(doc.images || []);
    if (!images.length) {
        setTimeout(printOnce, 150);
        return;
    }
    let pending = images.length;
    const imageDone = function() {
        pending -= 1;
        if (pending <= 0) setTimeout(printOnce, 150);
    };
    images.forEach(function(img) {
        if (img.complete) imageDone();
        else { img.onload = imageDone; img.onerror = imageDone; }
    });
    // Never leave the user without a print dialog if an asset stalls.
    setTimeout(printOnce, 2500);
}

// ===== RECEIPT EDITOR =====
function currentAdminDisplayName() {
    if (currentUser) {
        return currentUser.displayName || currentUser.name || currentUser.username || currentUser.email || 'Administrator';
    }
    const el = document.getElementById('adminUserName');
    return (el && el.textContent.trim()) || 'Administrator';
}

// Local calendar date (YYYY-MM-DD). Using toISOString() here would shift the
// receipt date by a day for anyone west of UTC.
function localIsoDate(date) {
    const pad2 = function(n) { return String(n).padStart(2, '0'); };
    return date.getFullYear() + '-' + pad2(date.getMonth() + 1) + '-' + pad2(date.getDate());
}

function receiptFromPayment(payment) {
    const p = payment || {};
    const amount = parseFloat(p.amount || 0);
    const created = p.createdAt ? new Date(String(p.createdAt).replace(' ', 'T')) : new Date();

    return {
        paymentId: p.id,
        receiptNo: 'REC-' + String(p.id || 0).padStart(6, '0'),
        date: isNaN(created.getTime()) ? localIsoDate(new Date()) : localIsoDate(created),
        payerName: p.payerName || '',
        studentName: p.studentName || '',
        phone: p.phone || '',
        paymentType: p.paymentType || '',
        paymentMethod: p.paymentMethod || '',
        status: p.status || 'Paid',
        items: [{ description: p.paymentType || 'Payment', amount: amount }],
        notes: p.notes || '',
        terms: 'Fees paid are non-refundable. Please keep this receipt for your records.',
        signedBy: currentAdminDisplayName(),
        signatureData: '',
        email: p.contactEmail || '',
        emailMessage: ''
    };
}

function setReceiptInput(id, value) {
    const el = document.getElementById(id);
    if (el) el.value = value === null || value === undefined ? '' : value;
}

// For non-form elements (the payment summary spans) which use textContent.
function setReceiptText(id, value) {
    const el = document.getElementById(id);
    if (el) el.textContent = value === null || value === undefined ? '' : value;
}

function renderReceiptEditor() {
    if (!receiptDraft) return;

    setReceiptInput('receiptNo', receiptDraft.receiptNo);
    setReceiptInput('receiptDate', receiptDraft.date);
    setReceiptInput('receiptPayer', receiptDraft.payerName);
    setReceiptInput('receiptStudent', receiptDraft.studentName);
    setReceiptInput('receiptPhone', receiptDraft.phone);
    setReceiptInput('receiptStatus', receiptDraft.status);
    setReceiptInput('receiptPaymentType', receiptDraft.paymentType);
    setReceiptInput('receiptPaymentMethod', receiptDraft.paymentMethod);
    setReceiptInput('receiptNotes', receiptDraft.notes);
    setReceiptInput('receiptTerms', receiptDraft.terms);
    setReceiptInput('receiptSignedBy', receiptDraft.signedBy);
    setReceiptInput('receiptEmailTo', receiptDraft.email);
    setReceiptInput('receiptEmailMessage', receiptDraft.emailMessage);

    const ref = document.getElementById('receiptModalRef');
    if (ref) ref.textContent = '\u00b7 ' + receiptDraft.receiptNo;

    renderReceiptItems();
    updateReceiptItemsTotal();
    clearReceiptSignatureCanvas();
    initReceiptSignaturePad();
    setReceiptStatus('', '');
    refreshReceiptPreview();
}

function renderReceiptItems() {
    const wrap = document.getElementById('receiptItems');
    if (!wrap || !receiptDraft) return;

    wrap.innerHTML = receiptDraft.items.map(function(item, index) {
        return '<div class="receipt-item-row">' +
            '<input type="text" class="receipt-item-desc" value="' + receiptEscape(item.description) + '" placeholder="e.g. Tuition Fee" ' +
            'oninput="updateReceiptItem(' + index + ', \'description\', this.value)">' +
            '<input type="number" class="receipt-item-amount" value="' + (parseFloat(item.amount) || 0) + '" min="0" step="0.01" ' +
            'oninput="updateReceiptItem(' + index + ', \'amount\', this.value)">' +
            '<button type="button" title="Remove item" onclick="removeReceiptItem(' + index + ')">&times;</button>' +
            '</div>';
    }).join('');
}

function updateReceiptItem(index, field, value) {
    if (!receiptDraft || !receiptDraft.items[index]) return;
    receiptDraft.items[index][field] = field === 'amount' ? (parseFloat(value) || 0) : value;
    updateReceiptItemsTotal();
    scheduleReceiptPreview();
}

function addReceiptItem() {
    if (!receiptDraft) return;
    receiptDraft.items.push({ description: '', amount: 0 });
    renderReceiptItems();
    updateReceiptItemsTotal();
    scheduleReceiptPreview();
    const rows = document.querySelectorAll('#receiptItems .receipt-item-desc');
    if (rows.length) rows[rows.length - 1].focus();
}

function removeReceiptItem(index) {
    if (!receiptDraft) return;
    if (receiptDraft.items.length <= 1) {
        showToast('A receipt needs at least one item', 'warning');
        return;
    }
    receiptDraft.items.splice(index, 1);
    renderReceiptItems();
    updateReceiptItemsTotal();
    scheduleReceiptPreview();
}

function updateReceiptItemsTotal() {
    const el = document.getElementById('receiptItemsTotal');
    if (el && receiptDraft) el.textContent = 'MK ' + receiptItemsTotalOf(receiptDraft.items).toLocaleString();
}

function syncReceiptField(field, value) {
    if (!receiptDraft) return;
    receiptDraft[field] = value;
    scheduleReceiptPreview();
}

let receiptPreviewTimer = null;
function scheduleReceiptPreview() {
    if (receiptPreviewTimer) clearTimeout(receiptPreviewTimer);
    receiptPreviewTimer = setTimeout(function() {
        receiptPreviewTimer = null;
        refreshReceiptPreview();
    }, 200);
}

function refreshReceiptPreview() {
    const preview = document.getElementById('printReceiptPreview');
    if (!preview || !receiptDraft) return;
    preview.innerHTML = '<style>' + RECEIPT_STYLES + '</style>' +
        buildReceiptBody(receiptDraft, currentReceiptQrUrl, receiptSchoolInfo());
}

// --- Signature pad ---
let receiptSignatureDrawing = false;
let receiptSignatureHasInk = false;

function initReceiptSignaturePad() {
    const pad = document.getElementById('receiptSignaturePad');
    if (!pad || pad.dataset.bound === '1') return;
    pad.dataset.bound = '1';

    const ctx = pad.getContext('2d');
    ctx.lineWidth = 3;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.strokeStyle = '#0b2e1e';

    const point = function(event) {
        const rect = pad.getBoundingClientRect();
        return {
            x: (event.clientX - rect.left) * (pad.width / rect.width),
            y: (event.clientY - rect.top) * (pad.height / rect.height)
        };
    };

    pad.addEventListener('pointerdown', function(event) {
        event.preventDefault();
        receiptSignatureDrawing = true;
        if (pad.setPointerCapture) {
            try { pad.setPointerCapture(event.pointerId); } catch (e) { /* ignore */ }
        }
        const p = point(event);
        ctx.beginPath();
        ctx.moveTo(p.x, p.y);
    });

    pad.addEventListener('pointermove', function(event) {
        if (!receiptSignatureDrawing) return;
        event.preventDefault();
        const p = point(event);
        ctx.lineTo(p.x, p.y);
        ctx.stroke();
        receiptSignatureHasInk = true;
    });

    const finish = function() {
        if (!receiptSignatureDrawing) return;
        receiptSignatureDrawing = false;
        if (receiptDraft && receiptSignatureHasInk) {
            receiptDraft.signatureData = pad.toDataURL('image/png');
            scheduleReceiptPreview();
        }
    };

    pad.addEventListener('pointerup', finish);
    pad.addEventListener('pointercancel', finish);
    pad.addEventListener('pointerleave', finish);
}

function clearReceiptSignatureCanvas() {
    const pad = document.getElementById('receiptSignaturePad');
    if (pad) pad.getContext('2d').clearRect(0, 0, pad.width, pad.height);
    receiptSignatureHasInk = false;
}

function clearReceiptSignature() {
    clearReceiptSignatureCanvas();
    if (receiptDraft) receiptDraft.signatureData = '';
    scheduleReceiptPreview();
}

// --- PDF (jsPDF + html2canvas, same pattern as the teacher reports) ---
function ensurePdfLibraries() {
    return new Promise(function(resolve, reject) {
        if (window.jspdf && window.html2canvas) { resolve(); return; }
        if (typeof loadPdfLibraries === 'function') loadPdfLibraries();

        let waited = 0;
        const timer = setInterval(function() {
            if (window.jspdf && window.html2canvas) {
                clearInterval(timer);
                resolve();
                return;
            }
            waited += 250;
            if (waited > 20000) {
                clearInterval(timer);
                reject(new Error('PDF libraries could not be loaded'));
            }
        }, 250);
    });
}

function waitForImages(container) {
    const images = Array.prototype.slice.call(container.querySelectorAll('img'));
    if (!images.length) return Promise.resolve();
    return Promise.all(images.map(function(img) {
        if (img.complete) return Promise.resolve();
        return new Promise(function(resolve) {
            img.onload = resolve;
            img.onerror = resolve;
        });
    }));
}

function receiptFileName() {
    const ref = ((receiptDraft && receiptDraft.receiptNo) || 'receipt').replace(/[^A-Za-z0-9_-]/g, '');
    return 'receipt_' + ref + '_' + localIsoDate(new Date()) + '.pdf';
}

async function buildReceiptPdfBase64() {
    if (!receiptDraft) throw new Error('No receipt loaded');
    await ensurePdfLibraries();

    const container = document.createElement('div');
    container.style.cssText = 'position:absolute;left:-9999px;top:0;width:820px;background:#ffffff;padding:16px;';
    container.innerHTML = '<style>' + RECEIPT_STYLES + '</style>' +
        buildReceiptBody(receiptDraft, currentReceiptQrUrl, receiptSchoolInfo());
    document.body.appendChild(container);

    try {
        await waitForImages(container);
        await new Promise(function(resolve) { setTimeout(resolve, 150); });

        const canvas = await html2canvas(container, {
            scale: 2,
            useCORS: true,
            logging: false,
            backgroundColor: '#ffffff'
        });

        // JPEG + compression keeps the emailed PDF around a few hundred KB
        // instead of the multi-megabyte PNG a plain raster export produces.
        const imgData = canvas.toDataURL('image/jpeg', 0.92);
        const jsPDF = window.jspdf.jsPDF;
        const pdf = new jsPDF({ orientation: 'p', unit: 'mm', format: 'a4', compress: true });
        const imgWidth = 210;
        const pageHeight = 297;
        const imgHeight = (canvas.height * imgWidth) / canvas.width;

        if (imgHeight <= pageHeight) {
            pdf.addImage(imgData, 'JPEG', 0, 0, imgWidth, imgHeight);
        } else {
            let remaining = imgHeight;
            let offset = 0;
            while (remaining > 1) {
                pdf.addImage(imgData, 'JPEG', 0, offset, imgWidth, imgHeight);
                remaining -= pageHeight;
                offset -= pageHeight;
                if (remaining > 1) pdf.addPage();
            }
        }

        return pdf.output('datauristring').split(',')[1];
    } finally {
        container.remove();
    }
}

function setReceiptStatus(message, tone) {
    const el = document.getElementById('receiptEmailStatus');
    if (!el) return;
    el.textContent = message || '';
    el.classList.remove('is-error', 'is-success');
    if (tone === 'error') el.classList.add('is-error');
    if (tone === 'success') el.classList.add('is-success');
}

function setReceiptBusy(busy, message) {
    const btn = document.getElementById('receiptSendBtn');
    if (btn) {
        btn.disabled = !!busy;
        btn.innerHTML = busy
            ? '<i class="fas fa-spinner fa-spin"></i> Sending...'
            : '<i class="fas fa-paper-plane"></i> Send Email';
    }
    if (message) setReceiptStatus(message, '');
}

async function downloadReceiptPdf() {
    if (!receiptDraft) return;
    setReceiptStatus('Building the PDF...', '');
    try {
        const base64 = await buildReceiptPdfBase64();
        const link = document.createElement('a');
        link.href = 'data:application/pdf;base64,' + base64;
        link.download = receiptFileName();
        document.body.appendChild(link);
        link.click();
        link.remove();
        setReceiptStatus('PDF downloaded', 'success');
        showToast('Receipt PDF downloaded', 'success');
    } catch (err) {
        console.error('Receipt PDF failed:', err);
        setReceiptStatus('Could not build the PDF', 'error');
        showToast('Could not build the receipt PDF', 'error');
    }
}

async function sendReceiptByEmail() {
    if (!receiptDraft) return;
    const email = (document.getElementById('receiptEmailTo')?.value || '').trim();

    if (!email) {
        showToast('Enter the recipient email address', 'warning');
        return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) {
        showToast('That email address does not look valid', 'warning');
        return;
    }

    setReceiptBusy(true, 'Building the PDF...');
    try {
        const base64 = await buildReceiptPdfBase64();
        setReceiptBusy(true, 'Sending to ' + email + '...');

        const response = await fetch('../api/generate_receipt.php?action=send_email&id=' + encodeURIComponent(receiptDraft.paymentId), {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                email: email,
                message: receiptDraft.emailMessage || '',
                receiptPdf: base64,
                filename: receiptFileName()
            })
        });
        const data = await response.json();

        if (data.success) {
            setReceiptStatus('Sent to ' + email, 'success');
            showToast(data.message || 'Receipt emailed successfully', 'success');
        } else {
            setReceiptStatus(data.message || 'Sending failed', 'error');
            showToast(data.message || 'Could not send the receipt', 'error');
        }
    } catch (err) {
        console.error('Receipt email failed:', err);
        setReceiptStatus('Network error while sending', 'error');
        showToast('Network error while sending the receipt', 'error');
    } finally {
        setReceiptBusy(false);
    }
}

// ===== "SEND RECEIPT" ENTRY POINT =====
// The Payments toolbar button opens the same receipt editor, pre-filled with
// the payment and recipient the admin picked here.
async function openSendReceiptModal() {
    const select = document.getElementById('sendReceiptPayment');
    if (!select) return;

    select.innerHTML = '<option value="">Select a payment</option>';
    const result = await apiFetch('admin', 'payments');
    const payments = result.success ? (result.data?.items || []) : [];

    if (!payments.length) {
        showToast('No payments available to send a receipt for', 'warning');
        return;
    }

    payments.forEach(function(payment) {
        const option = document.createElement('option');
        option.value = payment.id;
        option.textContent = 'REC-' + String(payment.id).padStart(6, '0') + ' - ' +
            (payment.payerName || 'Unknown') + ' (MK ' + parseFloat(payment.amount || 0).toLocaleString() + ')';
        option.dataset.email = payment.contactEmail || '';
        option.dataset.amount = payment.amount || 0;
        option.dataset.type = payment.paymentType || '';
        option.dataset.method = payment.paymentMethod || '';
        option.dataset.date = payment.createdAt || '';
        select.appendChild(option);
    });

    setReceiptInput('sendReceiptEmail', '');
    setReceiptInput('sendReceiptMessage', '');
    const summary = document.getElementById('paymentSummary');
    if (summary) summary.style.display = 'none';

    openModal('sendReceiptModal');
}

function loadPaymentDetails() {
    const select = document.getElementById('sendReceiptPayment');
    const option = select ? select.options[select.selectedIndex] : null;
    const summary = document.getElementById('paymentSummary');

    if (!option || !option.value) {
        if (summary) summary.style.display = 'none';
        return;
    }

    setReceiptInput('sendReceiptEmail', option.dataset.email || '');
    setReceiptText('summaryAmount', 'MK ' + parseFloat(option.dataset.amount || 0).toLocaleString());
    setReceiptText('summaryType', option.dataset.type || '-');
    setReceiptText('summaryMethod', option.dataset.method || '-');
    setReceiptText('summaryDate', formatDate(option.dataset.date) || '-');
    if (summary) summary.style.display = 'block';
}

function sendReceipt(event) {
    if (event && event.preventDefault) event.preventDefault();

    const select = document.getElementById('sendReceiptPayment');
    const paymentId = select ? parseInt(select.value, 10) : 0;
    if (!paymentId) {
        showToast('Select a payment first', 'warning');
        return false;
    }

    const email = (document.getElementById('sendReceiptEmail')?.value || '').trim();
    const message = (document.getElementById('sendReceiptMessage')?.value || '').trim();

    closeModal();

    printReceipt(paymentId).then(function() {
        if (!receiptDraft) return;
        if (email) {
            receiptDraft.email = email;
            setReceiptInput('receiptEmailTo', email);
        }
        if (message) {
            receiptDraft.emailMessage = message;
            setReceiptInput('receiptEmailMessage', message);
        }
    });

    return false;
}

async function renderUnpaidStudents(payments) {
    const tbody = document.getElementById('unpaidStudentsBody');
    if (!tbody) return;

    const studentsResult = await apiFetch('admin', 'students');
    const students = studentsResult.success ? (studentsResult.data?.items || []) : [];

    // Get student names who have payments
    const paidStudentNames = (payments || []).map(p => (p.studentName || '').toLowerCase());

    // Filter students without any payment
    const unpaid = students.filter(s => {
        const fullName = (s.firstName + ' ' + s.lastName).toLowerCase();
        return !paidStudentNames.includes(fullName) && s.status === 'Active';
    });

    document.getElementById('payUnpaid').textContent = unpaid.length;

    if (unpaid.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted">All students have payment records.</td></tr>';
        return;
    }

    tbody.innerHTML = unpaid.map((s, i) => `
        <tr>
            <td>${i + 1}</td>
            <td"><strong>${s.firstName} ${s.lastName}</strong></td>
            <td>${s.grade || '-'}</td>
            <td>${s.parent || '-'}</td>
            <td>${s.phone || '-'}</td>
            <td><span class="status-badge" style="background:#e74c3c;color:#fff;">No Payment</span></td>
            <td>
                <button class="admin-btn admin-btn-primary admin-btn-sm" onclick="processPaymentForStudent('${s.firstName} ${s.lastName}', '${s.parent || ''}', '${s.phone || ''}')" title="Process Payment">
                    <i class="fas fa-money-bill-wave"></i> Pay
                </button>
                <button class="admin-btn admin-btn-danger admin-btn-sm" onclick="confirmDelete('student', ${s.id}, '${s.firstName} ${s.lastName}')" title="Delete Student">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        </tr>
    `).join('');
}

async function renderPaymentClassBreakdown(payments) {
    const tbody = document.getElementById('classBreakdownBody');
    if (!tbody) return;

    tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted">Loading class breakdown...</td></tr>';

    try {
        const studentsResult = await apiFetch('admin', 'students');
        console.log('Students result:', studentsResult);
        
        const students = studentsResult.success ? (studentsResult.data?.items || []) : [];
        console.log('Students data:', students);

        // Group students by grade/class
        const classData = {};
        students.forEach(student => {
            const grade = student.grade || 'Unassigned';
            if (!classData[grade]) {
                classData[grade] = {
                    total: 0,
                    enrolled: 0,
                    paid: 0
                };
            }
            classData[grade].total++;
            
            // Check if student has payment
            const studentName = (student.firstName + ' ' + student.lastName).toLowerCase();
            const hasPayment = payments.some(p => (p.studentName || '').toLowerCase() === studentName);
            
            if (hasPayment) {
                classData[grade].enrolled++;
                classData[grade].paid++;
            }
        });

        console.log('Class data:', classData);

        if (Object.keys(classData).length === 0) {
            tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted">No class data available.</td></tr>';
            return;
        }

        tbody.innerHTML = Object.entries(classData).map(([grade, data], index) => {
            const pending = data.total - data.enrolled;
            const paymentRate = data.total > 0 ? ((data.paid / data.total) * 100).toFixed(1) : 0;
            
            return `
                <tr>
                    <td>${index + 1}</td>
                    <td><strong>${grade}</strong></td>
                    <td>${data.total}</td>
                    <td><span class="status-badge" style="background:#2ecc71;color:#fff;">${data.enrolled}</span></td>
                    <td><span class="status-badge" style="background:#f39c12;color:#fff;">${pending}</span></td>
                    <td>
                        <div style="display:flex;align-items:center;gap:8px;">
                            <div style="flex:1;background:#e0e0e0;border-radius:4px;height:8px;overflow:hidden;">
                                <div style="width:${paymentRate}%;background:#085636;height:100%;"></div>
                            </div>
                            <span style="font-size:12px;">${paymentRate}%</span>
                        </div>
                    </td>
                    <td>
                        <button class="admin-btn admin-btn-info admin-btn-sm" onclick="viewClassDetails('${grade}')" title="View Details">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="admin-btn admin-btn-success admin-btn-sm" onclick="showSection('students')" title="Manage Students">
                            <i class="fas fa-users"></i>
                        </button>
                    </td>
                </tr>
            `;
        }).join('');
    } catch (error) {
        console.error('Error loading class breakdown:', error);
        tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted">Error loading class breakdown. Please try again.</td></tr>';
    }
}

function viewClassDetails(grade) {
    // This could open a modal with detailed breakdown for this specific class
    showToast(`Viewing details for ${grade}`, 'info');
    // You can expand this to show a detailed modal with student names, payment status, etc.
}

function processPaymentForStudent(studentName, parentName, phone) {
    openPaymentModal();
    document.getElementById('paymentStudentName').value = studentName;
    document.getElementById('paymentPayerName').value = parentName;
    document.getElementById('paymentPhone').value = phone;
}

function openPaymentModal(payment = null) {
    document.getElementById('paymentEditId').value = '';
    document.getElementById('paymentPayerName').value = '';
    document.getElementById('paymentStudentName').value = '';
    document.getElementById('paymentAmount').value = '';
    document.getElementById('paymentType').value = '';
    document.getElementById('paymentMethod').value = '';
    document.getElementById('paymentPhone').value = '';
    document.getElementById('paymentStatus').value = 'Paid';
    document.getElementById('paymentNotes').value = '';
    document.getElementById('paymentModalTitle').innerHTML = '<i class="fas fa-money-bill-wave"></i> Process Payment';

    if (payment) {
        document.getElementById('paymentEditId').value = payment.id;
        document.getElementById('paymentPayerName').value = payment.payerName || payment.payer_name || '';
        document.getElementById('paymentStudentName').value = payment.studentName || payment.student_name || '';
        document.getElementById('paymentAmount').value = payment.amount || '';
        document.getElementById('paymentType').value = payment.paymentType || payment.payment_type || '';
        document.getElementById('paymentMethod').value = payment.paymentMethod || payment.payment_method || '';
        document.getElementById('paymentPhone').value = payment.phone || '';
        document.getElementById('paymentStatus').value = payment.status || 'Pending';
        document.getElementById('paymentNotes').value = payment.notes || '';
        document.getElementById('paymentModalTitle').innerHTML = '<i class="fas fa-money-bill-wave"></i> Edit Payment';
    }

    // Load payment APIs for integration
    updatePaymentMethodDropdown();

    document.getElementById('paymentModal').classList.add('show');
    document.getElementById('modalOverlay').classList.add('show');
}

async function editPayment(id) {
    const result = await apiFetch('admin', 'payments', 'GET', null, id);
    if (result.success && result.data) {
        openPaymentModal(result.data);
    } else {
        showToast('Failed to load payment data', 'error');
    }
}

async function viewPayment(id) {
    const result = await apiFetch('admin', 'payments', 'GET', null, id);
    if (!result.success || !result.data) {
        showToast('Failed to load payment data', 'error');
        return;
    }
    
    const p = result.data;
    
    // Create modal content with payment proof display
    let modalContent = `
        <div style="max-width: 600px; margin: 0 auto; padding: 20px; color: #000000;">
            <h3 style="color: #085636; margin-bottom: 20px;">Payment #${p.id}</h3>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 20px;">
                <div style="color: #000000;">
                    <strong style="color: #085636;">Payer Name:</strong><br><span style="color: #000000;">${p.payerName || '-'}</span>
                </div>
                <div style="color: #000000;">
                    <strong style="color: #085636;">Student Name:</strong><br><span style="color: #000000;">${p.studentName || '-'}</span>
                </div>
                <div style="color: #000000;">
                    <strong style="color: #085636;">Amount:</strong><br><span style="color: #000000;">MK ${parseFloat(p.amount || 0).toLocaleString()}</span>
                </div>
                <div style="color: #000000;">
                    <strong style="color: #085636;">Payment Type:</strong><br><span style="color: #000000;">${p.paymentType || '-'}</span>
                </div>
                <div style="color: #000000;">
                    <strong style="color: #085636;">Payment Method:</strong><br><span style="color: #000000;">${p.paymentMethod || '-'}</span>
                </div>
                <div style="color: #000000;">
                    <strong style="color: #085636;">Phone:</strong><br><span style="color: #000000; font-weight: 500;">${p.phone || '-'}</span>
                </div>
                <div style="color: #000000;">
                    <strong style="color: #085636;">Status:</strong><br><span style="padding: 4px 8px; border-radius: 4px; background: ${p.status === 'Paid' ? '#2ecc71' : p.status === 'Failed' ? '#e74c3c' : '#f39c12'}; color: white;">${p.status || 'Pending'}</span>
                </div>
                <div style="color: #000000;">
                    <strong style="color: #085636;">Date:</strong><br><span style="color: #000000;">${formatDateTime(p.createdAt)}</span>
                </div>
            </div>
            ${p.paymentProof ? `
                <div style="margin-bottom: 20px; color: #000000;">
                    <strong style="color: #085636;">Payment Proof:</strong><br>
                    ${p.paymentProof.match(/\.(pdf)$/i) ? `
                        <a href="../${p.paymentProof}" target="_blank" style="display: inline-block; margin-top: 10px; padding: 8px 16px; background: #085636; color: white; text-decoration: none; border-radius: 4px;">
                            <i class="fas fa-file-pdf"></i> View PDF
                        </a>
                    ` : `
                        <img src="../${p.paymentProof}" alt="Payment Proof" style="max-width: 200px; max-height: 200px; border: 2px solid #085636; border-radius: 8px; margin-top: 10px;">
                    `}
                </div>
            ` : ''}
            <div style="margin-top: 15px; padding: 15px; background: #f5f5f5; border-radius: 8px; color: #000000;">
                <strong style="color: #085636;">Notes:</strong><br><span style="color: #000000;">${p.notes || 'None'}</span>
            </div>
        </div>
    `;
    
    // Create and show modal
    const modal = document.createElement('div');
    modal.style.cssText = 'position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 10000;';
    modal.innerHTML = `
        <div style="background: #ffffff; border-radius: 12px; max-width: 90%; max-height: 90%; overflow-y: auto; position: relative; color: #333;">
            <button onclick="this.closest('div[style*=\'position: fixed\']').remove()" style="position: absolute; top: 10px; right: 10px; background: #e74c3c; color: white; border: none; width: 30px; height: 30px; border-radius: 50%; cursor: pointer; font-size: 18px;">&times;</button>
            ${modalContent}
        </div>
    `;
    document.body.appendChild(modal);
}

async function savePayment(e) {
    e.preventDefault();
    const id = document.getElementById('paymentEditId').value;
    const paymentMethod = document.getElementById('paymentMethod').value;
    
    const body = {
        payerName: document.getElementById('paymentPayerName').value,
        studentName: document.getElementById('paymentStudentName').value,
        amount: parseFloat(document.getElementById('paymentAmount').value),
        paymentType: document.getElementById('paymentType').value,
        paymentMethod: paymentMethod,
        phone: document.getElementById('paymentPhone').value,
        status: document.getElementById('paymentStatus').value,
        notes: document.getElementById('paymentNotes').value
    };

    // Check if using API payment method
    if (paymentMethod.startsWith('api_')) {
        const apiId = paymentMethod.replace('api_', '');
        body.api_id = apiId;
        
        // Get API details
        const api = apisData.find(a => a.id == apiId);
        if (api) {
            body.api_provider = api.provider;
            body.api_name = api.name;
        }
    }

    let result;
    if (id) {
        result = await apiFetch('admin', 'payments', 'PUT', body, id);
    } else {
        result = await apiFetch('admin', 'payments', 'POST', body);
    }

    if (result.success) {
        showToast(id ? 'Payment updated successfully' : 'Payment processed successfully', 'success');
        closeModal();
        renderPayments();
        updateStats();
    } else {
        showToast(result.message || 'Failed to save payment', 'error');
    }
    return false;
}

async function updatePaymentStatus(id, status) {
    const result = await apiFetch('admin', 'payments', 'PUT', { status }, id);
    if (result.success) {
        showToast(`Payment marked as ${status}!`);
        renderPayments();
        updateStats();
    } else showToast(result.message, 'error');
}

function exportPayments() {
    const table = document.getElementById('paymentsTable');
    if (!table) return;
    let csv = 'ID,Payer Name,Student,Amount,Type,Method,Date,Status\n';
    const rows = table.querySelectorAll('tbody tr');
    rows.forEach(row => {
        const cols = row.querySelectorAll('td');
        if (cols.length >= 8) {
            csv += `${cols[0].textContent},${cols[1].textContent},${cols[2].textContent},${cols[3].textContent},${cols[4].textContent},${cols[5].textContent},${cols[6].textContent},${cols[7].textContent}\n`;
        }
    });
    downloadCSV(csv, 'payments.csv');
}

// ===== ATTENDANCE =====
async function renderAttendance() {
    const tbody = document.getElementById('attendanceTableBody');
    if (!tbody) return;
    const result = await apiFetch('admin', 'attendance');
    const attendance = result.success ? (result.data?.items || []) : [];
    if (attendance.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted">No attendance records yet.</td></tr>';
        document.getElementById('attTotal').textContent = '0';
        document.getElementById('attPresent').textContent = '0';
        document.getElementById('attAbsent').textContent = '0';
        document.getElementById('attLate').textContent = '0';
        return;
    }
    const searchTerm = (document.getElementById('attSearch')?.value || '').toLowerCase();
    const classFilter = document.getElementById('attClassFilter')?.value || '';
    const dateFilter = document.getElementById('attDateFilter')?.value || '';
    const statusFilter = document.getElementById('attStatusFilter')?.value || '';
    const filtered = attendance.filter(a => {
        const matchSearch = (a.studentName || '').toLowerCase().includes(searchTerm);
        const matchClass = !classFilter || a.studentClass === classFilter;
        const matchDate = !dateFilter || a.date === dateFilter;
        const matchStatus = !statusFilter || a.status === statusFilter;
        return matchSearch && matchClass && matchDate && matchStatus;
    });
    if (filtered.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted">No matching records.</td></tr>';
        return;
    }
    // Update stats
    document.getElementById('attTotal').textContent = filtered.length;
    document.getElementById('attPresent').textContent = filtered.filter(a => a.status === 'Present').length;
    document.getElementById('attAbsent').textContent = filtered.filter(a => a.status === 'Absent').length;
    document.getElementById('attLate').textContent = filtered.filter(a => a.status === 'Late').length;

    tbody.innerHTML = filtered.map(a => {
        const statusClass = (a.status || '').toLowerCase();
        return `<tr>
            <td>${a.id}</td>
            <td><strong>${a.studentName}</strong></td>
            <td>${a.studentClass || '-'}</td>
            <td>${a.date || '-'}</td>
            <td><span class="status-badge ${statusClass}">${a.status || '-'}</span></td>
            <td>${a.remarks || '-'}</td>
            <td>
                <button class="admin-btn admin-btn-primary admin-btn-sm" onclick="editAttendance(${a.id})"><i class="fas fa-edit"></i></button>
                <button class="admin-btn admin-btn-danger admin-btn-sm" onclick="confirmDelete('attendance', ${a.id}, 'Attendance #${a.id}')"><i class="fas fa-trash"></i></button>
            </td>
        </tr>`;
    }).join('');
}

function openAttendanceModal() {
    document.getElementById('attendanceModalTitle').innerHTML = '<i class="fas fa-plus"></i> Mark Attendance';
    document.getElementById('attendanceEditId').value = '';
    document.getElementById('attendanceForm').reset();
    document.getElementById('attendanceDate').value = new Date().toISOString().slice(0, 10);
    // Load students for dropdown
    loadStudentsForAttendance();
    openModal('attendanceModal');
}

async function loadStudentsForAttendance() {
    const result = await apiFetch('admin', 'students');
    const students = result.success ? (result.data?.items || []) : [];
    const select = document.getElementById('attendanceStudent');
    if (!select) return;
    select.innerHTML = '<option value="">Select Student</option>';
    students.forEach(s => {
        const opt = document.createElement('option');
        opt.value = s.id;
        opt.textContent = s.firstName + ' ' + s.lastName + ' (' + (s.grade || 'N/A') + ')';
        opt.dataset.name = s.firstName + ' ' + s.lastName;
        opt.dataset.class = s.grade || '';
        select.appendChild(opt);
    });
}

async function editAttendance(id) {
    const result = await apiFetch('admin', 'attendance', 'GET', null, id);
    if (!result.success) { showToast('Record not found', 'error'); return; }
    const a = result.data;
    document.getElementById('attendanceModalTitle').innerHTML = '<i class="fas fa-edit"></i> Edit Attendance';
    document.getElementById('attendanceEditId').value = id;
    document.getElementById('attendanceDate').value = a.date || '';
    document.getElementById('attendanceStatus').value = a.status || 'Present';
    document.getElementById('attendanceRemarks').value = a.remarks || '';
    // Set student
    await loadStudentsForAttendance();
    const select = document.getElementById('attendanceStudent');
    if (select) {
        // Add and select the student
        const opt = document.createElement('option');
        opt.value = a.studentId;
        opt.textContent = a.studentName;
        opt.selected = true;
        opt.dataset.name = a.studentName;
        opt.dataset.class = a.studentClass || '';
        select.prepend(opt);
    }
    openModal('attendanceModal');
}

async function saveAttendance(event) {
    event.preventDefault();
    const editId = document.getElementById('attendanceEditId').value;
    const studentSelect = document.getElementById('attendanceStudent');
    const studentId = parseInt(studentSelect?.value) || 0;
    const selectedOpt = studentSelect?.selectedOptions?.[0];
    const studentName = selectedOpt?.dataset?.name || '';
    const studentClass = selectedOpt?.dataset?.class || '';

    const data = {
        studentId,
        studentName,
        studentClass,
        date: document.getElementById('attendanceDate').value,
        status: document.getElementById('attendanceStatus').value,
        remarks: document.getElementById('attendanceRemarks').value || ''
    };
    if (!studentId) { showToast('Please select a student!', 'error'); return false; }
    if (!data.date) { showToast('Please select a date!', 'error'); return false; }

    if (editId) {
        const result = await apiFetch('admin', 'attendance', 'PUT', data, editId);
        if (result.success) showToast('Attendance updated!');
        else showToast(result.message, 'error');
    } else {
        const result = await apiFetch('admin', 'attendance', 'POST', data);
        if (result.success) showToast('Attendance marked!');
        else showToast(result.message, 'error');
    }
    closeModal();
    renderAttendance();
    updateStats();
    return false;
}

function exportAttendance() {
    const table = document.getElementById('attendanceTable');
    if (!table) return;
    let csv = 'ID,Student Name,Class,Date,Status,Remarks\n';
    const rows = table.querySelectorAll('tbody tr');
    rows.forEach(row => {
        const cols = row.querySelectorAll('td');
        if (cols.length >= 6) {
            csv += `${cols[0].textContent},${cols[1].textContent},${cols[2].textContent},${cols[3].textContent},${cols[4].textContent},${cols[5].textContent}\n`;
        }
    });
    downloadCSV(csv, 'attendance.csv');
}

// ===== ACTIVITY LOG =====
async function renderActivityLog() {
    const tbody = document.getElementById('activityTableBody');
    if (!tbody) return;
    const result = await apiFetch('admin', 'activity');
    const activities = result.success ? (result.data?.items || []) : [];
    if (activities.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" class="text-center text-muted">No activity recorded yet.</td></tr>';
        return;
    }
    const searchTerm = (document.getElementById('activitySearch')?.value || '').toLowerCase();
    const filtered = activities.filter(a => {
        return (a.action + ' ' + (a.detail || '')).toLowerCase().includes(searchTerm);
    });
    if (filtered.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" class="text-center text-muted">No matching activity.</td></tr>';
        return;
    }
    tbody.innerHTML = filtered.slice(0, 100).map(a => `<tr>
        <td><strong>${a.action || '-'}</strong></td>
        <td>${a.user || 'System'}</td>
        <td>${a.detail || '-'}</td>
        <td>${a.ip_address || a.ipAddress || '-'}</td>
        <td>${formatDateTime(a.created_at || a.createdAt || a.time)}</td>
    </tr>`).join('');
}

function confirmClearActivity() {
    if (!confirm('Clear all activity logs? This cannot be undone.')) return;
    // For now, just refresh
    showToast('Activity log cleared', 'info');
    renderActivityLog();
}

// ===== CLASS SUMMARY =====
async function renderClassSummary() {
    const tbody = document.getElementById('classSummaryBody');
    if (!tbody) return;
    const studentsResult = await apiFetch('admin', 'students');
    const teachersResult = await apiFetch('admin', 'teachers');
    const students = studentsResult.success ? (studentsResult.data?.items || []) : [];
    const teachers = teachersResult.success ? (teachersResult.data?.items || []) : [];
    
    // Group by grade
    const classMap = {};
    students.forEach(s => {
        const grade = s.grade || 'Unassigned';
        if (!classMap[grade]) {
            classMap[grade] = { male: 0, female: 0, total: 0, teachers: [] };
        }
        classMap[grade].total++;
        if (s.gender === 'Male') classMap[grade].male++;
        else if (s.gender === 'Female') classMap[grade].female++;
    });
    
    // Assign teachers to classes
    teachers.forEach(t => {
        if (t.classAssigned && classMap[t.classAssigned]) {
            classMap[t.classAssigned].teachers.push(t.firstName + ' ' + t.lastName);
        }
    });
    
    const grades = Object.keys(classMap).sort();
    const totalStudents = grades.reduce((sum, g) => sum + classMap[g].total, 0);
    const totalMale = grades.reduce((sum, g) => sum + classMap[g].male, 0);
    const totalFemale = grades.reduce((sum, g) => sum + classMap[g].female, 0);
    
    document.getElementById('csTotalStudents').textContent = totalStudents;
    document.getElementById('csTotalMale').textContent = totalMale;
    document.getElementById('csTotalFemale').textContent = totalFemale;
    document.getElementById('csTotalClasses').textContent = grades.length;
    
    if (grades.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted">No students added yet.</td></tr>';
        return;
    }
    
    const searchTerm = (document.getElementById('csSearch')?.value || '').toLowerCase();
    const filteredGrades = grades.filter(g => g.toLowerCase().includes(searchTerm));
    
    if (filteredGrades.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted">No matching classes.</td></tr>';
        return;
    }
    
    tbody.innerHTML = filteredGrades.map((g, idx) => {
        const cls = classMap[g];
        const statusClass = cls.total > 0 ? 'active' : 'pending';
        return `<tr>
            <td>${idx + 1}</td>
            <td><strong>${g}</strong></td>
            <td>${cls.male}</td>
            <td>${cls.female}</td>
            <td><strong>${cls.total}</strong></td>
            <td>${cls.teachers.length > 0 ? cls.teachers.join(', ') : '-'}</td>
            <td><span class="status-badge ${statusClass}">${cls.total > 0 ? 'Active' : 'Empty'}</span></td>
        </tr>`;
    }).join('');
}

function editClassTeachers() {
    showToast('Use the Teachers section to assign classes to teachers.', 'info');
}

function exportClassSummary() {
    let csv = 'Class,Male,Female,Total,Teachers,Status\n';
    const rows = document.getElementById('classSummaryTable')?.querySelectorAll('tbody tr');
    if (rows) {
        rows.forEach(row => {
            const cols = row.querySelectorAll('td');
            if (cols.length >= 7) {
                csv += `${cols[1].textContent},${cols[2].textContent},${cols[3].textContent},${cols[4].textContent},${cols[5].textContent},${cols[6].textContent}\n`;
            }
        });
    }
    downloadCSV(csv, 'class_summary.csv');
}

function importClassSummary(event) {
    const file = event.target.files?.[0];
    if (file) {
        showToast('Import feature: please use the data import in Settings.', 'info');
    }
}

// ===== ANNOUNCEMENTS =====
async function renderAnnouncements() {
    const tbody = document.getElementById('announcementsTableBody');
    if (!tbody) return;
    const result = await apiFetch('admin', 'announcements', 'GET');
    const announcements = (result.success && result.data) ? (result.data.items || []) : [];

    // Apply filters
    const priorityFilter = document.getElementById('announcementPriorityFilter') ? document.getElementById('announcementPriorityFilter').value : '';
    const statusFilter = document.getElementById('announcementStatusFilter') ? document.getElementById('announcementStatusFilter').value : '';
    let filtered = announcements;
    if (priorityFilter) filtered = filtered.filter(a => a.priority === priorityFilter);
    if (statusFilter) filtered = filtered.filter(a => a.status === statusFilter);

    if (filtered.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted">No announcements match this filter.</td></tr>';
        const badge = document.getElementById('annBadge');
        if (badge) badge.textContent = announcements.length;
        return;
    }
    tbody.innerHTML = filtered.map(a => {
        const priority = a.priority || 'normal';
        const priorityColors = { normal: 'priority-normal', important: 'priority-important', urgent: 'priority-urgent' };
        const priorityIcons = { normal: 'fa-circle-info', important: 'fa-exclamation', urgent: 'fa-fire' };
        const audience = a.targetAudience || 'all';
        const audienceLabels = { all: 'Everyone', teachers: 'Teachers', parents: 'Parents' };
        const audienceIcons = { all: 'fa-users', teachers: 'fa-chalkboard-user', parents: 'fa-people-roof' };
        return `<tr>
            <td>
                <div class="announcement-title-cell">
                    ${a.pinned ? '<i class="fas fa-thumbtack pin-icon" title="Pinned"></i>' : ''}
                    <strong>${a.title}</strong>
                </div>
            </td>
            <td><div class="announcement-content-cell">${(a.content || '').substring(0, 80)}${(a.content || '').length > 80 ? '...' : ''}</div></td>
            <td><span class="status-badge ${priorityColors[priority]}"><i class="fas ${priorityIcons[priority]}"></i> ${priority.charAt(0).toUpperCase() + priority.slice(1)}</span></td>
            <td><span class="audience-badge"><i class="fas ${audienceIcons[audience] || 'fa-users'}"></i> ${audienceLabels[audience] || audience}</span></td>
            <td><span class="status-badge ${a.status === 'Published' ? 'active' : 'draft'}">${a.status}</span></td>
            <td><span class="announcement-date">${formatDate(a.createdAt)}</span></td>
            <td>
                <button class="admin-btn admin-btn-primary admin-btn-sm" onclick="editAnnouncement(${a.id})" title="Edit"><i class="fas fa-edit"></i></button>
                <button class="admin-btn admin-btn-danger admin-btn-sm" onclick="confirmDelete('announcement', ${a.id}, '${a.title.replace(/'/g, "\\'")}')" title="Delete"><i class="fas fa-trash"></i></button>
            </td>
        </tr>`;
    }).join('');
    const badge = document.getElementById('annBadge');
    if (badge) badge.textContent = announcements.length;
}

function openAnnouncementModal() {
    document.getElementById('announcementModalTitle').innerHTML = '<i class="fas fa-plus"></i> New Announcement';
    document.getElementById('announcementEditId').value = '';
    document.getElementById('announcementForm').reset();
    document.getElementById('announcementPriority').value = 'normal';
    document.getElementById('announcementAudience').value = 'all';
    document.getElementById('announcementStatus').value = 'Published';
    openModal('announcementModal');
}

async function editAnnouncement(id) {
    const result = await apiFetch('admin', 'announcements', 'GET', null, id);
    if (!result.success) return;
    const a = result.data;
    document.getElementById('announcementModalTitle').innerHTML = '<i class="fas fa-edit"></i> Edit Announcement';
    document.getElementById('announcementEditId').value = id;
    document.getElementById('announcementTitle').value = a.title || '';
    document.getElementById('announcementContent').value = a.content || '';
    document.getElementById('announcementPriority').value = a.priority || 'normal';
    document.getElementById('announcementAudience').value = a.targetAudience || 'all';
    document.getElementById('announcementStatus').value = a.status || 'Published';
    document.getElementById('announcementPinned').checked = a.pinned || false;
    openModal('announcementModal');
}

async function saveAnnouncement(event) {
    event.preventDefault();
    const editId = document.getElementById('announcementEditId').value;
    const data = {
        title: document.getElementById('announcementTitle').value.trim(),
        content: document.getElementById('announcementContent').value.trim(),
        priority: document.getElementById('announcementPriority').value,
        targetAudience: document.getElementById('announcementAudience').value,
        status: document.getElementById('announcementStatus').value,
        pinned: document.getElementById('announcementPinned')?.checked ? 1 : 0,
        createdBy: 'Admin'
    };
    if (editId) {
        const result = await apiFetch('admin', 'announcements', 'PUT', data, editId);
        if (result.success) showToast('Announcement updated!');
        else showToast(result.message, 'error');
    } else {
        const result = await apiFetch('admin', 'announcements', 'POST', data);
        if (result.success) showToast('Announcement created!');
        else showToast(result.message, 'error');
    }
    closeModal();
    renderAnnouncements();
    updateStats();
    return false;
}

// ===== NOTIFICATIONS CENTER =====

async function markNotificationRead(notifId) {
    const result = await apiFetch('admin', 'notifications', 'PUT', { isRead: true }, notifId);
    if (result.success) {
        renderNotifications();
    }
}

async function markAllNotificationsRead() {
    const result = await apiFetch('admin', 'notifications', 'GET');
    if (!result.success || !result.data || !result.data.items) return;
    const unread = result.data.items.filter(n => !n.isRead);
    const promises = unread.map(n => apiFetch('admin', 'notifications', 'PUT', { isRead: true }, n.id));
    await Promise.all(promises);
    showToast('All notifications marked as read');
    renderNotifications();
}

// ===== REPORT WORKFLOW =====

async function loadPendingReports() {
    const result = await apiReportWorkflow('admin_get_pending_reports');
    if (result.success) {
        renderPendingReports(result.data.items);
    } else {
        // Check if it's just a case of no pending reports vs actual error
        if (result.message && result.message.includes('Server returned empty response')) {
            renderPendingReports([]); // Show empty state
        } else {
            showToast('Failed to load pending reports: ' + (result.message || 'Unknown error'), 'error');
        }
    }
}

function renderPendingReports(reports) {
    const tbody = document.getElementById('pendingReportsTableBody');
    if (!tbody) return;
    
    if (!reports || reports.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" class="text-center text-muted">No pending reports to review.</td></tr>';
        return;
    }
    
    let html = '';
    reports.forEach(r => {
        html += `
            <tr>
                <td><strong>${r.studentName}</strong></td>
                <td>${r.teacherName}</td>
                <td>${r.className}</td>
                <td>${r.term}</td>
                <td>${r.overallGrade || '-'}</td>
                <td><span class="badge badge-pending">${r.workflowStatus}</span></td>
                <td>${r.submissionMessage || '-'}</td>
                <td>
                    <button class="admin-btn admin-btn-sm admin-btn-success" onclick="viewReportForReview(${r.id})">
                        <i class="fas fa-eye"></i> Review
                    </button>
                </td>
            </tr>
        `;
    });
    
    tbody.innerHTML = html;
}

async function loadAllReports() {
    const result = await apiReportWorkflow('admin_get_all_reports');
    if (result.success) {
        renderAllReports(result.data.items);
    } else {
        showToast('Failed to load reports', 'error');
    }
}

function renderAllReports(reports) {
    const tbody = document.getElementById('allReportsTableBody');
    if (!tbody) return;
    
    if (!reports || reports.length === 0) {
        tbody.innerHTML = '<tr><td colspan="10" class="text-center text-muted">No reports found.</td></tr>';
        return;
    }
    
    tbody.innerHTML = reports.map(r => `
        <tr>
            <td><strong>${r.studentName}</strong></td>
            <td>${r.teacherName}</td>
            <td>${r.className}</td>
            <td>${r.term}</td>
            <td>${r.overallGrade || '-'}</td>
            <td><span class="badge badge-${r.workflowStatus.toLowerCase()}">${r.workflowStatus}</span></td>
            <td>${r.currentLocation}</td>
            <td>${r.sentToAdmin ? '<i class="fas fa-check text-success"></i>' : '<i class="fas fa-times text-danger"></i>'}</td>
            <td>${r.sentToParent ? '<i class="fas fa-check text-success"></i>' : '<i class="fas fa-times text-danger"></i>'}</td>
            <td>
                <button class="admin-btn admin-btn-sm admin-btn-info" onclick="viewReportForReview(${r.id})">
                    <i class="fas fa-eye"></i> View
                </button>
            </td>
        </tr>
    `).join('');
}

let currentReviewReportId = null;

async function viewReportForReview(reportId) {
    currentReviewReportId = reportId;
    
    // Get report details
    const result = await apiFetch('admin', 'school_reports', 'GET', null, reportId);
    if (result.success && result.data) {
        const report = result.data;
        document.getElementById('reviewReportStudentName').textContent = report.studentName;
        document.getElementById('reviewReportTeacherName').textContent = report.teacherName;
        document.getElementById('reviewReportClass').textContent = report.className;
        document.getElementById('reviewReportTerm').textContent = report.term;
        document.getElementById('reviewReportGrade').textContent = report.overallGrade || 'N/A';
        document.getElementById('reviewReportComment').textContent = report.overallComment || 'No comment';
        document.getElementById('reviewReportFeedback').value = '';
        
        document.getElementById('reportReviewModal').classList.add('show');
        document.getElementById('modalOverlay').classList.add('show');
    } else {
        showToast('Failed to load report details', 'error');
    }
}

function closeReportReviewModal() {
    document.getElementById('reportReviewModal').classList.remove('show');
    document.getElementById('modalOverlay').classList.remove('show');
    currentReviewReportId = null;
}

async function approveReport() {
    if (!currentReviewReportId || !currentUser) return;
    
    const feedback = document.getElementById('reviewReportFeedback').value.trim();
    
    const result = await apiReportWorkflow('admin_approve_report', {}, {
        reportId: currentReviewReportId,
        adminId: currentUser.id,
        feedback: feedback
    });
    
    if (result.success) {
        showToast('Report approved successfully', 'success');
        closeReportReviewModal();
        loadPendingReports();
        loadAllReports();
    } else {
        showToast(result.message || 'Failed to approve report', 'error');
    }
}

async function rejectReport() {
    if (!currentReviewReportId || !currentUser) return;
    
    const feedback = document.getElementById('reviewReportFeedback').value.trim();
    if (!feedback) {
        showToast('Please provide feedback for rejection', 'error');
        return;
    }
    
    const result = await apiReportWorkflow('admin_reject_report', {}, {
        reportId: currentReviewReportId,
        adminId: currentUser.id,
        feedback: feedback
    });
    
    if (result.success) {
        showToast('Report rejected and returned to teacher', 'success');
        closeReportReviewModal();
        loadPendingReports();
        loadAllReports();
    } else {
        showToast(result.message || 'Failed to reject report', 'error');
    }
}

async function returnReportToTeacher() {
    if (!currentReviewReportId || !currentUser) return;
    
    const message = document.getElementById('reviewReportFeedback').value.trim();
    if (!message) {
        showToast('Please provide a message for the teacher', 'error');
        return;
    }
    
    const result = await apiReportWorkflow('admin_return_to_teacher', {}, {
        reportId: currentReviewReportId,
        adminId: currentUser.id,
        message: message
    });
    
    if (result.success) {
        showToast('Report returned to teacher for revision', 'success');
        closeReportReviewModal();
        loadPendingReports();
        loadAllReports();
    } else {
        showToast(result.message || 'Failed to return report', 'error');
    }
}

let currentPublishReportId = null;

function openPublishModal(reportId) {
    currentPublishReportId = reportId;
    document.getElementById('publishReportModal').classList.add('show');
    document.getElementById('modalOverlay').classList.add('show');
    
    // Load parents for selection
    loadParentsForPublish();
}

function closePublishModal() {
    document.getElementById('publishReportModal').classList.remove('show');
    document.getElementById('modalOverlay').classList.remove('show');
    currentPublishReportId = null;
}

async function loadParentsForPublish() {
    const result = await apiFetch('admin', 'parents', 'GET');
    if (result.success) {
        const select = document.getElementById('publishParentSelect');
        select.innerHTML = '<option value="">Select Parent</option>';
        result.data.items.forEach(p => {
            select.innerHTML += `<option value="${p.id}">${p.firstName} ${p.lastName}</option>`;
        });
    }
}

async function publishReportToParent() {
    if (!currentPublishReportId || !currentUser) return;
    
    const parentId = parseInt(document.getElementById('publishParentSelect').value);
    const studentId = parseInt(document.getElementById('publishStudentSelect').value);
    const message = document.getElementById('publishMessage').value.trim();
    
    if (!parentId || !studentId) {
        showToast('Please select parent and student', 'error');
        return;
    }
    
    const result = await apiReportWorkflow('admin_publish_to_parent', {}, {
        reportId: currentPublishReportId,
        adminId: currentUser.id,
        parentId: parentId,
        studentId: studentId,
        message: message
    });
    
    if (result.success) {
        showToast('Report published to parent successfully', 'success');
        closePublishModal();
        loadAllReports();
    } else {
        showToast(result.message || 'Failed to publish report', 'error');
    }
}

// Load report workflow section
function loadReportWorkflowSection() {
    loadPendingReports();
    loadAllReports();
}

// ===== CLASS BREAKDOWN =====
async function loadRegistrationClassBreakdown() {
    const result = await apiFetch('admin', 'registrations');
    if (result.success) {
        const registrations = result.data.items || [];
        // Filter only approved registrations
        const approvedRegistrations = registrations.filter(r => r.status === 'Approved');
        renderRegistrationClassBreakdown(approvedRegistrations);
    } else {
        showToast('Failed to load registration data', 'error');
    }
}

function renderRegistrationClassBreakdown(registrations) {
    // Define class categories
    const categories = {
        'Early Childhood': ['Daycare', 'Baby', 'Middle', 'Reception'],
        'Primary': ['Standard 1', 'Standard 2', 'Standard 3', 'Standard 4', 'Standard 5', 'Standard 6', 'Standard 7', 'Standard 8'],
        'Secondary': ['Form 1', 'Form 2', 'Form 3', 'Form 4']
    };

    const container = document.getElementById('classBreakdownContainer');
    if (!container) return;
    
    if (registrations.length === 0) {
        container.innerHTML = `
            <div class="admin-card">
                <div class="admin-card-body">
                    <div class="text-center text-muted" style="padding:40px;">
                        <i class="fas fa-users" style="font-size:48px;margin-bottom:16px;"></i>
                        <h4>No Approved Registrations</h4>
                        <p>There are no approved registrations to display in the class breakdown.</p>
                    </div>
                </div>
            </div>
        `;
        return;
    }
    
    let html = '<div class="admin-card"><div class="admin-card-body">';
    
    // Create summary table
    html += `
        <div style="margin-bottom:24px;">
            <h3 style="color:#085636;margin-bottom:16px;"><i class="fas fa-chart-bar"></i> Class Breakdown by Approved Registrations</h3>
            <div class="table-responsive">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>Category</th>
                            <th>Class</th>
                            <th>Approved Students</th>
                            <th>Percentage</th>
                        </tr>
                    </thead>
                    <tbody>
    `;
    
    let grandTotal = 0;
    const classCounts = {};
    
    // Process each category
    for (const [categoryName, classes] of Object.entries(categories)) {
        let categoryTotal = 0;
        
        for (const className of classes) {
            const classRegistrations = registrations.filter(r => r.grade === className);
            const count = classRegistrations.length;
            classCounts[className] = count;
            categoryTotal += count;
            grandTotal += count;
        }
        
        // Add category subtotal row
        html += `
            <tr style="background:#f8f9fa;font-weight:600;">
                <td>${categoryName}</td>
                <td>Total</td>
                <td>${categoryTotal}</td>
                <td>-</td>
            </tr>
        `;
        
        // Add individual class rows
        for (const className of classes) {
            const count = classCounts[className] || 0;
            const percentage = grandTotal > 0 ? ((count / grandTotal) * 100).toFixed(1) : 0;
            
            html += `
                <tr>
                    <td></td>
                    <td>${className}</td>
                    <td><span class="badge ${count > 0 ? 'badge-success' : 'badge-secondary'}">${count}</span></td>
                    <td>${percentage}%</td>
                </tr>
            `;
        }
    }
    
    // Add grand total row
    html += `
        <tr style="background:#085636;color:#fff;font-weight:700;">
            <td><strong>GRAND TOTAL</strong></td>
            <td><strong>All Classes</strong></td>
            <td><strong>${grandTotal}</strong></td>
            <td><strong>100%</strong></td>
        </tr>
    </tbody>
    </table>
    </div>
    </div>
    
    <!-- Additional Statistics -->
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:16px;margin-top:24px;">
        <div style="background:#e8f5e9;padding:16px;border-radius:8px;text-align:center;">
            <div style="font-size:32px;font-weight:700;color:#085636;">${grandTotal}</div>
            <div style="font-size:14px;color:#666;">Total Approved</div>
        </div>
        <div style="background:#e3f2fd;padding:16px;border-radius:8px;text-align:center;">
            <div style="font-size:32px;font-weight:700;color:#1976d2;">${Object.keys(categories).length}</div>
            <div style="font-size:14px;color:#666;">Categories</div>
        </div>
        <div style="background:#fff3e0;padding:16px;border-radius:8px;text-align:center;">
            <div style="font-size:32px;font-weight:700;color:#f57c00;">${Object.values(categories).flat().length}</div>
            <div style="font-size:14px;color:#666;">Total Classes</div>
        </div>
    </div>
    </div></div>`;
    
    container.innerHTML = html;
}

async function renderNotifications() {
    const list = document.getElementById('notificationList');
    if (!list) return;

    list.innerHTML = '<div class="text-center text-muted" style="padding:40px;"><i class="fas fa-spinner fa-spin"></i> Loading...</div>';

    const result = await apiFetch('admin', 'notifications', 'GET');
    const notifications = (result.success && result.data) ? (result.data.items || []) : [];

    // Update summary cards
    const pendingCount = notifications.filter(n => n.type === 'approval' && !n.isRead).length;
    const unreadMsg = notifications.filter(n => n.type === 'message' && !n.isRead).length;
    const newRegs = notifications.filter(n => n.type === 'registration' && !n.isRead).length;
    const recentPays = notifications.filter(n => n.type === 'payment' && !n.isRead).length;

    const pendingEl = document.getElementById('notifPendingCount');
    const msgEl = document.getElementById('notifUnreadMsg');
    const regEl = document.getElementById('notifNewReg');
    const payEl = document.getElementById('notifPayments');
    if (pendingEl) pendingEl.textContent = pendingCount;
    if (msgEl) msgEl.textContent = unreadMsg;
    if (regEl) regEl.textContent = newRegs;
    if (payEl) payEl.textContent = recentPays;

    // Update sidebar badge
    const unreadTotal = notifications.filter(n => !n.isRead).length;
    const badge = document.getElementById('notifBadge');
    if (badge) {
        badge.textContent = unreadTotal;
        badge.style.display = unreadTotal > 0 ? 'inline-block' : 'none';
    }

    // Apply filters
    const typeFilter = document.getElementById('notifTypeFilter') ? document.getElementById('notifTypeFilter').value : '';
    const readFilter = document.getElementById('notifReadFilter') ? document.getElementById('notifReadFilter').value : '';
    let filtered = notifications;
    if (typeFilter) filtered = filtered.filter(n => n.type === typeFilter);
    if (readFilter === 'unread') filtered = filtered.filter(n => !n.isRead);
    if (readFilter === 'read') filtered = filtered.filter(n => n.isRead);

    if (filtered.length === 0) {
        list.innerHTML = '<div class="notif-empty"><i class="fas fa-bell-slash"></i><p>No notifications</p><span>You\'re all caught up!</span></div>';
        return;
    }

    let html = '';
    filtered.forEach(n => {
        const timeStr = n.createdAt ? formatDateTime(n.createdAt) : '';
        const linkAction = n.link ? `showSection('${n.link}')` : '';
        html += `<div class="notif-item ${n.isRead ? 'notif-read' : 'notif-unread'}" data-id="${n.id}">
            <div class="notif-icon" style="background:${n.iconBg || '#085636'};">
                <i class="fas ${n.icon || 'fa-bell'}"></i>
            </div>
            <div class="notif-body">
                <div class="notif-header">
                    <span class="notif-title">${n.title}</span>
                    <span class="notif-time">${timeStr}</span>
                </div>
                <p class="notif-message">${n.message || ''}</p>
                <div class="notif-actions">
                    ${n.link ? `<button class="admin-btn admin-btn-sm admin-btn-primary" onclick="${linkAction}"><i class="fas fa-arrow-right"></i> ${n.linkLabel || 'View'}</button>` : ''}
                    ${!n.isRead ? `<button class="admin-btn admin-btn-sm admin-btn-secondary" onclick="markNotificationRead(${n.id})"><i class="fas fa-check"></i> Mark Read</button>` : '<span class="notif-read-label"><i class="fas fa-check-circle"></i> Read</span>'}
                </div>
            </div>
        </div>`;
    });
    list.innerHTML = html;
}

// ===== NOTIFICATION ACTIONS =====
async function markAllNotificationsRead() {
    try {
        const result = await apiFetch('admin', 'notifications', 'PUT', { markAllRead: true });
        if (result.success) {
            showToast('All notifications marked as read');
            renderNotifications();
        } else {
            showToast(result.message || 'Failed to mark all as read', 'error');
        }
    } catch (error) {
        showToast('Error marking notifications as read', 'error');
    }
}

async function markNotificationRead(id) {
    try {
        const result = await apiFetch('admin', 'notifications', 'PUT', { isRead: true }, id);
        if (result.success) {
            showToast('Notification marked as read');
            renderNotifications();
        } else {
            showToast(result.message || 'Failed to mark as read', 'error');
        }
    } catch (error) {
        showToast('Error marking notification as read', 'error');
    }
}

async function deleteNotification(id) {
    if (!confirm('Are you sure you want to delete this notification?')) return;
    try {
        const result = await apiFetch('admin', 'notifications', 'DELETE', null, id);
        if (result.success) {
            showToast('Notification deleted');
            renderNotifications();
        } else {
            showToast(result.message || 'Failed to delete notification', 'error');
        }
    } catch (error) {
        showToast('Error deleting notification', 'error');
    }
}

function openSendNotificationModal() {
    document.getElementById('sendNotificationModalTitle').innerHTML = '<i class="fas fa-paper-plane"></i> Send Notification';
    document.getElementById('sendNotificationForm').reset();
    document.getElementById('sendNotificationTarget').value = 'all';
    document.getElementById('sendNotificationPriority').value = 'normal';
    document.getElementById('sendToTeacherPortal').checked = true;
    document.getElementById('sendToParentPortal').checked = false;
    document.getElementById('sendToEmail').checked = false;
    document.getElementById('sendToSms').checked = false;
    document.getElementById('emailRecipientsGroup').style.display = 'none';
    document.getElementById('smsRecipientsGroup').style.display = 'none';
    document.getElementById('smsApiGroup').style.display = 'none';
    document.getElementById('sendNotificationModalOverlay').classList.add('show');
    document.getElementById('sendNotificationModal').classList.add('show');
    
    // Load SMS APIs
    loadSmsApis();
    
    // Add event listener for email checkbox
    document.getElementById('sendToEmail').onchange = function() {
        document.getElementById('emailRecipientsGroup').style.display = this.checked ? 'block' : 'none';
    };
    
    // Add event listener for SMS checkbox
    document.getElementById('sendToSms').onchange = function() {
        document.getElementById('smsRecipientsGroup').style.display = this.checked ? 'block' : 'none';
        document.getElementById('smsApiGroup').style.display = this.checked ? 'block' : 'none';
    };
}

async function loadSmsApis() {
    try {
        const result = await apiFetch('admin', 'apis');
        const select = document.getElementById('smsApiSelect');
        
        if (result.success && result.data) {
            const apis = Array.isArray(result.data) ? result.data : (result.data.items || []);
            const smsApis = apis.filter(api => api.type === 'sms' && api.status === 'active');
            
            if (smsApis.length === 0) {
                select.innerHTML = '<option value="">No active SMS APIs configured</option>';
                select.disabled = true;
            } else {
                select.innerHTML = '<option value="">Select SMS API...</option>' + 
                    smsApis.map(api => `<option value="${api.id}">${api.name} (${api.provider})</option>`).join('');
                select.disabled = false;
            }
        } else {
            select.innerHTML = '<option value="">Failed to load SMS APIs</option>';
            select.disabled = true;
        }
    } catch (error) {
        console.error('Error loading SMS APIs:', error);
        const select = document.getElementById('smsApiSelect');
        select.innerHTML = '<option value="">Error loading SMS APIs</option>';
        select.disabled = true;
    }
}

function closeSendNotificationModal() {
    document.getElementById('sendNotificationModalOverlay').classList.remove('show');
    document.getElementById('sendNotificationModal').classList.remove('show');
}

async function sendNotification(event) {
    event.preventDefault();
    
    // Get delivery destinations
    const sendToTeacherPortal = document.getElementById('sendToTeacherPortal').checked;
    const sendToParentPortal = document.getElementById('sendToParentPortal').checked;
    const sendToEmail = document.getElementById('sendToEmail').checked;
    const sendToSms = document.getElementById('sendToSms').checked;
    
    if (!sendToTeacherPortal && !sendToParentPortal && !sendToEmail && !sendToSms) {
        showToast('Please select at least one destination (Teacher Portal, Parent Portal, Email, or SMS)', 'error');
        return false;
    }
    
    const data = {
        title: document.getElementById('sendNotificationTitle').value.trim(),
        message: document.getElementById('sendNotificationMessage').value.trim(),
        target: document.getElementById('sendNotificationTarget').value,
        priority: document.getElementById('sendNotificationPriority').value,
        type: document.getElementById('sendNotificationType').value,
        link: document.getElementById('sendNotificationLink').value.trim(),
        delivery: {
            teacherPortal: sendToTeacherPortal,
            parentPortal: sendToParentPortal,
            email: sendToEmail,
            emailRecipients: sendToEmail ? document.getElementById('emailRecipients').value.trim() : '',
            sms: sendToSms,
            smsRecipients: sendToSms ? document.getElementById('smsRecipients').value.trim() : '',
            smsApiId: sendToSms ? document.getElementById('smsApiSelect').value : null
        }
    };
    
    if (!data.title || !data.message) {
        showToast('Please fill in title and message', 'error');
        return false;
    }
    
    // Validate SMS API selection if SMS is enabled
    if (sendToSms && !data.delivery.smsApiId) {
        showToast('Please select an SMS API', 'error');
        return false;
    }
    
    try {
        // Send notification to portals/email first
        const result = await apiFetch('admin', 'notifications', 'POST', data);
        if (result.success) {
            let destinations = [];
            if (sendToTeacherPortal) destinations.push('Teacher Portal');
            if (sendToParentPortal) destinations.push('Parent Portal');
            if (sendToEmail) destinations.push('Email');
            
            // Handle SMS sending separately
            if (sendToSms) {
                try {
                    // Get phone numbers based on target audience
                    let phoneNumbers = [];
                    if (data.delivery.smsRecipients) {
                        // Use custom recipients
                        phoneNumbers = data.delivery.smsRecipients.split(',').map(p => p.trim()).filter(p => p);
                    } else {
                        // Get phone numbers based on target audience
                        const target = data.target;
                        let phoneData = [];
                        
                        if (target === 'all' || target === 'parents') {
                            const parentsResult = await apiFetch('admin', 'parents');
                            if (parentsResult.success && parentsResult.data) {
                                const parents = Array.isArray(parentsResult.data) ? parentsResult.data : (parentsResult.data.items || []);
                                const parentPhones = parents.map(p => p.phone).filter(p => p);
                                phoneData = phoneData.concat(parentPhones);
                            }
                        }
                        if (target === 'all' || target === 'teachers') {
                            const teachersResult = await apiFetch('admin', 'teachers');
                            if (teachersResult.success && teachersResult.data) {
                                const teachers = Array.isArray(teachersResult.data) ? teachersResult.data : (teachersResult.data.items || []);
                                const teacherPhones = teachers.map(t => t.phone).filter(p => p);
                                phoneData = phoneData.concat(teacherPhones);
                            }
                        }
                        if (target === 'all' || target === 'admins') {
                            const adminsResult = await apiFetch('admin', 'admins');
                            if (adminsResult.success && adminsResult.data) {
                                const admins = Array.isArray(adminsResult.data) ? adminsResult.data : (adminsResult.data.items || []);
                                const adminPhones = admins.map(a => a.phone).filter(p => p);
                                phoneData = phoneData.concat(adminPhones);
                            }
                        }
                        
                        phoneNumbers = phoneData.filter(p => p && p.trim() !== '');
                    }
                    
                    if (phoneNumbers.length > 0) {
                        // Send SMS via API
                        const smsData = {
                            apiId: data.delivery.smsApiId,
                            phoneNumbers: phoneNumbers,
                            message: data.message
                        };
                        
                        const smsResult = await fetch(`${API_BASE}?type=admin&api_action=send_sms`, {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify(smsData)
                        });
                        
                        const smsResponse = await safeFetch(smsResult);
                        if (smsResponse.success) {
                            destinations.push(`SMS (${smsResponse.data.success} sent)`);
                        } else {
                            destinations.push('SMS (failed)');
                        }
                    } else {
                        showToast('No phone numbers found for SMS sending', 'warning');
                    }
                } catch (smsError) {
                    console.error('SMS sending error:', smsError);
                    destinations.push('SMS (error)');
                }
            }
            
            showToast(`Notification sent to: ${destinations.join(', ')}!`);
            closeSendNotificationModal();
            renderNotifications();
        } else {
            showToast(result.message || 'Failed to send notification', 'error');
        }
    } catch (error) {
        showToast('Error sending notification', 'error');
    }
    return false;
}

async function exportNotifications() {
    try {
        const result = await apiFetch('admin', 'notifications');
        const notifications = result.success ? (result.data?.items || []) : [];
        
        if (notifications.length === 0) {
            showToast('No notifications to export', 'warning');
            return;
        }
        
        const csv = [
            ['ID', 'Title', 'Message', 'Type', 'Priority', 'Read', 'Created At'].join(','),
            ...notifications.map(n => [
                n.id,
                `"${(n.title || '').replace(/"/g, '""')}"`,
                `"${(n.message || '').replace(/"/g, '""')}"`,
                n.type || '',
                n.priority || '',
                n.isRead ? 'Yes' : 'No',
                n.createdAt || ''
            ].join(','))
        ].join('\n');
        
        const blob = new Blob([csv], { type: 'text/csv' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `notifications_${new Date().toISOString().slice(0, 10)}.csv`;
        a.click();
        URL.revokeObjectURL(url);
        showToast('Notifications exported successfully!');
    } catch (error) {
        showToast('Error exporting notifications', 'error');
    }
}

function openNotificationSettings() {
    document.getElementById('notificationSettingsModalOverlay').classList.add('show');
    document.getElementById('notificationSettingsModal').classList.add('show');
}

function closeNotificationSettings() {
    document.getElementById('notificationSettingsModalOverlay').classList.remove('show');
    document.getElementById('notificationSettingsModal').classList.remove('show');
}

async function saveNotificationSettings(event) {
    event.preventDefault();
    const settings = {
        enableEmailNotifications: document.getElementById('settingEmailNotif').checked,
        enablePushNotifications: document.getElementById('settingPushNotif').checked,
        autoDeleteAfter: document.getElementById('settingAutoDelete').value,
        soundEnabled: document.getElementById('settingSound').checked
    };
    
    // Save to localStorage for now
    localStorage.setItem('notificationSettings', JSON.stringify(settings));
    showToast('Notification settings saved!');
    closeNotificationSettings();
    return false;
}

function confirmClearAllNotifications() {
    if (!confirm('Are you sure you want to delete ALL notifications? This cannot be undone!')) return;
    
    apiFetch('admin', 'notifications', 'DELETE', { clearAll: true }).then(result => {
        if (result.success) {
            showToast('All notifications cleared');
            renderNotifications();
        } else {
            showToast(result.message || 'Failed to clear notifications', 'error');
        }
    }).catch(error => {
        showToast('Error clearing notifications', 'error');
    });
}

// ===== CONTENT MANAGEMENT =====
function switchContentTab(page, btn) {
    document.querySelectorAll('.content-tab').forEach(t => t.style.display = 'none');
    document.querySelectorAll('.subject-tab').forEach(t => t.classList.remove('active'));
    document.getElementById('content-' + page).style.display = 'block';
    if (btn) btn.classList.add('active');
    loadContent(page);
}

async function loadContent(page) {
    const result = await apiFetch('admin', 'content');
    if (!result.success) return;
    const content = result.data || {};
    const pageContent = content[page] || {};
    Object.keys(pageContent).forEach(key => {
        const el = document.getElementById(`content_${page}_${key}`);
        if (el) el.value = pageContent[key] || '';
    });
}

async function saveContent(page, event) {
    event.preventDefault();
    const form = event.target;
    const inputs = form.querySelectorAll('input, textarea, select');
    const data = {};
    inputs.forEach(inp => {
        const id = inp.id;
        if (id && id.startsWith(`content_${page}_`)) {
            const key = id.replace(`content_${page}_`, '');
            data[key] = inp.value;
        }
    });
    const result = await apiFetch('admin', 'content', 'POST', { page, data });
    if (result.success) {
        showToast(`${page.charAt(0).toUpperCase() + page.slice(1)} content saved!`);
    } else {
        showToast(result.message, 'error');
    }
    return false;
}

// ===== DATA MANAGEMENT =====
function confirmClearAll() {
    if (!confirm('Are you sure you want to clear ALL data? This cannot be undone!')) return;
    showToast('Clear all data - not implemented for safety. Use Export first.', 'warning');
}

async function exportData() {
    const result = await apiFetch('admin', 'students');
    const data = { exportedAt: new Date().toISOString(), students: result.success ? result.data?.items : [] };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `nca_data_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('Data exported successfully!');
}

function importData(event) {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = function(e) {
        try {
            const data = JSON.parse(e.target.result);
            showToast('Import completed (sample data loaded for demo)', 'success');
        } catch (err) {
            showToast('Invalid JSON file', 'error');
        }
    };
    reader.readAsText(file);
}

function loadSampleData() {
    showToast('Sample data would be loaded here.', 'info');
}

function downloadCSV(csv, filename) {
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
}

// ===== LOAD ALL SECTIONS ON STARTUP =====
async function loadAllSections() {
    await updateStats();
    renderRegistrations();
    renderPayments();
    renderAttendance();
    renderStudents();
    renderTeachers();
    renderParents();
    renderEvents();
    renderGallery();
    renderBlog();
    renderTeamMembers();
    renderServices();
    renderMessages();
    // renderContracts(); // Temporarily disabled - API endpoint not implemented
    renderClassSummary();
    renderActivityLog();
    renderAnnouncements();
    renderTestimonials();
    renderUsers();
    renderApis();
    loadColors();
    // Load phone correction data
    await loadRegistrationPhones();
    await loadTeacherPhones();
    await loadParentPhones();
    await loadAdminPhones();
}

// ===== INIT =====
document.addEventListener('DOMContentLoaded', function() {
    // Try auto-login first
    if (!autoLogin()) {
        document.getElementById('loginScreen').style.display = 'flex';
        document.getElementById('dashboardScreen').style.display = 'none';
    }
});

// ===== ADMINS MANAGEMENT =====
let adminsData = [];

async function renderAdmins() {
    const result = await apiFetch('admin', 'admins');
    const tbody = document.getElementById('adminsTableBody');
    if (!tbody) return;

    let admins = result.success ? (result.data?.items || []) : [];
    adminsData = admins; // Store for reference in delete function

    // Apply filters
    const search = (document.getElementById('adminSearch')?.value || '').toLowerCase();
    const roleFilter = document.getElementById('adminRoleFilter')?.value || '';
    const statusFilter = document.getElementById('adminStatusFilter')?.value || '';

    if (search) {
        admins = admins.filter(a =>
            (a.firstName + ' ' + a.lastName).toLowerCase().includes(search) ||
            (a.username || '').toLowerCase().includes(search) ||
            (a.email || '').toLowerCase().includes(search)
        );
    }
    if (roleFilter) {
        admins = admins.filter(a => a.role === roleFilter);
    }
    if (statusFilter) {
        admins = admins.filter(a => a.status === statusFilter);
    }

    if (admins.length === 0) {
        tbody.innerHTML = '<tr><td colspan="10" class="text-center text-muted">No admin accounts found.</td></tr>';
        return;
    }

    tbody.innerHTML = admins.map((a, i) => {
        // Flag accounts with username "admin" as default credentials warning
        const isDefaultCreds = a.username === 'admin';

        return `
        <tr>
            <td>${i + 1}</td>
            <td>${a.firstName || ''} ${a.lastName || ''} ${isDefaultCreds ? '<span class="badge badge-warning" style="margin-left: 5px;" title="Default credentials">Default</span>' : ''}</td>
            <td>${a.username || '-'}</td>
            <td>
                <code id="password-${a.id}" data-password="${a.password || ''}" style="background: ${isDefaultCreds ? '#fff3cd' : '#f0f0f0'}; padding: 2px 6px; border-radius: 3px; cursor: pointer; font-size: 11px; max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" onclick="toggleAdminPassword(${a.id})" title="${a.password || 'Not set'}">
                    ${a.password ? a.password.substring(0, 20) + (a.password.length > 20 ? '...' : '') : 'Not set'}
                </code>
                <button class="admin-btn admin-btn-sm admin-btn-info" onclick="toggleAdminPassword(${a.id})" style="margin-left: 5px;">
                    <i class="fas fa-eye" id="eye-${a.id}"></i>
                </button>
            </td>
            <td>${a.email || '-'}</td>
            <td>${a.phone || '-'}</td>
            <td><span class="badge badge-info">${a.role || 'Admin'}</span></td>
            <td><span class="badge badge-${a.status === 'Active' ? 'success' : 'danger'}">${a.status}</span></td>
            <td>${formatDate(a.createdAt)}</td>
            <td>
                <button class="admin-btn admin-btn-sm admin-btn-warning" onclick="editAdmin(${a.id})"><i class="fas fa-edit"></i></button>
                <button class="admin-btn admin-btn-sm admin-btn-danger" onclick="deleteAdmin(${a.id})"><i class="fas fa-trash"></i></button>
            </td>
        </tr>
    `;
    }).join('');
}

function toggleAdminPassword(adminId) {
    const passwordElement = document.getElementById(`password-${adminId}`);
    const eyeIcon = document.getElementById(`eye-${adminId}`);
    
    if (!passwordElement || !eyeIcon) return;
    
    const actualPassword = passwordElement.getAttribute('data-password') || '';
    
    if (passwordElement.textContent === '••••••••' && actualPassword) {
        passwordElement.textContent = actualPassword;
        eyeIcon.classList.remove('fa-eye');
        eyeIcon.classList.add('fa-eye-slash');
    } else {
        passwordElement.textContent = actualPassword ? '••••••••' : 'Not set';
        eyeIcon.classList.remove('fa-eye-slash');
        eyeIcon.classList.add('fa-eye');
    }
}

async function exportAdminCredentials() {
    const result = await apiFetch('admin', 'admins');
    if (!result.success || !result.data?.items) {
        showToast('Failed to load admin data', 'error');
        return;
    }
    
    const admins = result.data.items;
    let csvContent = "ID,Name,Username,Password,Email,Phone,Role,Status,Created\n";
    
    admins.forEach(admin => {
        csvContent += `${admin.id},"${admin.first_name} ${admin.last_name}",${admin.username},${admin.password || ''},${admin.email || ''},${admin.phone || ''},${admin.role || 'Admin'},${admin.status},${admin.created_at}\n`;
    });
    
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `admin_credentials_${new Date().toISOString().slice(0,10)}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
    
    showToast('Admin credentials exported successfully!', 'success');
}

function openAdminModal() {
    document.getElementById('adminEditId').value = '';
    document.getElementById('adminFirstName').value = '';
    document.getElementById('adminLastName').value = '';
    document.getElementById('adminUsername').value = '';
    document.getElementById('adminEmail').value = '';
    document.getElementById('adminPhone').value = '';
    document.getElementById('adminRole').value = 'Admin';
    document.getElementById('adminPassword').value = '';
    document.getElementById('adminStatus').value = 'Active';
    document.getElementById('adminModalTitle').innerHTML = '<i class="fas fa-user-shield"></i> Add Admin';
    document.getElementById('adminPassword').required = true;
    document.getElementById('adminPasswordLabel').textContent = 'Password *';
    openModal('adminModal');
}

function openVacancyModal(vacancy = null) {
    document.getElementById('vacancyModalTitle').innerHTML = '<i class="fas fa-briefcase"></i> Post Vacancy';
    document.getElementById('vacancyEditId').value = '';
    document.getElementById('vacancyForm').reset();
    openModal('vacancyModal');
}

async function saveVacancy(event) {
    event.preventDefault();
    const editId = document.getElementById('vacancyEditId').value;
    const body = {
        title: document.getElementById('vacancyTitle').value,
        description: document.getElementById('vacancyDescription').value,
        requirements: document.getElementById('vacancyRequirements').value,
        grade: document.getElementById('vacancyGrade').value,
        responsibilities: document.getElementById('vacancyResponsibilities').value,
        duties: document.getElementById('vacancyDuties').value,
        contactEmail: document.getElementById('vacancyContactEmail').value,
        location: document.getElementById('vacancyLocation').value,
        positionType: document.getElementById('vacancyPositionType').value,
        salaryRange: document.getElementById('vacancySalaryRange').value,
        applicationDeadline: document.getElementById('vacancyDeadline').value,
        status: document.getElementById('vacancyStatus').value
    };
    
    const result = editId 
        ? await apiFetch('admin', 'vacancies', 'PUT', body, editId)
        : await apiFetch('admin', 'vacancies', 'POST', body);
    
    if (result.success) {
        showToast('Vacancy saved successfully', 'success');
        closeModal();
        renderVacancies();
    } else {
        showToast(result.message || 'Failed to save vacancy', 'error');
    }
}

async function renderVacancies() {
    const result = await apiFetch('admin', 'vacancies', 'GET');
    const tbody = document.getElementById('vacanciesTableBody');
    if (!tbody) return;

    const vacancies = result.success ? (result.data?.items || []) : [];
    
    if (vacancies.length === 0) {
        tbody.innerHTML = '<tr><td colspan="12" class="text-center text-muted">No vacancies posted yet.</td></tr>';
        return;
    }

    const filter = document.getElementById('vacancyStatusFilter').value;
    const filtered = filter ? vacancies.filter(v => v.status === filter) : vacancies;

    tbody.innerHTML = filtered.length ? filtered.map((v, i) => `
        <tr>
            <td><input type="checkbox" data-id="${v.id}"></td>
            <td>${i + 1}</td>
            <td><strong>${v.title}</strong></td>
            <td>${v.department || '-'}</td>
            <td>${v.location || '-'}</td>
            <td>${v.positionType || 'Full-time'}</td>
            <td>${v.experience || '-'}</td>
            <td>${v.education || '-'}</td>
            <td>${v.salaryRange || '-'}</td>
            <td>${v.applicationDeadline || '-'}</td>
            <td><span class="badge ${v.status === 'Active' ? 'badge-success' : 'badge-secondary'}">${v.status}</span></td>
            <td>
                <button class="admin-btn admin-btn-sm admin-btn-primary" onclick="editVacancy(${v.id})"><i class="fas fa-edit"></i></button>
                <button class="admin-btn admin-btn-sm admin-btn-danger" onclick="deleteVacancy(${v.id})"><i class="fas fa-trash"></i></button>
            </td>
        </tr>
    `).join('') : '<tr><td colspan="12" class="text-center text-muted">No vacancies match this filter.</td></tr>';
}

async function editVacancy(id) {
    const result = await apiFetch('admin', 'vacancies', 'GET', null, id);
    if (result.success && result.data) {
        const v = result.data;
        document.getElementById('vacancyModalTitle').innerHTML = '<i class="fas fa-briefcase"></i> Edit Vacancy';
        document.getElementById('vacancyEditId').value = v.id;
        document.getElementById('vacancyTitle').value = v.title || '';
        document.getElementById('vacancyDescription').value = v.description || '';
        document.getElementById('vacancyRequirements').value = v.requirements || '';
        document.getElementById('vacancyGrade').value = v.grade || '';
        document.getElementById('vacancyResponsibilities').value = v.responsibilities || '';
        document.getElementById('vacancyDuties').value = v.duties || '';
        document.getElementById('vacancyContactEmail').value = v.contactEmail || '';
        document.getElementById('vacancyLocation').value = v.location || '';
        document.getElementById('vacancyPositionType').value = v.positionType || 'Full-time';
        document.getElementById('vacancySalaryRange').value = v.salaryRange || '';
        document.getElementById('vacancyDeadline').value = v.applicationDeadline || '';
        document.getElementById('vacancyStatus').value = v.status || 'Active';
        openModal('vacancyModal');
    } else {
        showToast(result.message || 'Failed to load vacancy', 'error');
    }
}

async function deleteVacancy(id) {
    if (confirm('Are you sure you want to delete this vacancy?')) {
        const result = await apiFetch('admin', 'vacancies', 'DELETE', null, id);
        if (result.success) {
            showToast('Vacancy deleted successfully', 'success');
            renderVacancies();
        } else {
            showToast(result.message || 'Failed to delete vacancy', 'error');
        }
    }
}

// ===== VACANCY BUTTON FUNCTIONS =====

// Export vacancies to CSV
async function exportVacancies() {
    const result = await apiFetch('admin', 'vacancies', 'GET');
    if (result.success && result.data?.items) {
        const vacancies = result.data.items;
        if (vacancies.length === 0) {
            showToast('No vacancies to export', 'warning');
            return;
        }
        
        // Create CSV content
        const headers = ['Title', 'Description', 'Requirements', 'Department', 'Location', 'Type', 'Experience', 'Education', 'Salary Range', 'Deadline', 'Status'];
        const csvContent = [
            headers.join(','),
            ...vacancies.map(v => [
                `"${v.title || ''}"`,
                `"${(v.description || '').replace(/"/g, '""')}"`,
                `"${(v.requirements || '').replace(/"/g, '""')}"`,
                `"${v.department || ''}"`,
                `"${v.location || ''}"`,
                `"${v.positionType || ''}"`,
                `"${v.experience || ''}"`,
                `"${v.education || ''}"`,
                `"${v.salaryRange || ''}"`,
                `"${v.applicationDeadline || ''}"`,
                `"${v.status || ''}"`
            ].join(','))
        ].join('\n');
        
        // Download CSV
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = `vacancies_${new Date().toISOString().split('T')[0]}.csv`;
        link.click();
        showToast('Vacancies exported successfully', 'success');
    } else {
        showToast('Failed to export vacancies', 'error');
    }
}

// Duplicate a vacancy
async function duplicateVacancy() {
    const selected = getSelectedVacancies();
    if (selected.length === 0) {
        showToast('Please select a vacancy to duplicate', 'warning');
        return;
    }
    if (selected.length > 1) {
        showToast('Please select only one vacancy to duplicate', 'warning');
        return;
    }
    
    const result = await apiFetch('admin', 'vacancies', 'GET', null, selected[0]);
    if (result.success && result.data) {
        const v = result.data;
        const duplicate = {
            title: `${v.title} (Copy)`,
            description: v.description,
            requirements: v.requirements,
            grade: v.grade,
            responsibilities: v.responsibilities,
            duties: v.duties,
            contactEmail: v.contactEmail,
            department: v.department,
            experience: v.experience,
            education: v.education,
            workHours: v.workHours,
            benefits: v.benefits,
            location: v.location,
            positionType: v.positionType,
            salaryRange: v.salaryRange,
            applicationDeadline: v.applicationDeadline,
            status: 'Active'
        };
        
        const createResult = await apiFetch('admin', 'vacancies', 'POST', duplicate);
        if (createResult.success) {
            showToast('Vacancy duplicated successfully', 'success');
            renderVacancies();
        } else {
            showToast('Failed to duplicate vacancy', 'error');
        }
    } else {
        showToast('Failed to load vacancy', 'error');
    }
}

// Archive vacancies
async function archiveVacancies() {
    const selected = getSelectedVacancies();
    if (selected.length === 0) {
        showToast('Please select vacancies to archive', 'warning');
        return;
    }
    
    if (confirm(`Archive ${selected.length} vacancy/vacancies?`)) {
        let successCount = 0;
        for (const id of selected) {
            const result = await apiFetch('admin', 'vacancies', 'PUT', { status: 'Archived' }, id);
            if (result.success) successCount++;
        }
        
        if (successCount > 0) {
            showToast(`${successCount} vacancy/vacancies archived`, 'success');
            renderVacancies();
        } else {
            showToast('Failed to archive vacancies', 'error');
        }
    }
}

// Refresh vacancies list
function refreshVacancies() {
    renderVacancies();
    showToast('Vacancies refreshed', 'info');
}

// Preview a vacancy
async function previewVacancy() {
    const selected = getSelectedVacancies();
    if (selected.length === 0) {
        showToast('Please select a vacancy to preview', 'warning');
        return;
    }
    if (selected.length > 1) {
        showToast('Please select only one vacancy to preview', 'warning');
        return;
    }
    
    const result = await apiFetch('admin', 'vacancies', 'GET', null, selected[0]);
    if (result.success && result.data) {
        const v = result.data;
        const previewHtml = `
            <div style="max-height:70vh;overflow-y:auto;">
                <h2 style="color:#085636;margin-bottom:15px;">${v.title}</h2>
                <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:10px;margin-bottom:20px;">
                    <div><strong>Department:</strong> ${v.department || '-'}</div>
                    <div><strong>Location:</strong> ${v.location || '-'}</div>
                    <div><strong>Type:</strong> ${v.positionType || '-'}</div>
                    <div><strong>Experience:</strong> ${v.experience || '-'}</div>
                    <div><strong>Education:</strong> ${v.education || '-'}</div>
                    <div><strong>Salary:</strong> ${v.salaryRange || '-'}</div>
                    <div><strong>Deadline:</strong> ${v.applicationDeadline || '-'}</div>
                    <div><strong>Status:</strong> ${v.status || '-'}</div>
                </div>
                <div style="margin-bottom:15px;">
                    <strong>Description:</strong>
                    <p style="margin-top:5px;line-height:1.6;">${v.description || '-'}</p>
                </div>
                <div style="margin-bottom:15px;">
                    <strong>Requirements:</strong>
                    <p style="margin-top:5px;line-height:1.6;">${v.requirements || '-'}</p>
                </div>
                <div style="margin-bottom:15px;">
                    <strong>Responsibilities:</strong>
                    <p style="margin-top:5px;line-height:1.6;">${v.responsibilities || '-'}</p>
                </div>
                <div style="margin-bottom:15px;">
                    <strong>Benefits:</strong>
                    <p style="margin-top:5px;line-height:1.6;">${v.benefits || '-'}</p>
                </div>
                ${v.contactEmail ? `<div><strong>Contact:</strong> <a href="mailto:${v.contactEmail}">${v.contactEmail}</a></div>` : ''}
            </div>
        `;
        
        const modal = document.createElement('div');
        modal.className = 'admin-modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="admin-modal-content" style="max-width:700px;">
                <div class="admin-modal-header">
                    <h3><i class="fas fa-eye"></i> Vacancy Preview</h3>
                    <button class="admin-modal-close" onclick="this.closest('.admin-modal').remove()">&times;</button>
                </div>
                <div class="admin-modal-body">${previewHtml}</div>
                <div class="admin-modal-footer">
                    <button class="admin-btn admin-btn-secondary" onclick="this.closest('.admin-modal').remove()">Close</button>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    } else {
        showToast('Failed to load vacancy', 'error');
    }
}

// Bulk close vacancies
async function bulkCloseVacancies() {
    const selected = getSelectedVacancies();
    if (selected.length === 0) {
        showToast('Please select vacancies to close', 'warning');
        return;
    }
    
    if (confirm(`Close ${selected.length} vacancy/vacancies?`)) {
        let successCount = 0;
        for (const id of selected) {
            const result = await apiFetch('admin', 'vacancies', 'PUT', { status: 'Closed' }, id);
            if (result.success) successCount++;
        }
        
        if (successCount > 0) {
            showToast(`${successCount} vacancy/vacancies closed`, 'success');
            renderVacancies();
        } else {
            showToast('Failed to close vacancies', 'error');
        }
    }
}

// Delete selected vacancies
async function deleteSelectedVacancies() {
    const selected = getSelectedVacancies();
    if (selected.length === 0) {
        showToast('Please select vacancies to delete', 'warning');
        return;
    }
    
    if (confirm(`Delete ${selected.length} vacancy/vacancies? This action cannot be undone.`)) {
        let successCount = 0;
        for (const id of selected) {
            const result = await apiFetch('admin', 'vacancies', 'DELETE', null, id);
            if (result.success) successCount++;
        }
        
        if (successCount > 0) {
            showToast(`${successCount} vacancy/vacancies deleted`, 'success');
            renderVacancies();
        } else {
            showToast('Failed to delete vacancies', 'error');
        }
    }
}

// Send vacancy notifications
async function sendVacancyNotifications() {
    const selected = getSelectedVacancies();
    if (selected.length === 0) {
        showToast('Please select vacancies to notify about', 'warning');
        return;
    }
    
    // Open notification modal with pre-filled vacancy info
    const result = await apiFetch('admin', 'vacancies', 'GET');
    if (result.success && result.data?.items) {
        const vacancies = result.data.items.filter(v => selected.includes(v.id));
        const vacancyTitles = vacancies.map(v => v.title).join(', ');
        
        document.getElementById('sendNotificationTitle').value = `New Job Vacancy: ${vacancies.length > 1 ? vacancies.length + ' Positions' : vacancies[0]?.title}`;
        document.getElementById('sendNotificationMessage').value = `We have ${selected.length} new job vacancy/vacancies available: ${vacancyTitles}. Apply now!`;
        openModal('sendNotificationModal');
    } else {
        showToast('Failed to load vacancy data', 'error');
    }
}

// Publish all vacancies
async function publishVacancies() {
    const result = await apiFetch('admin', 'vacancies', 'GET');
    if (result.success && result.data?.items) {
        const vacancies = result.data.items;
        const draftVacancies = vacancies.filter(v => v.status !== 'Active');
        
        if (draftVacancies.length === 0) {
            showToast('All vacancies are already published', 'info');
            return;
        }
        
        if (confirm(`Publish ${draftVacancies.length} vacancy/vacancies?`)) {
            let successCount = 0;
            for (const v of draftVacancies) {
                const result = await apiFetch('admin', 'vacancies', 'PUT', { status: 'Active' }, v.id);
                if (result.success) successCount++;
            }
            
            if (successCount > 0) {
                showToast(`${successCount} vacancy/vacancies published`, 'success');
                renderVacancies();
            } else {
                showToast('Failed to publish vacancies', 'error');
            }
        }
    } else {
        showToast('Failed to load vacancies', 'error');
    }
}

// Toggle all vacancies checkbox
function toggleAllVacancies() {
    const selectAll = document.getElementById('selectAllVacancies');
    const checkboxes = document.querySelectorAll('#vacanciesTableBody input[type="checkbox"]');
    checkboxes.forEach(cb => cb.checked = selectAll.checked);
}

// Helper function to get selected vacancy IDs
function getSelectedVacancies() {
    const checkboxes = document.querySelectorAll('#vacanciesTableBody input[type="checkbox"]:checked');
    return Array.from(checkboxes).map(cb => parseInt(cb.dataset.id || cb.closest('tr')?.querySelector('td:nth-child(2)')?.textContent));
}

// ===== JOB APPLICATIONS =====
async function renderJobApplications() {
    const tbody = document.getElementById('applicationsTableBody');
    if (!tbody) return;

    try {
        const response = await fetch('../api/get_applications.php');
        const data = await safeFetch(response);
        
        if (!data.success || !data.data || data.data.length === 0) {
            tbody.innerHTML = '<tr><td colspan="9" class="text-center text-muted">No applications yet.</td></tr>';
            // Update badge even when empty
            updateAppBadge();
            return;
        }

        const applications = data.data;
        const statusFilter = document.getElementById('appStatusFilter')?.value || '';
        const filtered = statusFilter ? applications.filter(a => a.status === statusFilter) : applications;

        if (!Array.isArray(filtered) || filtered.length === 0) {
            tbody.innerHTML = '<tr><td colspan="9" class="text-center text-muted">No applications match this filter.</td></tr>';
        } else {
            tbody.innerHTML = filtered.map(app => `
                <tr>
                    <td>${app.id}</td>
                    <td><strong>${app.applicant_name}</strong></td>
                    <td>${app.applicant_email}</td>
                    <td>${app.applicant_phone || '-'}</td>
                    <td>${app.vacancy_title || 'N/A'}</td>
                    <td><span class="badge badge-info">${app.document_count || 0} files</span></td>
                    <td><span class="badge badge-${app.status === 'Pending' ? 'warning' : app.status === 'Accepted' ? 'success' : app.status === 'Rejected' ? 'danger' : 'secondary'}">${app.status}</span></td>
                    <td>${formatDate(app.applied_at)}</td>
                    <td>
                        <button class="admin-btn admin-btn-sm admin-btn-primary" onclick="viewApplication(${app.id})" title="View Details"><i class="fas fa-eye"></i></button>
                        <button class="admin-btn admin-btn-sm admin-btn-success" onclick="updateApplicationStatus(${app.id}, 'Accepted')" title="Accept"><i class="fas fa-check"></i></button>
                        <button class="admin-btn admin-btn-sm admin-btn-warning" onclick="updateApplicationStatus(${app.id}, 'Reviewed')" title="Mark as Reviewed"><i class="fas fa-check-double"></i></button>
                        <button class="admin-btn admin-btn-sm admin-btn-danger" onclick="updateApplicationStatus(${app.id}, 'Rejected')" title="Reject"><i class="fas fa-times"></i></button>
                        <button class="admin-btn admin-btn-sm admin-btn-danger" onclick="deleteApplication(${app.id})" title="Delete"><i class="fas fa-trash"></i></button>
                    </td>
                </tr>
            `).join('');
        }
        
        // Update badge count
        updateAppBadge();
    } catch (error) {
        console.error('Error fetching applications:', error);
        tbody.innerHTML = '<tr><td colspan="9" class="text-center text-muted">Error loading applications.</td></tr>';
    }
}

async function viewApplication(id) {
    try {
        const response = await fetch(`../api/get_application_details.php?id=${id}`);
        const data = await safeFetch(response);
        
        if (!data.success) {
            showToast('Failed to load application details', 'error');
            return;
        }

        const app = data.data;
        const documents = data.documents || [];

        let docsHtml = '';
        if (documents.length > 0) {
            documents.forEach(doc => {
                docsHtml += `
                    <div style="padding:8px;background:#f0f7f4;border:1px solid #d0e8da;border-radius:4px;margin-bottom:8px;">
                        <strong>${doc.document_type || 'Document'}:</strong> 
                        <a href="../${doc.file_path}" target="_blank" style="color:#085636;text-decoration:none;">
                            <i class="fas fa-download"></i> ${doc.file_name}
                        </a>
                    </div>
                `;
            });
        } else {
            docsHtml = '<p style="color:#666;">No documents uploaded</p>';
        }

        const modalHtml = `
            <div id="applicationViewModal" class="admin-modal" style="display:flex;">
                <div class="admin-modal-content" style="max-width:700px;">
                    <div class="admin-modal-header">
                        <h3><i class="fas fa-file-signature"></i> Application Details</h3>
                        <button class="admin-modal-close" onclick="closeModal()">&times;</button>
                    </div>
                    <div class="admin-modal-body">
                        <div style="margin-bottom:16px;">
                            <strong>Position:</strong> ${app.vacancy_title || 'N/A'}
                        </div>
                        <div style="margin-bottom:16px;">
                            <strong>Applicant:</strong> ${app.applicant_name}
                        </div>
                        <div style="margin-bottom:16px;">
                            <strong>Email:</strong> ${app.applicant_email}
                        </div>
                        <div style="margin-bottom:16px;">
                            <strong>Phone:</strong> ${app.applicant_phone || 'N/A'}
                        </div>
                        <div style="margin-bottom:16px;">
                            <strong>Cover Letter:</strong>
                            <div style="padding:12px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:6px;margin-top:8px;white-space:pre-wrap;color:#333;">${app.cover_letter || 'No cover letter provided'}</div>
                        </div>
                        <div style="margin-bottom:16px;">
                            <strong>Documents:</strong>
                            <div style="margin-top:8px;">${docsHtml}</div>
                        </div>
                        <div style="margin-bottom:16px;">
                            <strong>Status:</strong> <span class="badge badge-${app.status === 'Pending' ? 'warning' : app.status === 'Accepted' ? 'success' : app.status === 'Rejected' ? 'danger' : 'secondary'}">${app.status}</span>
                        </div>
                        <div style="margin-bottom:16px;">
                            <strong>Applied:</strong> ${formatDateTime(app.applied_at)}
                        </div>
                    </div>
                    <div class="admin-modal-footer">
                        <button type="button" class="admin-btn admin-btn-secondary" onclick="closeModal()">Close</button>
                    </div>
                </div>
            </div>
        `;

        // Remove existing modal if present
        const existingModal = document.getElementById('applicationViewModal');
        if (existingModal) existingModal.remove();

        document.body.insertAdjacentHTML('beforeend', modalHtml);
    } catch (error) {
        console.error('Error viewing application:', error);
        showToast('Error loading application details', 'error');
    }
}

async function updateApplicationStatus(id, status) {
    if (!confirm(`Are you sure you want to mark this application as ${status}?`)) return;
    
    try {
        const formData = new FormData();
        formData.append('id', id);
        formData.append('status', status);
        
        const response = await fetch('../api/update_application_status.php', {
            method: 'POST',
            body: formData
        });
        const data = await safeFetch(response);
        
        if (data.success) {
            showToast(`Application ${status.toLowerCase()} successfully`, 'success');
            renderJobApplications();
        } else {
            showToast(data.message || 'Failed to update status', 'error');
        }
    } catch (error) {
        console.error('Error updating application status:', error);
        showToast('Error updating status', 'error');
    }
}

async function deleteApplication(id) {
    if (!confirm('Are you sure you want to delete this application? This action cannot be undone.')) return;
    
    try {
        const formData = new FormData();
        formData.append('id', id);
        
        const response = await fetch('../api/delete_application.php', {
            method: 'POST',
            body: formData
        });
        const data = await safeFetch(response);
        
        if (data.success) {
            showToast('Application deleted successfully', 'success');
            renderJobApplications();
        } else {
            showToast(data.message || 'Failed to delete application', 'error');
        }
    } catch (error) {
        console.error('Error deleting application:', error);
        showToast('Error deleting application', 'error');
    }
}

// Update job applications badge count
async function updateAppBadge() {
    try {
        const response = await fetch('../api/get_applications.php');
        const data = await safeFetch(response);

        if (data.success && Array.isArray(data.data)) {
            const pendingCount = data.data.filter(a => a.status === 'Pending').length;
            const appBadge = document.getElementById('appBadge');
            if (appBadge) {
                appBadge.textContent = pendingCount;
                appBadge.style.display = pendingCount > 0 ? 'inline' : 'none';
            }
        }
    } catch (error) {
        console.error('Error updating app badge:', error);
    }
}

// Refresh job applications
function refreshJobApplications() {
    renderJobApplications();
    showToast('Applications refreshed', 'success');
}

// Search job applications
function searchJobApplications() {
    const searchTerm = (document.getElementById('appSearchInput')?.value || '').toLowerCase();
    const tbody = document.getElementById('applicationsTableBody');
    if (!tbody) return;

    const rows = tbody.querySelectorAll('tr');
    if (rows.length === 0) return;

    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(searchTerm) ? '' : 'none';
    });
}

// Export job applications as CSV
async function exportJobApplications() {
    try {
        const response = await fetch('../api/get_applications.php');
        const data = await safeFetch(response);
        
        if (!data.success || !data.data || data.data.length === 0) {
            showToast('No applications to export', 'warning');
            return;
        }

        const applications = data.data;
        const csvHeader = 'ID,Applicant Name,Email,Phone,Position,Status,Applied Date\n';
        const csvRows = applications.map(app => 
            `${app.id},"${app.applicant_name}","${app.applicant_email}","${app.applicant_phone || ''}","${app.vacancy_title || 'N/A'}",${app.status},"${app.applied_at}"`
        ).join('\n');
        
        downloadCSV(csvHeader + csvRows, 'job_applications.csv');
        showToast('Applications exported successfully', 'success');
    } catch (error) {
        console.error('Error exporting applications:', error);
        showToast('Error exporting applications', 'error');
    }
}

// Mark all applications as reviewed
async function markAllApplicationsReviewed() {
    if (!confirm('Are you sure you want to mark all pending applications as reviewed?')) return;
    
    try {
        const response = await fetch('../api/get_applications.php');
        const data = await safeFetch(response);
        
        if (!data.success || !data.data || data.data.length === 0) {
            showToast('No applications to update', 'warning');
            return;
        }

        const pendingApps = data.data.filter(a => a.status === 'Pending');
        if (pendingApps.length === 0) {
            showToast('No pending applications to mark as reviewed', 'info');
            return;
        }

        let updatedCount = 0;
        for (const app of pendingApps) {
            const formData = new FormData();
            formData.append('id', app.id);
            formData.append('status', 'Reviewed');
            
            const updateResponse = await fetch('../api/update_application_status.php', {
                method: 'POST',
                body: formData
            });
            const updateData = await updateResponse.json();
            
            if (updateData.success) {
                updatedCount++;
            }
        }

        showToast(`${updatedCount} applications marked as reviewed`, 'success');
        renderJobApplications();
    } catch (error) {
        console.error('Error marking applications as reviewed:', error);
        showToast('Error updating applications', 'error');
    }
}

// Confirm clear all applications
function confirmClearAllApplications() {
    document.getElementById('confirmModalTitle').textContent = 'Clear All Applications';
    document.getElementById('confirmModalMessage').textContent = 'Are you sure you want to delete all job applications? This action cannot be undone.';
    document.getElementById('confirmModalBody').innerHTML = '';
    
    const confirmBtn = document.getElementById('confirmModalBtn');
    confirmBtn.onclick = function() {
        clearAllApplications();
        closeModal();
    };
    
    openModal('confirmModal');
}

// Clear all applications
async function clearAllApplications() {
    try {
        const response = await fetch('../api/get_applications.php');
        const data = await safeFetch(response);
        
        if (!data.success || !data.data || data.data.length === 0) {
            showToast('No applications to clear', 'warning');
            return;
        }

        let deletedCount = 0;
        for (const app of data.data) {
            const formData = new FormData();
            formData.append('id', app.id);
            
            const deleteResponse = await fetch('../api/delete_application.php', {
                method: 'POST',
                body: formData
            });
            const deleteData = await deleteResponse.json();
            
            if (deleteData.success) {
                deletedCount++;
            }
        }

        showToast(`${deletedCount} applications deleted`, 'success');
        renderJobApplications();
    } catch (error) {
        console.error('Error clearing applications:', error);
        showToast('Error clearing applications', 'error');
    }
}

// ===== TESTIMONIALS =====
function loadTestimonials(status) {
    if (status !== undefined) {
        const filter = document.getElementById('testimonialStatusFilter');
        if (filter) filter.value = status;
    }
    renderTestimonials();
}

async function renderTestimonials() {
    const tbody = document.getElementById('testimonialsTableBody');
    if (!tbody) return;

    try {
        const statusFilter = document.getElementById('testimonialStatusFilter')?.value || '';
        let url = API_BASE + '?type=admin&collection=testimonials';
        if (statusFilter) {
            url += '&status=' + statusFilter;
        }
        
        const response = await fetch(url);
        const data = await safeFetch(response);
        
        if (!data.success || !data.data || data.data.length === 0) {
            tbody.innerHTML = '<tr><td colspan="9" class="text-center text-muted">No testimonials yet.</td></tr>';
            updateTestimonialBadge();
            return;
        }

        const testimonials = data.data;
        globalData.testimonials = testimonials; // Update global data
        tbody.innerHTML = testimonials.map(t => `
            <tr>
                <td>${t.id}</td>
                <td><strong>${t.anonymous ? 'Anonymous' : t.parent_name}</strong></td>
                <td>${t.student_name}</td>
                <td>${t.grade}</td>
                <td><span style="color:#ffd700;">${'<i class="fas fa-star"></i>'.repeat(t.rating)}</span></td>
                <td><div style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${t.testimonial.substring(0, 50)}${t.testimonial.length > 50 ? '...' : ''}</div></td>
                <td><span class="badge badge-${t.status === 'pending' ? 'warning' : t.status === 'approved' ? 'success' : 'danger'}">${t.status}</span></td>
                <td>${formatDate(t.created_at)}</td>
                <td>
                    <button class="admin-btn admin-btn-sm admin-btn-primary" onclick="viewTestimonial(${t.id})" title="View Details"><i class="fas fa-eye"></i></button>
                    ${t.status === 'pending' ? `
                        <button class="admin-btn admin-btn-sm admin-btn-success" onclick="approveTestimonial(${t.id})" title="Approve"><i class="fas fa-check"></i></button>
                        <button class="admin-btn admin-btn-sm admin-btn-warning" onclick="rejectTestimonial(${t.id})" title="Reject"><i class="fas fa-times"></i></button>
                    ` : ''}
                    <button class="admin-btn admin-btn-sm admin-btn-danger" onclick="deleteTestimonial(${t.id})" title="Delete"><i class="fas fa-trash"></i></button>
                </td>
            </tr>
        `).join('');
        
        updateTestimonialBadge();
        updateTestimonialStats(testimonials);
    } catch (error) {
        console.error('Error rendering testimonials:', error);
        tbody.innerHTML = '<tr><td colspan="9" class="text-center text-danger">Error loading testimonials.</td></tr>';
    }
}

function refreshTestimonials() {
    renderTestimonials();
    showToast('Testimonials refreshed', 'success');
}

async function exportTestimonials() {
    try {
        const response = await fetch(API_BASE + '?type=admin&collection=testimonials');
        const data = await safeFetch(response);
        
        if (!data.success || !data.data || data.data.length === 0) {
            showToast('No testimonials to export', 'warning');
            return;
        }

        const testimonials = data.data;
        const csvHeader = 'ID,Parent Name,Student Name,Grade,Years Enrolled,Rating,Anonymous,Status,Testimonial,Created At\n';
        const csvRows = testimonials.map(t => 
            `${t.id},"${t.parent_name}","${t.student_name}","${t.grade}",${t.years_enrolled},${t.rating},${t.anonymous},${t.status},"${t.testimonial.replace(/"/g, '""')}","${t.created_at}"`
        ).join('\n');
        
        downloadCSV(csvHeader + csvRows, 'testimonials.csv');
        showToast('Testimonials exported successfully', 'success');
    } catch (error) {
        console.error('Error exporting testimonials:', error);
        showToast('Error exporting testimonials', 'error');
    }
}

// Update testimonial badge count
async function updateTestimonialBadge() {
    try {
        const response = await fetch(API_BASE + '?type=admin&collection=testimonials&status=pending');
        const data = await safeFetch(response);
        
        if (data.success && data.data) {
            const pendingCount = data.data.length;
            const testimonialBadge = document.getElementById('testimonialBadge');
            if (testimonialBadge) {
                testimonialBadge.textContent = pendingCount;
                testimonialBadge.style.display = pendingCount > 0 ? 'inline' : 'none';
            }
        }
    } catch (error) {
        console.error('Error updating testimonial badge:', error);
    }
}

// Update testimonial statistics
function updateTestimonialStats(testimonials) {
    if (!testimonials || !Array.isArray(testimonials)) return;
    
    const total = testimonials.length;
    const pending = testimonials.filter(t => t.status === 'pending').length;
    const approved = testimonials.filter(t => t.status === 'approved').length;
    const rejected = testimonials.filter(t => t.status === 'rejected').length;
    const avgRating = testimonials.length > 0 
        ? (testimonials.reduce((sum, t) => sum + (t.rating || 0), 0) / testimonials.length).toFixed(1)
        : 0;
    
    // Update stats if elements exist
    const totalEl = document.getElementById('testimonialTotal');
    const pendingEl = document.getElementById('testimonialPending');
    const approvedEl = document.getElementById('testimonialApproved');
    const rejectedEl = document.getElementById('testimonialRejected');
    const avgRatingEl = document.getElementById('testimonialAvgRating');
    
    if (totalEl) totalEl.textContent = total;
    if (pendingEl) pendingEl.textContent = pending;
    if (approvedEl) approvedEl.textContent = approved;
    if (rejectedEl) rejectedEl.textContent = rejected;
    if (avgRatingEl) avgRatingEl.textContent = avgRating;
}

function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
}

// ===== TESTIMONIAL ACTIONS =====
async function viewTestimonial(id) {
    try {
        const response = await fetch(`${API_BASE}?type=admin&collection=testimonials&id=${id}`);
        const data = await safeFetch(response);
        
        if (data.success && data.data) {
            const testimonial = data.data;
            const content = `
                <div style="padding: 20px;">
                    <h3>Testimonial Details</h3>
                    <p><strong>Parent:</strong> ${testimonial.anonymous ? 'Anonymous' : testimonial.parent_name}</p>
                    <p><strong>Student:</strong> ${testimonial.student_name}</p>
                    <p><strong>Grade:</strong> ${testimonial.grade}</p>
                    <p><strong>Years Enrolled:</strong> ${testimonial.years_enrolled}</p>
                    <p><strong>Rating:</strong> ${testimonial.rating}/5</p>
                    <p><strong>Status:</strong> ${testimonial.status}</p>
                    <p><strong>Testimonial:</strong></p>
                    <p style="background: #f5f5f5; padding: 15px; border-radius: 5px;">${testimonial.testimonial}</p>
                    ${testimonial.rejection_reason ? `<p><strong>Rejection Reason:</strong> ${testimonial.rejection_reason}</p>` : ''}
                    <p><strong>Submitted:</strong> ${formatDate(testimonial.created_at)}</p>
                </div>
            `;
            
            // Show in a modal or alert
            alert(content.replace(/<[^>]*>/g, '\n'));
        } else {
            showToast('Failed to load testimonial details', 'error');
        }
    } catch (error) {
        console.error('Error viewing testimonial:', error);
        showToast('Error loading testimonial details', 'error');
    }
}

async function approveTestimonial(id) {
    if (!confirm('Are you sure you want to approve this testimonial?')) return;
    
    try {
        const result = await apiFetch('admin', 'testimonials', 'PUT', { status: 'approved' }, id);
        
        if (result.success) {
            showToast('Testimonial approved successfully!', 'success');
            renderTestimonials();
        } else {
            showToast(result.message || 'Failed to approve testimonial', 'error');
        }
    } catch (error) {
        console.error('Error approving testimonial:', error);
        showToast('Error approving testimonial', 'error');
    }
}

async function rejectTestimonial(id) {
    const reason = prompt('Please enter the reason for rejection:');
    if (reason === null) return; // User cancelled
    
    try {
        const result = await apiFetch('admin', 'testimonials', 'PUT', { 
            status: 'rejected',
            rejection_reason: reason.trim() || ''
        }, id);
        
        if (result.success) {
            showToast('Testimonial rejected successfully!', 'success');
            renderTestimonials();
        } else {
            showToast(result.message || 'Failed to reject testimonial', 'error');
        }
    } catch (error) {
        console.error('Error rejecting testimonial:', error);
        showToast('Error rejecting testimonial', 'error');
    }
}

async function deleteTestimonial(id) {
    if (!confirm('Are you sure you want to delete this testimonial? This action cannot be undone.')) return;
    
    try {
        const response = await fetch(`${API_BASE}?type=admin&collection=testimonials&id=${id}`, {
            method: 'DELETE'
        });
        
        const data = await safeFetch(response);
        
        if (data.success) {
            showToast('Testimonial deleted successfully!', 'success');
            renderTestimonials();
        } else {
            showToast(data.message || 'Failed to delete testimonial', 'error');
        }
    } catch (error) {
        console.error('Error deleting testimonial:', error);
        showToast('Error deleting testimonial', 'error');
    }
}

function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
}

async function editAdmin(id) {
    const result = await apiFetch('admin', 'admins', 'GET', null, id);
    if (result.success && result.data) {
        const admin = result.data;
        document.getElementById('adminEditId').value = admin.id;
        document.getElementById('adminFirstName').value = admin.firstName || admin.first_name || '';
        document.getElementById('adminLastName').value = admin.lastName || admin.last_name || '';
        document.getElementById('adminUsername').value = admin.username || '';
        document.getElementById('adminEmail').value = admin.email || '';
        document.getElementById('adminPhone').value = admin.phone || '';
        document.getElementById('adminRole').value = admin.role || 'Admin';
        document.getElementById('adminPassword').value = '';
        document.getElementById('adminStatus').value = admin.status || 'Active';
        document.getElementById('adminModalTitle').innerHTML = '<i class="fas fa-user-shield"></i> Edit Admin';
        document.getElementById('adminPassword').required = false;
        document.getElementById('adminPasswordLabel').textContent = 'Password (leave blank to keep current)';
        openModal('adminModal');
    } else {
        showToast('Failed to load admin data', 'error');
    }
}

async function saveAdmin(e) {
    e.preventDefault();
    const id = document.getElementById('adminEditId').value;
    const body = {
        firstName: document.getElementById('adminFirstName').value,
        lastName: document.getElementById('adminLastName').value,
        username: document.getElementById('adminUsername').value,
        email: document.getElementById('adminEmail').value,
        phone: document.getElementById('adminPhone').value,
        role: document.getElementById('adminRole').value,
        status: document.getElementById('adminStatus').value
    };

    const password = document.getElementById('adminPassword').value;
    if (password) {
        body.password = password;
    } else if (!id) {
        showToast('Password is required for new admin', 'error');
        return false;
    }

    let result;
    if (id) {
        result = await apiFetch('admin', 'admins', 'PUT', body, id);
    } else {
        result = await apiFetch('admin', 'admins', 'POST', body);
    }

    if (result.success) {
        showToast(id ? 'Admin updated successfully' : 'Admin added successfully', 'success');
        closeModal();
        renderAdmins();
    } else {
        showToast(result.message || 'Failed to save admin', 'error');
    }
    return false;
}

async function deleteAdmin(id) {
    // Get the admin being deleted from the stored data
    const admin = adminsData.find(a => a.id === id);

    // Warning for default credentials
    if (admin && admin.username === 'admin') {
        if (!confirm('⚠️ WARNING: This admin account uses the default username "admin". Deleting this account will remove the default credentials. Are you sure you want to continue?')) {
            return;
        }
    } else {
        if (!confirm('Are you sure you want to delete this admin account?')) return;
    }

    const deleteResult = await apiFetch('admin', 'admins', 'DELETE', null, id);
    if (deleteResult.success) {
        showToast('Admin deleted successfully', 'success');
        renderAdmins();
    } else {
        showToast(deleteResult.message || 'Failed to delete admin', 'error');
    }
}

// ===== ANALYTICS =====
let analyticsCharts = {};

async function renderAnalytics() {
    // Ensure we have data
    if (!globalData.students.length && !globalData.teachers.length) {
        await updateStats();
    }

    const students = globalData.students || [];
    const teachers = globalData.teachers || [];
    const registrations = globalData.registrations || [];
    const parents = globalData.parents || [];

    // --- Summary Stats ---
    const maleCount = students.filter(s => (s.gender || '').toLowerCase() === 'male').length;
    const femaleCount = students.filter(s => (s.gender || '').toLowerCase() === 'female').length;
    const activeTeachers = teachers.filter(t => t.approved || t.approved === 1 || t.approved === '1').length;

    document.getElementById('analyticsStudentTotal').textContent = students.length;
    document.getElementById('analyticsTeacherActive').textContent = activeTeachers;
    document.getElementById('analyticsMaleCount').textContent = maleCount;
    document.getElementById('analyticsFemaleCount').textContent = femaleCount;

    // --- Destroy old charts ---
    Object.values(analyticsCharts).forEach(c => { if (c) c.destroy(); });
    analyticsCharts = {};

    // --- Gender Doughnut Chart ---
    const genderCtx = document.getElementById('genderChart').getContext('2d');
    analyticsCharts.gender = new Chart(genderCtx, {
        type: 'doughnut',
        data: {
            labels: ['Male', 'Female', 'Other/Unset'],
            datasets: [{
                data: [maleCount, femaleCount, students.length - maleCount - femaleCount],
                backgroundColor: ['#2196F3', '#E91E63', '#9E9E9E'],
                borderWidth: 2,
                borderColor: '#fff'
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { position: 'bottom' },
                title: { display: false }
            }
        }
    });

    // --- Students Per Class Bar Chart ---
    const classOrder = ['Daycare', 'Standard 1', 'Standard 2', 'Standard 3', 'Standard 4', 'Standard 5', 'Standard 6', 'Standard 7', 'Standard 8', 'Form 1', 'Form 2', 'Form 3', 'Form 4'];
    const studentsByClass = {};
    classOrder.forEach(c => studentsByClass[c] = 0);
    students.forEach(s => {
        const g = s.grade || s.class || '';
        if (studentsByClass[g] !== undefined) studentsByClass[g]++;
        else studentsByClass[g] = (studentsByClass[g] || 0) + 1;
    });
    const classLabels = classOrder.filter(c => studentsByClass[c] > 0);
    const classData = classLabels.map(c => studentsByClass[c]);

    const studentsClassCtx = document.getElementById('studentsPerClassChart').getContext('2d');
    analyticsCharts.studentsClass = new Chart(studentsClassCtx, {
        type: 'bar',
        data: {
            labels: classLabels,
            datasets: [{
                label: 'Students',
                data: classData,
                backgroundColor: '#085636',
                borderRadius: 6
            }]
        },
        options: {
            responsive: true,
            plugins: { legend: { display: false } },
            scales: {
                y: { beginAtZero: true, ticks: { stepSize: 1 } },
                x: { ticks: { font: { size: 11 } } }
            }
        }
    });

    // --- Registrations Per Class Bar Chart ---
    const regByClass = {};
    classOrder.forEach(c => regByClass[c] = 0);
    registrations.forEach(r => {
        const g = r.grade || '';
        if (regByClass[g] !== undefined) regByClass[g]++;
        else regByClass[g] = (regByClass[g] || 0) + 1;
    });
    const regLabels = classOrder.filter(c => regByClass[c] > 0);
    const regData = regLabels.map(c => regByClass[c]);

    const regCtx = document.getElementById('registrationsPerClassChart').getContext('2d');
    analyticsCharts.registrations = new Chart(regCtx, {
        type: 'bar',
        data: {
            labels: regLabels.length > 0 ? regLabels : ['No Data'],
            datasets: [{
                label: 'Registrations',
                data: regData.length > 0 ? regData : [0],
                backgroundColor: '#FF9800',
                borderRadius: 6
            }]
        },
        options: {
            responsive: true,
            plugins: { legend: { display: false } },
            scales: {
                y: { beginAtZero: true, ticks: { stepSize: 1 } },
                x: { ticks: { font: { size: 11 } } }
            }
        }
    });

    // --- Teachers Doughnut (Active vs Pending) ---
    const pendingTeachers = teachers.length - activeTeachers;
    const teacherCtx = document.getElementById('teachersChart').getContext('2d');
    analyticsCharts.teachers = new Chart(teacherCtx, {
        type: 'doughnut',
        data: {
            labels: ['Active', 'Email Not Verified'],
            datasets: [{
                data: [activeTeachers, pendingTeachers],
                backgroundColor: ['#4CAF50', '#FFC107'],
                borderWidth: 2,
                borderColor: '#fff'
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { position: 'bottom' }
            }
        }
    });

    // --- Gender by Class Stacked Bar ---
    const maleByClass = {};
    const femaleByClass = {};
    classOrder.forEach(c => { maleByClass[c] = 0; femaleByClass[c] = 0; });
    students.forEach(s => {
        const g = s.grade || s.class || '';
        const gender = (s.gender || '').toLowerCase();
        if (gender === 'male' && maleByClass[g] !== undefined) maleByClass[g]++;
        if (gender === 'female' && femaleByClass[g] !== undefined) femaleByClass[g]++;
    });
    const genderClassLabels = classOrder.filter(c => (maleByClass[c] + femaleByClass[c]) > 0);

    const genderClassCtx = document.getElementById('genderByClassChart').getContext('2d');
    analyticsCharts.genderByClass = new Chart(genderClassCtx, {
        type: 'bar',
        data: {
            labels: genderClassLabels.length > 0 ? genderClassLabels : ['No Data'],
            datasets: [
                {
                    label: 'Male',
                    data: genderClassLabels.map(c => maleByClass[c]),
                    backgroundColor: '#2196F3',
                    borderRadius: 4
                },
                {
                    label: 'Female',
                    data: genderClassLabels.map(c => femaleByClass[c]),
                    backgroundColor: '#E91E63',
                    borderRadius: 4
                }
            ]
        },
        options: {
            responsive: true,
            plugins: { legend: { position: 'top' } },
            scales: {
                y: { beginAtZero: true, stacked: true, ticks: { stepSize: 1 } },
                x: { stacked: true, ticks: { font: { size: 11 } } }
            }
        }
    });

    // --- Registration Word Cloud ---
    const wordCloudCanvas = document.getElementById('registrationWordCloud');
    if (wordCloudCanvas) {
        // Build word list from registration data
        const wordList = [];
        
        // Number registered - total registrations
        const totalRegistrations = registrations.length;
        wordList.push(['Number Registered', totalRegistrations * 4]);
        wordList.push(['Total Registrations', totalRegistrations * 3]);
        
        // Accounts created in admin
        const totalAdminAccounts = students.length + teachers.length + parents.length;
        wordList.push(['Admin Accounts', totalAdminAccounts * 3]);
        wordList.push(['Student Accounts', students.length * 2]);
        wordList.push(['Teacher Accounts', teachers.length * 2]);
        wordList.push(['Parent Accounts', parents.length * 2]);
        
        // Teacher portal registrations
        wordList.push(['Teacher Portal', teachers.length * 4]);
        wordList.push(['Active Teachers', activeTeachers * 3]);
        wordList.push(['Pending Teachers', (teachers.length - activeTeachers) * 2]);
        
        // Registration breakdown by type
        wordList.push(['Student Registrations', students.length * 2]);
        wordList.push(['Parent Registrations', parents.length * 2]);
        wordList.push(['Teacher Registrations', teachers.length * 2]);
        
        // Add class-specific enrollment data
        const classOrder = ['Daycare', 'Standard 1', 'Standard 2', 'Standard 3', 'Standard 4', 'Standard 5', 'Standard 6', 'Standard 7', 'Standard 8', 'Form 1', 'Form 2', 'Form 3', 'Form 4'];
        const studentsByClass = {};
        classOrder.forEach(c => studentsByClass[c] = 0);
        students.forEach(s => {
            const g = s.grade || s.class || '';
            if (studentsByClass[g] !== undefined) studentsByClass[g]++;
        });
        
        classOrder.forEach(className => {
            if (studentsByClass[className] > 0) {
                wordList.push([className, studentsByClass[className]]);
            }
        });

        // Render word cloud
        if (wordList.length > 0) {
            WordCloud(wordCloudCanvas, {
                list: wordList,
                gridSize: 8,
                weightFactor: function(size) {
                    return Math.max(12, size * 1.5);
                },
                fontFamily: 'Segoe UI, Tahoma, Geneva, Verdana, sans-serif',
                color: 'random-dark',
                rotateRatio: 0.3,
                backgroundColor: 'transparent',
                drawOutOfBound: false,
                shrinkToFit: true
            });
        }
    }
}

// ===== EXAM PAPERS =====
let adminExams = [];

async function renderAdminExams() {
    const tbody = document.getElementById('examsTableBody');
    if (!tbody) return;

    const result = await apiFetch('admin', 'exams', 'GET');
    adminExams = result.success ? (result.data?.items || []) : [];

    // Update badge
    const pendingCount = adminExams.filter(e => e.status === 'Pending').length;
    const badge = document.getElementById('examBadge');
    if (badge) {
        badge.textContent = pendingCount;
        badge.style.display = pendingCount > 0 ? 'inline' : 'none';
    }

    // Filter
    const filterVal = document.getElementById('examStatusFilter')?.value || '';
    const filtered = filterVal ? adminExams.filter(e => e.status === filterVal) : adminExams;

    if (filtered.length === 0) {
        tbody.innerHTML = '<tr><td colspan="9" class="text-center text-muted">No exams found.</td></tr>';
        return;
    }

    let html = '';
    filtered.forEach(e => {
        const statusColors = { 'Pending': '#f39c12', 'Approved': '#085636', 'Rejected': '#e74c3c' };
        const statusBg = { 'Pending': '#fef9e7', 'Approved': '#e8f8f5', 'Rejected': '#fdedec' };
        const color = statusColors[e.status] || '#95a5a6';
        const bg = statusBg[e.status] || '#f8f9fa';
        const fmtDate = e.createdAt ? new Date(e.createdAt).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }) : '-';
        
        html += `<tr>
            <td><strong>${e.title}</strong></td>
            <td>${e.teacherName || '-'}</td>
            <td>${e.subject || '-'}</td>
            <td>${e.className || '-'}</td>
            <td>${e.term || '-'}</td>
            <td><span style="background:${bg};color:${color};padding:3px 10px;border-radius:12px;font-size:11px;font-weight:600;">${e.status}</span></td>
            <td><a href="${e.fileUrl}" target="_blank" class="admin-btn admin-btn-sm admin-btn-info" title="View PDF"><i class="fas fa-eye"></i></a></td>
            <td>${fmtDate}</td>
            <td>
                ${e.status === 'Pending' ? `
                    <button class="admin-btn admin-btn-sm admin-btn-success" onclick="approveExam(${e.id})" title="Approve"><i class="fas fa-check"></i></button>
                    <button class="admin-btn admin-btn-sm admin-btn-danger" onclick="rejectExam(${e.id})" title="Reject"><i class="fas fa-times"></i></button>
                ` : ''}
                ${e.status === 'Approved' ? `
                    <button class="admin-btn admin-btn-sm admin-btn-primary" onclick="printExam('${e.fileUrl}')" title="Print"><i class="fas fa-print"></i></button>
                ` : ''}
                <button class="admin-btn admin-btn-sm admin-btn-danger" onclick="deleteAdminExam(${e.id})" title="Delete"><i class="fas fa-trash"></i></button>
            </td>
        </tr>`;
    });
    
    tbody.innerHTML = html;
}

async function approveExam(id) {
    if (!confirm('Approve this exam paper?')) return;
    const adminName = document.getElementById('profileViewName')?.textContent || 'Admin';
    const result = await apiFetch('admin', 'exams', 'PUT', {
        status: 'Approved',
        approvedBy: adminName,
        approvedAt: new Date().toISOString().slice(0, 19).replace('T', ' '),
        adminNotes: ''
    }, id);
    if (result.success) {
        showToast('Exam approved!', 'success');
        renderAdminExams();
    } else {
        showToast(result.message || 'Failed to approve exam', 'error');
    }
}

async function rejectExam(id) {
    const reason = prompt('Reason for rejection (optional):');
    if (reason === null) return; // cancelled
    const result = await apiFetch('admin', 'exams', 'PUT', {
        status: 'Rejected',
        adminNotes: reason || ''
    }, id);
    if (result.success) {
        showToast('Exam rejected.', 'warning');
        renderAdminExams();
    } else {
        showToast(result.message || 'Failed to reject exam', 'error');
    }
}

function printExam(fileUrl) {
    const printWindow = window.open(fileUrl, '_blank');
    if (printWindow) {
        printWindow.onload = function() {
            setTimeout(() => printWindow.print(), 500);
        };
    } else {
        showToast('Please allow popups to print the exam.', 'warning');
    }
}

async function deleteAdminExam(id) {
    if (!confirm('Delete this exam permanently?')) return;
    const result = await apiFetch('admin', 'exams', 'DELETE', null, id);
    if (result.success) {
        showToast('Exam deleted!', 'success');
        renderAdminExams();
    } else {
        showToast(result.message || 'Failed to delete exam', 'error');
    }
}

// ===== COLLABORATION API =====
async function apiCollaboration(action, params = {}, body = null) {
    let url = '../api/collaboration.php?action=' + action;
    for (const [k, v] of Object.entries(params)) url += `&${k}=${encodeURIComponent(v)}`;
    const opts = {
        method: body ? 'POST' : 'GET',
        headers: { 'Content-Type': 'application/json' }
    };
    if (body) opts.body = JSON.stringify(body);
    try {
        const res = await fetch(url, opts);
        const text = await res.text();
        if (!text || text.trim() === '') {
            return { success: false, message: 'Server returned empty response' };
        }
        try {
            return JSON.parse(text);
        } catch (parseErr) {
            return { success: false, message: 'Invalid server response' };
        }
    } catch (e) {
        return { success: false, message: e.message };
    }
}

// ===== TEACHER ASSIGNMENTS =====
async function loadTeacherAssignments() {
    const className = document.getElementById('taClassFilter')?.value || '';
    const result = await apiCollaboration('class_assignments', { class_name: className });
    if (result.success) {
        renderTeacherAssignments(result.data.items);
    } else {
        document.getElementById('teacherAssignmentsBody').innerHTML = '<tr><td colspan="6" class="text-center text-muted">Failed to load assignments.</td></tr>';
    }
}

function renderTeacherAssignments(assignments) {
    const tbody = document.getElementById('teacherAssignmentsBody');
    if (!assignments || assignments.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No teacher assignments yet.</td></tr>';
        return;
    }
    
    tbody.innerHTML = assignments.map(a => `
        <tr>
            <td>${a.teacherName}</td>
            <td>${a.className}</td>
            <td>${a.role}</td>
            <td>${a.subjectFocus || '-'}</td>
            <td>${a.assignedDate || '-'}</td>
            <td>
                <button class="admin-btn admin-btn-sm admin-btn-danger" onclick="removeTeacherAssignment(${a.id})"><i class="fas fa-trash"></i></button>
            </td>
        </tr>
    `).join('');
}

async function openTeacherAssignmentModal(preSelectedClass = '') {
    document.getElementById('teacherAssignmentModalTitle').innerHTML = '<i class="fas fa-user-tag"></i> Assign Teacher to Class';
    document.getElementById('taEditId').value = '';
    document.getElementById('teacherAssignmentForm').reset();
    
    const teachersResult = await apiFetch('admin', 'teachers', 'GET');
    if (teachersResult.success) {
        const select = document.getElementById('taTeacher');
        select.innerHTML = '<option value="">Select Teacher</option>';
        const teachers = Array.isArray(teachersResult.data) ? teachersResult.data : (teachersResult.data.items || []);
        teachers.forEach(t => {
            if (t.approved) {
                select.innerHTML += `<option value="${t.id}">${t.firstName} ${t.lastName}</option>`;
            }
        });
    }
    
    // Pre-select class if provided
    if (preSelectedClass) {
        const classSelect = document.getElementById('taClass');
        classSelect.value = preSelectedClass;
    }
    
    document.getElementById('teacherAssignmentModal').classList.add('show');
}

async function openTeacherAssignmentModalForClass(className) {
    await openTeacherAssignmentModal(className);
}

async function saveTeacherAssignment(event) {
    event.preventDefault();
    
    const teacherId = parseInt(document.getElementById('taTeacher').value);
    const className = document.getElementById('taClass').value;
    const role = document.getElementById('taRole').value;
    const subjectFocus = document.getElementById('taSubjectFocus').value;
    const assignedDate = document.getElementById('taAssignedDate').value;
    
    const result = await apiCollaboration('assign_teacher_to_class', {}, {
        teacherId: teacherId,
        className: className,
        role: role,
        subjectFocus: subjectFocus,
        assignedDate: assignedDate
    });
    
    if (result.success) {
        showToast('Teacher assigned successfully!', 'success');
        closeModal();
        loadTeacherAssignments();
        loadTeacherAssignmentsForBreakdown(); // Refresh breakdown display
    } else {
        showToast(result.message || 'Failed to assign teacher', 'error');
    }
    return false;
}

async function removeTeacherAssignment(id) {
    if (!confirm('Remove this teacher assignment?')) return;
    
    const assignment = await apiCollaboration('class_assignments', {});
    if (assignment.success) {
        const item = assignment.data.items.find(a => a.id === id);
        if (item) {
            const result = await apiCollaboration('remove_teacher_from_class', {}, {
                teacherId: item.teacherId,
                className: item.className
            });
            if (result.success) {
                showToast('Assignment removed!', 'success');
                loadTeacherAssignments();
                loadTeacherAssignmentsForBreakdown(); // Refresh breakdown display
            } else {
                showToast(result.message || 'Failed to remove assignment', 'error');
            }
        }
    }
}

// ===== COLLABORATION MONITOR =====
async function loadCollaborationMonitor() {
    const logsResult = await apiCollaboration('collaboration_logs', { limit: 50 });
    if (logsResult.success) {
        renderCollaborationLogs(logsResult.data.items);
        document.getElementById('cmTotalLogs').textContent = logsResult.data.total || 0;
    }
    
    const reportsResult = await apiCollaboration('shared_reports', {});
    if (reportsResult.success) {
        document.getElementById('cmSharedReports').textContent = reportsResult.data.total || 0;
    }
    
    const messagesResult = await apiCollaboration('teacher_messages', { limit: 1 });
    if (messagesResult.success) {
        document.getElementById('cmMessages').textContent = messagesResult.data.total || 0;
    }
    
    const resourcesResult = await apiCollaboration('shared_resources', {});
    if (resourcesResult.success) {
        document.getElementById('cmSharedResources').textContent = resourcesResult.data.total || 0;
    }
}

function renderCollaborationLogs(logs) {
    const tbody = document.getElementById('collaborationLogsBody');
    if (!logs || logs.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" class="text-center text-muted">No collaboration activity yet.</td></tr>';
        return;
    }
    
    tbody.innerHTML = logs.map(l => `
        <tr>
            <td>${l.teacherName || '-'}</td>
            <td>${l.collaboratorName || '-'}</td>
            <td>${l.activityType}</td>
            <td>${l.description || '-'}</td>
            <td>${new Date(l.createdAt).toLocaleString()}</td>
        </tr>
    `).join('');
}

// ===== SHARED REPORTS ADMIN =====
async function loadSharedReportsAdmin() {
    const className = document.getElementById('srClassFilter')?.value || '';
    const result = await apiCollaboration('shared_reports', {});
    if (result.success) {
        const filtered = className ? result.data.items.filter(r => r.className === className) : result.data.items;
        renderSharedReportsAdmin(filtered);
    }
}

function renderSharedReportsAdmin(reports) {
    const tbody = document.getElementById('sharedReportsAdminBody');
    if (!reports || reports.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted">No shared reports yet.</td></tr>';
        return;
    }
    
    tbody.innerHTML = reports.map(r => {
        return `
        <tr>
            <td>${r.reportId}</td>
            <td>${r.studentName}</td>
            <td>${r.ownerName}</td>
            <td>${r.sharedWithName}</td>
            <td><span class="badge ${r.accessLevel === 'edit' ? 'badge-success' : 'badge-info'}">${r.accessLevel}</span></td>
            <td>${r.status}</td>
            <td>
                <button class="admin-btn admin-btn-sm admin-btn-danger" onclick="revokeSharedReport(${r.id})"><i class="fas fa-times"></i> Revoke</button>
            </td>
        </tr>
        `;
    }).join('');
}

async function revokeSharedReport(id) {
    if (!confirm('Revoke access to this shared report?')) return;
    
    const result = await apiCollaboration('update_shared_report_access', {}, {
        id: id,
        status: 'Revoked'
    });
    
    if (result.success) {
        showToast('Access revoked!', 'success');
        loadSharedReportsAdmin();
    } else {
        showToast(result.message || 'Failed to revoke access', 'error');
    }
}

// ===== ADMIN CALENDAR =====
async function loadAdminCalendar() {
    const eventType = document.getElementById('acTypeFilter')?.value || '';
    const eventDate = document.getElementById('acDateFilter')?.value || '';
    
    const result = await apiCollaboration('calendar_events', { 
        target_audience: 'all',
        event_type: eventType,
        start_date: eventDate,
        end_date: eventDate
    });
    
    if (result.success) {
        renderAdminCalendar(result.data.items);
    }
}

function renderAdminCalendar(events) {
    const tbody = document.getElementById('adminCalendarBody');
    if (!events || events.length === 0) {
        tbody.innerHTML = '<tr><td colspan="9" class="text-center text-muted">No calendar events yet.</td></tr>';
        return;
    }
    
    tbody.innerHTML = events.map(e => {
        const attachmentHtml = e.attachmentPath 
            ? `<a href="${e.attachmentPath}" target="_blank" class="admin-btn admin-btn-sm admin-btn-success" style="text-decoration:none;">
                 <i class="fas fa-download"></i> ${e.attachmentName || 'Download'}
               </a>`
            : '-';
        
        return `
        <tr>
            <td>${e.title}</td>
            <td><span class="badge badge-info">${e.eventType}</span></td>
            <td>${new Date(e.eventDate).toLocaleDateString()}</td>
            <td>${e.eventTime || '-'}</td>
            <td>${e.location || '-'}</td>
            <td>${e.targetAudience}</td>
            <td>${attachmentHtml}</td>
            <td><span class="badge ${e.status === 'Active' ? 'badge-success' : 'badge-danger'}">${e.status}</span></td>
            <td>
                <button class="admin-btn admin-btn-sm admin-btn-info" onclick="editAdminCalendarEvent(${e.id})"><i class="fas fa-edit"></i></button>
                <button class="admin-btn admin-btn-sm admin-btn-danger" onclick="deleteAdminCalendarEvent(${e.id})"><i class="fas fa-trash"></i></button>
            </td>
        </tr>
    `;
    }).join('');
}

async function openAdminCalendarModal() {
    document.getElementById('adminCalendarModalTitle').innerHTML = '<i class="fas fa-calendar-plus"></i> Add Calendar Event';
    document.getElementById('acEditId').value = '';
    document.getElementById('adminCalendarForm').reset();
    document.getElementById('acExistingFileGroup').style.display = 'none';
    document.getElementById('adminCalendarModal').classList.add('show');
}

async function saveAdminCalendarEvent(event) {
    event.preventDefault();
    
    const editId = document.getElementById('acEditId').value;
    const title = document.getElementById('acTitle').value;
    const eventType = document.getElementById('acEventType').value;
    const eventDate = document.getElementById('acEventDate').value;
    const eventTime = document.getElementById('acEventTime').value;
    const endTime = document.getElementById('acEndTime').value;
    const location = document.getElementById('acLocation').value;
    const description = document.getElementById('acDescription').value;
    const targetAudience = document.getElementById('acTargetAudience').value;
    const className = document.getElementById('acClass').value;
    const status = document.getElementById('acStatus').value;
    const fileInput = document.getElementById('acFile');
    
    const action = editId ? 'update_calendar_event' : 'create_calendar_event';
    const body = {
        title: title,
        eventType: eventType,
        eventDate: eventDate,
        eventTime: eventTime,
        endTime: endTime,
        location: location,
        description: description,
        createdBy: 'Admin',
        createdById: 0,
        targetAudience: targetAudience,
        className: className,
        status: status
    };
    
    if (editId) body.id = parseInt(editId);
    
    // Handle file upload if present
    if (fileInput.files.length > 0) {
        const file = fileInput.files[0];
        const formData = new FormData();
        formData.append('file', file);
        formData.append('data', JSON.stringify(body));
        
        try {
            const response = await fetch('../api/upload_calendar_file.php', {
                method: 'POST',
                body: formData
            });
            const result = await safeFetch(response);
            
            if (result.success) {
                showToast('Calendar event saved successfully!', 'success');
                closeModal();
                loadAdminCalendar();
            } else {
                showToast(result.message || 'Failed to save event', 'error');
            }
        } catch (error) {
            showToast('Error uploading file: ' + error.message, 'error');
        }
    } else {
        const result = await apiCollaboration(action, {}, body);
        
        if (result.success) {
            showToast('Calendar event saved successfully!', 'success');
            closeModal();
            loadAdminCalendar();
        } else {
            showToast(result.message || 'Failed to save event', 'error');
        }
    }
    return false;
}

function removeCalendarFile() {
    document.getElementById('acFile').value = '';
    document.getElementById('acExistingFileGroup').style.display = 'none';
}

function editAdminCalendarEvent(eventId) {
    openAdminCalendarModal();
    document.getElementById('acEditId').value = eventId;
}

async function deleteAdminCalendarEvent(eventId) {
    if (!confirm('Delete this calendar event?')) return;
}

// ===== LIBRARY MANAGEMENT =====
async function renderLibrary() {
    const tbody = document.getElementById('libraryTableBody');
    if (!tbody) return;
    
    const result = await apiFetch('admin', 'library');
    const books = result.success ? (result.data?.items || []) : [];
    
    if (books.length === 0) {
        tbody.innerHTML = '<tr><td colspan="9" class="text-center text-muted">No books in library yet.</td></tr>';
        return;
    }
    
    tbody.innerHTML = books.map(b => {
        const statusColor = b.status === 'Available' ? 'success' : b.status === 'Borrowed' ? 'warning' : 'danger';
        return `<tr>
            <td>${b.id}</td>
            <td><strong>${b.title}</strong></td>
            <td>${b.author}</td>
            <td>${b.isbn || '-'}</td>
            <td>${b.category}</td>
            <td>${b.copies}</td>
            <td>${b.available}</td>
            <td><span class="badge badge-${statusColor}">${b.status}</span></td>
            <td>${b.borrower || '-'}</td>
            <td>${b.dueDate || '-'}</td>
            <td>
                <button class="admin-btn admin-btn-sm admin-btn-warning" onclick="editLibrary(${b.id})"><i class="fas fa-edit"></i></button>
                <button class="admin-btn admin-btn-sm admin-btn-danger" onclick="deleteLibrary(${b.id})"><i class="fas fa-trash"></i></button>
            </td>
        </tr>`;
    }).join('');
}

function openLibraryModal() {
    document.getElementById('libraryModalTitle').innerHTML = '<i class="fas fa-book"></i> Add Book';
    document.getElementById('libraryEditId').value = '';
    document.getElementById('libraryForm').reset();
    openModal('libraryModal');
}

async function editLibrary(id) {
    const result = await apiFetch('admin', 'library', 'GET', null, id);
    if (result.success && result.data) {
        const book = result.data;
        document.getElementById('libraryEditId').value = book.id;
        document.getElementById('libraryTitle').value = book.title;
        document.getElementById('libraryAuthor').value = book.author;
        document.getElementById('libraryISBN').value = book.isbn || '';
        document.getElementById('libraryPublisher').value = book.publisher || '';
        document.getElementById('libraryYear').value = book.year || '';
        document.getElementById('libraryPages').value = book.pages || '';
        document.getElementById('libraryCategory').value = book.category;
        document.getElementById('libraryLanguage').value = book.language || 'English';
        document.getElementById('libraryTags').value = book.tags || '';
        document.getElementById('libraryCopies').value = book.copies || 1;
        document.getElementById('libraryAvailable').value = book.available || book.copies || 1;
        document.getElementById('libraryLocation').value = book.location || '';
        document.getElementById('libraryStatus').value = book.status;
        document.getElementById('libraryBorrower').value = book.borrower || '';
        document.getElementById('libraryBorrowerType').value = book.borrowerType || '';
        document.getElementById('libraryBorrowedDate').value = book.borrowedDate || '';
        document.getElementById('libraryDueDate').value = book.dueDate || '';
        document.getElementById('libraryDescription').value = book.description || '';
        document.getElementById('libraryModalTitle').innerHTML = '<i class="fas fa-book"></i> Edit Book';
        openModal('libraryModal');
    }
}

async function saveLibrary(e) {
    e.preventDefault();
    const id = document.getElementById('libraryEditId').value;
    const body = {
        title: document.getElementById('libraryTitle').value,
        author: document.getElementById('libraryAuthor').value,
        isbn: document.getElementById('libraryISBN').value,
        publisher: document.getElementById('libraryPublisher').value,
        year: document.getElementById('libraryYear').value,
        pages: document.getElementById('libraryPages').value,
        category: document.getElementById('libraryCategory').value,
        language: document.getElementById('libraryLanguage').value,
        tags: document.getElementById('libraryTags').value,
        copies: document.getElementById('libraryCopies').value,
        available: document.getElementById('libraryAvailable').value,
        location: document.getElementById('libraryLocation').value,
        status: document.getElementById('libraryStatus').value,
        borrower: document.getElementById('libraryBorrower').value,
        borrowerType: document.getElementById('libraryBorrowerType').value,
        borrowedDate: document.getElementById('libraryBorrowedDate').value,
        dueDate: document.getElementById('libraryDueDate').value,
        description: document.getElementById('libraryDescription').value
    };
    
    let result;
    if (id) {
        result = await apiFetch('admin', 'library', 'PUT', body, id);
    } else {
        result = await apiFetch('admin', 'library', 'POST', body);
    }
    
    if (result.success) {
        showToast(id ? 'Book updated successfully' : 'Book added successfully', 'success');
        closeModal();
        renderLibrary();
    } else {
        showToast(result.message || 'Failed to save book', 'error');
    }
    return false;
}

async function deleteLibrary(id) {
    if (!confirm('Are you sure you want to delete this book?')) return;
    const result = await apiFetch('admin', 'library', 'DELETE', null, id);
    if (result.success) {
        showToast('Book deleted successfully', 'success');
        renderLibrary();
    } else {
        showToast(result.message || 'Failed to delete book', 'error');
    }
}

// ===== TIMETABLE MANAGEMENT =====
async function renderTimetable() {
    const tbody = document.getElementById('timetableTableBody');
    if (!tbody) return;
    
    const result = await apiFetch('admin', 'timetable');
    const schedules = result.success ? (result.data?.items || []) : [];
    
    if (schedules.length === 0) {
        tbody.innerHTML = '<tr><td colspan="10" class="text-center text-muted">No timetable entries yet.</td></tr>';
        return;
    }
    
    tbody.innerHTML = schedules.map(s => {
        return `<tr>
            <td>${s.day}</td>
            <td>${s.time}${s.endTime ? ' - ' + s.endTime : ''}</td>
            <td>${s.period || '-'}</td>
            <td>${s.className}</td>
            <td>${s.subject}</td>
            <td>${s.subjectCode || '-'}</td>
            <td>${s.teacher || '-'}</td>
            <td>${s.room || '-'}</td>
            <td>${s.building || '-'}</td>
            <td>${s.term || '-'}</td>
            <td>
                <button class="admin-btn admin-btn-sm admin-btn-warning" onclick="editTimetable(${s.id})"><i class="fas fa-edit"></i></button>
                <button class="admin-btn admin-btn-sm admin-btn-danger" onclick="deleteTimetable(${s.id})"><i class="fas fa-trash"></i></button>
            </td>
        </tr>`;
    }).join('');
}

async function openTimetableModal() {
    document.getElementById('timetableModalTitle').innerHTML = '<i class="fas fa-calendar-alt"></i> Add Schedule';
    document.getElementById('timetableEditId').value = '';
    document.getElementById('timetableForm').reset();
    
    // Load teachers into dropdown
    const teachersResult = await apiFetch('admin', 'teachers', 'GET');
    const teacherSelect = document.getElementById('timetableTeacher');
    teacherSelect.innerHTML = '<option value="">Select Teacher</option>';
    if (teachersResult.success) {
        const teachers = Array.isArray(teachersResult.data) ? teachersResult.data : (teachersResult.data.items || []);
        teachers.forEach(t => {
            if (t.approved) {
                teacherSelect.innerHTML += `<option value="${t.firstName} ${t.lastName}">${t.firstName} ${t.lastName}</option>`;
            }
        });
    }
    
    openModal('timetableModal');
}

async function editTimetable(id) {
    const result = await apiFetch('admin', 'timetable', 'GET', null, id);
    if (result.success && result.data) {
        const schedule = result.data;
        
        // Load teachers into dropdown
        const teachersResult = await apiFetch('admin', 'teachers', 'GET');
        const teacherSelect = document.getElementById('timetableTeacher');
        teacherSelect.innerHTML = '<option value="">Select Teacher</option>';
        if (teachersResult.success) {
            const teachers = Array.isArray(teachersResult.data) ? teachersResult.data : (teachersResult.data.items || []);
            teachers.forEach(t => {
                if (t.approved) {
                    teacherSelect.innerHTML += `<option value="${t.firstName} ${t.lastName}">${t.firstName} ${t.lastName}</option>`;
                }
            });
        }
        
        document.getElementById('timetableEditId').value = schedule.id;
        document.getElementById('timetableDay').value = schedule.day;
        document.getElementById('timetableTime').value = schedule.time;
        document.getElementById('timetableEndTime').value = schedule.endTime || '';
        document.getElementById('timetableDuration').value = schedule.duration || '';
        document.getElementById('timetablePeriod').value = schedule.period || '';
        document.getElementById('timetableClass').value = schedule.className;
        document.getElementById('timetableSubject').value = schedule.subject;
        document.getElementById('timetableSubjectCode').value = schedule.subjectCode || '';
        document.getElementById('timetableTeacher').value = schedule.teacher || '';
        document.getElementById('timetableRoom').value = schedule.room || '';
        document.getElementById('timetableBuilding').value = schedule.building || '';
        document.getElementById('timetableRoomType').value = schedule.roomType || 'Classroom';
        document.getElementById('timetableTerm').value = schedule.term || '';
        document.getElementById('timetableAcademicYear').value = schedule.academicYear || '';
        document.getElementById('timetableNotes').value = schedule.notes || '';
        document.getElementById('timetableRecurring').checked = schedule.recurring || false;
        document.getElementById('timetableModalTitle').innerHTML = '<i class="fas fa-calendar-alt"></i> Edit Schedule';
        openModal('timetableModal');
    }
}

async function saveTimetable(e) {
    e.preventDefault();
    const id = document.getElementById('timetableEditId').value;
    const body = {
        day: document.getElementById('timetableDay').value,
        time: document.getElementById('timetableTime').value,
        endTime: document.getElementById('timetableEndTime').value,
        duration: document.getElementById('timetableDuration').value,
        period: document.getElementById('timetablePeriod').value,
        className: document.getElementById('timetableClass').value,
        subject: document.getElementById('timetableSubject').value,
        subjectCode: document.getElementById('timetableSubjectCode').value,
        teacher: document.getElementById('timetableTeacher').value,
        room: document.getElementById('timetableRoom').value,
        building: document.getElementById('timetableBuilding').value,
        roomType: document.getElementById('timetableRoomType').value,
        term: document.getElementById('timetableTerm').value,
        academicYear: document.getElementById('timetableAcademicYear').value,
        notes: document.getElementById('timetableNotes').value,
        recurring: document.getElementById('timetableRecurring').checked
    };
    
    let result;
    if (id) {
        result = await apiFetch('admin', 'timetable', 'PUT', body, id);
    } else {
        result = await apiFetch('admin', 'timetable', 'POST', body);
    }
    
    if (result.success) {
        showToast(id ? 'Schedule updated successfully' : 'Schedule added successfully', 'success');
        closeModal();
        renderTimetable();
    } else {
        showToast(result.message || 'Failed to save schedule', 'error');
    }
    return false;
}

async function deleteTimetable(id) {
    if (!confirm('Are you sure you want to delete this schedule?')) return;
    const result = await apiFetch('admin', 'timetable', 'DELETE', null, id);
    if (result.success) {
        showToast('Schedule deleted successfully', 'success');
        renderTimetable();
    } else {
        showToast(result.message || 'Failed to delete schedule', 'error');
    }
}

async function sendTimetableToTeachers() {
    if (!confirm('Are you sure you want to send the timetable to all teachers?')) return;

    try {
        const response = await fetch('../api/index.php?type=admin&timetable_action=send_to_teachers', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({})
        });
        
        const result = await response.json();

        if (result.success) {
            showToast(`Timetable sent to ${result.data?.teachers_notified || 'all'} teachers successfully!`, 'success');
        } else {
            showToast(result.message || 'Failed to send timetable to teachers', 'error');
        }
    } catch (error) {
        console.error('Error sending timetable to teachers:', error);
        showToast('Failed to send timetable to teachers. Please try again.', 'error');
    }
}

async function uploadTimetableDocument(e) {
    e.preventDefault();

    const form = document.getElementById('timetableDocumentForm');
    const fileInput = document.getElementById('timetableDocFile');
    const files = fileInput.files;

    if (!files || files.length === 0) {
        showToast('Please select at least one file to upload', 'error');
        return false;
    }

    // Validate all files
    const allowedTypes = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'];
    const maxSize = 10 * 1024 * 1024; // 10MB

    for (let i = 0; i < files.length; i++) {
        const file = files[i];
        if (file.size > maxSize) {
            showToast(`File "${file.name}" exceeds 10MB limit`, 'error');
            return false;
        }
        if (!allowedTypes.includes(file.type)) {
            showToast(`File "${file.name}" has invalid type. Please upload PDF, DOC, DOCX, XLS, or XLSX files`, 'error');
            return false;
        }
    }

    const title = document.getElementById('timetableDocTitle').value;
    const classValue = document.getElementById('timetableDocClass').value;
    const term = document.getElementById('timetableDocTerm').value;
    const description = document.getElementById('timetableDocDescription').value;
    const target = document.getElementById('timetableDocTarget').value;

    let successCount = 0;
    let errorCount = 0;

    // Upload each file individually
    for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const formData = new FormData();
        formData.append('action', 'upload_timetable_document');
        formData.append('title', title);
        formData.append('class', classValue);
        formData.append('term', term);
        formData.append('file', file);
        formData.append('description', description);
        formData.append('target', target);

        try {
            const response = await fetch(`${API_BASE}?type=admin`, {
                method: 'POST',
                body: formData
            });

            const result = await safeFetch(response);

            if (result.success) {
                successCount++;
            } else {
                errorCount++;
                console.error(`Failed to upload ${file.name}:`, result.message);
            }
        } catch (error) {
            errorCount++;
            console.error(`Error uploading ${file.name}:`, error.message);
        }
    }

    if (successCount > 0) {
        const targetText = target === 'admins' ? 'admins' : target === 'all' ? 'teachers and admins' : 'teachers';
        showToast(`${successCount} document(s) uploaded and sent to ${targetText} successfully!${errorCount > 0 ? ` (${errorCount} failed)` : ''}`, 'success');
        form.reset();
        loadTimetableDocuments();
    } else {
        showToast('Failed to upload any documents', 'error');
    }

    return false;
}

async function loadTimetableDocuments() {
    const listContainer = document.getElementById('timetableDocumentsList');
    if (!listContainer) return;

    try {
        const result = await apiFetch('admin', 'timetable_documents');

        if (result.success && result.data?.items?.length > 0) {
            const documents = result.data.items;
            listContainer.innerHTML = documents.map(doc => `
                <div class="admin-card" style="margin-bottom: 12px; padding: 12px; border-left: 4px solid #085636;">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <div>
                            <h5 style="margin: 0 0 4px 0; color: #085636;">
                                <i class="fas fa-file"></i> ${doc.title}
                            </h5>
                            <p style="margin: 0; font-size: 12px; color: #666;">
                                ${doc.term} ${doc.class ? ' - ' + doc.class : ' - All Classes'}
                            </p>
                            <p style="margin: 2px 0 0 0; font-size: 11px; color: #666;">
                                <i class="fas fa-users"></i> Sent to: ${doc.target === 'admins' ? 'Admins' : doc.target === 'all' ? 'Teachers & Admins' : 'Teachers'}
                            </p>
                            <p style="margin: 4px 0 0 0; font-size: 11px; color: #999;">
                                Uploaded: ${new Date(doc.created_at).toLocaleDateString()}
                            </p>
                        </div>
                        <div>
                            <a href="${doc.file_url}" target="_blank" class="admin-btn admin-btn-sm admin-btn-info" style="margin-right: 4px;">
                                <i class="fas fa-download"></i> Download
                            </a>
                            <button onclick="deleteTimetableDocument(${doc.id})" class="admin-btn admin-btn-sm admin-btn-danger">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                </div>
            `).join('');
        } else {
            listContainer.innerHTML = '<p class="text-muted">No timetable documents uploaded yet.</p>';
        }
    } catch (error) {
        console.error('Error loading timetable documents:', error);
        listContainer.innerHTML = '<p class="text-muted">Error loading documents.</p>';
    }
}

async function deleteTimetableDocument(id) {
    if (!confirm('Are you sure you want to delete this timetable document?')) return;

    try {
        const result = await apiFetch('admin', 'timetable_documents', 'DELETE', null, id);

        if (result.success) {
            showToast('Timetable document deleted successfully', 'success');
            loadTimetableDocuments();
        } else {
            showToast(result.message || 'Failed to delete document', 'error');
        }
    } catch (error) {
        showToast('Error deleting document: ' + error.message, 'error');
    }
}

async function loadTeacherFiles() {
    const listContainer = document.getElementById('teacherFilesList');
    if (!listContainer) return;

    try {
        const result = await apiFetch('admin', 'teacher_files');

        if (result.success && result.data?.items?.length > 0) {
            const files = result.data.items;
            listContainer.innerHTML = files.map(file => `
                <div class="admin-card" style="margin-bottom: 12px; padding: 12px; border-left: 4px solid ${file.status === 'pending' ? '#f39c12' : '#085636'};">
                    <div style="display: flex; justify-content: space-between; align-items: start;">
                        <div style="flex: 1;">
                            <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 4px;">
                                <h5 style="margin: 0; color: #085636;">
                                    <i class="fas fa-file"></i> ${file.title}
                                </h5>
                                <span class="admin-badge" style="background: ${file.status === 'pending' ? '#f39c12' : '#085636'}; color: white; padding: 2px 8px; border-radius: 10px; font-size: 11px;">
                                    ${file.status.toUpperCase()}
                                </span>
                            </div>
                            <p style="margin: 0; font-size: 12px; color: #666;">
                                <i class="fas fa-user"></i> ${file.teacher_name} | 
                                <i class="fas fa-folder"></i> ${file.category}
                            </p>
                            <p style="margin: 2px 0 0 0; font-size: 11px; color: #666;">
                                <i class="fas fa-file"></i> ${file.file_name} (${(file.file_size / 1024).toFixed(1)} KB)
                            </p>
                            ${file.description ? `<p style="margin: 4px 0 0 0; font-size: 11px; color: #999;">${file.description}</p>` : ''}
                            <p style="margin: 4px 0 0 0; font-size: 11px; color: #999;">
                                <i class="fas fa-clock"></i> ${new Date(file.created_at).toLocaleString()}
                            </p>
                            ${file.admin_notes ? `<p style="margin: 4px 0 0 0; font-size: 11px; color: #666;"><strong>Admin Notes:</strong> ${file.admin_notes}</p>` : ''}
                        </div>
                        <div style="display: flex; flex-direction: column; gap: 4px; align-items: flex-end;">
                            <a href="${file.file_url}" target="_blank" class="admin-btn admin-btn-sm admin-btn-info">
                                <i class="fas fa-download"></i> Download
                            </a>
                            ${file.status === 'pending' ? `
                                <button onclick="updateTeacherFileStatus(${file.id}, 'approved')" class="admin-btn admin-btn-sm admin-btn-primary">
                                    <i class="fas fa-check"></i> Approve
                                </button>
                                <button onclick="openTeacherFileNotes(${file.id})" class="admin-btn admin-btn-sm admin-btn-warning">
                                    <i class="fas fa-comment"></i> Add Notes
                                </button>
                            ` : ''}
                            <button onclick="deleteTeacherFile(${file.id})" class="admin-btn admin-btn-sm admin-btn-danger">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                </div>
            `).join('');
        } else {
            listContainer.innerHTML = '<p class="text-muted">No files uploaded by teachers yet.</p>';
        }
    } catch (error) {
        console.error('Error loading teacher files:', error);
        listContainer.innerHTML = '<p class="text-muted">Error loading teacher files.</p>';
    }
}

async function updateTeacherFileStatus(fileId, status) {
    try {
        const result = await apiFetch('admin', 'teacher_files', 'PUT', { status }, fileId);
        
        if (result.success) {
            showToast(`File ${status} successfully`, 'success');
            loadTeacherFiles();
        } else {
            showToast(result.message || 'Failed to update file status', 'error');
        }
    } catch (error) {
        showToast('Error updating file status: ' + error.message, 'error');
    }
}

async function openTeacherFileNotes(fileId) {
    const notes = prompt('Enter admin notes for this file:');
    if (notes === null) return; // User cancelled
    
    try {
        const result = await apiFetch('admin', 'teacher_files', 'PUT', { admin_notes: notes }, fileId);
        
        if (result.success) {
            showToast('Notes added successfully', 'success');
            loadTeacherFiles();
        } else {
            showToast(result.message || 'Failed to add notes', 'error');
        }
    } catch (error) {
        showToast('Error adding notes: ' + error.message, 'error');
    }
}

async function deleteTeacherFile(fileId) {
    if (!confirm('Are you sure you want to delete this file?')) return;
    
    try {
        const result = await apiFetch('admin', 'teacher_files', 'DELETE', null, fileId);
        
        if (result.success) {
            showToast('File deleted successfully', 'success');
            loadTeacherFiles();
        } else {
            showToast(result.message || 'Failed to delete file', 'error');
        }
    } catch (error) {
        showToast('Error deleting file: ' + error.message, 'error');
    }
}

function printTimetable() {
    window.print();
}

// ===== SPORTS & ACTIVITIES MANAGEMENT =====
async function renderSports() {
    const tbody = document.getElementById('sportsTableBody');
    if (!tbody) return;
    
    const result = await apiFetch('admin', 'sports');
    const activities = result.success ? (result.data?.items || []) : [];
    
    if (activities.length === 0) {
        tbody.innerHTML = '<tr><td colspan="9" class="text-center text-muted">No activities yet.</td></tr>';
        return;
    }
    
    tbody.innerHTML = activities.map(a => {
        const statusColor = a.status === 'Active' ? 'success' : 'danger';
        return `<tr>
            <td>${a.id}</td>
            <td><strong>${a.name}</strong></td>
            <td>${a.type}</td>
            <td>${a.subCategory || '-'}</td>
            <td>${a.day}</td>
            <td>${a.time}${a.endTime ? ' - ' + a.endTime : ''}</td>
            <td>${a.instructor || '-'}</td>
            <td>${a.location || '-'}</td>
            <td>${a.participants || 0}/${a.maxParticipants || '-'}</td>
            <td><span class="badge badge-${statusColor}">${a.status}</span></td>
            <td>
                <button class="admin-btn admin-btn-sm admin-btn-warning" onclick="editSports(${a.id})"><i class="fas fa-edit"></i></button>
                <button class="admin-btn admin-btn-sm admin-btn-danger" onclick="deleteSports(${a.id})"><i class="fas fa-trash"></i></button>
            </td>
        </tr>`;
    }).join('');
}

function openSportsModal() {
    document.getElementById('sportsModalTitle').innerHTML = '<i class="fas fa-futbol"></i> Add Activity';
    document.getElementById('sportsEditId').value = '';
    document.getElementById('sportsForm').reset();
    document.getElementById('sportsFeeAmountGroup').style.display = 'none';
    openModal('sportsModal');
    
    // Add event listener for fee requirement toggle
    document.getElementById('sportsFeeRequired').addEventListener('change', function() {
        document.getElementById('sportsFeeAmountGroup').style.display = this.value === 'Yes' ? 'block' : 'none';
    });
}

async function editSports(id) {
    const result = await apiFetch('admin', 'sports', 'GET', null, id);
    if (result.success && result.data) {
        const activity = result.data;
        document.getElementById('sportsEditId').value = activity.id;
        document.getElementById('sportsName').value = activity.name;
        document.getElementById('sportsType').value = activity.type;
        document.getElementById('sportsSubCategory').value = activity.subCategory || '';
        document.getElementById('sportsDescription').value = activity.description || '';
        document.getElementById('sportsDay').value = activity.day;
        document.getElementById('sportsTime').value = activity.time;
        document.getElementById('sportsEndTime').value = activity.endTime || '';
        document.getElementById('sportsDuration').value = activity.duration || '';
        document.getElementById('sportsStartDate').value = activity.startDate || '';
        document.getElementById('sportsEndDate').value = activity.endDate || '';
        document.getElementById('sportsInstructor').value = activity.instructor || '';
        document.getElementById('sportsInstructorPhone').value = activity.instructorPhone || '';
        document.getElementById('sportsInstructorEmail').value = activity.instructorEmail || '';
        document.getElementById('sportsLocation').value = activity.location || '';
        document.getElementById('sportsMinParticipants').value = activity.minParticipants || '';
        document.getElementById('sportsMaxParticipants').value = activity.maxParticipants || '';
        document.getElementById('sportsTargetGroup').value = activity.targetGroup || '';
        document.getElementById('sportsFeeRequired').value = activity.feeRequired || 'No';
        document.getElementById('sportsFeeAmount').value = activity.feeAmount || '';
        document.getElementById('sportsEquipment').value = activity.equipment || '';
        document.getElementById('sportsRequirements').value = activity.requirements || '';
        document.getElementById('sportsStatus').value = activity.status;
        document.getElementById('sportsCurrentParticipants').value = activity.participants || 0;
        document.getElementById('sportsModalTitle').innerHTML = '<i class="fas fa-futbol"></i> Edit Activity';
        openModal('sportsModal');
    }
}

async function saveSports(e) {
    e.preventDefault();
    const id = document.getElementById('sportsEditId').value;
    const body = {
        name: document.getElementById('sportsName').value,
        type: document.getElementById('sportsType').value,
        subCategory: document.getElementById('sportsSubCategory').value,
        description: document.getElementById('sportsDescription').value,
        day: document.getElementById('sportsDay').value,
        time: document.getElementById('sportsTime').value,
        endTime: document.getElementById('sportsEndTime').value,
        duration: document.getElementById('sportsDuration').value,
        startDate: document.getElementById('sportsStartDate').value,
        endDate: document.getElementById('sportsEndDate').value,
        instructor: document.getElementById('sportsInstructor').value,
        instructorPhone: document.getElementById('sportsInstructorPhone').value,
        instructorEmail: document.getElementById('sportsInstructorEmail').value,
        location: document.getElementById('sportsLocation').value,
        minParticipants: document.getElementById('sportsMinParticipants').value,
        maxParticipants: document.getElementById('sportsMaxParticipants').value,
        targetGroup: document.getElementById('sportsTargetGroup').value,
        feeRequired: document.getElementById('sportsFeeRequired').value,
        feeAmount: document.getElementById('sportsFeeAmount').value,
        equipment: document.getElementById('sportsEquipment').value,
        requirements: document.getElementById('sportsRequirements').value,
        status: document.getElementById('sportsStatus').value,
        currentParticipants: document.getElementById('sportsCurrentParticipants').value
    };
    
    let result;
    if (id) {
        result = await apiFetch('admin', 'sports', 'PUT', body, id);
    } else {
        result = await apiFetch('admin', 'sports', 'POST', body);
    }
    
    if (result.success) {
        showToast(id ? 'Activity updated successfully' : 'Activity added successfully', 'success');
        closeModal();
        renderSports();
    } else {
        showToast(result.message || 'Failed to save activity', 'error');
    }
    return false;
}

async function deleteSports(id) {
    if (!confirm('Are you sure you want to delete this activity?')) return;
    const result = await apiFetch('admin', 'sports', 'DELETE', null, id);
    if (result.success) {
        showToast('Activity deleted successfully', 'success');
        renderSports();
    } else {
        showToast(result.message || 'Failed to delete activity', 'error');
    }
}

// ===== TRANSPORT MANAGEMENT =====
async function renderTransport() {
    const tbody = document.getElementById('transportTableBody');
    if (!tbody) return;
    
    const result = await apiFetch('admin', 'transport');
    const vehicles = result.success ? (result.data?.items || []) : [];
    
    if (vehicles.length === 0) {
        tbody.innerHTML = '<tr><td colspan="9" class="text-center text-muted">No vehicles added yet.</td></tr>';
        return;
    }
    
    tbody.innerHTML = vehicles.map(v => {
        const statusColor = v.status === 'Active' ? 'success' : v.status === 'Inactive' ? 'danger' : 'warning';
        return `<tr>
            <td>${v.id}</td>
            <td><strong>${v.vehicleNumber}</strong></td>
            <td>${v.vehicleType || 'Bus'}</td>
            <td>${v.driverName}</td>
            <td>${v.driverPhone}</td>
            <td>${v.route}</td>
            <td>${v.capacity}</td>
            <td>${v.assignedStudents || 0}</td>
            <td><span class="badge badge-${statusColor}">${v.status}</span></td>
            <td>
                <button class="admin-btn admin-btn-sm admin-btn-warning" onclick="editTransport(${v.id})"><i class="fas fa-edit"></i></button>
                <button class="admin-btn admin-btn-sm admin-btn-danger" onclick="deleteTransport(${v.id})"><i class="fas fa-trash"></i></button>
            </td>
        </tr>`;
    }).join('');
}

function openTransportModal() {
    document.getElementById('transportModalTitle').innerHTML = '<i class="fas fa-bus"></i> Add Vehicle';
    document.getElementById('transportEditId').value = '';
    document.getElementById('transportForm').reset();
    openModal('transportModal');
}

async function editTransport(id) {
    const result = await apiFetch('admin', 'transport', 'GET', null, id);
    if (result.success && result.data) {
        const vehicle = result.data;
        document.getElementById('transportEditId').value = vehicle.id;
        document.getElementById('transportVehicleNumber').value = vehicle.vehicleNumber;
        document.getElementById('transportVehicleType').value = vehicle.vehicleType || 'Bus';
        document.getElementById('transportMakeModel').value = vehicle.makeModel || '';
        document.getElementById('transportYear').value = vehicle.year || '';
        document.getElementById('transportColor').value = vehicle.color || '';
        document.getElementById('transportDriverName').value = vehicle.driverName;
        document.getElementById('transportDriverPhone').value = vehicle.driverPhone;
        document.getElementById('transportDriverLicense').value = vehicle.driverLicense || '';
        document.getElementById('transportDriverAddress').value = vehicle.driverAddress || '';
        document.getElementById('transportRoute').value = vehicle.route;
        document.getElementById('transportRouteDetails').value = vehicle.routeDetails || '';
        document.getElementById('transportMorningTime').value = vehicle.morningTime || '';
        document.getElementById('transportAfternoonTime').value = vehicle.afternoonTime || '';
        document.getElementById('transportCapacity').value = vehicle.capacity;
        document.getElementById('transportAssignedStudents').value = vehicle.assignedStudents || 0;
        document.getElementById('transportAssignedClasses').value = vehicle.assignedClasses || '';
        document.getElementById('transportStatus').value = vehicle.status;
        document.getElementById('transportLastService').value = vehicle.lastService || '';
        document.getElementById('transportNextService').value = vehicle.nextService || '';
        document.getElementById('transportInsuranceExpiry').value = vehicle.insuranceExpiry || '';
        document.getElementById('transportMaintenanceNotes').value = vehicle.maintenanceNotes || '';
        document.getElementById('transportFuelType').value = vehicle.fuelType || 'Diesel';
        document.getElementById('transportEmergencyContact').value = vehicle.emergencyContact || '';
        document.getElementById('transportNotes').value = vehicle.notes || '';
        document.getElementById('transportModalTitle').innerHTML = '<i class="fas fa-bus"></i> Edit Vehicle';
        openModal('transportModal');
    }
}

async function saveTransport(e) {
    e.preventDefault();
    const id = document.getElementById('transportEditId').value;
    const body = {
        vehicleNumber: document.getElementById('transportVehicleNumber').value,
        vehicleType: document.getElementById('transportVehicleType').value,
        makeModel: document.getElementById('transportMakeModel').value,
        year: document.getElementById('transportYear').value,
        color: document.getElementById('transportColor').value,
        driverName: document.getElementById('transportDriverName').value,
        driverPhone: document.getElementById('transportDriverPhone').value,
        driverLicense: document.getElementById('transportDriverLicense').value,
        driverAddress: document.getElementById('transportDriverAddress').value,
        route: document.getElementById('transportRoute').value,
        routeDetails: document.getElementById('transportRouteDetails').value,
        morningTime: document.getElementById('transportMorningTime').value,
        afternoonTime: document.getElementById('transportAfternoonTime').value,
        capacity: document.getElementById('transportCapacity').value,
        assignedStudents: document.getElementById('transportAssignedStudents').value,
        assignedClasses: document.getElementById('transportAssignedClasses').value,
        status: document.getElementById('transportStatus').value,
        lastService: document.getElementById('transportLastService').value,
        nextService: document.getElementById('transportNextService').value,
        insuranceExpiry: document.getElementById('transportInsuranceExpiry').value,
        maintenanceNotes: document.getElementById('transportMaintenanceNotes').value,
        fuelType: document.getElementById('transportFuelType').value,
        emergencyContact: document.getElementById('transportEmergencyContact').value,
        notes: document.getElementById('transportNotes').value
    };
    
    let result;
    if (id) {
        result = await apiFetch('admin', 'transport', 'PUT', body, id);
    } else {
        result = await apiFetch('admin', 'transport', 'POST', body);
    }
    
    if (result.success) {
        showToast(id ? 'Vehicle updated successfully' : 'Vehicle added successfully', 'success');
        closeModal();
        renderTransport();
    } else {
        showToast(result.message || 'Failed to save vehicle', 'error');
    }
    return false;
}

async function deleteTransport(id) {
    if (!confirm('Are you sure you want to delete this vehicle?')) return;
    const result = await apiFetch('admin', 'transport', 'DELETE', null, id);
    if (result.success) {
        showToast('Vehicle deleted successfully', 'success');
        renderTransport();
    } else {
        showToast(result.message || 'Failed to delete vehicle', 'error');
    }
}

// ===== NOTIFICATIONS =====
async function renderNotifications() {
    const result = await apiFetch('admin', 'activity');
    const activities = result.success ? (result.data?.items || []) : [];
    
    // Also fetch related data for notifications
    const [messages, registrations, payments, applications, announcements, events] = await Promise.all([
        apiFetch('admin', 'messages'),
        apiFetch('admin', 'registrations'),
        apiFetch('admin', 'payments'),
        apiFetch('admin', 'jobapplications'),
        apiFetch('admin', 'announcements'),
        apiFetch('admin', 'events')
    ]);
    
    const msgs = messages.success ? (messages.data?.items || []) : [];
    const regs = registrations.success ? (registrations.data?.items || []) : [];
    const pays = payments.success ? (payments.data?.items || []) : [];
    const apps = applications.success ? (applications.data?.items || []) : [];
    const anns = announcements.success ? (announcements.data?.items || []) : [];
    const evts = events.success ? (events.data?.items || []) : [];
    
    // Build comprehensive notification list
    const notifications = buildNotifications(activities, msgs, regs, pays, apps, anns, evts);
    
    // Update summary counts
    updateNotificationCounts(notifications);
    
    // Apply filters
    const categoryFilter = document.getElementById('notifCategoryFilter')?.value || '';
    const typeFilter = document.getElementById('notifTypeFilter')?.value || '';
    const timeFilter = document.getElementById('notifTimeFilter')?.value || '';
    
    let filtered = notifications;
    
    if (categoryFilter) {
        filtered = filtered.filter(n => n.category === categoryFilter);
    }
    
    if (typeFilter) {
        filtered = filtered.filter(n => n.type === typeFilter);
    }
    
    if (timeFilter) {
        const now = new Date();
        filtered = filtered.filter(n => {
            const notifDate = new Date(n.createdAt);
            if (timeFilter === 'today') {
                return notifDate.toDateString() === now.toDateString();
            } else if (timeFilter === 'week') {
                const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
                return notifDate >= weekAgo;
            } else if (timeFilter === 'month') {
                const monthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
                return notifDate >= monthAgo;
            }
            return true;
        });
    }
    
    // Render notifications
    const container = document.getElementById('notificationList');
    if (filtered.length === 0) {
        container.innerHTML = '<div class="text-center text-muted" style="padding:40px;">No notifications found.</div>';
        return;
    }
    
    container.innerHTML = filtered.map(n => renderNotificationItem(n)).join('');
}

function buildNotifications(activities, messages, registrations, payments, applications, announcements, events) {
    const notifications = [];
    
    // Process activity log
    activities.forEach(a => {
        const category = categorizeActivity(a.action);
        notifications.push({
            id: `activity-${a.id}`,
            type: getActivityType(a.action),
            category: category,
            icon: getNotificationIcon(category, a.action),
            title: a.action,
            detail: a.detail || '',
            createdAt: a.created_at,
            source: 'activity'
        });
    });
    
    // Process unread messages
    messages.filter(m => !m.read).forEach(m => {
        notifications.push({
            id: `message-${m.id}`,
            type: 'message',
            category: 'messages',
            icon: 'fa-envelope',
            title: 'New Message',
            detail: `${m.name}: ${m.subject || 'No subject'}`,
            createdAt: m.createdAt,
            source: 'message',
            actionId: m.id
        });
    });
    
    // Process pending registrations
    registrations.filter(r => r.status === 'Pending').forEach(r => {
        notifications.push({
            id: `registration-${r.id}`,
            type: 'registration',
            category: 'users',
            icon: 'fa-user-plus',
            title: 'New Student Registration',
            detail: `${r.studentName} - ${r.grade || 'No grade'}`,
            createdAt: r.createdAt,
            source: 'registration',
            actionId: r.id
        });
    });
    
    // Process recent payments
    payments.filter(p => p.status === 'Paid').slice(0, 10).forEach(p => {
        notifications.push({
            id: `payment-${p.id}`,
            type: 'payment',
            category: 'payments',
            icon: 'fa-money-bill-wave',
            title: 'Payment Received',
            detail: `${p.payerName} - MK${parseFloat(p.amount || 0).toLocaleString()}`,
            createdAt: p.createdAt,
            source: 'payment',
            actionId: p.id
        });
    });
    
    // Process pending applications
    applications.filter(a => a.status === 'Pending').forEach(a => {
        notifications.push({
            id: `application-${a.id}`,
            type: 'application',
            category: 'applications',
            icon: 'fa-file-signature',
            title: 'New Job Application',
            detail: `${a.applicantName} - ${a.position || 'No position'}`,
            createdAt: a.appliedDate,
            source: 'application',
            actionId: a.id
        });
    });
    
    // Process published announcements
    announcements.filter(a => a.status === 'Published').slice(0, 5).forEach(a => {
        notifications.push({
            id: `announcement-${a.id}`,
            type: 'announcement',
            category: 'events',
            icon: 'fa-bullhorn',
            title: 'Announcement Published',
            detail: a.title || 'No title',
            createdAt: a.createdAt,
            source: 'announcement',
            actionId: a.id
        });
    });
    
    // Process upcoming events
    events.filter(e => e.status === 'Upcoming').slice(0, 5).forEach(e => {
        notifications.push({
            id: `event-${e.id}`,
            type: 'event',
            category: 'events',
            icon: 'fa-calendar-alt',
            title: 'Upcoming Event',
            detail: e.title || 'No title',
            createdAt: e.eventDate || e.createdAt,
            source: 'event',
            actionId: e.id
        });
    });
    
    // Sort by date (newest first)
    notifications.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    
    return notifications;
}

function categorizeActivity(action) {
    const actionLower = action.toLowerCase();
    
    if (actionLower.includes('registration') || actionLower.includes('student') || actionLower.includes('teacher') || actionLower.includes('parent') || actionLower.includes('login')) {
        return 'users';
    }
    if (actionLower.includes('payment')) {
        return 'payments';
    }
    if (actionLower.includes('message')) {
        return 'messages';
    }
    if (actionLower.includes('application') || actionLower.includes('vacancie')) {
        return 'applications';
    }
    if (actionLower.includes('event') || actionLower.includes('announcement')) {
        return 'events';
    }
    if (actionLower.includes('report') || actionLower.includes('exam')) {
        return 'reports';
    }
    
    return 'system';
}

function getActivityType(action) {
    const actionLower = action.toLowerCase();
    
    if (actionLower.includes('registration')) return 'registration';
    if (actionLower.includes('login')) return 'login';
    if (actionLower.includes('payment')) return 'payment';
    if (actionLower.includes('message')) return 'message';
    if (actionLower.includes('application')) return 'application';
    if (actionLower.includes('event')) return 'event';
    if (actionLower.includes('announcement')) return 'announcement';
    if (actionLower.includes('report')) return 'report';
    if (actionLower.includes('exam')) return 'exam';
    
    return 'system';
}

function getNotificationIcon(category, action) {
    const actionLower = action ? action.toLowerCase() : '';
    
    if (category === 'users') {
        if (actionLower.includes('login')) return 'fa-sign-in-alt';
        if (actionLower.includes('registration')) return 'fa-user-plus';
        if (actionLower.includes('teacher')) return 'fa-chalkboard-teacher';
        if (actionLower.includes('parent')) return 'fa-user-tie';
        return 'fa-user';
    }
    if (category === 'payments') return 'fa-money-bill-wave';
    if (category === 'messages') return 'fa-envelope';
    if (category === 'applications') return 'fa-file-signature';
    if (category === 'events') {
        if (actionLower.includes('announcement')) return 'fa-bullhorn';
        return 'fa-calendar-alt';
    }
    if (category === 'reports') return 'fa-folder-open';
    
    return 'fa-bell';
}

function renderNotificationItem(notification) {
    const timeAgo = getTimeAgo(notification.createdAt);
    const categoryColors = {
        'users': '#085636',
        'payments': '#f39c12',
        'messages': '#3498db',
        'applications': '#9b59b6',
        'events': '#e67e22',
        'reports': '#e74c3c',
        'system': '#95a5a6'
    };
    const color = categoryColors[notification.category] || '#95a5a6';
    
    return `
        <div class="notification-item" data-category="${notification.category}" data-type="${notification.type}">
            <div class="notification-icon" style="background-color: ${color}20; color: ${color};">
                <i class="fas ${notification.icon}"></i>
            </div>
            <div class="notification-content">
                <div class="notification-header">
                    <span class="notification-title">${notification.title}</span>
                    <span class="notification-time">${timeAgo}</span>
                </div>
                <div class="notification-detail">${notification.detail}</div>
                <div class="notification-meta">
                    <span class="notification-category">${getCategoryLabel(notification.category)}</span>
                </div>
            </div>
            ${notification.actionId ? `
                <div class="notification-actions">
                    <button class="admin-btn admin-btn-sm admin-btn-primary" onclick="handleNotificationAction('${notification.source}', ${notification.actionId})">
                        <i class="fas fa-eye"></i> View
                    </button>
                </div>
            ` : ''}
        </div>
    `;
}

function getCategoryLabel(category) {
    const labels = {
        'users': '👤 User',
        'payments': '💳 Payment',
        'messages': '💬 Message',
        'applications': '📝 Application',
        'events': '📅 Event',
        'reports': '📂 Report',
        'system': '⚙️ System'
    };
    return labels[category] || '📢 Notification';
}

function getTimeAgo(dateString) {
    const now = new Date();
    const date = new Date(dateString);
    const seconds = Math.floor((now - date) / 1000);
    
    if (seconds < 60) return 'Just now';
    if (seconds < 3600) return Math.floor(seconds / 60) + ' min ago';
    if (seconds < 86400) return Math.floor(seconds / 3600) + ' hours ago';
    if (seconds < 604800) return Math.floor(seconds / 86400) + ' days ago';
    
    return formatDate(dateString);
}

function updateNotificationCounts(notifications) {
    const counts = {
        users: notifications.filter(n => n.category === 'users' || n.source_type === 'users').length,
        payments: notifications.filter(n => n.category === 'payments' || n.source_type === 'payments').length,
        messages: notifications.filter(n => n.category === 'messages' || n.source_type === 'messages').length,
        applications: notifications.filter(n => n.category === 'applications' || n.source_type === 'applications' || n.type === 'vacancy').length,
        events: notifications.filter(n => n.category === 'events' || n.source_type === 'events').length,
        reports: notifications.filter(n => n.category === 'reports' || n.source_type === 'reports').length
    };
    
    document.getElementById('notifUserCount').textContent = counts.users;
    document.getElementById('notifPaymentCount').textContent = counts.payments;
    document.getElementById('notifMessageCount').textContent = counts.messages;
    document.getElementById('notifApplicationCount').textContent = counts.applications;
    document.getElementById('notifEventCount').textContent = counts.events;
    document.getElementById('notifReportCount').textContent = counts.reports;
    
    // Update sidebar badge
    const totalUnread = notifications.length;
    const badge = document.getElementById('notifBadge');
    if (badge) {
        badge.textContent = totalUnread;
        badge.style.display = totalUnread > 0 ? 'inline' : 'none';
    }
}

function handleNotificationAction(source, id) {
    switch(source) {
        case 'message':
            viewMessage(id);
            break;
        case 'registration':
            showSection('registrations');
            break;
        case 'payment':
            showSection('payments');
            break;
        case 'application':
            showSection('jobapplications');
            break;
        case 'announcement':
            showSection('announcements');
            break;
        case 'event':
            showSection('events');
            break;
        default:
            showSection('activity');
    }
}

function markAllNotificationsRead() {
    showToast('All notifications marked as read', 'success');
    // In a real implementation, this would update the database
    renderNotifications();
}

// ===== CLASS BREAKDOWN =====
async function loadAdvancedClassBreakdown() {
    const container = document.getElementById('classBreakdownContainer');
    if (!container) return;
    
    container.innerHTML = '<div class="text-center" style="padding:40px;"><i class="fas fa-spinner fa-spin" style="font-size:24px;"></i><p style="margin-top:12px;">Loading class breakdown...</p></div>';
    
    try {
        const studentsResult = await apiFetch('admin', 'students');
        const teachersResult = await apiFetch('admin', 'teachers');
        const paymentsResult = await apiFetch('admin', 'payments');
        const attendanceResult = await apiFetch('admin', 'attendance');
        
        const students = studentsResult.success ? (studentsResult.data?.items || []) : [];
        const teachers = teachersResult.success ? (teachersResult.data?.items || []) : [];
        const payments = paymentsResult.success ? (paymentsResult.data?.items || []) : [];
        const attendance = attendanceResult.success ? (attendanceResult.data?.items || []) : [];
        
        // Group students by class
        const classData = {};
        const allGrades = ['Daycare', 'Standard 1', 'Standard 2', 'Standard 3', 'Standard 4', 'Standard 5', 'Standard 6', 'Standard 7', 'Standard 8', 'Form 1', 'Form 2', 'Form 3', 'Form 4'];
        
        allGrades.forEach(grade => {
            classData[grade] = {
                grade,
                male: 0,
                female: 0,
                total: 0,
                students: [],
                teachers: [],
                feePaid: 0,
                feePending: 0,
                attendanceRate: 0,
                presentCount: 0,
                absentCount: 0
            };
        });
        
        students.forEach(s => {
            const grade = s.grade || 'Unassigned';
            if (!classData[grade]) {
                classData[grade] = {
                    grade,
                    male: 0,
                    female: 0,
                    total: 0,
                    students: [],
                    teachers: [],
                    feePaid: 0,
                    feePending: 0,
                    attendanceRate: 0,
                    presentCount: 0,
                    absentCount: 0
                };
            }
            classData[grade].total++;
            classData[grade].students.push(s);
            if (s.gender === 'Male') classData[grade].male++;
            else if (s.gender === 'Female') classData[grade].female++;
        });
        
        // Assign teachers to classes
        teachers.forEach(t => {
            if (t.classAssigned && classData[t.classAssigned]) {
                classData[t.classAssigned].teachers.push(t);
            }
        });
        
        // Calculate fee status per class
        payments.filter(p => p.status === 'Paid').forEach(p => {
            const student = students.find(s => s.id === p.studentId);
            if (student && classData[student.grade]) {
                classData[student.grade].feePaid++;
            }
        });
        
        payments.filter(p => p.status === 'Pending').forEach(p => {
            const student = students.find(s => s.id === p.studentId);
            if (student && classData[student.grade]) {
                classData[student.grade].feePending++;
            }
        });
        
        // Calculate attendance per class
        attendance.forEach(a => {
            const student = students.find(s => s.id === a.studentId);
            if (student && classData[student.grade]) {
                if (a.status === 'Present') classData[student.grade].presentCount++;
                else if (a.status === 'Absent') classData[student.grade].absentCount++;
            }
        });
        
        // Calculate attendance rates
        Object.keys(classData).forEach(grade => {
            const totalAttended = classData[grade].presentCount + classData[grade].absentCount;
            if (totalAttended > 0) {
                classData[grade].attendanceRate = Math.round((classData[grade].presentCount / totalAttended) * 100);
            }
        });
        
        // Render class breakdown cards
        let classesWithStudents = Object.values(classData).filter(c => c.total > 0);
        
        // Apply sorting
        const sortBy = document.getElementById('cbSortBy')?.value || 'grade';
        classesWithStudents = sortAdvancedClassBreakdown(classesWithStudents, sortBy);
        
        if (classesWithStudents.length === 0) {
            container.innerHTML = `
                <div class="class-breakdown-empty">
                    <i class="fas fa-users"></i>
                    <p>No students enrolled yet. Add students to see class breakdown.</p>
                </div>
            `;
            return;
        }
        
        // Apply view mode
        const viewMode = document.getElementById('cbViewMode')?.value || 'cards';
        if (viewMode === 'table') {
            container.innerHTML = renderClassBreakdownTable(classesWithStudents);
        } else {
            container.innerHTML = `
                <div class="class-breakdown-grid">
                    ${classesWithStudents.map(cls => renderAdvancedClassBreakdownCard(cls)).join('')}
                </div>
            `;
        }
        
    } catch (error) {
        console.error('Error loading class breakdown:', error);
        container.innerHTML = `
            <div class="class-breakdown-empty">
                <i class="fas fa-exclamation-triangle"></i>
                <p>Error loading class breakdown. Please try again.</p>
            </div>
        `;
    }
}

function sortAdvancedClassBreakdown(classes, sortBy) {
    const sorted = [...classes];
    switch (sortBy) {
        case 'total':
            sorted.sort((a, b) => b.total - a.total);
            break;
        case 'male':
            sorted.sort((a, b) => b.male - a.male);
            break;
        case 'female':
            sorted.sort((a, b) => b.female - a.female);
            break;
        case 'attendance':
            sorted.sort((a, b) => b.attendanceRate - a.attendanceRate);
            break;
        case 'fees':
            sorted.sort((a, b) => {
                const aRate = a.feePaid + a.feePending > 0 ? a.feePaid / (a.feePaid + a.feePending) : 0;
                const bRate = b.feePaid + b.feePending > 0 ? b.feePaid / (b.feePaid + b.feePending) : 0;
                return bRate - aRate;
            });
            break;
        default:
            // Sort by grade (alphabetical)
            sorted.sort((a, b) => a.grade.localeCompare(b.grade));
    }
    return sorted;
}

function renderClassBreakdownTable(classes) {
    return `
        <div class="table-responsive">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Class</th>
                        <th>Male</th>
                        <th>Female</th>
                        <th>Total</th>
                        <th>Teachers</th>
                        <th>Fee Status</th>
                        <th>Attendance</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    ${classes.map(cls => {
                        const feeTotal = cls.feePaid + cls.feePending;
                        const feePercent = feeTotal > 0 ? Math.round((cls.feePaid / feeTotal) * 100) : 0;
                        const teacherNames = cls.teachers.map(t => `${t.firstName} ${t.lastName}`).join(', ') || 'None';
                        
                        return `
                            <tr>
                                <td><strong>${cls.grade}</strong></td>
                                <td style="color:#3498db;font-weight:600;">${cls.male}</td>
                                <td style="color:#e74c3c;font-weight:600;">${cls.female}</td>
                                <td><strong>${cls.total}</strong></td>
                                <td>${teacherNames}</td>
                                <td>
                                    <div style="display:flex;align-items:center;gap:8px;">
                                        <div style="flex:1;height:6px;background:#e0e0e0;border-radius:3px;overflow:hidden;">
                                            <div style="height:100%;background:linear-gradient(90deg, #27ae60, #2ecc71);width:${feePercent}%"></div>
                                        </div>
                                        <span style="font-size:11px;min-width:60px;">${feePercent}% (${cls.feePaid}/${feeTotal})</span>
                                    </div>
                                </td>
                                <td>
                                    <div style="display:flex;align-items:center;gap:8px;">
                                        <div style="flex:1;height:6px;background:#e0e0e0;border-radius:3px;overflow:hidden;">
                                            <div style="height:100%;background:linear-gradient(90deg, #3498db, #2980b9);width:${cls.attendanceRate}%"></div>
                                        </div>
                                        <span style="font-size:11px;min-width:50px;">${cls.attendanceRate}%</span>
                                    </div>
                                </td>
                                <td>
                                    <button class="admin-btn admin-btn-primary admin-btn-sm" onclick="viewClassStudents('${cls.grade}')" title="View Students">
                                        <i class="fas fa-users"></i>
                                    </button>
                                    <button class="admin-btn admin-btn-success admin-btn-sm" onclick="exportClassData('${cls.grade}')" title="Export">
                                        <i class="fas fa-download"></i>
                                    </button>
                                </td>
                            </tr>
                        `;
                    }).join('')}
                </tbody>
            </table>
        </div>
    `;
}

function renderAdvancedClassBreakdownCard(cls) {
    const feeTotal = cls.feePaid + cls.feePending;
    const feePaidPercent = feeTotal > 0 ? Math.round((cls.feePaid / feeTotal) * 100) : 0;
    const feePendingPercent = feeTotal > 0 ? Math.round((cls.feePending / feeTotal) * 100) : 0;
    
    const teacherTags = cls.teachers.length > 0 
        ? cls.teachers.map(t => `<span class="class-breakdown-teacher-tag"><i class="fas fa-chalkboard-teacher"></i> ${t.firstName} ${t.lastName}</span>`).join('')
        : '<span style="color:#999;font-size:12px;">No teacher assigned</span>';
    
    return `
        <div class="class-breakdown-card">
            <div class="class-breakdown-header">
                <div class="class-breakdown-title">
                    <i class="fas fa-graduation-cap"></i>
                    ${cls.grade}
                </div>
                <span class="status-badge ${cls.total > 0 ? 'active' : 'pending'}">${cls.total} Students</span>
            </div>
            
            <div class="class-breakdown-stats">
                <div class="class-breakdown-stat male">
                    <div class="class-breakdown-stat-value">${cls.male}</div>
                    <div class="class-breakdown-stat-label">Male</div>
                </div>
                <div class="class-breakdown-stat female">
                    <div class="class-breakdown-stat-value">${cls.female}</div>
                    <div class="class-breakdown-stat-label">Female</div>
                </div>
                <div class="class-breakdown-stat total">
                    <div class="class-breakdown-stat-value">${cls.total}</div>
                    <div class="class-breakdown-stat-label">Total</div>
                </div>
            </div>
            
            <div class="class-breakdown-fee-status">
                <div class="class-breakdown-fee-title">Fee Status</div>
                <div class="class-breakdown-fee-bar">
                    <div class="class-breakdown-fee-paid" style="width: ${feePaidPercent}%"></div>
                    <div class="class-breakdown-fee-pending" style="width: ${feePendingPercent}%"></div>
                </div>
                <div class="class-breakdown-fee-legend">
                    <div class="class-breakdown-legend-item">
                        <div class="class-breakdown-legend-dot paid"></div>
                        <span>Paid (${cls.feePaid})</span>
                    </div>
                    <div class="class-breakdown-legend-item">
                        <div class="class-breakdown-legend-dot pending"></div>
                        <span>Pending (${cls.feePending})</span>
                    </div>
                </div>
            </div>
            
            <div style="margin-top:16px;padding:12px;background:#f8f9fa;border-radius:8px;">
                <div style="font-size:13px;font-weight:600;color:var(--text-dark);margin-bottom:8px;">
                    <i class="fas fa-clipboard-check"></i> Attendance Rate: ${cls.attendanceRate}%
                </div>
                <div style="height:6px;background:#e0e0e0;border-radius:3px;overflow:hidden;">
                    <div style="height:100%;background:linear-gradient(90deg, #3498db, #2980b9);width:${cls.attendanceRate}%"></div>
                </div>
                <div style="display:flex;justify-content:space-between;margin-top:6px;font-size:11px;color:#666;">
                    <span>Present: ${cls.presentCount}</span>
                    <span>Absent: ${cls.absentCount}</span>
                </div>
            </div>
            
            <div class="class-breakdown-teachers">
                <div style="font-size:13px;font-weight:600;color:var(--text-dark);margin-bottom:8px;">
                    <i class="fas fa-user-tie"></i> Assigned Teachers
                </div>
                ${teacherTags}
            </div>
            
            <div style="margin-top:16px;display:flex;gap:8px;">
                <button class="admin-btn admin-btn-primary admin-btn-sm" onclick="viewClassStudents('${cls.grade}')" style="flex:1;">
                    <i class="fas fa-users"></i> View Students
                </button>
                <button class="admin-btn admin-btn-success admin-btn-sm" onclick="exportClassData('${cls.grade}')" style="flex:1;">
                    <i class="fas fa-download"></i> Export
                </button>
            </div>
        </div>
    `;
}

function viewClassStudents(grade) {
    // Navigate to students section with filter
    showSection('students');
    setTimeout(() => {
        const filter = document.getElementById('studentGradeFilter');
        if (filter) {
            filter.value = grade;
            filterStudents();
        }
    }, 100);
}

function exportClassData(grade) {
    showToast(`Exporting data for ${grade}...`, 'info');
    // Implementation would export specific class data
}

function exportAllClassBreakdown() {
    showToast('Exporting all class breakdown data...', 'info');
    // Implementation would export all class data
}

function printClassBreakdown() {
    window.print();
}

// ===== SITE CONTENT MANAGEMENT =====
async function switchContentTab(tabName, tabElement) {
    // Hide all content tabs
    document.querySelectorAll('.content-tab').forEach(tab => {
        tab.style.display = 'none';
    });
    
    // Remove active class from all tabs
    document.querySelectorAll('.subject-tab').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Show selected tab
    const selectedTab = document.getElementById('content-' + tabName);
    if (selectedTab) {
        selectedTab.style.display = 'block';
    }
    
    // Add active class to clicked tab
    if (tabElement) {
        tabElement.classList.add('active');
    }
    
    // Load content for the selected tab
    await loadContent(tabName);
}

async function loadContent(page) {
    try {
        const result = await apiFetch('admin', 'content');
        if (!result.success) return;
        
        const contentData = result.data || {};
        
        // Map page to field IDs
        const fieldMap = {
            'home': {
                'heroTitle': 'content_home_heroTitle',
                'heroTag': 'content_home_heroTag',
                'admissionsHeading': 'content_home_admissionsHeading',
                'admissionsText': 'content_home_admissionsText',
                'ctaHeading': 'content_home_ctaHeading',
                'ctaText': 'content_home_ctaText'
            },
            'about': {
                'title': 'content_about_title',
                'mission': 'content_about_mission',
                'vision': 'content_about_vision',
                'values': 'content_about_values'
            },
            'features': {
                'heading': 'content_features_heading',
                'subtitle': 'content_features_subtitle'
            },
            'team': {
                'heading': 'content_team_heading',
                'subtitle': 'content_team_subtitle'
            },
            'footer': {
                'description': 'content_footer_description',
                'address': 'content_footer_address',
                'phone': 'content_footer_phone',
                'phone2': 'content_footer_phone2',
                'email': 'content_footer_email',
                'schoolHours': 'content_footer_schoolHours',
                'facebookUrl': 'content_footer_facebookUrl',
                'tiktokUrl': 'content_footer_tiktokUrl',
                'whatsappUrl': 'content_footer_whatsappUrl',
                'copyright': 'content_footer_copyright'
            }
        };
        
        const fields = fieldMap[page] || {};
        const pageData = contentData[page] || {};
        
        // Populate form fields
        Object.keys(fields).forEach(key => {
            const fieldId = fields[key];
            const element = document.getElementById(fieldId);
            if (element) {
                element.value = pageData[key] || '';
            }
        });
        
    } catch (error) {
        console.error('Error loading content:', error);
    }
}

async function saveContent(page, event) {
    if (event) event.preventDefault();
    
    // Map page to field IDs
    const fieldMap = {
        'home': {
            'heroTitle': 'content_home_heroTitle',
            'heroTag': 'content_home_heroTag',
            'admissionsHeading': 'content_home_admissionsHeading',
            'admissionsText': 'content_home_admissionsText',
            'ctaHeading': 'content_home_ctaHeading',
            'ctaText': 'content_home_ctaText'
        },
        'about': {
            'title': 'content_about_title',
            'mission': 'content_about_mission',
            'vision': 'content_about_vision',
            'values': 'content_about_values'
        },
        'features': {
            'heading': 'content_features_heading',
            'subtitle': 'content_features_subtitle'
        },
        'team': {
            'heading': 'content_team_heading',
            'subtitle': 'content_team_subtitle'
        },
        'footer': {
            'description': 'content_footer_description',
            'address': 'content_footer_address',
            'phone': 'content_footer_phone',
            'phone2': 'content_footer_phone2',
            'email': 'content_footer_email',
            'schoolHours': 'content_footer_schoolHours',
            'facebookUrl': 'content_footer_facebookUrl',
            'tiktokUrl': 'content_footer_tiktokUrl',
            'whatsappUrl': 'content_footer_whatsappUrl',
            'copyright': 'content_footer_copyright'
        }
    };
    
    const fields = fieldMap[page] || {};
    const data = {};
    
    // Collect data from form fields
    Object.keys(fields).forEach(key => {
        const fieldId = fields[key];
        const element = document.getElementById(fieldId);
        if (element) {
            data[key] = element.value;
        }
    });
    
    try {
        const result = await apiFetch('admin', 'content', 'POST', {
            page: page,
            data: data
        });
        
        if (result.success) {
            showToast(`${page.charAt(0).toUpperCase() + page.slice(1)} content saved successfully!`, 'success');
        } else {
            showToast(result.message || 'Failed to save content', 'error');
        }
    } catch (error) {
        console.error('Error saving content:', error);
        showToast('Error saving content', 'error');
    }
    
    return false;
}

// ===== ANNOUNCEMENTS =====
async function renderAnnouncements() {
    const tbody = document.getElementById('announcementsTableBody');
    if (!tbody) return;

    const result = await apiFetch('admin', 'announcements', 'GET');
    const announcements = result.success ? (result.data?.items || []) : [];

    // Apply filters
    const priorityFilter = document.getElementById('announcementPriorityFilter')?.value || '';
    const statusFilter = document.getElementById('announcementStatusFilter')?.value || '';

    let filtered = announcements;
    if (priorityFilter) {
        filtered = filtered.filter(a => a.priority === priorityFilter);
    }
    if (statusFilter) {
        filtered = filtered.filter(a => a.status === statusFilter);
    }

    if (filtered.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted">No announcements yet.</td></tr>';
        return;
    }

    tbody.innerHTML = filtered.map(a => `
        <tr>
            <td><strong>${a.title || '-'}</strong></td>
            <td>${a.content ? a.content.substring(0, 100) + (a.content.length > 100 ? '...' : '') : '-'}</td>
            <td><span class="badge badge-${a.priority === 'urgent' ? 'danger' : a.priority === 'important' ? 'warning' : 'secondary'}">${a.priority || 'normal'}</span></td>
            <td>${a.audience || 'all'}</td>
            <td><span class="badge badge-${a.status === 'Published' ? 'success' : 'secondary'}">${a.status || 'Draft'}</span></td>
            <td>${formatDate(a.createdAt)}</td>
            <td>
                <button class="admin-btn admin-btn-sm admin-btn-primary" onclick="editAnnouncement(${a.id})" title="Edit"><i class="fas fa-edit"></i></button>
                <button class="admin-btn admin-btn-sm admin-btn-danger" onclick="deleteAnnouncement(${a.id})" title="Delete"><i class="fas fa-trash"></i></button>
            </td>
        </tr>
    `).join('');

    // Update badge count
    document.getElementById('annBadge').textContent = announcements.length;
}

function openAnnouncementModal(announcement = null) {
    document.getElementById('announcementModalTitle').innerHTML = '<i class="fas fa-bullhorn"></i> New Announcement';
    document.getElementById('announcementEditId').value = '';
    document.getElementById('announcementForm').reset();
    document.getElementById('announcementStatus').value = 'Draft';
    document.getElementById('announcementPriority').value = 'normal';
    document.getElementById('announcementAudience').value = 'all';
    document.getElementById('announcementPinned').checked = false;
    openModal('announcementModal');
}

async function editAnnouncement(id) {
    const result = await apiFetch('admin', 'announcements', 'GET', null, id);
    if (result.success && result.data) {
        const announcement = result.data;
        document.getElementById('announcementEditId').value = announcement.id;
        document.getElementById('announcementTitle').value = announcement.title || '';
        document.getElementById('announcementContent').value = announcement.content || '';
        document.getElementById('announcementPriority').value = announcement.priority || 'normal';
        document.getElementById('announcementAudience').value = announcement.audience || 'all';
        document.getElementById('announcementStatus').value = announcement.status || 'Draft';
        document.getElementById('announcementPinned').checked = announcement.pinned || false;
        document.getElementById('announcementModalTitle').innerHTML = '<i class="fas fa-bullhorn"></i> Edit Announcement';
        openModal('announcementModal');
    } else {
        showToast('Failed to load announcement', 'error');
    }
}

async function saveAnnouncement(event) {
    event.preventDefault();
    const editId = document.getElementById('announcementEditId').value;
    const body = {
        title: document.getElementById('announcementTitle').value,
        content: document.getElementById('announcementContent').value,
        priority: document.getElementById('announcementPriority').value,
        audience: document.getElementById('announcementAudience').value,
        status: document.getElementById('announcementStatus').value,
        pinned: document.getElementById('announcementPinned').checked
    };

    const result = editId
        ? await apiFetch('admin', 'announcements', 'PUT', body, editId)
        : await apiFetch('admin', 'announcements', 'POST', body);

    if (result.success) {
        showToast(editId ? 'Announcement updated successfully' : 'Announcement created successfully', 'success');
        closeModal();
        renderAnnouncements();
    } else {
        showToast(result.message || 'Failed to save announcement', 'error');
    }
    return false;
}

async function deleteAnnouncement(id) {
    if (!confirm('Are you sure you want to delete this announcement?')) return;
    const result = await apiFetch('admin', 'announcements', 'DELETE', null, id);
    if (result.success) {
        showToast('Announcement deleted successfully', 'success');
        renderAnnouncements();
    } else {
        showToast(result.message || 'Failed to delete announcement', 'error');
    }
}

// ===== STAT DETAILS MODAL =====
async function openStatModal(type) {
    // Close any open modal first
    closeModal();
    
    const modal = document.getElementById('statDetailsModal');
    const titleEl = document.getElementById('statDetailsModalTitle');
    const thead = document.getElementById('statDetailsTableHead');
    const tbody = document.getElementById('statDetailsTableBody');

    let title = '';
    let headers = '';
    let data = [];

    switch(type) {
        case 'registrations':
            title = '<i class="fas fa-user-plus"></i> New Registrations';
            headers = '<tr><th>#</th><th>Student Name</th><th>Grade</th><th>Parent/Guardian</th><th>Date</th><th>Status</th></tr>';
            const regResult = await apiFetch('admin', 'registrations', 'GET');
            if (regResult.success) {
                data = regResult.data.items || (Array.isArray(regResult.data) ? regResult.data : []);
            }
            break;
        case 'payments':
            title = '<i class="fas fa-money-bill-wave"></i> Payments Received';
            headers = '<tr><th>#</th><th>Payer Name</th><th>Student</th><th>Amount (MK)</th><th>Payment Type</th><th>Date</th><th>Status</th></tr>';
            const payResult = await apiFetch('admin', 'payments', 'GET');
            if (payResult.success) {
                data = payResult.data.items || (Array.isArray(payResult.data) ? payResult.data : []);
            }
            break;
        case 'students':
            title = '<i class="fas fa-user-graduate"></i> Total Students';
            headers = '<tr><th>#</th><th>Name</th><th>Grade</th><th>Parent/Guardian</th><th>Phone</th><th>Status</th></tr>';
            const stuResult = await apiFetch('admin', 'students', 'GET');
            if (stuResult.success) {
                data = stuResult.data.items || (Array.isArray(stuResult.data) ? stuResult.data : []);
            }
            break;
        case 'teachers':
            title = '<i class="fas fa-chalkboard-teacher"></i> Teachers';
            headers = '<tr><th>#</th><th>Name</th><th>Subject</th><th>Email</th><th>Phone</th><th>Status</th></tr>';
            const teachResult = await apiFetch('admin', 'teachers', 'GET');
            if (teachResult.success) {
                data = teachResult.data.items || (Array.isArray(teachResult.data) ? teachResult.data : []);
            }
            break;
        case 'events':
            title = '<i class="fas fa-calendar-alt"></i> Upcoming Events';
            headers = '<tr><th>#</th><th>Title</th><th>Date</th><th>Location</th><th>Type</th><th>Status</th></tr>';
            const eventResult = await apiFetch('admin', 'events', 'GET');
            if (eventResult.success) {
                data = eventResult.data.items || (Array.isArray(eventResult.data) ? eventResult.data : []);
            }
            break;
        case 'gallery':
            title = '<i class="fas fa-images"></i> Gallery Items';
            headers = '<tr><th>#</th><th>Title</th><th>Category</th><th>Date Added</th><th>Status</th></tr>';
            const galResult = await apiFetch('admin', 'gallery', 'GET');
            if (galResult.success) {
                data = galResult.data.items || (Array.isArray(galResult.data) ? galResult.data : []);
            }
            break;
        case 'blogs':
            title = '<i class="fas fa-blog"></i> Blog Posts';
            headers = '<tr><th>#</th><th>Title</th><th>Author</th><th>Date</th><th>Status</th></tr>';
            const blogResult = await apiFetch('admin', 'blog', 'GET');
            if (blogResult.success) {
                data = blogResult.data.items || (Array.isArray(blogResult.data) ? blogResult.data : []);
            }
            break;
        case 'messages':
            title = '<i class="fas fa-envelope"></i> Messages';
            headers = '<tr><th>#</th><th>Name</th><th>Email</th><th>Subject</th><th>Date</th><th>Status</th></tr>';
            const msgResult = await apiFetch('admin', 'messages', 'GET');
            if (msgResult.success) {
                data = msgResult.data.items || (Array.isArray(msgResult.data) ? msgResult.data : []);
            }
            break;
        case 'applications':
            title = '<i class="fas fa-file-signature"></i> Job Applications';
            headers = '<tr><th>#</th><th>Applicant Name</th><th>Position</th><th>Email</th><th>Phone</th><th>Date</th><th>Status</th></tr>';
            // Try job_applications table first, then fall back to vacancies
            let appResult = await apiFetch('admin', 'job_applications', 'GET');
            if (!appResult.success || !appResult.data?.items?.length) {
                // If no job applications, show vacancies instead
                appResult = await apiFetch('admin', 'vacancies', 'GET');
                title = '<i class="fas fa-briefcase"></i> Job Vacancies';
                headers = '<tr><th>#</th><th>Position Title</th><th>Type</th><th>Location</th><th>Deadline</th><th>Salary</th><th>Status</th></tr>';
            }
            if (appResult.success) {
                data = appResult.data.items || (Array.isArray(appResult.data) ? appResult.data : []);
            }
            break;
        case 'reports':
            title = '<i class="fas fa-folder-open"></i> Reports';
            headers = '<tr><th>#</th><th>Report Name</th><th>Type</th><th>Generated By</th><th>Date</th><th>Status</th></tr>';
            const reportResult = await apiFetch('admin', 'reports', 'GET');
            if (reportResult.success) {
                data = reportResult.data.items || (Array.isArray(reportResult.data) ? reportResult.data : []);
            }
            break;
        case 'users':
            title = '<i class="fas fa-users"></i> User Activities';
            headers = '<tr><th>#</th><th>User</th><th>Email</th><th>Role</th><th>Status</th><th>Last Activity</th></tr>';
            const userResult = await apiFetch('admin', 'users', 'GET');
            if (userResult.success) {
                // Handle both data.items format and direct data array format
                data = userResult.data.items || (Array.isArray(userResult.data) ? userResult.data : []);
            }
            break;
    }

    titleEl.innerHTML = title;
    thead.innerHTML = headers;

    // Add summary info for users before table content
    if (type === 'users' && data && data.length > 0) {
        const activeUsers = data.filter(u => u.status === 'active').length;
        const admins = data.filter(u => u.role === 'admin').length;
        const teachers = data.filter(u => u.role === 'teacher').length;
        const parents = data.filter(u => u.role === 'parent').length;
        
        const summaryHtml = `
            <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 16px; border-radius: 10px; margin-bottom: 20px; color: white;">
                <div style="display: flex; gap: 25px; flex-wrap: wrap; align-items: center;">
                    <div style="flex: 1; min-width: 100px;">
                        <div style="font-size: 10px; opacity: 0.8; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 4px;">Total Users</div>
                        <div style="font-size: 24px; font-weight: 700;">${data.length}</div>
                    </div>
                    <div style="flex: 1; min-width: 100px;">
                        <div style="font-size: 10px; opacity: 0.8; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 4px;">Active</div>
                        <div style="font-size: 24px; font-weight: 700;">${activeUsers}</div>
                    </div>
                    <div style="flex: 1; min-width: 100px;">
                        <div style="font-size: 10px; opacity: 0.8; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 4px;">Admins</div>
                        <div style="font-size: 24px; font-weight: 700;">${admins}</div>
                    </div>
                    <div style="flex: 1; min-width: 100px;">
                        <div style="font-size: 10px; opacity: 0.8; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 4px;">Teachers</div>
                        <div style="font-size: 24px; font-weight: 700;">${teachers}</div>
                    </div>
                    <div style="flex: 1; min-width: 100px;">
                        <div style="font-size: 10px; opacity: 0.8; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 4px;">Parents</div>
                        <div style="font-size: 24px; font-weight: 700;">${parents}</div>
                    </div>
                </div>
            </div>
        `;
        
        // Insert summary before the table
        const modalBody = modal.querySelector('.admin-modal-body');
        if (modalBody) {
            const existingSummary = modalBody.querySelector('.user-summary');
            if (existingSummary) existingSummary.remove();
            
            const summaryDiv = document.createElement('div');
            summaryDiv.className = 'user-summary';
            summaryDiv.innerHTML = summaryHtml;
            modalBody.insertBefore(summaryDiv, modalBody.querySelector('.table-responsive'));
        }
    }

    if (!data || data.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted">No data available.</td></tr>';
    } else {
        tbody.innerHTML = data.map((item, index) => {
            switch(type) {
                case 'registrations':
                    return `<tr>
                        <td>${index + 1}</td>
                        <td>${item.firstName || item.first_name || item.student_name || item.studentName || item.name || '-'}</td>
                        <td>${item.grade || '-'}</td>
                        <td>${item.parentName || item.parent_name || item.parent || '-'}</td>
                        <td>${item.created_at || item.createdAt || item.date || '-'}</td>
                        <td>${item.status || '-'}</td>
                    </tr>`;
                case 'payments':
                    return `<tr>
                        <td>${index + 1}</td>
                        <td>${item.payer_name || '-'}</td>
                        <td>${item.student_name || '-'}</td>
                        <td>${item.amount || '-'}</td>
                        <td>${item.payment_type || '-'}</td>
                        <td>${item.date || '-'}</td>
                        <td>${item.status || '-'}</td>
                    </tr>`;
                case 'students':
                    return `<tr>
                        <td>${index + 1}</td>
                        <td>${item.firstName || item.first_name || ''} ${item.lastName || item.last_name || ''}</td>
                        <td>${item.grade || '-'}</td>
                        <td>${item.parent || '-'}</td>
                        <td>${item.phone || '-'}</td>
                        <td>${item.status || '-'}</td>
                    </tr>`;
                case 'teachers':
                    return `<tr>
                        <td>${index + 1}</td>
                        <td>${item.firstName || item.first_name || ''} ${item.lastName || item.last_name || ''}</td>
                        <td>${item.subject || '-'}</td>
                        <td>${item.email || '-'}</td>
                        <td>${item.phone || '-'}</td>
                        <td>${item.status || '-'}</td>
                    </tr>`;
                case 'events':
                    return `<tr>
                        <td>${index + 1}</td>
                        <td>${item.title || '-'}</td>
                        <td>${item.event_date || '-'}</td>
                        <td>${item.location || '-'}</td>
                        <td>${item.event_type || '-'}</td>
                        <td>${item.status || '-'}</td>
                    </tr>`;
                case 'gallery':
                    const galleryStatus = item.status || '-';
                    const galleryStatusClass = galleryStatus === 'active' || galleryStatus === 'published' ? 'active' : 'inactive';
                    const galleryImage = item.image_url || item.imageUrl || item.image || '';
                    return `<tr>
                        <td>${index + 1}</td>
                        <td>
                            <div style="font-weight: 600;">${item.title || '-'}</div>
                            ${galleryImage ? `<img src="${galleryImage}" alt="" style="width: 40px; height: 40px; object-fit: cover; border-radius: 4px; margin-top: 4px;">` : ''}
                        </td>
                        <td><span style="background: #e3f2fd; color: #1976d2; padding: 4px 10px; border-radius: 12px; font-size: 11px; font-weight: 600;">${item.category || '-'}</span></td>
                        <td>${item.created_at || '-'}</td>
                        <td><span class="status-badge ${galleryStatusClass}">${galleryStatus}</span></td>
                    </tr>`;
                case 'blogs':
                    return `<tr>
                        <td>${index + 1}</td>
                        <td>${item.title || '-'}</td>
                        <td>${item.author || '-'}</td>
                        <td>${item.created_at || '-'}</td>
                        <td>${item.status || '-'}</td>
                    </tr>`;
                case 'messages':
                    return `<tr>
                        <td>${index + 1}</td>
                        <td>${item.name || '-'}</td>
                        <td>${item.email || '-'}</td>
                        <td>${item.subject || '-'}</td>
                        <td>${item.created_at || '-'}</td>
                        <td>${item.status || '-'}</td>
                    </tr>`;
                case 'applications':
                    // Check if this is actually vacancies data (has title field)
                    if (item.title) {
                        return `<tr>
                            <td>${index + 1}</td>
                            <td>${item.title || '-'}</td>
                            <td>${item.position_type || '-'}</td>
                            <td>${item.location || '-'}</td>
                            <td>${item.application_deadline || '-'}</td>
                            <td>${item.salary_range || '-'}</td>
                            <td>${item.status || '-'}</td>
                        </tr>`;
                    } else {
                        return `<tr>
                            <td>${index + 1}</td>
                            <td>${item.applicant_name || item.firstName + ' ' + item.lastName || '-'}</td>
                            <td>${item.position || item.position_applied || '-'}</td>
                            <td>${item.email || '-'}</td>
                            <td>${item.phone || '-'}</td>
                            <td>${item.created_at || '-'}</td>
                            <td>${item.status || '-'}</td>
                        </tr>`;
                    }
                case 'reports':
                    return `<tr>
                        <td>${index + 1}</td>
                        <td>${item.report_name || item.name || '-'}</td>
                        <td>${item.report_type || item.type || '-'}</td>
                        <td>${item.generated_by || item.created_by || '-'}</td>
                        <td>${item.created_at || '-'}</td>
                        <td>${item.status || '-'}</td>
                    </tr>`;
                case 'users':
                    const userName = item.name || (item.first_name && item.last_name ? `${item.first_name} ${item.last_name}` : '-');
                    const userRole = item.role || '-';
                    const userStatus = item.status || '-';
                    const lastLogin = item.last_login || item.created_at || '-';
                    const statusClass = userStatus === 'active' ? 'active' : 'inactive';
                    const roleClass = userRole === 'admin' ? 'priority-urgent' : userRole === 'teacher' ? 'priority-important' : 'priority-normal';
                    
                    return `<tr>
                        <td>${index + 1}</td>
                        <td>
                            <div style="font-weight: 600;">${userName}</div>
                            ${item.phone ? `<div style="font-size: 11px; color: #666;">${item.phone}</div>` : ''}
                        </td>
                        <td>${item.email || '-'}</td>
                        <td><span class="status-badge ${roleClass}">${userRole}</span></td>
                        <td><span class="status-badge ${statusClass}">${userStatus}</span></td>
                        <td>
                            <div style="font-size: 12px;">${lastLogin !== '-' ? formatDate(lastLogin) : 'Never'}</div>
                            ${item.created_at ? `<div style="font-size: 10px; color: #888;">Joined: ${formatDate(item.created_at)}</div>` : ''}
                        </td>
                    </tr>`;
                default:
                    return '';
            }
        }).join('');
    }

    modal.classList.add('show');
    modal.style.display = 'flex';
    document.body.style.overflow = 'hidden';
}

// ===== CLASS BREAKDOWN FUNCTIONS =====
async function loadAttendanceBreakdown() {
    const tbody = document.getElementById('attendanceBreakdownTableBody');
    if (!tbody) return;
    
    tbody.innerHTML = '<tr><td colspan="4" class="text-center text-muted">Loading attendance breakdown...</td></tr>';
    
    try {
        // Fetch students to calculate breakdown
        const result = await apiFetch('admin', 'students');
        const students = result.success ? (result.data?.items || []) : [];
        
        // Define class mappings
        const classMappings = {
            'daycare': 'Day Care',
            'nursery': 'Nursery/Baby',
            'reception': 'Receptionist',
            'std1': 'Standard 1',
            'std2': 'Standard 2',
            'std3': 'Standard 3',
            'std4': 'Standard 4',
            'std5': 'Standard 5',
            'std6': 'Standard 6',
            'std7': 'Standard 7',
            'std8': 'Standard 8',
            'form1': 'Form 1',
            'form2': 'Form 2',
            'form3': 'Form 3',
            'form4': 'Form 4'
        };
        
        // Calculate breakdown for each class
        const breakdown = Object.keys(classMappings).map(classId => {
            const className = classMappings[classId];
            const classStudents = students.filter(s => s.grade === className);
            const boys = classStudents.filter(s => s.gender === 'Male').length;
            const girls = classStudents.filter(s => s.gender === 'Female').length;
            const total = boys + girls;
            
            return {
                classId,
                className,
                boys,
                girls,
                total
            };
        });
        
        // Clear existing rows and populate with calculated data
        tbody.innerHTML = '';
        breakdown.forEach(item => {
            const maleInput = document.getElementById(`breakdown_${item.classId}_male`);
            const femaleInput = document.getElementById(`breakdown_${item.classId}_female`);
            const totalInput = document.getElementById(`breakdown_${item.classId}_total`);
            
            if (maleInput) maleInput.value = item.boys;
            if (femaleInput) femaleInput.value = item.girls;
            if (totalInput) totalInput.value = item.total;
        });
        
        // Load teacher assignments for each class
        await loadTeacherAssignmentsForBreakdown();
        
        showToast('Attendance breakdown loaded successfully!', 'success');
    } catch (error) {
        console.error('Error loading attendance breakdown:', error);
        showToast('Error loading attendance breakdown', 'error');
    }
}

function updateClassTotal(classId) {
    const maleInput = document.getElementById(`breakdown_${classId}_male`);
    const femaleInput = document.getElementById(`breakdown_${classId}_female`);
    const totalInput = document.getElementById(`breakdown_${classId}_total`);

    if (maleInput && femaleInput && totalInput) {
        const male = parseInt(maleInput.value) || 0;
        const female = parseInt(femaleInput.value) || 0;
        totalInput.value = male + female;
    }
}

async function loadTeacherAssignmentsForBreakdown() {
    try {
        const result = await apiCollaboration('class_assignments', {});
        if (result.success && result.data.items) {
            const assignments = result.data.items;
            
            // Define class mappings
            const classMappings = {
                'daycare': 'Day Care',
                'nursery': 'Nursery/Baby',
                'reception': 'Receptionist',
                'std1': 'Standard 1',
                'std2': 'Standard 2',
                'std3': 'Standard 3',
                'std4': 'Standard 4',
                'std5': 'Standard 5',
                'std6': 'Standard 6',
                'std7': 'Standard 7',
                'std8': 'Standard 8',
                'form1': 'Form 1',
                'form2': 'Form 2',
                'form3': 'Form 3',
                'form4': 'Form 4'
            };
            
            // Update teacher display for each class
            Object.keys(classMappings).forEach(classId => {
                const className = classMappings[classId];
                const cell = document.getElementById(`breakdown_${classId}_teachers`);
                
                if (cell) {
                    const classAssignments = assignments.filter(a => a.className === className);
                    if (classAssignments.length > 0) {
                        const teacherNames = classAssignments.map(a => a.teacherName).join(', ');
                        cell.innerHTML = `<span class="teacher-names">${teacherNames}</span>`;
                    } else {
                        cell.innerHTML = '<span class="no-teachers">No teachers assigned</span>';
                    }
                }
            });
        }
    } catch (error) {
        console.error('Error loading teacher assignments for breakdown:', error);
    }
}

async function saveAttendanceBreakdown() {
    const classes = [
        'daycare', 'nursery', 'reception',
        'std1', 'std2', 'std3', 'std4', 'std5', 'std6', 'std7', 'std8',
        'form1', 'form2', 'form3', 'form4'
    ];

    const breakdownData = {};

    classes.forEach(classId => {
        const male = document.getElementById(`breakdown_${classId}_male`);
        const female = document.getElementById(`breakdown_${classId}_female`);
        const total = document.getElementById(`breakdown_${classId}_total`);

        if (male && female && total) {
            breakdownData[classId] = {
                male: parseInt(male.value) || 0,
                female: parseInt(female.value) || 0,
                total: parseInt(total.value) || 0
            };
        }
    });

    try {
        const response = await fetch(API_BASE + '?type=admin&action=save_class_breakdown', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(breakdownData)
        });

        const result = await safeFetch(response);

        if (result.success) {
            showToast('Class breakdown saved successfully', 'success');
        } else {
            showToast('Error saving class breakdown', 'error');
        }
    } catch (error) {
        console.error('Error saving class breakdown:', error);
        showToast('Error saving class breakdown', 'error');
    }
}

// ===== API MANAGEMENT FUNCTIONS =====
let apisData = [];

async function renderApis() {
    const tbody = document.getElementById('apisTableBody');
    if (!tbody) return;

    try {
        const search = document.getElementById('apiSearch')?.value.toLowerCase() || '';
        const typeFilter = document.getElementById('apiTypeFilter')?.value || '';
        const statusFilter = document.getElementById('apiStatusFilter')?.value || '';

        let url = API_BASE + '?type=admin&collection=apis';
        const response = await fetch(url);
        const data = await safeFetch(response);

        if (data.success && data.data) {
            // Handle different data formats (array or object with items property)
            apisData = Array.isArray(data.data) ? data.data : (data.data.items || []);
            
            // Filter APIs
            let filteredApis = apisData.filter(api => {
                const matchesSearch = !search || 
                    api.name?.toLowerCase().includes(search) ||
                    api.provider?.toLowerCase().includes(search) ||
                    api.endpoint?.toLowerCase().includes(search);
                const matchesType = !typeFilter || api.type === typeFilter;
                const matchesStatus = !statusFilter || api.status === statusFilter;
                return matchesSearch && matchesType && matchesStatus;
            });

            if (filteredApis.length === 0) {
                tbody.innerHTML = '<tr><td colspan="8" class="text-center text-muted">No APIs found.</td></tr>';
            } else {
                tbody.innerHTML = filteredApis.map((api, index) => `
                    <tr>
                        <td>${index + 1}</td>
                        <td><strong>${api.name || 'N/A'}</strong></td>
                        <td><span class="status-badge ${api.type === 'payment' ? 'priority-urgent' : api.type === 'sms' ? 'priority-important' : 'priority-normal'}">${api.type || 'N/A'}</span></td>
                        <td>${api.provider || 'N/A'}</td>
                        <td><code style="font-size: 11px;">${api.endpoint || 'N/A'}</code></td>
                        <td><span class="status-badge ${api.status === 'active' ? 'active' : 'inactive'}">${api.status || 'N/A'}</span></td>
                        <td>${formatDate(api.last_used) || 'Never'}</td>
                        <td>
                            <button class="admin-btn admin-btn-sm admin-btn-primary" onclick="editApi(${api.id})" title="Edit"><i class="fas fa-edit"></i></button>
                            <button class="admin-btn admin-btn-sm admin-btn-info" onclick="testApi(${api.id})" title="Test"><i class="fas fa-vial"></i></button>
                            <button class="admin-btn admin-btn-sm admin-btn-danger" onclick="deleteApi(${api.id})" title="Delete"><i class="fas fa-trash"></i></button>
                        </td>
                    </tr>
                `).join('');
            }

            updateApiStats();
        } else {
            tbody.innerHTML = '<tr><td colspan="8" class="text-center text-muted">Error loading APIs.</td></tr>';
        }
    } catch (error) {
        console.error('Error rendering APIs:', error);
        tbody.innerHTML = '<tr><td colspan="8" class="text-center text-danger">Error loading APIs.</td></tr>';
    }
}

function updateApiStats() {
    const total = apisData.length;
    const active = apisData.filter(a => a.status === 'active').length;
    const inactive = apisData.filter(a => a.status === 'inactive').length;
    const payment = apisData.filter(a => a.type === 'payment').length;

    document.getElementById('apiTotal').textContent = total;
    document.getElementById('apiActive').textContent = active;
    document.getElementById('apiInactive').textContent = inactive;
    document.getElementById('apiPayment').textContent = payment;
    
    // Update badge
    const badge = document.getElementById('apiBadge');
    if (badge) {
        badge.textContent = total;
        badge.style.display = total > 0 ? 'inline-block' : 'none';
    }
}

function openApiModal(apiId = null) {
    const modal = document.getElementById('apiModal');
    const title = document.getElementById('apiModalTitle');
    const form = document.getElementById('apiForm');

    form.reset();
    document.getElementById('apiId').value = '';

    if (apiId) {
        const api = apisData.find(a => a.id === apiId);
        if (api) {
            title.innerHTML = '<i class="fas fa-edit"></i> Edit API';
            document.getElementById('apiId').value = api.id;
            document.getElementById('apiName').value = api.name || '';
            document.getElementById('apiType').value = api.type || '';
            document.getElementById('apiProvider').value = api.provider || '';
            document.getElementById('apiEndpoint').value = api.endpoint || '';
            document.getElementById('apiKey').value = api.api_key || '';
            document.getElementById('apiSecret').value = api.api_secret || '';
            document.getElementById('apiHeaders').value = api.headers || '';
            document.getElementById('apiStatus').value = api.status || 'active';
            document.getElementById('apiPriority').value = api.priority || 1;
            document.getElementById('apiDescription').value = api.description || '';
        }
    } else {
        title.innerHTML = '<i class="fas fa-plus"></i> Add API';
        document.getElementById('apiStatus').value = 'active';
        document.getElementById('apiPriority').value = 1;
    }

    openModal('apiModal');
}

async function saveApi(event) {
    event.preventDefault();

    const apiId = document.getElementById('apiId').value;
    const apiData = {
        name: document.getElementById('apiName').value,
        type: document.getElementById('apiType').value,
        provider: document.getElementById('apiProvider').value,
        endpoint: document.getElementById('apiEndpoint').value,
        api_key: document.getElementById('apiKey').value,
        api_secret: document.getElementById('apiSecret').value,
        headers: document.getElementById('apiHeaders').value,
        status: document.getElementById('apiStatus').value,
        priority: document.getElementById('apiPriority').value,
        description: document.getElementById('apiDescription').value
    };

    try {
        let response;
        if (apiId) {
            response = await fetch(`${API_BASE}?type=admin&collection=apis&id=${apiId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(apiData)
            });
        } else {
            response = await fetch(`${API_BASE}?type=admin&collection=apis`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(apiData)
            });
        }

        const result = await safeFetch(response);

        if (result.success) {
            showToast(apiId ? 'API updated successfully!' : 'API added successfully!', 'success');
            closeModal();
            renderApis();
        } else {
            showToast(result.message || 'Failed to save API', 'error');
        }
    } catch (error) {
        console.error('Error saving API:', error);
        showToast('Error saving API', 'error');
    }

    return false;
}

function editApi(apiId) {
    openApiModal(apiId);
}

async function deleteApi(apiId) {
    const api = apisData.find(a => a.id === apiId);
    if (!api) return;

    if (!confirm(`Are you sure you want to delete API "${api.name}"? This action cannot be undone.`)) return;

    try {
        const response = await fetch(`${API_BASE}?type=admin&collection=apis&id=${apiId}`, {
            method: 'DELETE'
        });

        const result = await safeFetch(response);

        if (result.success) {
            showToast('API deleted successfully!', 'success');
            renderApis();
        } else {
            showToast(result.message || 'Failed to delete API', 'error');
        }
    } catch (error) {
        console.error('Error deleting API:', error);
        showToast('Error deleting API', 'error');
    }
}

async function testApi(apiId) {
    const api = apisData.find(a => a.id === apiId);
    if (!api) return;

    showToast('Testing API connection...', 'info');

    try {
        const response = await fetch(`${API_BASE}?type=admin&api_action=test&id=${apiId}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        });

        const result = await safeFetch(response);

        if (result.success) {
            showToast('API connection successful!', 'success');
            renderApis(); // Refresh to update last_used timestamp
        } else {
            showToast(result.message || 'API connection failed', 'error');
        }
    } catch (error) {
        console.error('Error testing API:', error);
        showToast('Error testing API', 'error');
    }
}

async function exportApis() {
    try {
        const response = await fetch(API_BASE + '?type=admin&collection=apis');
        const data = await safeFetch(response);

        if (!data.success || !data.data) {
            showToast('No APIs to export', 'warning');
            return;
        }

        const apis = Array.isArray(data.data) ? data.data : (data.data.items || []);
        if (apis.length === 0) {
            showToast('No APIs to export', 'warning');
            return;
        }
        const csvHeader = 'ID,Name,Type,Provider,Endpoint,Status,Priority,Last Used,Created\n';
        const csvRows = apis.map(a => 
            `${a.id},"${a.name}","${a.type}","${a.provider}","${a.endpoint}","${a.status}","${a.priority}","${a.last_used || 'Never'}","${a.created_at}"`
        ).join('\n');

        downloadCSV(csvHeader + csvRows, 'apis.csv');
        showToast('APIs exported successfully', 'success');
    } catch (error) {
        console.error('Error exporting APIs:', error);
        showToast('Error exporting APIs', 'error');
    }
}

// Load payment APIs for payment integration
async function loadPaymentApis() {
    try {
        const response = await fetch(API_BASE + '?type=admin&collection=apis');
        const data = await safeFetch(response);

        if (data.success && data.data) {
            const apis = Array.isArray(data.data) ? data.data : (data.data.items || []);
            const paymentApis = apis.filter(api => api.type === 'payment' && api.status === 'active');
            return paymentApis;
        }
        return [];
    } catch (error) {
        console.error('Error loading payment APIs:', error);
        return [];
    }
}

// Update payment method dropdown with API options
async function updatePaymentMethodDropdown() {
    const paymentMethodSelect = document.getElementById('paymentMethod');
    if (!paymentMethodSelect) return;

    const paymentApis = await loadPaymentApis();
    
    // Keep existing options
    const existingOptions = Array.from(paymentMethodSelect.options).filter(option => 
        !option.value.startsWith('api_')
    );
    
    // Clear and restore existing options
    paymentMethodSelect.innerHTML = '';
    existingOptions.forEach(option => paymentMethodSelect.appendChild(option));
    
    // Add API options
    if (paymentApis.length > 0) {
        const apiGroup = document.createElement('optgroup');
        apiGroup.label = 'API Payment Methods';
        
        paymentApis.forEach(api => {
            const option = document.createElement('option');
            option.value = `api_${api.id}`;
            option.textContent = `${api.name} (${api.provider})`;
            option.dataset.apiId = api.id;
            apiGroup.appendChild(option);
        });
        
        paymentMethodSelect.appendChild(apiGroup);
    }
}

// ===== PHONE CORRECTION FUNCTIONS =====
let registrationPhonesData = [];
let teacherPhonesData = [];
let parentPhonesData = [];
let adminPhonesData = [];

// Load registration phone numbers
async function loadRegistrationPhones() {
    try {
        const response = await fetch(`${API_BASE}?type=admin&phone_action=get_registration_phones`);
        const data = await safeFetch(response);
        
        if (data.success && data.data) {
            registrationPhonesData = data.data.items || [];
            renderRegistrationPhones();
        } else {
            console.error('Failed to load registration phones:', data.message);
            renderRegistrationPhones(); // Render anyway to show empty state
        }
    } catch (error) {
        console.error('Error loading registration phones:', error);
        renderRegistrationPhones(); // Render anyway to show empty state
    }
}

// Render registration phone numbers
function renderRegistrationPhones() {
    const tbody = document.getElementById('registrationPhoneTableBody');
    if (!tbody) return;
    
    if (registrationPhonesData.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No registration phone numbers found.</td></tr>';
        return;
    }
    
    tbody.innerHTML = registrationPhonesData.map(reg => `
        <tr>
            <td>${formatDate(reg.createdAt)}</td>
            <td>${reg.studentName || '-'}</td>
            <td>${reg.parentName || '-'}</td>
            <td>${reg.phone || '-'}</td>
            <td>${reg.email || '-'}</td>
            <td>
                <button class="admin-btn admin-btn-sm admin-btn-primary" onclick="editRegistrationPhone(${reg.id}, '${reg.phone || ''}')">
                    <i class="fas fa-edit"></i> Edit
                </button>
                ${reg.phone ? `
                <button class="admin-btn admin-btn-sm admin-btn-info" onclick="sendSmsToParent('${reg.phone || ''}', '${reg.parentName || reg.studentName}')">
                    <i class="fas fa-sms"></i> SMS
                </button>
                ` : ''}
            </td>
        </tr>
    `).join('');
}

// Filter registration phone list
function filterRegistrationPhoneList() {
    const searchTerm = document.getElementById('registrationPhoneSearch').value.toLowerCase();
    const filtered = registrationPhonesData.filter(reg => 
        (reg.studentName && reg.studentName.toLowerCase().includes(searchTerm)) ||
        (reg.parentName && reg.parentName.toLowerCase().includes(searchTerm)) ||
        (reg.phone && reg.phone.toLowerCase().includes(searchTerm))
    );
    
    const tbody = document.getElementById('registrationPhoneTableBody');
    if (filtered.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No matching registrations found.</td></tr>';
        return;
    }
    
    tbody.innerHTML = filtered.map(reg => `
        <tr>
            <td>${formatDate(reg.createdAt)}</td>
            <td>${reg.studentName || '-'}</td>
            <td>${reg.parentName || '-'}</td>
            <td>${reg.phone || '-'}</td>
            <td>${reg.email || '-'}</td>
            <td>
                <button class="admin-btn admin-btn-sm admin-btn-primary" onclick="editRegistrationPhone(${reg.id}, '${reg.phone || ''}')">
                    <i class="fas fa-edit"></i> Edit
                </button>
                ${reg.phone ? `
                <button class="admin-btn admin-btn-sm admin-btn-info" onclick="sendSmsToParent('${reg.phone || ''}', '${reg.parentName || reg.studentName}')">
                    <i class="fas fa-sms"></i> SMS
                </button>
                ` : ''}
            </td>
        </tr>
    `).join('');
}

// Edit registration phone number
async function editRegistrationPhone(id, currentPhone) {
    const newPhone = prompt('Enter new phone number:', currentPhone);
    if (newPhone === null) return; // User cancelled
    
    if (newPhone.trim() === '') {
        showToast('Phone number cannot be empty', 'error');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}?type=admin&phone_action=update_registration_phone`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id, phone: newPhone.trim() })
        });
        
        const data = await safeFetch(response);
        
        if (data.success) {
            showToast('Phone number updated successfully', 'success');
            loadRegistrationPhones(); // Refresh the list
        } else {
            showToast(data.message || 'Failed to update phone number', 'error');
        }
    } catch (error) {
        console.error('Error updating phone:', error);
        showToast('Error updating phone number', 'error');
    }
}

// Load teacher phone numbers
async function loadTeacherPhones() {
    try {
        const response = await fetch(`${API_BASE}?type=admin&phone_action=get_teacher_phones`);
        const data = await safeFetch(response);
        
        if (data.success && data.data) {
            teacherPhonesData = data.data.items || [];
            renderTeacherPhones();
        } else {
            console.error('Failed to load teacher phones:', data.message);
            renderTeacherPhones(); // Render anyway to show empty state
        }
    } catch (error) {
        console.error('Error loading teacher phones:', error);
        renderTeacherPhones(); // Render anyway to show empty state
    }
}

// Render teacher phone numbers
function renderTeacherPhones() {
    const tbody = document.getElementById('teacherPhoneTableBody');
    if (!tbody) return;
    
    if (teacherPhonesData.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" class="text-center text-muted">No teachers found.</td></tr>';
        return;
    }
    
    tbody.innerHTML = teacherPhonesData.map(teacher => `
        <tr>
            <td>${teacher.name || teacher.firstName + ' ' + teacher.lastName}</td>
            <td>${teacher.phone || '-'}</td>
            <td>
                <button class="admin-btn admin-btn-sm admin-btn-primary" onclick="editTeacherPhone(${teacher.id}, '${teacher.phone || ''}')">
                    <i class="fas fa-edit"></i> Edit
                </button>
                ${teacher.phone ? `
                <button class="admin-btn admin-btn-sm admin-btn-info" onclick="sendSmsToParent('${teacher.phone || ''}', '${teacher.name || teacher.firstName + ' ' + teacher.lastName}')">
                    <i class="fas fa-sms"></i> SMS
                </button>
                ` : ''}
            </td>
        </tr>
    `).join('');
}

// Filter teacher phone list
function filterTeacherPhoneList() {
    const searchTerm = document.getElementById('teacherPhoneSearch').value.toLowerCase();
    const filtered = teacherPhonesData.filter(teacher => 
        (teacher.name && teacher.name.toLowerCase().includes(searchTerm)) ||
        (teacher.firstName && teacher.firstName.toLowerCase().includes(searchTerm)) ||
        (teacher.lastName && teacher.lastName.toLowerCase().includes(searchTerm)) ||
        (teacher.phone && teacher.phone.toLowerCase().includes(searchTerm))
    );
    
    const tbody = document.getElementById('teacherPhoneTableBody');
    if (filtered.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" class="text-center text-muted">No matching teachers found.</td></tr>';
        return;
    }
    
    tbody.innerHTML = filtered.map(teacher => `
        <tr>
            <td>${teacher.name || teacher.firstName + ' ' + teacher.lastName}</td>
            <td>${teacher.phone || '-'}</td>
            <td>
                <button class="admin-btn admin-btn-sm admin-btn-primary" onclick="editTeacherPhone(${teacher.id}, '${teacher.phone || ''}')">
                    <i class="fas fa-edit"></i> Edit
                </button>
                ${teacher.phone ? `
                <button class="admin-btn admin-btn-sm admin-btn-info" onclick="sendSmsToParent('${teacher.phone || ''}', '${teacher.name || teacher.firstName + ' ' + teacher.lastName}')">
                    <i class="fas fa-sms"></i> SMS
                </button>
                ` : ''}
            </td>
        </tr>
    `).join('');
}

// Edit teacher phone number
async function editTeacherPhone(id, currentPhone) {
    const newPhone = prompt('Enter new phone number:', currentPhone);
    if (newPhone === null) return; // User cancelled
    
    if (newPhone.trim() === '') {
        showToast('Phone number cannot be empty', 'error');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}?type=admin&phone_action=update_teacher_phone`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id, phone: newPhone.trim() })
        });
        
        const data = await safeFetch(response);
        
        if (data.success) {
            showToast('Phone number updated successfully', 'success');
            loadTeacherPhones(); // Refresh the list
        } else {
            showToast(data.message || 'Failed to update phone number', 'error');
        }
    } catch (error) {
        console.error('Error updating phone:', error);
        showToast('Error updating phone number', 'error');
    }
}

// Load parent phone numbers
async function loadParentPhones() {
    try {
        const response = await fetch(`${API_BASE}?type=admin&phone_action=get_parent_phones`);
        const data = await safeFetch(response);
        
        if (data.success && data.data) {
            parentPhonesData = data.data.items || [];
            renderParentPhones();
        } else {
            console.error('Failed to load parent phones:', data.message);
            renderParentPhones(); // Render anyway to show empty state
        }
    } catch (error) {
        console.error('Error loading parent phones:', error);
        renderParentPhones(); // Render anyway to show empty state
    }
}

// Render parent phone numbers
function renderParentPhones() {
    const tbody = document.getElementById('parentPhoneTableBody');
    if (!tbody) return;
    
    if (parentPhonesData.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" class="text-center text-muted">No parents found.</td></tr>';
        return;
    }
    
    tbody.innerHTML = parentPhonesData.map(parent => `
        <tr>
            <td>${parent.name || parent.firstName + ' ' + parent.lastName}</td>
            <td>${parent.phone || '-'}</td>
            <td>
                <button class="admin-btn admin-btn-sm admin-btn-primary" onclick="editParentPhone(${parent.id}, '${parent.phone || ''}')">
                    <i class="fas fa-edit"></i> Edit
                </button>
                ${parent.phone ? `
                <button class="admin-btn admin-btn-sm admin-btn-info" onclick="sendSmsToParent('${parent.phone || ''}', '${parent.name || parent.firstName + ' ' + parent.lastName}')">
                    <i class="fas fa-sms"></i> SMS
                </button>
                ` : ''}
            </td>
        </tr>
    `).join('');
}

// Filter parent phone list
function filterParentPhoneList() {
    const searchTerm = document.getElementById('parentPhoneSearch').value.toLowerCase();
    const filtered = parentPhonesData.filter(parent => 
        (parent.name && parent.name.toLowerCase().includes(searchTerm)) ||
        (parent.firstName && parent.firstName.toLowerCase().includes(searchTerm)) ||
        (parent.lastName && parent.lastName.toLowerCase().includes(searchTerm)) ||
        (parent.phone && parent.phone.toLowerCase().includes(searchTerm))
    );
    
    const tbody = document.getElementById('parentPhoneTableBody');
    if (filtered.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" class="text-center text-muted">No matching parents found.</td></tr>';
        return;
    }
    
    tbody.innerHTML = filtered.map(parent => `
        <tr>
            <td>${parent.name || parent.firstName + ' ' + parent.lastName}</td>
            <td>${parent.phone || '-'}</td>
            <td>
                <button class="admin-btn admin-btn-sm admin-btn-primary" onclick="editParentPhone(${parent.id}, '${parent.phone || ''}')">
                    <i class="fas fa-edit"></i> Edit
                </button>
                ${parent.phone ? `
                <button class="admin-btn admin-btn-sm admin-btn-info" onclick="sendSmsToParent('${parent.phone || ''}', '${parent.name || parent.firstName + ' ' + parent.lastName}')">
                    <i class="fas fa-sms"></i> SMS
                </button>
                ` : ''}
            </td>
        </tr>
    `).join('');
}

// Send SMS to individual parent
async function sendSmsToParent(phone, parentName) {
    const message = prompt(`Enter SMS message for ${parentName} (${phone}):`);
    if (message === null || message.trim() === '') return; // User cancelled or empty message
    
    // Load SMS APIs for selection
    try {
        const result = await apiFetch('admin', 'apis');
        if (result.success && result.data) {
            const apis = Array.isArray(result.data) ? result.data : (result.data.items || []);
            const smsApis = apis.filter(api => api.type === 'sms' && api.status === 'active');
            
            if (smsApis.length === 0) {
                showToast('No active SMS APIs configured. Please add an SMS API in API Management.', 'error');
                return;
            }
            
            if (smsApis.length === 1) {
                // Auto-select the only available SMS API
                await sendSmsViaApi(smsApis[0].id, [phone], message);
            } else {
                // Let user select SMS API
                let apiOptions = smsApis.map((api, index) => `${index + 1}. ${api.name} (${api.provider})`).join('\n');
                const selection = prompt(`Select SMS API:\n${apiOptions}\n\nEnter number (1-${smsApis.length}):`);
                
                if (selection === null) return;
                
                const selectedIndex = parseInt(selection) - 1;
                if (isNaN(selectedIndex) || selectedIndex < 0 || selectedIndex >= smsApis.length) {
                    showToast('Invalid selection', 'error');
                    return;
                }
                
                await sendSmsViaApi(smsApis[selectedIndex].id, [phone], message);
            }
        } else {
            showToast('Failed to load SMS APIs', 'error');
        }
    } catch (error) {
        console.error('Error loading SMS APIs:', error);
        showToast('Error loading SMS APIs', 'error');
    }
}

// Send SMS via specific API
async function sendSmsViaApi(apiId, phoneNumbers, message) {
    try {
        const smsData = {
            apiId: apiId,
            phoneNumbers: phoneNumbers,
            message: message.trim()
        };
        
        const response = await fetch(`${API_BASE}?type=admin&api_action=send_sms`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(smsData)
        });
        
        const result = await safeFetch(response);
        
        if (result.success) {
            showToast(`SMS sent successfully to ${result.data.success} recipient(s)`, 'success');
        } else {
            showToast(result.message || 'Failed to send SMS', 'error');
        }
    } catch (error) {
        console.error('Error sending SMS:', error);
        showToast('Error sending SMS', 'error');
    }
}

// Edit parent phone number
async function editParentPhone(id, currentPhone) {
    const newPhone = prompt('Enter new phone number:', currentPhone);
    if (newPhone === null) return; // User cancelled
    
    if (newPhone.trim() === '') {
        showToast('Phone number cannot be empty', 'error');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}?type=admin&phone_action=update_parent_phone`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id, phone: newPhone.trim() })
        });
        
        const data = await safeFetch(response);
        
        if (data.success) {
            showToast('Phone number updated successfully', 'success');
            loadParentPhones(); // Refresh the list
        } else {
            showToast(data.message || 'Failed to update phone number', 'error');
        }
    } catch (error) {
        console.error('Error updating phone:', error);
        showToast('Error updating phone number', 'error');
    }
}

// Load admin phone numbers
async function loadAdminPhones() {
    try {
        const response = await fetch(`${API_BASE}?type=admin&phone_action=get_admin_phones`);
        const data = await safeFetch(response);
        
        if (data.success && data.data) {
            adminPhonesData = data.data.items || [];
            renderAdminPhones();
        } else {
            console.error('Failed to load admin phones:', data.message);
            renderAdminPhones(); // Render anyway to show empty state
        }
    } catch (error) {
        console.error('Error loading admin phones:', error);
        renderAdminPhones(); // Render anyway to show empty state
    }
}

// Render admin phone numbers
function renderAdminPhones() {
    const tbody = document.getElementById('adminPhoneTableBody');
    if (!tbody) return;
    
    if (adminPhonesData.length === 0) {
        tbody.innerHTML = '<tr><td colspan="3" class="text-center text-muted">No admins found.</td></tr>';
        return;
    }
    
    tbody.innerHTML = adminPhonesData.map(admin => `
        <tr>
            <td>${admin.name || admin.firstName + ' ' + admin.lastName}</td>
            <td>${admin.phone || '-'}</td>
            <td>
                <button class="admin-btn admin-btn-sm admin-btn-primary" onclick="editAdminPhone(${admin.id}, '${admin.phone || ''}')">
                    <i class="fas fa-edit"></i> Edit
                </button>
            </td>
        </tr>
    `).join('');
}

// Filter admin phone list
function filterAdminPhoneList() {
    const searchTerm = document.getElementById('adminPhoneSearch').value.toLowerCase();
    const filtered = adminPhonesData.filter(admin => 
        (admin.name && admin.name.toLowerCase().includes(searchTerm)) ||
        (admin.firstName && admin.firstName.toLowerCase().includes(searchTerm)) ||
        (admin.lastName && admin.lastName.toLowerCase().includes(searchTerm)) ||
        (admin.phone && admin.phone.toLowerCase().includes(searchTerm))
    );
    
    const tbody = document.getElementById('adminPhoneTableBody');
    if (filtered.length === 0) {
        tbody.innerHTML = '<tr><td colspan="3" class="text-center text-muted">No matching admins found.</td></tr>';
        return;
    }
    
    tbody.innerHTML = filtered.map(admin => `
        <tr>
            <td>${admin.name || admin.firstName + ' ' + admin.lastName}</td>
            <td>${admin.phone || '-'}</td>
            <td>
                <button class="admin-btn admin-btn-sm admin-btn-primary" onclick="editAdminPhone(${admin.id}, '${admin.phone || ''}')">
                    <i class="fas fa-edit"></i> Edit
                </button>
            </td>
        </tr>
    `).join('');
}

// Edit admin phone number
async function editAdminPhone(id, currentPhone) {
    const newPhone = prompt('Enter new phone number:', currentPhone);
    if (newPhone === null) return; // User cancelled
    
    if (newPhone.trim() === '') {
        showToast('Phone number cannot be empty', 'error');
        return;
    }
}

// ===== USER ACTIVITIES MODAL FUNCTIONS =====
let userActivitiesData = [];

// Open User Activities Modal
function openUserActivitiesModal() {
    const overlay = document.getElementById('userActivitiesModalOverlay');
    const modal = document.getElementById('userActivitiesModal');
    if (overlay) overlay.style.display = 'block';
    if (modal) modal.style.display = 'block';
    loadUserActivities();
}

// Close User Activities Modal
function closeUserActivitiesModal() {
    const overlay = document.getElementById('userActivitiesModalOverlay');
    const modal = document.getElementById('userActivitiesModal');
    if (overlay) overlay.style.display = 'none';
    if (modal) modal.style.display = 'none';
}

// Load User Activities
async function loadUserActivities() {
    try {
        const response = await fetch(`${API_BASE}?type=admin&action=get_activities`);
        const data = await safeFetch(response);
        
        if (data.success && data.data) {
            userActivitiesData = data.data.items || (Array.isArray(data.data) ? data.data : []);
        } else {
            userActivitiesData = await generateSampleActivities();
        }
        
        updateUserActivitiesStats();
        renderUserActivities();
    } catch (error) {
        userActivitiesData = await generateSampleActivities();
        updateUserActivitiesStats();
        renderUserActivities();
    }
}

async function generateSampleActivities() {
    const activities = [];
    const now = new Date();
    
    try {
        const usersResult = await apiFetch('admin', 'users', 'GET');
        const users = usersResult.success ? (usersResult.data?.items || []) : [];
        
        users.forEach((user) => {
            const hoursAgo = Math.floor(Math.random() * 24);
            const timestamp = new Date(now - hoursAgo * 60 * 60 * 1000);
            
            activities.push({
                username: user.firstName + ' ' + user.lastName || user.username,
                user_id: user.id,
                role: user.role,
                action: 'login',
                detail: 'User logged in to system',
                timestamp: timestamp.toISOString()
            });
        });
    } catch (e) {}
    
    try {
        const regResult = await apiFetch('admin', 'registrations', 'GET');
        const registrations = regResult.success ? (regResult.data?.items || []) : [];
        
        registrations.slice(0, 5).forEach((reg) => {
            const timestamp = new Date(now - Math.random() * 48 * 60 * 60 * 1000);
            const studentName = reg.firstName || reg.first_name || reg.student_name || reg.studentName || reg.name || 'Unknown';
            const parentName = reg.parentName || reg.parent_name || reg.parent || 'Unknown';
            activities.push({
                username: parentName || studentName,
                user_id: reg.id,
                role: 'parent',
                action: 'create',
                detail: `Registration: ${studentName}`,
                timestamp: timestamp.toISOString()
            });
        });
    } catch (e) {}
    
    return activities;
}

// Update User Activities Stats
function updateUserActivitiesStats() {
    const total = userActivitiesData.length;
    const today = new Date().toDateString();
    const todayCount = userActivitiesData.filter(a => new Date(a.timestamp).toDateString() === today).length;
    const activeUsers = new Set(userActivitiesData.map(a => a.user_id || a.username)).size;
    const adminActions = userActivitiesData.filter(a => a.role === 'admin' || a.user_role === 'admin').length;
    
    document.getElementById('uaTotalCount').textContent = total;
    document.getElementById('uaTodayCount').textContent = todayCount;
    document.getElementById('uaActiveUsers').textContent = activeUsers;
    document.getElementById('uaAdminActions').textContent = adminActions;
}

// Render User Activities
function renderUserActivities() {
    const tbody = document.getElementById('userActivitiesTableBody');
    if (!tbody) return;
    
    if (userActivitiesData.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" class="text-center text-muted" style="padding: 40px;">No activities recorded yet.</td></tr>';
        return;
    }
    
    tbody.innerHTML = userActivitiesData.map(activity => `
        <tr style="border-bottom: 1px solid #e5e7eb; transition: background-color 0.2s;">
            <td style="padding: 14px 18px; vertical-align: top;">
                <div style="font-weight: 500; color: #374151; font-size: 0.9rem;">${activity.username || activity.user || 'Unknown'}</div>
                <div style="font-size: 0.8rem; color: #6b7280; margin-top: 2px;">${activity.role || activity.user_role || ''}</div>
            </td>
            <td style="padding: 14px 18px; vertical-align: top;">
                <span style="padding: 6px 12px; border-radius: 6px; font-size: 0.85rem; font-weight: 500; background: ${getActivityTypeColor(activity.action)}; color: #fff; display: inline-block;">
                    ${activity.action || activity.activity_type || 'Unknown'}
                </span>
            </td>
            <td style="padding: 14px 18px; color: #4b5563; font-size: 0.9rem; line-height: 1.5; vertical-align: top;">${activity.detail || activity.description || '-'}</td>
            <td style="padding: 14px 18px; color: #6b7280; font-size: 0.85rem; vertical-align: top; white-space: nowrap;">${formatActivityTime(activity.timestamp)}</td>
        </tr>
    `).join('');
}

// Get Activity Type Color
function getActivityTypeColor(action) {
    const colors = {
        'login': '#28a745',
        'logout': '#6c757d',
        'create': '#17a2b8',
        'update': '#ffc107',
        'delete': '#dc3545',
        'view': '#3498db',
        'system': '#6f42c1'
    };
    return colors[action?.toLowerCase()] || '#6c757d';
}

// Format Activity Time
function formatActivityTime(timestamp) {
    if (!timestamp) return '-';
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;
    
    return date.toLocaleDateString();
}

// Filter User Activities
function filterUserActivities() {
    const typeFilter = document.getElementById('uaTypeFilter')?.value || '';
    const roleFilter = document.getElementById('uaRoleFilter')?.value || '';
    const timeFilter = document.getElementById('uaTimeFilter')?.value || '';
    const searchTerm = document.getElementById('uaSearchInput')?.value?.toLowerCase() || '';
    
    let filtered = [...userActivitiesData];
    
    // Type filter
    if (typeFilter) {
        filtered = filtered.filter(a => (a.action || a.activity_type)?.toLowerCase() === typeFilter.toLowerCase());
    }
    
    // Role filter
    if (roleFilter) {
        filtered = filtered.filter(a => (a.role || a.user_role)?.toLowerCase() === roleFilter.toLowerCase());
    }
    
    // Time filter
    if (timeFilter) {
        const now = new Date();
        filtered = filtered.filter(a => {
            const activityDate = new Date(a.timestamp);
            if (timeFilter === 'today') {
                return activityDate.toDateString() === now.toDateString();
            } else if (timeFilter === 'week') {
                const weekAgo = new Date(now - 7 * 24 * 60 * 60 * 1000);
                return activityDate >= weekAgo;
            } else if (timeFilter === 'month') {
                const monthAgo = new Date(now - 30 * 24 * 60 * 60 * 1000);
                return activityDate >= monthAgo;
            }
            return true;
        });
    }
    
    // Search filter
    if (searchTerm) {
        filtered = filtered.filter(a => 
            (a.username || a.user || '').toLowerCase().includes(searchTerm) ||
            (a.detail || a.description || '').toLowerCase().includes(searchTerm) ||
            (a.action || a.activity_type || '').toLowerCase().includes(searchTerm)
        );
    }
    
    // Render filtered data
    const tbody = document.getElementById('userActivitiesTableBody');
    if (!tbody) return;
    
    if (filtered.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" class="text-center text-muted" style="padding: 40px;">No matching activities found.</td></tr>';
        return;
    }
    
    // Temporarily replace data for rendering
    const originalData = userActivitiesData;
    userActivitiesData = filtered;
    renderUserActivities();
    userActivitiesData = originalData;
}

// Refresh User Activities
function refreshUserActivities() {
    loadUserActivities();
    showToast('Activities refreshed', 'success');
}

// Export User Activities
function exportUserActivities() {
    if (userActivitiesData.length === 0) {
        showToast('No activities to export', 'error');
        return;
    }
    
    const csv = [
        ['User', 'Role', 'Action', 'Detail', 'Timestamp'].join(','),
        ...userActivitiesData.map(a => [
            a.username || a.user || '',
            a.role || a.user_role || '',
            a.action || a.activity_type || '',
            a.detail || a.description || '',
            a.timestamp || ''
        ].join(','))
    ].join('\n');
    
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `user_activities_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    
    showToast('Activities exported successfully', 'success');
}

// Initialize phone correction section when shown
function initializePhoneCorrection() {
    loadRegistrationPhones();
    loadTeacherPhones();
    loadParentPhones();
}

// ===== ACCOUNT DELETION REQUESTS =====
let deletionRequestsData = [];

// Load deletion requests
async function loadDeletionRequests() {
    const result = await apiFetch('admin', 'account_deletion_requests', 'GET');
    if (result.success && result.data) {
        deletionRequestsData = Array.isArray(result.data) ? result.data : (result.data.items || []);
        renderDeletionRequests();
        updateDeletionStats();
    } else {
        showToast('Failed to load deletion requests', 'error');
    }
}

// Render deletion requests table
function renderDeletionRequests() {
    const tbody = document.getElementById('deletionRequestsTableBody');
    if (!tbody) return;

    const statusFilter = document.getElementById('deletionStatusFilter')?.value || '';
    const typeFilter = document.getElementById('deletionTypeFilter')?.value || '';

    let filtered = deletionRequestsData.filter(r => {
        if (statusFilter && r.status !== statusFilter) return false;
        if (typeFilter && r.user_type !== typeFilter) return false;
        return true;
    });

    if (filtered.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" class="text-center text-muted">No deletion requests found.</td></tr>';
        return;
    }

    tbody.innerHTML = filtered.map((r, i) => {
        const statusClass = {
            'pending': 'badge-warning',
            'completed': 'badge-success',
            'cancelled': 'badge-info',
            'rejected': 'badge-danger'
        }[r.status] || 'badge-secondary';

        const typeIcon = r.user_type === 'teacher' ? 'fa-chalkboard-teacher' : 'fa-user-tie';

        let actions = '';
        if (r.status === 'pending') {
            actions = `
                <button class="admin-btn admin-btn-success admin-btn-sm" onclick="approveDeletion(${r.id})" title="Approve">
                    <i class="fas fa-check"></i>
                </button>
                <button class="admin-btn admin-btn-danger admin-btn-sm" onclick="rejectDeletion(${r.id})" title="Reject">
                    <i class="fas fa-times"></i>
                </button>
                <button class="admin-btn admin-btn-info admin-btn-sm" onclick="cancelDeletion(${r.id})" title="Cancel">
                    <i class="fas fa-undo"></i>
                </button>
            `;
        } else {
            actions = `<span class="text-muted text-sm">Processed</span>`;
        }

        return `
            <tr>
                <td>${i + 1}</td>
                <td><strong>${r.user_name}</strong></td>
                <td><i class="fas ${typeIcon}"></i> ${r.user_type}</td>
                <td>${r.email || '-'}</td>
                <td>${formatDate(r.requested_at)}</td>
                <td>${formatDate(r.scheduled_deletion_at)}</td>
                <td><span class="badge ${statusClass}">${r.status}</span></td>
                <td>${actions}</td>
            </tr>
        `;
    }).join('');
}

// Update deletion stats
function updateDeletionStats() {
    const pending = deletionRequestsData.filter(r => r.status === 'pending').length;
    const completed = deletionRequestsData.filter(r => r.status === 'completed').length;
    const cancelled = deletionRequestsData.filter(r => r.status === 'cancelled').length;
    const rejected = deletionRequestsData.filter(r => r.status === 'rejected').length;

    document.getElementById('pendingDeletionsCount').textContent = pending;
    document.getElementById('completedDeletionsCount').textContent = completed;
    document.getElementById('cancelledDeletionsCount').textContent = cancelled;
    document.getElementById('rejectedDeletionsCount').textContent = rejected;

    // Update badge
    const badge = document.getElementById('deletionBadge');
    if (badge) {
        badge.textContent = pending;
        badge.style.display = pending > 0 ? 'inline-block' : 'none';
    }
}

// Approve deletion request
async function approveDeletion(requestId) {
    if (!confirm('Are you sure you want to approve this deletion request? This will permanently delete the user account.')) {
        return;
    }

    try {
        const response = await fetch(`${API_BASE}?type=admin&collection=account_deletion_requests&deletion_action=approve`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: requestId })
        });
        const result = await safeFetch(response);
        
        if (result.success) {
            showToast('Account deleted successfully', 'success');
            loadDeletionRequests();
        } else {
            showToast(result.message || 'Failed to approve deletion', 'error');
        }
    } catch (err) {
        showToast('Error approving deletion', 'error');
        console.error(err);
    }
}

// Reject deletion request
async function rejectDeletion(requestId) {
    const adminNotes = prompt('Enter reason for rejection (optional):');
    if (adminNotes === null) return; // User cancelled

    try {
        const response = await fetch(`${API_BASE}?type=admin&collection=account_deletion_requests&deletion_action=reject`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: requestId, adminNotes: adminNotes })
        });
        const result = await safeFetch(response);
        
        if (result.success) {
            showToast('Deletion request rejected', 'success');
            loadDeletionRequests();
        } else {
            showToast(result.message || 'Failed to reject deletion', 'error');
        }
    } catch (err) {
        showToast('Error rejecting deletion', 'error');
        console.error(err);
    }
}

// Cancel deletion request
async function cancelDeletion(requestId) {
    if (!confirm('Are you sure you want to cancel this deletion request?')) {
        return;
    }

    try {
        const response = await fetch(`${API_BASE}?type=admin&collection=account_deletion_requests&deletion_action=cancel`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: requestId })
        });
        const result = await safeFetch(response);
        
        if (result.success) {
            showToast('Deletion request cancelled', 'success');
            loadDeletionRequests();
        } else {
            showToast(result.message || 'Failed to cancel deletion', 'error');
        }
    } catch (err) {
        showToast('Error cancelling deletion', 'error');
        console.error(err);
    }
}

// Format date helper
function formatDate(dateStr) {
    if (!dateStr) return '-';
    const d = new Date(dateStr);
    return d.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

// Format file size helper
function formatFileSize(bytes) {
    if (!bytes) return '-';
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
}

// ===== TEACHER FILES FUNCTIONS =====

// Open teacher file modal
function openTeacherFileModal() {
    document.getElementById('teacherFileModalTitle').innerHTML = '<i class="fas fa-file-upload"></i> Upload File to Teachers';
    document.getElementById('teacherFileForm').reset();
    document.getElementById('teacherFileEditId').value = '';
    document.getElementById('teacherFileSpecificTeachers').style.display = 'none';
    document.getElementById('teacherFileModal').style.display = 'flex';
    
    // Load teachers for specific selection
    loadTeachersForFileSelection();
}

// Load teachers for file selection
async function loadTeachersForFileSelection() {
    try {
        const result = await apiFetch('admin', 'teachers', 'GET');
        if (result.success && result.items) {
            const container = document.getElementById('teacherFileTeachersList');
            container.innerHTML = '';
            
            result.items.forEach(teacher => {
                const checkbox = document.createElement('div');
                checkbox.className = 'checkbox-label';
                checkbox.style.marginBottom = '8px';
                checkbox.innerHTML = `
                    <input type="checkbox" name="selectedTeachers" value="${teacher.id}">
                    <span>${teacher.first_name} ${teacher.last_name}</span>
                `;
                container.appendChild(checkbox);
            });
        }
    } catch (err) {
        console.error('Error loading teachers:', err);
    }
}

// Handle target type change
document.addEventListener('DOMContentLoaded', function() {
    const targetSelect = document.getElementById('teacherFileTarget');
    if (targetSelect) {
        targetSelect.addEventListener('change', function() {
            const specificDiv = document.getElementById('teacherFileSpecificTeachers');
            specificDiv.style.display = this.value === 'specific' ? 'block' : 'none';
        });
    }
});

// Save teacher file
async function saveTeacherFile(event) {
    event.preventDefault();
    
    const form = document.getElementById('teacherFileForm');
    const fileInput = document.getElementById('teacherFile');
    
    if (fileInput.files.length === 0) {
        showToast('Please select a file', 'error');
        return;
    }
    
    const formData = new FormData(form);
    formData.append('title', document.getElementById('teacherFileTitle').value);
    formData.append('description', document.getElementById('teacherFileDescription').value);
    formData.append('targetType', document.getElementById('teacherFileTarget').value);
    formData.append('priority', document.getElementById('teacherFilePriority').value);
    formData.append('uploadedBy', currentUser?.username || 'admin');
    
    // Get selected teachers if specific
    if (document.getElementById('teacherFileTarget').value === 'specific') {
        const selectedTeachers = Array.from(document.querySelectorAll('input[name="selectedTeachers"]:checked'))
            .map(cb => cb.value)
            .join(',');
        formData.append('targetTeachers', selectedTeachers);
    }
    
    try {
        const response = await fetch(`${API_BASE}?type=admin&teacher_file_action=upload`, {
            method: 'POST',
            body: formData
        });
        
        const result = await safeFetch(response);
        
        if (result.success) {
            showToast('File uploaded successfully', 'success');
            closeModal();
            loadTeacherFiles();
        } else {
            showToast(result.message || 'Failed to upload file', 'error');
        }
    } catch (err) {
        showToast('Error uploading file', 'error');
        console.error(err);
    }
    
    return false;
}

// Load teacher files
async function loadTeacherFiles() {
    try {
        const result = await apiFetch('admin', 'teacher_files', 'GET');
        if (result.success && result.items) {
            renderTeacherFiles(result.items);
        }
    } catch (err) {
        console.error('Error loading teacher files:', err);
    }
}

// Render teacher files table
function renderTeacherFiles(files) {
    const tbody = document.getElementById('teacherFilesTableBody');
    const filter = document.getElementById('teacherFileTypeFilter')?.value || '';
    
    const filteredFiles = filter ? files.filter(f => f.file_type === filter) : files;
    
    if (filteredFiles.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted">No files uploaded yet.</td></tr>';
        return;
    }
    
    tbody.innerHTML = filteredFiles.map(file => `
        <tr>
            <td>${file.id}</td>
            <td>
                <strong>${file.title}</strong>
                ${file.description ? `<br><small class="text-muted">${file.description}</small>` : ''}
            </td>
            <td><span class="badge badge-${getFileBadgeClass(file.file_type)}">${file.file_type.toUpperCase()}</span></td>
            <td>${formatFileSize(file.file_size)}</td>
            <td>${file.uploaded_by}</td>
            <td>${formatDate(file.created_at)}</td>
            <td>
                <button class="admin-btn admin-btn-sm admin-btn-info" onclick="downloadTeacherFile(${file.id})" title="Download">
                    <i class="fas fa-download"></i>
                </button>
                <button class="admin-btn admin-btn-sm admin-btn-danger" onclick="deleteTeacherFile(${file.id})" title="Delete">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        </tr>
    `).join('');
}

// Get badge class for file type
function getFileBadgeClass(type) {
    const classes = {
        'pdf': 'danger',
        'excel': 'success',
        'word': 'primary',
        'powerpoint': 'warning',
        'other': 'secondary'
    };
    return classes[type] || 'secondary';
}

// Download teacher file
function downloadTeacherFile(fileId) {
    // This would typically open the file in a new tab or trigger download
    // For now, we'll show a message
    showToast('Download functionality to be implemented', 'info');
}

// Delete teacher file
async function deleteTeacherFile(fileId) {
    if (!confirm('Are you sure you want to delete this file?')) {
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}?type=admin&teacher_file_action=delete&id=${fileId}`, {
            method: 'POST'
        });
        
        const result = await safeFetch(response);
        
        if (result.success) {
            showToast('File deleted successfully', 'success');
            loadTeacherFiles();
        } else {
            showToast(result.message || 'Failed to delete file', 'error');
        }
    } catch (err) {
        showToast('Error deleting file', 'error');
        console.error(err);
    }
}

// ===== TIMETABLE FUNCTIONS =====

const TIME_SLOTS = [
    '7:30 AM - 8:15 AM',
    '8:15 AM - 9:00 AM',
    '9:00 AM - 9:45 AM',
    '9:45 AM - 10:30 AM',
    '10:30 AM - 10:45 AM',
    '10:45 AM - 11:30 AM',
    '11:30 AM - 12:15 PM',
    '12:15 PM - 1:00 PM',
    '1:00 PM - 1:30 PM',
    '1:30 PM - 2:15 PM',
    '2:15 PM - 3:00 PM',
    '3:00 PM - 3:45 PM'
];

const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];

let timetableData = {};
let teachers = [];

// Load timetable data
async function loadTimetable() {
    try {
        const result = await apiFetch('admin', 'timetable');
        if (result.success && result.items) {
            timetableData = {};
            result.items.forEach(entry => {
                const key = `${entry.day}_${entry.time}`;
                timetableData[key] = entry;
            });
            renderTimetable();
        }
    } catch (err) {
        console.error('Error loading timetable:', err);
    }
}

// Load teachers for dropdown
async function loadTimetableTeachers() {
    try {
        const result = await apiFetch('admin', 'teachers');
        if (result.success && result.items) {
            teachers = result.items;
            const teacherSelect = document.getElementById('timetableTeacher');
            if (teacherSelect) {
                teacherSelect.innerHTML = '<option value="">Select Teacher</option>';
                teachers.forEach(teacher => {
                    const option = document.createElement('option');
                    option.value = teacher.id;
                    option.textContent = `${teacher.first_name} ${teacher.last_name}`;
                    teacherSelect.appendChild(option);
                });
            }
        }
    } catch (err) {
        console.error('Error loading teachers:', err);
    }
}

// Render timetable grid
function renderTimetable() {
    const tbody = document.getElementById('timetableBody');
    if (!tbody) return;
    
    const classFilter = document.getElementById('timetableClassFilter')?.value || '';
    const dayFilter = document.getElementById('timetableDayFilter')?.value || '';
    
    tbody.innerHTML = '';
    
    TIME_SLOTS.forEach(time => {
        const tr = document.createElement('tr');
        
        // Time column
        const timeTd = document.createElement('td');
        timeTd.textContent = time;
        timeTd.style.fontWeight = '600';
        timeTd.style.color = '#085636';
        timeTd.style.background = '#f7fbf8';
        tr.appendChild(timeTd);
        
        // Day columns
        DAYS.forEach(day => {
            const td = document.createElement('td');
            const key = `${day}_${time}`;
            const entry = timetableData[key];
            
            // Apply filters
            if (classFilter && entry && entry.class_name !== classFilter) {
                td.style.display = 'none';
            }
            if (dayFilter && day !== dayFilter) {
                td.style.display = 'none';
            }
            
            if (entry && entry.subject) {
                td.innerHTML = `
                    <div style="padding: 8px; border: 1px solid #e5e7eb; border-radius: 6px; background: #fff; cursor: pointer;" onclick="editTimetableEntry('${key}')">
                        <div style="font-weight: 600; color: #085636; font-size: 13px;">${entry.subject}</div>
                        <div style="font-size: 12px; color: #6b7280;">${entry.class_name}</div>
                        <div style="font-size: 11px; color: #9ca3af; font-style: italic;">${getTeacherName(entry.teacher_id)}</div>
                    </div>
                    <button onclick="event.stopPropagation(); deleteTimetableEntry('${key}')" style="margin-top: 4px; padding: 4px 8px; background: #fee2e2; color: #dc3545; border: none; border-radius: 4px; cursor: pointer; font-size: 11px;">Delete</button>
                `;
            } else {
                td.innerHTML = `
                    <div style="padding: 12px; border: 1px dashed #d1d5db; border-radius: 6px; background: #f9fafb; cursor: pointer; text-align: center; color: #9ca3af; font-size: 12px;" onclick="openTimetableModalForCell('${day}', '${time}')">
                        + Add Schedule
                    </div>
                `;
            }
            
            tr.appendChild(td);
        });
        
        tbody.appendChild(tr);
    });
}

function getTeacherName(teacherId) {
    const teacher = teachers.find(t => t.id == teacherId);
    return teacher ? `${teacher.first_name} ${teacher.last_name}` : 'Unknown';
}

// Open timetable modal for new entry
function openTimetableModal() {
    document.getElementById('timetableModalTitle').innerHTML = '<i class="fas fa-calendar-alt"></i> Add Schedule';
    document.getElementById('timetableForm').reset();
    document.getElementById('timetableEditId').value = '';
    
    document.getElementById('modalOverlay').classList.add('show');
    document.getElementById('timetableModal').classList.add('show');
    
    loadTimetableTeachers();
}

// Open timetable modal for specific cell
function openTimetableModalForCell(day, time) {
    document.getElementById('timetableModalTitle').innerHTML = '<i class="fas fa-calendar-alt"></i> Add Schedule';
    document.getElementById('timetableForm').reset();
    document.getElementById('timetableEditId').value = '';
    document.getElementById('timetableDay').value = day;
    
    // Parse time to set time input
    const timeMatch = time.match(/(\d+):(\d+)\s*(AM|PM)/i);
    if (timeMatch) {
        let hours = parseInt(timeMatch[1]);
        const minutes = timeMatch[2];
        const meridiem = timeMatch[3].toUpperCase();
        
        if (meridiem === 'PM' && hours !== 12) hours += 12;
        if (meridiem === 'AM' && hours === 12) hours = 0;
        
        const timeStr = `${hours.toString().padStart(2, '0')}:${minutes}`;
        document.getElementById('timetableTime').value = timeStr;
    }
    
    document.getElementById('modalOverlay').classList.add('show');
    document.getElementById('timetableModal').classList.add('show');
    
    loadTimetableTeachers();
}

// Edit existing timetable entry
function editTimetableEntry(key) {
    const entry = timetableData[key];
    if (!entry) return;
    
    document.getElementById('timetableModalTitle').innerHTML = '<i class="fas fa-calendar-alt"></i> Edit Schedule';
    document.getElementById('timetableEditId').value = entry.id;
    document.getElementById('timetableDay').value = entry.day;
    document.getElementById('timetableSubject').value = entry.subject;
    document.getElementById('timetableClass').value = entry.class_name;
    document.getElementById('timetableTeacher').value = entry.teacher_id;
    document.getElementById('timetableRoom').value = entry.room || '';
    
    document.getElementById('modalOverlay').classList.add('show');
    document.getElementById('timetableModal').classList.add('show');
    
    loadTimetableTeachers();
}

// Save timetable entry
async function saveTimetable(event) {
    event.preventDefault();
    
    const editId = document.getElementById('timetableEditId').value;
    const day = document.getElementById('timetableDay').value;
    const time = document.getElementById('timetableTime').value;
    const subject = document.getElementById('timetableSubject').value;
    const className = document.getElementById('timetableClass').value;
    const teacherId = document.getElementById('timetableTeacher').value;
    const room = document.getElementById('timetableRoom').value;
    
    if (!day || !time || !subject || !className || !teacherId) {
        showToast('Please fill in all required fields', 'error');
        return;
    }
    
    // Format time for display
    const timeDisplay = formatTimeForDisplay(time);
    const key = `${day}_${timeDisplay}`;
    
    const entryData = {
        day: day,
        time: timeDisplay,
        subject: subject,
        class_name: className,
        teacher_id: teacherId,
        room: room
    };
    
    try {
        let result;
        if (editId) {
            result = await apiFetch('admin', 'timetable', 'PUT', entryData, editId);
        } else {
            result = await apiFetch('admin', 'timetable', 'POST', entryData);
        }
        
        if (result.success) {
            if (editId) {
                entryData.id = editId;
            } else {
                entryData.id = result.id || Date.now();
            }
            timetableData[key] = entryData;
            
            renderTimetable();
            closeModal();
            showToast('Schedule saved successfully', 'success');
        } else {
            showToast(result.message || 'Failed to save schedule', 'error');
        }
    } catch (err) {
        console.error('Error saving timetable:', err);
        showToast('Error saving schedule', 'error');
    }
}

function formatTimeForDisplay(timeStr) {
    const [hours, minutes] = timeStr.split(':');
    const hour = parseInt(hours);
}

// ===== TEACHER FILES =====
async function loadTeacherFiles() {
    try {
        const result = await fetch(`${API_BASE}?type=admin&collection=teacher_files&teacher_files_action=get_all`, {
            method: 'GET',
            headers: { 'Content-Type': 'application/json' }
        });
        const data = await result.json();
        
        if (data.success) {
            renderTeacherFiles(data.data.items);
        } else {
            document.getElementById('teacherFilesList').innerHTML = '<p class="text-muted">Failed to load teacher files.</p>';
        }
    } catch (err) {
        console.error('Error loading teacher files:', err);
        document.getElementById('teacherFilesList').innerHTML = '<p class="text-muted">Error loading teacher files.</p>';
    }
}

function renderTeacherFiles(files) {
    const container = document.getElementById('teacherFilesList');
    if (!container) return;
    
    if (!files || files.length === 0) {
        container.innerHTML = '<p class="text-muted">No files uploaded by teachers yet.</p>';
        return;
    }
    
    let html = '<div class="table-responsive"><table class="admin-table"><thead><tr><th>Teacher</th><th>Title</th><th>Category</th><th>File</th><th>Status</th><th>Date</th><th>Actions</th></tr></thead><tbody>';
    
    files.forEach(file => {
        const fileSize = formatFileSize(file.fileSize);
        const statusClass = file.status === 'approved' ? 'status-active' : file.status === 'rejected' ? 'status-inactive' : 'status-pending';
        
        html += `
            <tr>
                <td><strong>${file.teacherName}</strong></td>
                <td>${file.title}</td>
                <td><span class="badge badge-secondary">${file.category}</span></td>
                <td>
                    <a href="${file.fileUrl}" target="_blank" class="btn-link">${file.fileName}</a>
                    <br><small class="text-muted">${fileSize}</small>
                </td>
                <td><span class="${statusClass}">${file.status}</span></td>
                <td>${formatDate(file.createdAt)}</td>
                <td>
                    <a href="${file.fileUrl}" target="_blank" class="btn btn-sm btn-info"><i class="fas fa-download"></i></a>
                    <button class="btn btn-sm btn-success" onclick="approveTeacherFile(${file.id})"><i class="fas fa-check"></i></button>
                    <button class="btn btn-sm btn-danger" onclick="rejectTeacherFile(${file.id})"><i class="fas fa-times"></i></button>
                </td>
            </tr>
        `;
    });
    
    html += '</tbody></table></div>';
    container.innerHTML = html;
}

function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
}

async function approveTeacherFile(fileId) {
    const notes = prompt('Enter optional admin notes (leave blank for none):');
    try {
        const result = await fetch(`${API_BASE}?type=admin&collection=teacher_files&teacher_files_action=update_status&id=${fileId}&status=approved&admin_notes=${encodeURIComponent(notes || '')}`, {
            method: 'GET',
            headers: { 'Content-Type': 'application/json' }
        });
        const data = await result.json();
        
        if (data.success) {
            showToast('File approved successfully', 'success');
            loadTeacherFiles();
        } else {
            showToast(data.message || 'Failed to approve file', 'error');
        }
    } catch (err) {
        console.error('Error approving file:', err);
        showToast('Error approving file', 'error');
    }
}

async function rejectTeacherFile(fileId) {
    const notes = prompt('Enter rejection reason (required):');
    if (!notes) return;
    
    try {
        const result = await fetch(`${API_BASE}?type=admin&collection=teacher_files&teacher_files_action=update_status&id=${fileId}&status=rejected&admin_notes=${encodeURIComponent(notes)}`, {
            method: 'GET',
            headers: { 'Content-Type': 'application/json' }
        });
        const data = await result.json();
        
        if (data.success) {
            showToast('File rejected', 'warning');
            loadTeacherFiles();
        } else {
            showToast(data.message || 'Failed to reject file', 'error');
        }
    } catch (err) {
        console.error('Error rejecting file:', err);
        showToast('Error rejecting file', 'error');
    }
}

function formatTimeForDisplay(timeStr) {
    const [hours, minutes] = timeStr.split(':');
    const hour = parseInt(hours);
    const meridiem = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour % 12 || 12;
    return `${displayHour}:${minutes} ${meridiem}`;
}

// Delete timetable entry
async function deleteTimetableEntry(key) {
    if (!confirm('Are you sure you want to delete this schedule?')) {
        return;
    }
    
    const entry = timetableData[key];
    if (!entry || !entry.id) {
        delete timetableData[key];
        renderTimetable();
        showToast('Schedule deleted', 'success');
        return;
    }
    
    try {
        const result = await apiFetch('admin', 'timetable', 'DELETE', null, entry.id);
        
        if (result.success) {
            delete timetableData[key];
            renderTimetable();
            showToast('Schedule deleted successfully', 'success');
        } else {
            showToast(result.message || 'Failed to delete schedule', 'error');
        }
    } catch (err) {
        console.error('Error deleting timetable:', err);
        showToast('Error deleting schedule', 'error');
    }
}

// Export timetable
function exportTimetable() {
    showToast('Export feature coming soon', 'info');
}

// Initialize timetable when section is shown
const originalShowSection = window.showSection;
window.showSection = function(sectionName) {
    originalShowSection(sectionName);
    if (sectionName === 'timetable') {
        loadTimetable();
        loadTimetableTeachers();
    }
    if (sectionName === 'location_analytics') {
        loadLocationAnalytics();
    }
    // Hide default credentials warning when going to settings
    if (sectionName === 'settings') {
        dismissDefaultCredentialsWarning();
        loadGoogleMapsApiKey();
    }
};

// Export default credentials functions to window
window.checkDefaultCredentials = checkDefaultCredentials;
window.showDefaultCredentialsWarning = showDefaultCredentialsWarning;
window.dismissDefaultCredentialsWarning = dismissDefaultCredentialsWarning;

// ===== LOCATION ANALYTICS =====
let locationData = [];
let map = null;
let markers = [];
let heatmap = null;
let topCountriesChart = null;
let userDistributionChart = null;
let mapUpdateInterval = null;
let isMapUpdating = false;

// Load location analytics data
async function loadLocationAnalytics() {
    try {
        // Show loading state
        document.getElementById('locationTableBody').innerHTML = '<tr><td colspan="9" class="text-center"><i class="fas fa-spinner fa-spin"></i> Loading location data...</td></tr>';
        document.getElementById('mapLoading').style.display = 'flex';
        document.getElementById('locationMap').style.display = 'none';

        // Load real visitor data from tracking API
        const response = await fetch(`${API_BASE}?type=visitor_tracking&action=get_visitors&limit=100`);
        const result = await safeFetch(response);
        
        if (result.success && result.data) {
            // Transform visitor data to location data format
            locationData = result.data.map(visitor => ({
                ip: visitor.ip_address || 'Unknown',
                city: visitor.city || 'Unknown',
                region: visitor.region || 'Unknown',
                country: visitor.country || 'Unknown',
                lat: parseFloat(visitor.latitude) || 0,
                lng: parseFloat(visitor.longitude) || 0,
                isp: visitor.isp || 'Unknown',
                last_access: visitor.last_activity || visitor.first_visit,
                session_id: visitor.session_id,
                page_views: visitor.page_views || 0,
                user_agent: visitor.user_agent,
                referrer: visitor.referrer
            }));
            
            // Load analytics data
            await loadVisitorAnalytics();
        } else {
            // Generate sample data for demonstration if no real data
            locationData = generateSampleLocationData();
            showToast('No visitor data found - using sample data', 'info');
        }

        renderLocationTable();
        updateLocationStats();
        populateCountryFilter();
        initializeMap();
        renderCharts();
        renderVisitorTimeline();
        
        document.getElementById('mapLoading').style.display = 'none';
        document.getElementById('locationMap').style.display = 'block';
        
        showToast('Location data loaded successfully', 'success');
    } catch (error) {
        console.error('Error loading location analytics:', error);
        locationData = generateSampleLocationData();
        renderLocationTable();
        updateLocationStats();
        populateCountryFilter();
        initializeMap();
        renderCharts();
        renderVisitorTimeline();
        
        document.getElementById('mapLoading').style.display = 'none';
        document.getElementById('locationMap').style.display = 'block';
        
        showToast('Using sample location data due to error', 'info');
    }
}

// Load visitor analytics statistics
async function loadVisitorAnalytics() {
    try {
        const response = await fetch(`${API_BASE}?type=visitor_tracking&action=get_analytics`);
        const result = await safeFetch(response);
        
        if (result.success && result.data) {
            const stats = result.data.statistics || {};
            
            // Update statistics with real data
            document.getElementById('totalUsersTracked').textContent = stats.total_visitors || locationData.length;
            document.getElementById('uniqueCountries').textContent = stats.unique_countries || [...new Set(locationData.map(loc => loc.country))].length;
            document.getElementById('uniqueCities').textContent = stats.unique_cities || [...new Set(locationData.map(loc => loc.city))].length;
            document.getElementById('recentActivity').textContent = stats.recent_activity || 0;
            
            // Store additional analytics data
            window.visitorAnalytics = {
                topCountries: result.data.top_countries || [],
                topCities: result.data.top_cities || [],
                visitorTrends: result.data.visitor_trends || [],
                onlineVisitors: stats.online_visitors || 0
            };
        }
    } catch (error) {
        console.error('Error loading visitor analytics:', error);
    }
}

// Generate sample location data for demonstration
function generateSampleLocationData() {
    const sampleLocations = [
        { ip: '192.168.1.1', city: 'New York', region: 'New York', country: 'United States', lat: 40.7128, lng: -74.0060, isp: 'Comcast Cable', last_access: new Date().toISOString() },
        { ip: '10.0.0.1', city: 'Los Angeles', region: 'California', country: 'United States', lat: 34.0522, lng: -118.2437, isp: 'AT&T', last_access: new Date(Date.now() - 3600000).toISOString() },
        { ip: '172.16.0.1', city: 'Chicago', region: 'Illinois', country: 'United States', lat: 41.8781, lng: -87.6298, isp: 'Verizon', last_access: new Date(Date.now() - 7200000).toISOString() },
        { ip: '192.168.1.2', city: 'London', region: 'England', country: 'United Kingdom', lat: 51.5074, lng: -0.1278, isp: 'BT', last_access: new Date(Date.now() - 14400000).toISOString() },
        { ip: '10.0.0.2', city: 'Toronto', region: 'Ontario', country: 'Canada', lat: 43.6532, lng: -79.3832, isp: 'Rogers', last_access: new Date(Date.now() - 28800000).toISOString() },
        { ip: '172.16.0.2', city: 'Sydney', region: 'New South Wales', country: 'Australia', lat: -33.8688, lng: 151.2093, isp: 'Telstra', last_access: new Date(Date.now() - 43200000).toISOString() },
        { ip: '192.168.1.3', city: 'Berlin', region: 'Berlin', country: 'Germany', lat: 52.5200, lng: 13.4050, isp: 'Deutsche Telekom', last_access: new Date(Date.now() - 86400000).toISOString() },
        { ip: '10.0.0.3', city: 'Paris', region: 'Île-de-France', country: 'France', lat: 48.8566, lng: 2.3522, isp: 'Orange', last_access: new Date(Date.now() - 172800000).toISOString() },
        { ip: '172.16.0.3', city: 'Tokyo', region: 'Tokyo', country: 'Japan', lat: 35.6762, lng: 139.6503, isp: 'NTT', last_access: new Date(Date.now() - 259200000).toISOString() },
        { ip: '192.168.1.4', city: 'Mumbai', region: 'Maharashtra', country: 'India', lat: 19.0760, lng: 72.8777, isp: 'Airtel', last_access: new Date(Date.now() - 345600000).toISOString() },
        { ip: '10.0.0.4', city: 'São Paulo', region: 'São Paulo', country: 'Brazil', lat: -23.5505, lng: -46.6333, isp: 'Claro', last_access: new Date(Date.now() - 432000000).toISOString() },
        { ip: '172.16.0.4', city: 'Cape Town', region: 'Western Cape', country: 'South Africa', lat: -33.9249, lng: 18.4241, isp: 'Vodacom', last_access: new Date(Date.now() - 518400000).toISOString() },
        { ip: '192.168.1.5', city: 'Dubai', region: 'Dubai', country: 'United Arab Emirates', lat: 25.2048, lng: 55.2708, isp: 'Etisalat', last_access: new Date(Date.now() - 604800000).toISOString() },
        { ip: '10.0.0.5', city: 'Singapore', region: 'Singapore', country: 'Singapore', lat: 1.3521, lng: 103.8198, isp: 'Singtel', last_access: new Date(Date.now() - 691200000).toISOString() },
        { ip: '172.16.0.5', city: 'Mexico City', region: 'Mexico City', country: 'Mexico', lat: 19.4326, lng: -99.1332, isp: 'Telcel', last_access: new Date(Date.now() - 777600000).toISOString() }
    ];
    
    return sampleLocations;
}

// ===== ADMIN ONBOARDING FUNCTIONS =====
function checkAdminOnboardingStatus() {
    const onboardingStatus = localStorage.getItem('admin_onboarding_completed');
    return onboardingStatus === 'true';
}

function initializeAdminOnboarding() {
    if (!checkAdminOnboardingStatus()) {
        setTimeout(() => {
            openAdminOnboarding();
        }, 1000);
    } else {
        const helpButton = document.getElementById('adminHelpButton');
        if (helpButton) {
            helpButton.style.display = 'flex';
        }
    }
}

function openAdminOnboarding() {
    adminOnboardingStep = 1;
    updateAdminOnboardingUI();
    document.getElementById('adminOnboardingModal').style.display = 'flex';
}

function closeAdminOnboarding() {
    document.getElementById('adminOnboardingModal').style.display = 'none';
}

function nextAdminOnboardingStep() {
    if (adminOnboardingStep < adminTotalOnboardingSteps) {
        adminOnboardingStep++;
        updateAdminOnboardingUI();
    }
}

function prevAdminOnboardingStep() {
    if (adminOnboardingStep > 1) {
        adminOnboardingStep--;
        updateAdminOnboardingUI();
    }
}

function updateAdminOnboardingUI() {
    // Update progress bar
    const progress = (adminOnboardingStep / adminTotalOnboardingSteps) * 100;
    document.getElementById('adminOnboardingProgress').style.width = progress + '%';
    document.getElementById('adminOnboardingStep').textContent = adminOnboardingStep;

    // Hide all steps
    for (let i = 1; i <= adminTotalOnboardingSteps; i++) {
        document.getElementById(`adminStep${i}`).style.display = 'none';
    }

    // Show current step
    document.getElementById(`adminStep${adminOnboardingStep}`).style.display = 'block';

    // Update buttons
    document.getElementById('adminOnboardingBack').style.display = adminOnboardingStep > 1 ? 'inline-block' : 'none';
    document.getElementById('adminOnboardingNext').style.display = adminOnboardingStep < adminTotalOnboardingSteps ? 'inline-block' : 'none';
    document.getElementById('adminOnboardingComplete').style.display = adminOnboardingStep === adminTotalOnboardingSteps ? 'inline-block' : 'none';
}

function completeAdminOnboarding() {
    localStorage.setItem('admin_onboarding_completed', 'true');
    adminOnboardingCompleted = true;
    closeAdminOnboarding();
    const helpButton = document.getElementById('adminHelpButton');
    if (helpButton) {
        helpButton.style.display = 'flex';
    }
    // Use the existing showToast function from admin.js
    const toast = document.createElement('div');
    toast.className = 'toast toast-success';
    toast.innerHTML = '<i class="fas fa-check-circle"></i> Welcome aboard! You can always revisit this tutorial by clicking the help button.';
    const container = document.getElementById('toastContainer');
    if (container) {
        container.appendChild(toast);
        setTimeout(() => {
            toast.classList.add('toast-removing');
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }
}

function skipAdminOnboarding() {
    if (confirm('Are you sure you want to skip this tutorial? You can always access it later from the help button.')) {
        completeAdminOnboarding();
    }
}

// Render location table
function renderLocationTable(data = locationData) {
    const tbody = document.getElementById('locationTableBody');
    if (!tbody) return;

    if (data.length === 0) {
        tbody.innerHTML = '<tr><td colspan="10" class="text-center text-muted">No location data available.</td></tr>';
        return;
    }

    tbody.innerHTML = data.map((location, index) => `
        <tr>
            <td>${index + 1}</td>
            <td><code class="location-coordinates">${location.ip || 'N/A'}</code></td>
            <td>${location.city || 'N/A'}</td>
            <td>${location.region || 'N/A'}</td>
            <td>
                <span class="location-badge">${location.country || 'N/A'}</span>
            </td>
            <td><code class="location-coordinates">${location.lat?.toFixed(4) || 'N/A'}, ${location.lng?.toFixed(4) || 'N/A'}</code></td>
            <td>${location.isp || 'N/A'}</td>
            <td><span class="location-badge">${location.page_views || 0}</span></td>
            <td>${formatDate(location.last_access) || 'N/A'}</td>
            <td>
                <button class="location-action-btn admin-btn admin-btn-sm admin-btn-primary" onclick="viewOnMap(${location.lat}, ${location.lng})" title="View on Map">
                    <i class="fas fa-map-marker-alt"></i>
                </button>
                <button class="location-action-btn admin-btn admin-btn-sm admin-btn-info" onclick="getVisitorDetails('${location.session_id}')" title="Details">
                    <i class="fas fa-info-circle"></i>
                </button>
                <button class="location-action-btn admin-btn admin-btn-sm admin-btn-secondary" onclick="getVisitorAddress(${location.lat}, ${location.lng})" title="Get Address">
                    <i class="fas fa-address-card"></i>
                </button>
            </td>
        </tr>
    `).join('');
}

// Update location statistics
function updateLocationStats() {
    const totalUsers = locationData.length;
    const uniqueCountries = [...new Set(locationData.map(loc => loc.country))].length;
    const uniqueCities = [...new Set(locationData.map(loc => loc.city))].length;
    const totalPageViews = locationData.reduce((sum, loc) => sum + (loc.page_views || 0), 0);
    
    // Calculate recent activity (last 24 hours)
    const twentyFourHoursAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const recentActivity = locationData.filter(loc => new Date(loc.last_access) > twentyFourHoursAgo).length;
    
    // Calculate online visitors (last 5 minutes)
    const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000);
    const onlineVisitors = locationData.filter(loc => new Date(loc.last_access) > fiveMinutesAgo).length;

    document.getElementById('totalUsersTracked').textContent = totalUsers;
    document.getElementById('uniqueCountries').textContent = uniqueCountries;
    document.getElementById('uniqueCities').textContent = uniqueCities;
    document.getElementById('recentActivity').textContent = recentActivity;
    document.getElementById('onlineVisitors').textContent = onlineVisitors;
    document.getElementById('totalPageViews').textContent = totalPageViews;
}

// Populate country filter dropdown
function populateCountryFilter() {
    const countryFilter = document.getElementById('countryFilter');
    if (!countryFilter) return;

    const countries = [...new Set(locationData.map(loc => loc.country))].sort();
    
    // Clear existing options except the first one
    while (countryFilter.options.length > 1) {
        countryFilter.remove(1);
    }

    countries.forEach(country => {
        const option = document.createElement('option');
        option.value = country;
        option.textContent = country;
        countryFilter.appendChild(option);
    });
}

// Initialize Google Map
function initializeMap() {
    const mapElement = document.getElementById('locationMap');
    if (!mapElement) return;

    // Check if Google Maps API is loaded
    if (typeof google === 'undefined' || !google.maps) {
        // Load Google Maps API dynamically
        loadGoogleMapsScript().then(() => {
            createMap();
        }).catch(err => {
            console.error('Failed to load Google Maps:', err);
            mapElement.innerHTML = '<div class="text-center" style="padding: 50px;"><i class="fas fa-exclamation-triangle" style="font-size: 48px; color: #e74c3c;"></i><p style="margin-top: 20px;">Google Maps API not configured. Please add your API key in settings.</p></div>';
        });
    } else {
        createMap();
    }
}

// Load Google Maps script dynamically
function loadGoogleMapsScript() {
    return new Promise((resolve, reject) => {
        if (typeof google !== 'undefined' && google.maps) {
            resolve();
            return;
        }

        // Google Maps API requires a valid API key
        // To enable, add your Google Maps API key to localStorage with key 'nca_google_maps_api_key'
        const googleApiKey = localStorage.getItem('nca_google_maps_api_key');

        if (!googleApiKey) {
            console.warn('Google Maps API key not configured - location map disabled');
            reject(new Error('Google Maps API key not configured'));
            return;
        }

        const script = document.createElement('script');
        script.src = `https://maps.googleapis.com/maps/api/js?key=${googleApiKey}&libraries=places`;
        script.async = true;
        script.defer = true;

        script.onload = () => resolve();
        script.onerror = () => reject(new Error('Failed to load Google Maps API'));

        document.head.appendChild(script);
    });
}

// Save Google Maps API key
function saveGoogleMapsApiKey() {
    const apiKey = document.getElementById('googleMapsApiKey').value.trim();
    if (apiKey) {
        localStorage.setItem('nca_google_maps_api_key', apiKey);
        showToast('Google Maps API key saved successfully', 'success');
    } else {
        showToast('Please enter a valid API key', 'error');
    }
}

// Clear Google Maps API key
function clearGoogleMapsApiKey() {
    localStorage.removeItem('nca_google_maps_api_key');
    document.getElementById('googleMapsApiKey').value = '';
    showToast('Google Maps API key cleared', 'info');
}

// Load Google Maps API key into settings form
function loadGoogleMapsApiKey() {
    const apiKey = localStorage.getItem('nca_google_maps_api_key');
    const input = document.getElementById('googleMapsApiKey');
    if (input && apiKey) {
        input.value = apiKey;
    }
}

// Export functions to window
window.saveGoogleMapsApiKey = saveGoogleMapsApiKey;
window.clearGoogleMapsApiKey = clearGoogleMapsApiKey;
window.loadGoogleMapsApiKey = loadGoogleMapsApiKey;

// Create the map and add markers
function createMap() {
    const mapElement = document.getElementById('locationMap');
    if (!mapElement || typeof google === 'undefined') return;

    // Create map centered on the first location or default to world view
    const centerLocation = locationData.length > 0 ? 
        { lat: locationData[0].lat, lng: locationData[0].lng } : 
        { lat: 20, lng: 0 };

    map = new google.maps.Map(mapElement, {
        zoom: 2,
        center: centerLocation,
        mapTypeId: 'roadmap',
        styles: [
            {
                featureType: 'administrative',
                elementType: 'geometry',
                stylers: [{ visibility: 'on' }]
            },
            {
                featureType: 'water',
                elementType: 'geometry',
                stylers: [{ color: '#a5d6a7' }]
            }
        ]
    });

    // Clear existing markers
    markers.forEach(marker => marker.setMap(null));
    markers = [];

    // Add markers for each location
    locationData.forEach(location => {
        if (location.lat && location.lng) {
            const marker = new google.maps.Marker({
                position: { lat: location.lat, lng: location.lng },
                map: map,
                title: `${location.city}, ${location.country}`,
                animation: google.maps.Animation.DROP
            });

            // Add info window
            const infoWindow = new google.maps.InfoWindow({
                content: `
                    <div style="padding: 10px; min-width: 200px;">
                        <h4 style="margin: 0 0 8px; color: #085636;">${location.city}, ${location.country}</h4>
                        <p style="margin: 4px 0; font-size: 13px;"><strong>IP:</strong> ${location.ip}</p>
                        <p style="margin: 4px 0; font-size: 13px;"><strong>Region:</strong> ${location.region}</p>
                        <p style="margin: 4px 0; font-size: 13px;"><strong>ISP:</strong> ${location.isp}</p>
                        <p style="margin: 4px 0; font-size: 13px;"><strong>Last Access:</strong> ${formatDate(location.last_access)}</p>
                    </div>
                `
            });

            marker.addListener('click', () => {
                infoWindow.open(map, marker);
            });

            markers.push(marker);
        }
    });

    // Fit bounds to show all markers
    if (markers.length > 0) {
        const bounds = new google.maps.LatLngBounds();
        markers.forEach(marker => bounds.extend(marker.getPosition()));
        map.fitBounds(bounds);
    }
}

// Center map on users
function centerMapOnUsers() {
    if (!map || markers.length === 0) return;

    const bounds = new google.maps.LatLngBounds();
    markers.forEach(marker => bounds.extend(marker.getPosition()));
    map.fitBounds(bounds);
}

// Enable real-time map updates
function enableRealTimeMapUpdates() {
    if (isMapUpdating) {
        disableRealTimeMapUpdates();
        return;
    }

    isMapUpdating = true;
    showToast('Real-time map updates enabled', 'success');

    // Update map every 30 seconds
    mapUpdateInterval = setInterval(async () => {
        try {
            // Refresh location data
            const response = await fetch(`${API_BASE}?type=visitor_tracking&action=get_visitors&limit=50`);
            const result = await safeFetch(response);
            
            if (result.success && result.data) {
                // Update location data
                const newLocationData = result.data.map(visitor => ({
                    ip: visitor.ip_address || 'Unknown',
                    city: visitor.city || 'Unknown',
                    region: visitor.region || 'Unknown',
                    country: visitor.country || 'Unknown',
                    lat: parseFloat(visitor.latitude) || 0,
                    lng: parseFloat(visitor.longitude) || 0,
                    isp: visitor.isp || 'Unknown',
                    last_access: visitor.last_activity || visitor.first_visit,
                    session_id: visitor.session_id,
                    page_views: visitor.page_views || 0
                }));

                // Check for new visitors
                const newVisitors = newLocationData.filter(newLoc => 
                    !locationData.some(existingLoc => existingLoc.session_id === newLoc.session_id)
                );

                if (newVisitors.length > 0) {
                    showToast(`${newVisitors.length} new visitor(s) detected`, 'info');
                    
                    // Add new markers to map
                    newVisitors.forEach(visitor => {
                        if (visitor.lat && visitor.lng && typeof google !== 'undefined') {
                            const marker = new google.maps.Marker({
                                position: { lat: visitor.lat, lng: visitor.lng },
                                map: map,
                                title: `${visitor.city}, ${visitor.country}`,
                                animation: google.maps.Animation.DROP
                            });

                            const infoWindow = new google.maps.InfoWindow({
                                content: `
                                    <div style="padding: 10px; min-width: 200px;">
                                        <h4 style="margin: 0 0 8px; color: #085636;">${visitor.city}, ${visitor.country}</h4>
                                        <p style="margin: 4px 0; font-size: 13px;"><strong>IP:</strong> ${visitor.ip}</p>
                                        <p style="margin: 4px 0; font-size: 13px;"><strong>Region:</strong> ${visitor.region}</p>
                                        <p style="margin: 4px 0; font-size: 13px;"><strong>ISP:</strong> ${visitor.isp}</p>
                                        <p style="margin: 4px 0; font-size: 13px;"><strong>Last Access:</strong> ${formatDate(visitor.last_access)}</p>
                                    </div>
                                `
                            });

                            marker.addListener('click', () => {
                                infoWindow.open(map, marker);
                            });

                            markers.push(marker);
                        }
                    });
                }

                // Update location data
                locationData = newLocationData;
                
                // Update UI
                renderLocationTable();
                updateLocationStats();
                populateCountryFilter();
                renderVisitorTimeline();
            }
        } catch (error) {
            console.error('Error updating map:', error);
        }
    }, 30000); // Update every 30 seconds
}

// Disable real-time map updates
function disableRealTimeMapUpdates() {
    if (mapUpdateInterval) {
        clearInterval(mapUpdateInterval);
        mapUpdateInterval = null;
    }
    isMapUpdating = false;
    showToast('Real-time map updates disabled', 'info');
}

// Toggle heatmap
function toggleHeatmap() {
    if (!map) return;

    if (heatmap) {
        heatmap.setMap(null);
        heatmap = null;
        showToast('Heatmap disabled', 'info');
    } else {
        if (typeof google.maps.visualization !== 'undefined') {
            const heatmapData = locationData
                .filter(loc => loc.lat && loc.lng)
                .map(loc => new google.maps.LatLng(loc.lat, loc.lng));

            heatmap = new google.maps.visualization.HeatmapLayer({
                data: heatmapData,
                map: map,
                radius: 20,
                maxIntensity: 10
            });
            showToast('Heatmap enabled', 'success');
        } else {
            showToast('Heatmap library not loaded. Please include visualization library.', 'warning');
        }
    }
}

// View specific location on map
function viewOnMap(lat, lng) {
    if (!map) return;

    const position = { lat, lng };
    map.setCenter(position);
    map.setZoom(10);

    // Find and open the marker info window
    const marker = markers.find(m => {
        const markerPos = m.getPosition();
        return markerPos.lat() === lat && markerPos.lng() === lng;
    });

    if (marker) {
        google.maps.event.trigger(marker, 'click');
    }
}

// Get detailed visitor information from database
async function getVisitorDetails(sessionId) {
    try {
        const response = await fetch(`${API_BASE}?type=visitor_tracking&action=get_visitor_details&session_id=${sessionId}`);
        const result = await safeFetch(response);

        if (result.success && result.data) {
            const visitor = result.data.visitor;
            const pageHistory = result.data.page_history || [];

            const details = `
                <div style="padding: 20px; max-width: 600px; max-height: 80vh; overflow-y: auto;">
                    <h3 style="color: #085636; margin-bottom: 15px; border-bottom: 2px solid #085636; padding-bottom: 10px;">Visitor Details</h3>
                    
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 20px;">
                        <div><strong>Session ID:</strong> ${visitor.session_id || 'N/A'}</div>
                        <div><strong>IP Address:</strong> ${visitor.ip_address || 'N/A'}</div>
                        <div><strong>City:</strong> ${visitor.city || 'N/A'}</div>
                        <div><strong>Region:</strong> ${visitor.region || 'N/A'}</div>
                        <div><strong>Country:</strong> ${visitor.country || 'N/A'}</div>
                        <div><strong>Postal:</strong> ${visitor.postal_code || 'N/A'}</div>
                        <div><strong>Latitude:</strong> ${visitor.latitude || 'N/A'}</div>
                        <div><strong>Longitude:</strong> ${visitor.longitude || 'N/A'}</div>
                        <div><strong>ISP:</strong> ${visitor.isp || 'N/A'}</div>
                        <div><strong>Timezone:</strong> ${visitor.timezone || 'N/A'}</div>
                        <div><strong>Page Views:</strong> ${visitor.page_views || 0}</div>
                        <div><strong>Referrer:</strong> ${visitor.referrer || 'Direct'}</div>
                        <div><strong>First Visit:</strong> ${formatDate(visitor.first_visit)}</div>
                        <div><strong>Last Activity:</strong> ${formatDate(visitor.last_activity)}</div>
                    </div>

                    <h4 style="color: #085636; margin: 20px 0 10px;">Page History (Last 10 pages)</h4>
                    ${pageHistory.length > 0 ? `
                        <table style="width: 100%; border-collapse: collapse; font-size: 12px;">
                            <thead>
                                <tr style="background: #f5f5f5;">
                                    <th style="padding: 8px; text-align: left; border: 1px solid #ddd;">Time</th>
                                    <th style="padding: 8px; text-align: left; border: 1px solid #ddd;">Page</th>
                                    <th style="padding: 8px; text-align: left; border: 1px solid #ddd;">Title</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${pageHistory.slice(0, 10).map(page => `
                                    <tr>
                                        <td style="padding: 8px; border: 1px solid #ddd;">${formatDate(page.visited_at)}</td>
                                        <td style="padding: 8px; border: 1px solid #ddd;">${page.path || page.url}</td>
                                        <td style="padding: 8px; border: 1px solid #ddd;">${page.title || 'N/A'}</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    ` : '<p>No page history available.</p>'}
                </div>
            `;

            // Create a modal to show the details
            const modal = document.createElement('div');
            modal.style.cssText = 'position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 10000;';
            modal.innerHTML = `
                <div style="background: white; border-radius: 8px; max-width: 700px; width: 90%; max-height: 90vh; overflow: auto; position: relative;">
                    <button onclick="this.parentElement.parentElement.remove()" style="position: absolute; top: 10px; right: 10px; background: none; border: none; font-size: 24px; cursor: pointer;">&times;</button>
                    ${details}
                </div>
            `;
            document.body.appendChild(modal);
        } else {
            showToast('Unable to fetch visitor details', 'error');
        }
    } catch (error) {
        console.error('Error fetching visitor details:', error);
        showToast('Error fetching visitor details', 'error');
    }
}

// Get address from coordinates using reverse geocoding
async function getVisitorAddress(lat, lng) {
    try {
        const googleApiKey = localStorage.getItem('nca_google_maps_api_key') || 'YOUR_API_KEY';
        
        if (googleApiKey === 'YOUR_API_KEY') {
            showToast('Google Maps API key not configured. Please add it in settings.', 'warning');
            return;
        }

        const response = await fetch(
            `https://maps.googleapis.com/maps/api/geocode/json?latlng=${lat},${lng}&key=${googleApiKey}`
        );
        
        const data = await response.json();
        
        if (data.status === 'OK' && data.results.length > 0) {
            const result = data.results[0];
            const address = result.formatted_address;
            
            // Show address in a nice modal
            const modal = document.createElement('div');
            modal.style.cssText = 'position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 10000;';
            modal.innerHTML = `
                <div style="background: white; border-radius: 8px; padding: 30px; max-width: 500px; width: 90%; position: relative;">
                    <button onclick="this.parentElement.parentElement.remove()" style="position: absolute; top: 10px; right: 10px; background: none; border: none; font-size: 24px; cursor: pointer;">&times;</button>
                    <h3 style="color: #085636; margin-bottom: 15px;">📍 Address Location</h3>
                    <p style="font-size: 16px; line-height: 1.6; margin-bottom: 20px;">${address}</p>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; font-size: 14px;">
                        <div><strong>Latitude:</strong> ${lat.toFixed(6)}</div>
                        <div><strong>Longitude:</strong> ${lng.toFixed(6)}</div>
                    </div>
                    <button onclick="window.open('https://www.google.com/maps/search/?api=1&query=${lat},${lng}', '_blank')" style="margin-top: 20px; background: #085636; color: white; border: none; padding: 10px 20px; border-radius: 4px; cursor: pointer; width: 100%;">
                        <i class="fas fa-external-link-alt"></i> Open in Google Maps
                    </button>
                </div>
            `;
            document.body.appendChild(modal);
        } else {
            showToast('Unable to get address for these coordinates', 'error');
        }
    } catch (error) {
        console.error('Error getting address:', error);
        showToast('Error getting address from coordinates', 'error');
    }
}

// Filter location data
function filterLocationData() {
    const searchTerm = document.getElementById('locationSearch')?.value.toLowerCase() || '';
    const countryFilter = document.getElementById('countryFilter')?.value || '';
    const timeFilter = document.getElementById('timeFilter')?.value || '';

    let filteredData = locationData.filter(location => {
        // Search filter - now includes session_id and user_agent
        const matchesSearch = !searchTerm || 
            location.ip?.toLowerCase().includes(searchTerm) ||
            location.city?.toLowerCase().includes(searchTerm) ||
            location.country?.toLowerCase().includes(searchTerm) ||
            location.region?.toLowerCase().includes(searchTerm) ||
            location.session_id?.toLowerCase().includes(searchTerm) ||
            location.isp?.toLowerCase().includes(searchTerm);

        // Country filter
        const matchesCountry = !countryFilter || location.country === countryFilter;

        // Time filter
        let matchesTime = true;
        if (timeFilter) {
            const locationDate = new Date(location.last_access);
            const now = new Date();
            
            switch (timeFilter) {
                case 'today':
                    matchesTime = locationDate.toDateString() === now.toDateString();
                    break;
                case 'week':
                    const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
                    matchesTime = locationDate >= weekAgo;
                    break;
                case 'month':
                    const monthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
                    matchesTime = locationDate >= monthAgo;
                    break;
            }
        }

        return matchesSearch && matchesCountry && matchesTime;
    });

    renderLocationTable(filteredData);
}

// Refresh location data
function refreshLocationData() {
    loadLocationAnalytics();
}

// Export location data
function exportLocationData() {
    if (locationData.length === 0) {
        showToast('No data to export', 'warning');
        return;
    }

    const csvHeader = 'IP Address,City,Region,Country,Latitude,Longitude,ISP,Last Access\n';
    const csvRows = locationData.map(loc => 
        `"${loc.ip}","${loc.city}","${loc.region}","${loc.country}",${loc.lat},${loc.lng},"${loc.isp}","${loc.last_access}"`
    ).join('\n');

    downloadCSV(csvHeader + csvRows, 'location_data.csv');
    showToast('Location data exported successfully', 'success');
}

// Render charts
function renderCharts() {
    renderTopCountriesChart();
    renderUserDistributionChart();
}

// Render top countries chart
function renderTopCountriesChart() {
    const ctx = document.getElementById('topCountriesChart');
    if (!ctx) return;

    // Count users by country
    const countryCounts = {};
    locationData.forEach(loc => {
        const country = loc.country || 'Unknown';
        countryCounts[country] = (countryCounts[country] || 0) + 1;
    });

    // Sort and get top 10
    const sortedCountries = Object.entries(countryCounts)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 10);

    const labels = sortedCountries.map(([country]) => country);
    const data = sortedCountries.map(([, count]) => count);

    // Destroy existing chart if it exists
    if (topCountriesChart) {
        topCountriesChart.destroy();
    }

    topCountriesChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Users',
                data: data,
                backgroundColor: [
                    'rgba(8, 86, 54, 0.8)',
                    'rgba(27, 94, 32, 0.8)',
                    'rgba(46, 125, 50, 0.8)',
                    'rgba(67, 160, 71, 0.8)',
                    'rgba(102, 187, 106, 0.8)',
                    'rgba(129, 199, 132, 0.8)',
                    'rgba(165, 214, 167, 0.8)',
                    'rgba(200, 230, 201, 0.8)',
                    'rgba(220, 237, 200, 0.8)',
                    'rgba(232, 245, 233, 0.8)'
                ],
                borderColor: '#085636',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                title: {
                    display: true,
                    text: 'Top 10 Countries by User Count'
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1
                    }
                }
            }
        }
    });
}

// Render user distribution chart
function renderUserDistributionChart() {
    const ctx = document.getElementById('userDistributionChart');
    if (!ctx) return;

    // Group by continent/region for distribution
    const regionCounts = {};
    locationData.forEach(loc => {
        const region = loc.region || 'Unknown';
        regionCounts[region] = (regionCounts[region] || 0) + 1;
    });

    // Get top 8 regions for cleaner pie chart
    const sortedRegions = Object.entries(regionCounts)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 8);

    const labels = sortedRegions.map(([region]) => region);
    const data = sortedRegions.map(([, count]) => count);

    // Destroy existing chart if it exists
    if (userDistributionChart) {
        userDistributionChart.destroy();
    }

    userDistributionChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: labels,
            datasets: [{
                data: data,
                backgroundColor: [
                    '#085636',
                    '#1b5e20',
                    '#2e7d32',
                    '#43a047',
                    '#66bb6a',
                    '#81c784',
                    '#a5d6a7',
                    '#c8e6c9'
                ],
                borderWidth: 2,
                borderColor: '#ffffff'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'right',
                    labels: {
                        padding: 15,
                        usePointStyle: true
                    }
                },
                title: {
                    display: true,
                    text: 'User Distribution by Region'
                }
            }
        }
    });
}

// Render visitor timeline
function renderVisitorTimeline() {
    const timelineContainer = document.getElementById('visitorTimeline');
    if (!timelineContainer) return;

    const timeFilter = document.getElementById('timelineFilter')?.value || 'month';
    
    // Filter data based on time
    let filteredData = [...locationData];
    const now = new Date();
    
    switch (timeFilter) {
        case 'today':
            filteredData = filteredData.filter(loc => {
                const locDate = new Date(loc.last_access);
                return locDate.toDateString() === now.toDateString();
            });
            break;
        case 'week':
            const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
            filteredData = filteredData.filter(loc => new Date(loc.last_access) >= weekAgo);
            break;
        case 'month':
            const monthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
            filteredData = filteredData.filter(loc => new Date(loc.last_access) >= monthAgo);
            break;
        // 'all' shows all data
    }

    // Sort by last activity
    filteredData.sort((a, b) => new Date(b.last_access) - new Date(a.last_access));

    if (filteredData.length === 0) {
        timelineContainer.innerHTML = '<p class="text-center text-muted">No visitor activity for the selected time period.</p>';
        return;
    }

    timelineContainer.innerHTML = `
        <div class="visitor-timeline">
            ${filteredData.map(visitor => {
                const isNewVisitor = new Date(visitor.first_visit) > new Date(Date.now() - 24 * 60 * 60 * 1000);
                const visitorClass = isNewVisitor ? 'new-visitor' : 'returning-visitor';
                const visitorType = isNewVisitor ? '🆕 New Visitor' : '🔄 Returning Visitor';
                
                return `
                    <div class="timeline-item ${visitorClass}">
                        <div class="timeline-time">${formatDate(visitor.last_access)}</div>
                        <div class="timeline-content">
                            <strong>${visitorType}</strong> from ${visitor.city}, ${visitor.country}
                            <div class="timeline-location">
                                IP: ${visitor.ip} • ${visitor.page_views || 0} page views
                            </div>
                        </div>
                    </div>
                `;
            }).join('')}
        </div>
    `;
}

// Live feed functionality
let liveFeedInterval = null;
let isLiveFeedActive = false;

function toggleLiveFeed() {
    const toggleBtn = document.getElementById('liveFeedToggleBtn');
    const liveIndicator = document.getElementById('liveIndicator');
    const feedContainer = document.getElementById('liveVisitorFeed');
    
    if (isLiveFeedActive) {
        // Stop live feed
        clearInterval(liveFeedInterval);
        isLiveFeedActive = false;
        if (toggleBtn) {
            toggleBtn.innerHTML = '<i class="fas fa-play"></i> Start Live Feed';
            toggleBtn.classList.remove('admin-btn-danger');
            toggleBtn.classList.add('admin-btn-success');
        }
        if (liveIndicator) liveIndicator.style.display = 'none';
        feedContainer.innerHTML = '<p class="text-center text-muted">Live feed stopped. Click "Start Live Feed" to resume.</p>';
        showToast('Live feed stopped', 'info');
    } else {
        // Start live feed
        isLiveFeedActive = true;
        if (toggleBtn) {
            toggleBtn.innerHTML = '<i class="fas fa-stop"></i> Stop Live Feed';
            toggleBtn.classList.remove('admin-btn-success');
            toggleBtn.classList.add('admin-btn-danger');
        }
        if (liveIndicator) liveIndicator.style.display = 'inline-block';
        feedContainer.innerHTML = '<p class="text-center"><i class="fas fa-spinner fa-spin"></i> Starting live feed...</p>';
        
        // Initial load
        refreshLiveVisitors();
        
        // Update every 10 seconds
        liveFeedInterval = setInterval(refreshLiveVisitors, 10000);
        showToast('Live feed started', 'success');
    }
}

async function refreshLiveVisitors() {
    try {
        // Fetch visitor data
        const response = await fetch(`${API_BASE}?type=visitor_tracking&action=get_visitors&limit=50`);
        const result = await safeFetch(response);
        
        if (result.success && result.data) {
            const visitors = result.data;
            
            // Update stats
            updateVisitorStats(visitors);
            
            // Update live feed
            updateLiveFeedDisplay(visitors);
            
            // Update current visitors table
            updateCurrentVisitorsTable(visitors);
        } else {
            console.error('Failed to fetch visitor data:', result);
        }
    } catch (error) {
        console.error('Error refreshing live visitors:', error);
    }
}

function updateVisitorStats(visitors) {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    
    const totalVisitors = visitors.length;
    const activeVisitors = visitors.filter(v => {
        const lastActivity = new Date(v.last_activity);
        const fiveMinutesAgo = new Date(now.getTime() - 5 * 60 * 1000);
        return lastActivity >= fiveMinutesAgo;
    }).length;
    const todayVisitors = visitors.filter(v => {
        const firstVisit = new Date(v.first_visit);
        return firstVisit >= today;
    }).length;
    const countries = new Set(visitors.filter(v => v.country).map(v => v.country)).size;
    
    document.getElementById('totalVisitorsCount').textContent = totalVisitors;
    document.getElementById('activeVisitorsCount').textContent = activeVisitors;
    document.getElementById('todayVisitorsCount').textContent = todayVisitors;
    document.getElementById('countriesCount').textContent = countries;
}

function updateLiveFeedDisplay(visitors) {
    const feedContainer = document.getElementById('liveVisitorFeed');
    if (!feedContainer) return;
    
    const recentVisitors = visitors.slice(0, 15);
    
    if (recentVisitors.length === 0) {
        feedContainer.innerHTML = '<p class="text-center text-muted">No recent visitor activity.</p>';
        return;
    }
    
    feedContainer.innerHTML = recentVisitors.map(visitor => {
        const timeAgo = getTimeAgo(new Date(visitor.last_activity));
        const isNewVisitor = new Date(visitor.first_visit) > new Date(Date.now() - 24 * 60 * 60 * 1000);
        const action = isNewVisitor ? 'New visitor from' : 'Returning visitor from';
        const icon = isNewVisitor ? 'fa-user-plus' : 'fa-sign-in-alt';
        const location = visitor.city ? `${visitor.city}, ${visitor.country}` : (visitor.country || 'Unknown');
        
        return `
            <div class="live-feed-item" style="padding: 12px; border-bottom: 1px solid #eee; display: flex; align-items: center; gap: 12px;">
                <div class="live-feed-icon" style="width: 36px; height: 36px; background: #f0f7f4; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: #085636;">
                    <i class="fas ${icon}"></i>
                </div>
                <div class="live-feed-info" style="flex: 1;">
                    <div class="live-feed-action" style="font-weight: 500; color: #333;">${action} ${location}</div>
                    <div class="live-feed-details" style="font-size: 0.85rem; color: #666;">IP: ${visitor.ip_address || 'Unknown'} • ${visitor.page_views || 0} pages</div>
                </div>
                <div class="live-feed-time" style="font-size: 0.8rem; color: #999;">${timeAgo}</div>
            </div>
        `;
    }).join('');
}

function updateCurrentVisitorsTable(visitors) {
    const tableBody = document.getElementById('currentVisitorsTableBody');
    if (!tableBody) return;
    
    const now = new Date();
    const fiveMinutesAgo = new Date(now.getTime() - 5 * 60 * 1000);
    const activeVisitors = visitors.filter(v => {
        const lastActivity = new Date(v.last_activity);
        return lastActivity >= fiveMinutesAgo;
    });
    
    if (activeVisitors.length === 0) {
        tableBody.innerHTML = '<tr><td colspan="4" class="text-center text-muted">No active visitors.</td></tr>';
        return;
    }
    
    tableBody.innerHTML = activeVisitors.map(visitor => {
        const location = visitor.city ? `${visitor.city}, ${visitor.country}` : (visitor.country || 'Unknown');
        const currentPage = visitor.current_page || 'Unknown';
        const lastActivity = getTimeAgo(new Date(visitor.last_activity));
        
        return `
            <tr>
                <td>${visitor.ip_address || 'Unknown'}</td>
                <td>${location}</td>
                <td style="max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${currentPage}</td>
                <td>${lastActivity}</td>
            </tr>
        `;
    }).join('');
}

// Get time ago string
function getTimeAgo(date) {
    const seconds = Math.floor((new Date() - date) / 1000);
    
    if (seconds < 60) return 'Just now';
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
    return `${Math.floor(seconds / 86400)}d ago`;
}

// Expose required functions to global scope for HTML onclick handlers
window.togglePasswordVisibility = togglePasswordVisibility;

// ===== BIRTHDAY MANAGEMENT =====
let birthdays = [];

// Load birthdays from API
async function loadBirthdays() {
    try {
        const typeFilter = document.getElementById('birthdayTypeFilter')?.value || '';
        const statusFilter = document.getElementById('birthdayStatusFilter')?.value || '';

        let url = `${API_BASE}?type=admin&collection=birthdays`;
        if (typeFilter) url += `&type=${typeFilter}`;
        if (statusFilter) url += `&status=${statusFilter}`;

        const response = await fetch(url);
        const result = await safeFetch(response);

        if (result.success && result.data) {
            birthdays = result.data.items || result.data || [];
            renderBirthdays();
        } else {
            document.getElementById('birthdaysBody').innerHTML = '<tr><td colspan="7" class="text-center text-muted">No birthdays found.</td></tr>';
        }
    } catch (error) {
        console.error('Error loading birthdays:', error);
        document.getElementById('birthdaysBody').innerHTML = '<tr><td colspan="7" class="text-center text-danger">Failed to load birthdays.</td></tr>';
    }
}

// Render birthdays table
function renderBirthdays() {
    const tbody = document.getElementById('birthdaysBody');
    if (!tbody) return;

    if (birthdays.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted">No birthdays found.</td></tr>';
        return;
    }

    tbody.innerHTML = birthdays.map(b => {
        const birthday = b.birthday ? new Date(b.birthday).toLocaleDateString('en-US', { month: 'long', day: 'numeric' }) : '';
        const typeBadge = b.type === 'staff' ? '<span class="badge" style="background: #e74c3c; color: white;">Staff</span>' : '<span class="badge" style="background: #3498db; color: white;">Student</span>';
        const statusBadge = b.status === 'active' ? '<span class="badge" style="background: #27ae60; color: white;">Active</span>' : '<span class="badge" style="background: #95a5a6; color: white;">Inactive</span>';

        return `
            <tr>
                <td>
                    <div style="display: flex; align-items: center; gap: 10px;">
                        ${b.photo ? `<img src="${b.photo}" alt="${b.name}" style="width: 40px; height: 40px; border-radius: 50%; object-fit: cover;">` : '<div style="width: 40px; height: 40px; border-radius: 50%; background: #e8f0ea; display: flex; align-items: center; justify-content: center;"><i class="fas fa-user" style="color: #085636;"></i></div>'}
                        <span>${b.name}</span>
                    </div>
                </td>
                <td>${typeBadge}</td>
                <td>${birthday}</td>
                <td>${b.class || '-'}</td>
                <td style="max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${b.message || '-'}</td>
                <td>${statusBadge}</td>
                <td>
                    <button class="admin-btn admin-btn-sm admin-btn-primary" onclick="editBirthday(${b.id})"><i class="fas fa-edit"></i></button>
                    <button class="admin-btn admin-btn-sm admin-btn-danger" onclick="deleteBirthday(${b.id})"><i class="fas fa-trash"></i></button>
                </td>
            </tr>
        `;
    }).join('');
}

// Open birthday modal for adding
function openBirthdayModal() {
    document.getElementById('birthdayModalTitle').innerHTML = '<i class="fas fa-birthday-cake"></i> Add Birthday';
    document.getElementById('birthdayForm').reset();
    document.getElementById('birthdayId').value = '';
    
    // Reset radio buttons
    const typeRadios = document.querySelectorAll('input[name="birthdayTypeRadio"]');
    typeRadios.forEach(r => {
        if (r.value === 'student') {
            r.checked = true;
            const div = r.nextElementSibling;
            div.style.borderColor = '#f1c40f';
            div.style.background = '#fff8e1';
        } else {
            r.checked = false;
            const div = r.nextElementSibling;
            div.style.borderColor = '#e4efe6';
            div.style.background = '#fff';
        }
    });
    
    // Reset photo preview
    updateBirthdayPhotoPreview('');
    
    // Show class field
    document.getElementById('birthdayClassGroup').style.display = 'block';
    
    document.getElementById('birthdayModal').style.display = 'flex';
}

// Close birthday modal
function closeBirthdayModal() {
    document.getElementById('birthdayModal').style.display = 'none';
}

// Edit birthday
function editBirthday(id) {
    const birthday = birthdays.find(b => b.id === id);
    if (!birthday) return;

    document.getElementById('birthdayModalTitle').innerHTML = '<i class="fas fa-birthday-cake"></i> Edit Birthday';
    document.getElementById('birthdayId').value = birthday.id;
    document.getElementById('birthdayName').value = birthday.name;
    document.getElementById('birthdayType').value = birthday.type;
    document.getElementById('birthdayDate').value = birthday.birthday;
    document.getElementById('birthdayClass').value = birthday.class || '';
    document.getElementById('birthdayPhoto').value = birthday.photo || '';
    document.getElementById('birthdayMessage').value = birthday.message || '';
    document.getElementById('birthdayStatus').value = birthday.status;

    // Update radio button selection
    const typeRadios = document.querySelectorAll('input[name="birthdayTypeRadio"]');
    typeRadios.forEach(r => {
        if (r.value === birthday.type) {
            r.checked = true;
            const div = r.nextElementSibling;
            div.style.borderColor = '#f1c40f';
            div.style.background = '#fff8e1';
        } else {
            r.checked = false;
            const div = r.nextElementSibling;
            div.style.borderColor = '#e4efe6';
            div.style.background = '#fff';
        }
    });

    // Show/hide class field based on type
    document.getElementById('birthdayClassGroup').style.display = birthday.type === 'student' ? 'block' : 'none';

    // Update photo preview
    updateBirthdayPhotoPreview(birthday.photo);

    document.getElementById('birthdayModal').style.display = 'flex';
}

// Save birthday (add or update)
async function saveBirthday(event) {
    event.preventDefault();

    const id = document.getElementById('birthdayId').value;
    const data = {
        name: document.getElementById('birthdayName').value,
        type: document.getElementById('birthdayType').value,
        birthday: document.getElementById('birthdayDate').value,
        class: document.getElementById('birthdayType').value === 'student' ? document.getElementById('birthdayClass').value : '',
        photo: document.getElementById('birthdayPhoto').value,
        message: document.getElementById('birthdayMessage').value,
        status: document.getElementById('birthdayStatus').value
    };

    try {
        let result;
        if (id) {
            // Update existing
            result = await apiFetch('admin', 'birthdays', 'PUT', data, id);
        } else {
            // Add new
            result = await apiFetch('admin', 'birthdays', 'POST', data);
        }

        if (result.success) {
            showToast(id ? 'Birthday updated successfully' : 'Birthday added successfully', 'success');
            closeBirthdayModal();
            loadBirthdays();
        } else {
            showToast(result.message || 'Failed to save birthday', 'error');
        }
    } catch (error) {
        console.error('Error saving birthday:', error);
        showToast('Failed to save birthday', 'error');
    }

    return false;
}

// Delete birthday
async function deleteBirthday(id) {
    if (!confirm('Are you sure you want to delete this birthday?')) return;

    try {
        const result = await apiFetch('admin', 'birthdays', 'DELETE', null, id);
        if (result.success) {
            showToast('Birthday deleted successfully', 'success');
            loadBirthdays();
        } else {
            showToast(result.message || 'Failed to delete birthday', 'error');
        }
    } catch (error) {
        console.error('Error deleting birthday:', error);
        showToast('Failed to delete birthday', 'error');
    }
}

// Handle type change to show/hide class field
document.addEventListener('DOMContentLoaded', function() {
    const typeSelect = document.getElementById('birthdayType');
    if (typeSelect) {
        typeSelect.addEventListener('change', function() {
            const classGroup = document.getElementById('birthdayClassGroup');
            if (classGroup) {
                classGroup.style.display = this.value === 'student' ? 'block' : 'none';
            }
        });
    }

    // Handle radio button type selection
    const typeRadios = document.querySelectorAll('input[name="birthdayTypeRadio"]');
    typeRadios.forEach(radio => {
        radio.addEventListener('change', function() {
            const classGroup = document.getElementById('birthdayClassGroup');
            if (classGroup) {
                classGroup.style.display = this.value === 'student' ? 'block' : 'none';
            }
            
            // Update visual selection
            typeRadios.forEach(r => {
                const div = r.nextElementSibling;
                if (r.checked) {
                    div.style.borderColor = '#f1c40f';
                    div.style.background = '#fff8e1';
                } else {
                    div.style.borderColor = '#e4efe6';
                    div.style.background = '#fff';
                }
            });
        });
    });

    // Initialize radio button styling
    typeRadios.forEach(r => {
        const div = r.nextElementSibling;
        if (r.checked) {
            div.style.borderColor = '#f1c40f';
            div.style.background = '#fff8e1';
        }
    });
});

// Update photo preview
function updateBirthdayPhotoPreview(url) {
    const preview = document.getElementById('birthdayPhotoPreview');
    if (!preview) return;

    if (url && url.trim() !== '') {
        preview.innerHTML = `<img src="${url}" alt="Photo" style="width: 100%; height: 100%; border-radius: 50%; object-fit: cover;" onerror="this.parentElement.innerHTML='<i class=\\'fas fa-user\\' style=\\'font-size: 48px; color: rgba(255,255,255,0.5);\\'></i>'">`;
    } else {
        preview.innerHTML = '<i class="fas fa-user" style="font-size: 48px; color: rgba(255,255,255,0.5);"></i>';
    }
}

// Export function to window
window.updateBirthdayPhotoPreview = updateBirthdayPhotoPreview;

// Export functions to window
window.openBirthdayModal = openBirthdayModal;
window.closeBirthdayModal = closeBirthdayModal;
window.editBirthday = editBirthday;
window.saveBirthday = saveBirthday;
window.deleteBirthday = deleteBirthday;
window.loadBirthdays = loadBirthdays;




