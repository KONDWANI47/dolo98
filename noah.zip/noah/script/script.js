document.addEventListener('DOMContentLoaded', function() {
    const body = document.body;
    const menuToggle = document.querySelector('.menu-toggle');
    const navigation = document.getElementById('navigation');

    // WhatsApp floating button - always visible on the right
    const whatsappFab = document.createElement('a');
    whatsappFab.className = 'fab-button whatsapp';
    whatsappFab.href = 'https://wa.me/265999635561';
    whatsappFab.target = '_blank';
    whatsappFab.rel = 'noopener noreferrer';
    whatsappFab.setAttribute('aria-label', 'Chat with us on WhatsApp');
    whatsappFab.setAttribute('title', 'Chat with us on WhatsApp');
    whatsappFab.innerHTML = `
      <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
        <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.134.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.812 11.812 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
      </svg>
    `;
    document.body.appendChild(whatsappFab);

    // Back-to-top button - on the left, only visible when scrolling down
    const backToTopButton = document.createElement('button');
    backToTopButton.className = 'fab-button back-to-top';
    backToTopButton.type = 'button';
    backToTopButton.setAttribute('aria-label', 'Back to top');
    backToTopButton.setAttribute('title', 'Back to top');
    backToTopButton.innerHTML = `
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
        <path d="M12 19V5"></path>
        <path d="m5 12 7-7 7 7"></path>
      </svg>
    `;
    document.body.appendChild(backToTopButton);

    const toggleBackToTopVisibility = () => {
      if (window.scrollY > 300) {
        backToTopButton.classList.add('is-visible');
      } else {
        backToTopButton.classList.remove('is-visible');
      }
    };

    backToTopButton.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    window.addEventListener('scroll', toggleBackToTopVisibility, { passive: true });
    toggleBackToTopVisibility();

    const toggleHeaderState = () => {
      body.classList.toggle('scrolled', window.scrollY > 60);
    };

    const revealItems = Array.from(document.querySelectorAll('section, .info-card'));

    revealItems.forEach((item) => {
      item.classList.add('reveal');
    });

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          observer.unobserve(entry.target);
        }
      });
    }, {
      threshold: 0.15
    });

    revealItems.forEach((item) => {
      observer.observe(item);
    });

    if (menuToggle && navigation) {
      menuToggle.addEventListener('click', () => {
        const isOpen = body.classList.toggle('menu-open');
        menuToggle.setAttribute('aria-expanded', String(isOpen));
        navigation.setAttribute('aria-expanded', String(isOpen));
      });

      navigation.querySelectorAll('a').forEach((link) => {
        link.addEventListener('click', () => {
          body.classList.remove('menu-open');
          menuToggle.setAttribute('aria-expanded', 'false');
          navigation.setAttribute('aria-expanded', 'false');
        });
      });
    }

    window.addEventListener('scroll', toggleHeaderState);
    window.addEventListener('resize', () => {
      if (window.innerWidth > 768) {
        body.classList.remove('menu-open');
        if (menuToggle) {
          menuToggle.setAttribute('aria-expanded', 'false');
        }
        if (navigation) {
          navigation.setAttribute('aria-expanded', 'false');
        }
      }
    });

    toggleHeaderState();

    // Load announcements
    loadAnnouncements();

    // Load dynamic footer content from admin
    loadFooterContent();

    // Modal functionality
    const registrationModal = document.getElementById('registrationModal');
    const paymentModal = document.getElementById('paymentModal');
    const openRegistrationBtn = document.getElementById('openRegistrationModal');
    const openPaymentBtn = document.getElementById('openPaymentModal');
    const closeModalBtns = document.querySelectorAll('.close-modal');
    const registrationForm = document.getElementById('registrationForm');
    const paymentForm = document.querySelector('.payment-form');
    const photoInputs = document.querySelectorAll('input[type="file"][data-preview-target]');
    
    let currentlyOpenModal = null;
    let lastFocusedElement = null;

    // Function to get focusable elements inside a modal
    const getFocusableElements = (modal) => {
      return modal.querySelectorAll(
        'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
      );
    };

    // Function to trap focus inside modal
    const trapFocus = (modal, e) => {
      const focusableElements = getFocusableElements(modal);
      const firstElement = focusableElements[0];
      const lastElement = focusableElements[focusableElements.length - 1];

      if (e.key === 'Tab') {
        if (e.shiftKey) {
          // Shift + Tab
          if (document.activeElement === firstElement) {
            lastElement.focus();
            e.preventDefault();
          }
        } else {
          // Tab
          if (document.activeElement === lastElement) {
            firstElement.focus();
            e.preventDefault();
          }
        }
      }
    };

    // Function to open a modal
    const openModal = (modalElement, triggerButton) => {
      if (modalElement) {
        lastFocusedElement = triggerButton || document.activeElement;
        modalElement.style.display = 'block';
        body.style.overflow = 'hidden';
        currentlyOpenModal = modalElement;
        
        // Focus first focusable element
        const focusableElements = getFocusableElements(modalElement);
        if (focusableElements.length > 0) {
          focusableElements[0].focus();
        }
      }
    };

    // Function to close a modal
    const closeModal = (modalElement) => {
      if (modalElement) {
        modalElement.style.display = 'none';
        body.style.overflow = 'auto';
        currentlyOpenModal = null;
        
        // Restore focus to last focused element
        if (lastFocusedElement) {
          lastFocusedElement.focus();
        }
      }
    };

    const showImagePreview = (input) => {
      const preview = document.getElementById(input.dataset.previewTarget);
      if (!preview) {
        return;
      }

      const file = input.files && input.files[0];
      if (!file) {
        preview.innerHTML = 'No file selected yet.';
        return;
      }

      // Check if it's a PDF file
      if (file.type === 'application/pdf') {
        preview.innerHTML = `<div style="padding: 10px; background: #f0f0f0; border-radius: 4px; text-align: center;">
          <i class="fas fa-file-pdf" style="font-size: 24px; color: #e74c3c;"></i>
          <div style="margin-top: 5px; font-size: 12px;">PDF selected: ${file.name}</div>
        </div>`;
        return;
      }

      // Handle image files
      const reader = new FileReader();
      reader.onload = (event) => {
        preview.innerHTML = `<img src="${event.target.result}" alt="Uploaded preview" style="max-width: 100%; max-height: 200px; border-radius: 4px;">`;
      };
      reader.readAsDataURL(file);
    };

    photoInputs.forEach((input) => {
      input.addEventListener('change', () => showImagePreview(input));
    });

    // Open registration modal
    if (openRegistrationBtn) {
      openRegistrationBtn.addEventListener('click', () => openModal(registrationModal, openRegistrationBtn));
    }

    // Open payment modal
    if (openPaymentBtn) {
      openPaymentBtn.addEventListener('click', () => openModal(paymentModal, openPaymentBtn));
    }

    // Close modals with X buttons
    closeModalBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        const modalId = btn.getAttribute('data-modal');
        const modalElement = document.getElementById(modalId);
        closeModal(modalElement);
      });
    });

    // Close modals when clicking outside
    [registrationModal, paymentModal].forEach(modal => {
      if (modal) {
        modal.addEventListener('click', (e) => {
          if (e.target === modal) {
            closeModal(modal);
          }
        });
      }
    });

    // Handle ESC key to close modal
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && currentlyOpenModal) {
        closeModal(currentlyOpenModal);
      }
      
      // Trap focus in open modal
      if (currentlyOpenModal) {
        trapFocus(currentlyOpenModal, e);
      }
    });

    // ===== SAFE FETCH HELPER =====
    async function safeFetch(response) {
        if (!response.ok) {
            const text = await response.text();
            try {
                return JSON.parse(text);
            } catch {
                return { success: false, message: `HTTP ${response.status}: ${text || 'No response body'}` };
            }
        }
        
        const text = await response.text();
        if (!text.trim()) {
            return { success: false, message: 'Empty response from server' };
        }
        
        try {
            return JSON.parse(text);
        } catch (parseErr) {
            return { success: false, message: 'Invalid JSON response from server' };
        }
    }

    // ===== API HELPER =====
    async function apiPublic(action, data, isFormData = false) {
        // Route to MySQL-based APIs
        const scriptTag = Array.from(document.scripts).find(tag => tag.src && /\/script\/script\.js(?:\?|$)/.test(tag.src));
        const apiBase = scriptTag
            ? new URL('../api/', scriptTag.src).href
            : new URL('api/', document.baseURI).href;
        const endpointMap = {
            'register': new URL('registration.php', apiBase).href,
            'payment': new URL('payments.php', apiBase).href,
            'contact': new URL('index.php?type=public&action=contact', apiBase).href
        };
        const url = endpointMap[action] || new URL('index.php?type=public&action=' + encodeURIComponent(action), apiBase).href;
        try {
            const options = {
                method: 'POST',
                body: isFormData ? data : new URLSearchParams(data)
            };
            if (!isFormData) {
                options.headers = { 'Content-Type': 'application/x-www-form-urlencoded' };
            }
            // For FormData, let browser set Content-Type with boundary automatically
            const response = await fetch(url, options);
            return await safeFetch(response);
        } catch (err) {
            return { success: false, message: 'Network error: ' + err.message };
        }
    }

    // ===== REGISTRATION FORM SUBMIT =====
    if (registrationForm) {
      registrationForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const submitBtn = registrationForm.querySelector('.form-submit');
        submitBtn.disabled = true;
        submitBtn.textContent = 'Submitting...';
        
        // Send as FormData to support file uploads
        const formData = new FormData(registrationForm);
        
        // Debug: Log form data
        console.log('Form data being sent (FormData object)');
        
        // Check if student_name exists
        if (!formData.get('student_name')) {
          console.error('ERROR: student_name field is missing from form data!');
          alert('Error: Student name field is missing. Please check the form.');
          submitBtn.disabled = false;
          submitBtn.textContent = 'Submit Registration';
          return;
        }
        
        // Send as FormData (multipart) to support file uploads
        const result = await apiPublic('register', formData, true);
        
        console.log('API Response:', result);
        
        if (result.success) {
            alert('Thank you for your registration! Your reference number is: ' + (result.data?.id || 'N/A') + '. We will contact you soon.');
            closeModal(registrationModal);
            registrationForm.reset();
            const registrationPreview = document.getElementById('registrationPhotoPreview');
            if (registrationPreview) {
              registrationPreview.innerHTML = 'No image selected yet.';
            }
        } else {
            alert('Error: ' + (result.message || 'Failed to submit registration. Please try again.'));
        }
        
        submitBtn.disabled = false;
        submitBtn.textContent = 'Submit Registration';
      });
    }

    // ===== PAYMENT FORM SUBMIT =====
    if (paymentForm) {
      paymentForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const submitBtn = paymentForm.querySelector('.form-submit');
        submitBtn.disabled = true;
        submitBtn.textContent = 'Submitting...';
        
        const formData = new FormData(paymentForm);
        
        // Rename the file input to match API expectation
        if (formData.has('paymentIdPhoto')) {
            formData.append('paymentIdPhoto', formData.get('paymentIdPhoto'));
        }
        
        const result = await apiPublic('payment', formData, true);
        
        if (result.success) {
            alert('Payment details submitted! We will process your payment shortly.');
            closeModal(paymentModal);
            paymentForm.reset();
            const paymentPreview = document.getElementById('paymentPhotoPreview');
            if (paymentPreview) {
              paymentPreview.innerHTML = 'No image selected yet.';
            }
        } else {
            alert('Error: ' + (result.message || 'Failed to submit payment. Please try again.'));
        }
        
        submitBtn.disabled = false;
        submitBtn.textContent = 'Send Payment Request';
      });
    }
  });

  // ===== FETCH AND DISPLAY ANNOUNCEMENTS ON HOMEPAGE =====
  async function loadAnnouncements() {
    try {
      // Determine correct API path based on current page location
      const path = window.location.pathname;
      let apiBase = 'api/index.php';
      if (path.includes('/html/')) apiBase = '../api/index.php';
      else if (path.includes('/dashboard/')) apiBase = '../api/index.php';

      const res = await fetch(apiBase + '?type=announcements');
      const data = await res.json();
      const bar = document.getElementById('announcementBar');
      const text = document.getElementById('announcementText');
      if (!bar || !text) return;

      if (data.success && data.data?.items?.length > 0) {
        const announcements = data.data.items;
        const dotsWrap = document.getElementById('announcementDots');

        // Build dot indicators if more than one
        if (dotsWrap && announcements.length > 1) {
          dotsWrap.innerHTML = announcements.map((_, i) =>
            '<span class="ann-dot' + (i === 0 ? ' active' : '') + '" data-i="' + i + '" style="width: 8px; height: 8px; border-radius: 50%; background: #ccc; cursor: pointer; transition: all 0.3s ease;"></span>'
          ).join('');

          // Add click handlers to dots
          dotsWrap.querySelectorAll('.ann-dot').forEach((dot, i) => {
            dot.addEventListener('click', () => {
              current = i;
              showAnnouncement(i);
            });
          });
        }

        let current = 0;

        function showAnnouncement(idx) {
          const a = announcements[idx];
          const priority = (a.priority || '').toLowerCase();
          let icon = '';
          let priorityClass = '';

          if (priority === 'urgent') {
            icon = ' \ud83d\udea8';
            priorityClass = 'color: #dc3545;';
          } else if (priority === 'important') {
            icon = ' \u26a0\ufe0f';
            priorityClass = 'color: #ffc107;';
          } else {
            icon = ' \u2139\ufe0f';
            priorityClass = 'color: #085636;';
          }

          const label = announcements.length > 1 ? (idx + 1) + '/' + announcements.length + '  ' : '';
          text.style.opacity = '0';
          setTimeout(() => {
            text.innerHTML = label + '<strong style="' + priorityClass + '">' + a.title + '</strong>' + icon + (a.content ? '<br><small style="color: #666; font-size: 0.9rem;">' + a.content.substring(0, 100) + (a.content.length > 100 ? '...' : '') + '</small>' : '');
            text.style.opacity = '1';

            // Update active dot
            if (dotsWrap) {
              dotsWrap.querySelectorAll('.ann-dot').forEach((d, i) => {
                d.style.background = i === idx ? '#085636' : '#ccc';
                d.style.transform = i === idx ? 'scale(1.2)' : 'scale(1)';
              });
            }
          }, 300);
        }

        showAnnouncement(0);
        bar.style.display = 'block';

        // Cycle every 6 seconds if more than one
        if (announcements.length > 1) {
          setInterval(() => {
            current = (current + 1) % announcements.length;
            showAnnouncement(current);
          }, 6000);
        }
      } else {
        bar.style.display = 'none';
      }
    } catch (e) {
      const bar = document.getElementById('announcementBar');
      if (bar) bar.style.display = 'none';
    }
  }

  // ===== LOAD FOOTER CONTENT FROM ADMIN =====
  async function loadFooterContent() {
    try {
      // Determine correct API path based on current page location
      const path = window.location.pathname;
      let apiBase = 'api/index.php';
      if (path.includes('/html/')) apiBase = '../api/index.php';
      else if (path.includes('/dashboard/')) apiBase = '../api/index.php';

      const res = await fetch(apiBase + '?type=public&action=footer');
      const json = await res.json();
      if (!json.success || !json.data) return;
      const d = json.data;

      // Update elements by data-footer attribute
      const set = (field, fallback) => {
        document.querySelectorAll('[data-footer="' + field + '"]').forEach(el => {
          if (d[field]) el.textContent = d[field];
          else if (fallback) el.textContent = fallback;
        });
      };
      const setHref = (field) => {
        document.querySelectorAll('[data-footer-href="' + field + '"]').forEach(el => {
          if (d[field]) el.href = d[field];
        });
      };

      set('description');
      set('address');
      set('phone');
      set('phone2');
      set('email');
      set('schoolHours');
      set('copyright');

      // Update mailto: and tel: links
      document.querySelectorAll('[data-footer-href="email"]').forEach(el => {
        if (d.email) el.href = 'mailto:' + d.email;
      });
      document.querySelectorAll('[data-footer-href="phone"]').forEach(el => {
        if (d.phone) el.href = 'tel:' + d.phone.replace(/\s/g, '');
      });
      document.querySelectorAll('[data-footer-href="phone2"]').forEach(el => {
        if (d.phone2) el.href = 'tel:' + d.phone2.replace(/\s/g, '');
      });

      // Update social links
      setHref('facebookUrl');
      setHref('tiktokUrl');
      setHref('whatsappUrl');
    } catch (e) {
      // Silently fail - footer keeps its static content
    }
  }
