/**
 * AI Chat Interface - Noah Christian Academy
 * Handles AI assistant chat functionality
 */

class AIChat {
    constructor(config) {
        this.userId = config.userId;
        this.userRole = config.userRole;
        this.userClass = config.userClass || null;
        // Auto-detect correct path based on current location
        const currentPath = window.location.pathname;

        if (currentPath.includes('/dashboard/')) {
            // In dashboard/teacher.html or dashboard/parent.html
            // Need to go up one level: dashboard/ -> noah/
            this.apiBase = config.apiBase || '../api/ai.php';
        } else if (currentPath.includes('/admin/')) {
            // In admin/admin.html
            // Need to go up one level: admin/ -> noah/
            this.apiBase = config.apiBase || '../api/ai.php';
        } else {
            // In root or other location
            this.apiBase = config.apiBase || 'api/ai.php';
        }

        console.log('AI Chat initialized with API base:', this.apiBase);
        console.log('Current path:', currentPath);

        this.conversationId = null;
        this.history = [];
        this.isOpen = false;

        this.init();
    }

    init() {
        try {
            // Create UI elements
            this.createUI();

            // Load conversation history
            this.loadHistory();

            // Add event listeners
            this.attachEventListeners();
        } catch (error) {
            console.error('AI Chat initialization error:', error);
        }
    }

    createUI() {
        // Floating button
        const floatBtn = document.createElement('button');
        floatBtn.className = 'ai-float-button';
        floatBtn.innerHTML = '<i class="fas fa-robot"></i>';
        floatBtn.title = 'AI Assistant';
        floatBtn.onclick = () => this.toggle();
        document.body.appendChild(floatBtn);
        this.floatBtn = floatBtn;

        // Chat panel
        const panel = document.createElement('div');
        panel.className = 'ai-chat-panel';
        panel.innerHTML = `
            <div class="ai-chat-header">
                <h3><i class="fas fa-robot"></i>NCA AI Assistant</h3>
                <div class="ai-chat-header-actions">
                    <button class="ai-header-btn" onclick="aiChat.clearChat()" title="Clear Chat">
                        <i class="fas fa-trash"></i>
                    </button>
                    <button class="ai-header-btn" onclick="aiChat.toggle()" title="Close">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            </div>
            <div class="ai-chat-body" id="aiChatBody">
                <div class="ai-welcome">
                    <div class="ai-welcome-icon"><i class="fas fa-robot"></i></div>
                    <h4>Hello! I'm your school AI assistant.</h4>
                    <p>I can help you with students, results, attendance, lesson plans, and more.</p>
                    <div class="ai-suggestions" id="aiSuggestions"></div>
                </div>
            </div>
            <div class="ai-chat-footer">
                <button class="ai-attach-btn" id="aiAttachBtn" title="Add attachment">
                    <i class="fas fa-plus"></i>
                </button>
                <div class="ai-attach-menu" id="aiAttachMenu">
                    <button class="ai-attach-item" onclick="aiChat.triggerUpload('file')">
                        <i class="fas fa-file"></i>
                        <span>Upload File</span>
                    </button>
                    <button class="ai-attach-item" onclick="aiChat.triggerUpload('image')">
                        <i class="fas fa-image"></i>
                        <span>Upload Image</span>
                    </button>
                    <button class="ai-attach-item" onclick="aiChat.triggerUpload('pdf')">
                        <i class="fas fa-file-pdf"></i>
                        <span>Upload PDF</span>
                    </button>
                    <button class="ai-attach-item" onclick="aiChat.generateImage()">
                        <i class="fas fa-magic"></i>
                        <span>Generate Image</span>
                    </button>
                    <button class="ai-attach-item" onclick="aiChat.shareLocation()">
                        <i class="fas fa-map-marker-alt"></i>
                        <span>Share Location</span>
                    </button>
                    <button class="ai-attach-item" onclick="aiChat.createPoll()">
                        <i class="fas fa-poll"></i>
                        <span>Create Poll</span>
                    </button>
                    <button class="ai-attach-item" onclick="aiChat.createEvent()">
                        <i class="fas fa-calendar-alt"></i>
                        <span>Create Event</span>
                    </button>
                </div>
                <input type="file" class="ai-upload-input" id="aiUploadInput" accept=".pdf,.docx,.xlsx,.csv,.txt,.jpg,.jpeg,.png,.gif">
                <textarea class="ai-chat-input" id="aiChatInput" placeholder="Ask me anything..." rows="1"></textarea>
                <button class="ai-send-btn" id="aiSendBtn" title="Send">
                    <i class="fas fa-paper-plane"></i>
                </button>
            </div>
        `;
        document.body.appendChild(panel);
        this.panel = panel;
        this.chatBody = document.getElementById('aiChatBody');
        this.chatInput = document.getElementById('aiChatInput');
        this.sendBtn = document.getElementById('aiSendBtn');
        this.uploadInput = document.getElementById('aiUploadInput');
        this.attachBtn = document.getElementById('aiAttachBtn');
        this.attachMenu = document.getElementById('aiAttachMenu');
        this.suggestionsContainer = document.getElementById('aiSuggestions');

        // Add suggestions based on role
        this.addSuggestions();
    }

    addSuggestions() {
        const suggestions = this.getSuggestions();
        this.suggestionsContainer.innerHTML = suggestions.map(s => `
            <button class="ai-suggestion-btn" onclick="aiChat.ask('${s.question}')">
                <i class="fas fa-lightbulb"></i>
                ${s.label}
            </button>
        `).join('');
    }

    getSuggestions() {
        if (this.userRole === 'teacher') {
            return [
                { label: 'Show my class performance', question: 'Show me my class performance' },
                { label: 'Find students with low attendance', question: 'Which students have attendance below 75%?' },
                { label: 'Create a lesson plan', question: 'Create a lesson plan for my class' },
                { label: 'Generate homework', question: 'Create homework for my students' },
                { label: 'Analyze student results', question: 'Analyze my students\' results' }
            ];
        } else if (this.userRole === 'admin') {
            return [
                { label: 'School performance report', question: 'Generate a school performance report' },
                { label: 'Show fee balances', question: 'Show me students with outstanding fees' },
                { label: 'Analyze attendance', question: 'Show me attendance statistics' },
                { label: 'Compare term results', question: 'Compare examination results between terms' },
                { label: 'Enrollment report', question: 'Create an enrollment report' }
            ];
        } else {
            return [
                { label: 'Help me understand the system', question: 'What can you help me with?' },
                { label: 'View my information', question: 'Show me my information' }
            ];
        }
    }

    attachEventListeners() {
        // Send button
        this.sendBtn.onclick = () => this.sendMessage();

        // Enter key to send
        this.chatInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });

        // Auto-resize textarea
        this.chatInput.addEventListener('input', () => {
            this.chatInput.style.height = 'auto';
            this.chatInput.style.height = Math.min(this.chatInput.scrollHeight, 100) + 'px';
        });

        // File upload
        this.uploadInput.addEventListener('change', (e) => this.handleFileUpload(e));

        // Attach menu toggle
        this.attachBtn.onclick = (e) => {
            e.stopPropagation();
            this.attachMenu.classList.toggle('show');
        };

        // Close attach menu when clicking outside
        document.addEventListener('click', (e) => {
            if (!this.attachMenu.contains(e.target) && !this.attachBtn.contains(e.target)) {
                this.attachMenu.classList.remove('show');
            }
        });

        // Close on escape
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                if (this.isOpen) {
                    this.toggle();
                }
                this.attachMenu.classList.remove('show');
            }
        });
    }

    toggle() {
        this.isOpen = !this.isOpen;
        this.panel.classList.toggle('open', this.isOpen);

        if (this.isOpen) {
            this.chatInput.focus();
        }
    }

    async loadHistory() {
        try {
            const payload = {
                action: 'get_conversations',
                user_id: this.userId,
                user_role: this.userRole
            };

            const response = await fetch(this.apiBase, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            const rawText = await response.text();
            console.log('Load history response:', rawText);

            let data;
            try {
                data = JSON.parse(rawText);
            } catch (error) {
                console.error('Invalid JSON response:', rawText);
                return;
            }

            if (data.success && data.data && data.data.length > 0) {
                // Remove welcome message
                const welcome = this.chatBody.querySelector('.ai-welcome');
                if (welcome) welcome.remove();

                // Load recent conversations
                data.data.slice(0, 10).reverse().forEach(conv => {
                    this.addMessage(conv.user_message, 'user', false);
                    this.addMessage(conv.ai_response, 'ai', false);
                });

                this.scrollToBottom();
            }
        } catch (error) {
            console.error('Failed to load history:', error);
        }
    }

    async sendMessage() {
        const message = this.chatInput.value.trim();
        if (!message) return;

        // Clear input
        this.chatInput.value = '';
        this.chatInput.style.height = 'auto';

        // Remove welcome message
        const welcome = this.chatBody.querySelector('.ai-welcome');
        if (welcome) welcome.remove();

        // Add user message
        this.addMessage(message, 'user');
        this.history.push({ role: 'user', content: message });

        // Check if we can handle this locally (save API coins)
        const localResponse = this.handleLocalQuery(message);
        if (localResponse) {
            console.log('Query handled locally to save API coins:', message);
            this.addMessage(localResponse, 'ai');
            this.history.push({ role: 'assistant', content: localResponse });
            return;
        }

        // Show typing indicator
        this.showTyping();

        try {
            console.log('Sending message to AI:', message);
            console.log('API URL:', this.apiBase);

            const response = await fetch(this.apiBase, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    action: 'chat',
                    message: message,
                    user_id: this.userId,
                    user_role: this.userRole,
                    user_class: this.userClass,
                    conversation_id: this.conversationId,
                    history: this.history
                })
            });

            console.log('Response status:', response.status);

            const data = await response.json();
            console.log('Response data:', data);

            // Hide typing indicator
            this.hideTyping();

            if (data.success) {
                // Check if response contains an image
                if (data.data.image_url) {
                    this.addMessage('Here is the image you requested:', 'ai');
                    this.addImageMessage(data.data.image_url, data.data.prompt || 'Generated image');
                    this.history.push({ role: 'assistant', content: `[Image generated: ${data.data.prompt}]` });
                } else {
                    this.addMessage(data.data.content, 'ai');
                    this.history.push({ role: 'assistant', content: data.data.content });
                }
                this.conversationId = data.data.conversation_id;
            } else {
                // Check if it's an API key error
                if (data.message && data.message.includes('API key')) {
                    this.showError('AI API key not configured. Please add your OpenAI API key to the .env file. See AI_ASSISTANT_SETUP.md for instructions.');
                } else {
                    this.showError(data.message || 'Failed to get response');
                }
                console.error('API error:', data.message);
            }
        } catch (error) {
            this.hideTyping();
            this.showError('Network error: ' + error.message + '. Check console for details.');
            console.error('Chat error:', error);
            console.error('API URL was:', this.apiBase);
        }
    }

    /**
     * Handle simple queries locally to save API coins
     * Returns response if handled locally, null if needs AI
     */
    handleLocalQuery(message) {
        const lowerMessage = message.toLowerCase().trim();

        // Greetings
        const greetings = ['hi', 'hello', 'hey', 'good morning', 'good afternoon', 'good evening'];
        if (greetings.some(g => lowerMessage === g || lowerMessage.startsWith(g))) {
            return `Hello! I'm your NCA AI Assistant. How can I help you today? You can ask me about students, results, attendance, lesson plans, or any other topic.`;
        }

        // Help requests
        if (lowerMessage.includes('help') || lowerMessage.includes('what can you do') || lowerMessage.includes('capabilities')) {
            return this.getHelpResponse();
        }

        // System navigation
        if (lowerMessage.includes('dashboard') || lowerMessage.includes('navigate') || lowerMessage.includes('where is')) {
            return `You can access different sections from your dashboard menu. As a ${this.userRole}, you have access to ${this.userRole === 'teacher' ? 'student management, attendance, results, and lesson planning' : 'school-wide data, reports, and administrative functions'}.`;
        }

        // Thank you responses
        if (lowerMessage.includes('thank') || lowerMessage === 'thanks') {
            return "You're welcome! If you need any more help, just ask.";
        }

        // Goodbye
        if (lowerMessage.includes('bye') || lowerMessage.includes('goodbye')) {
            return "Goodbye! Feel free to come back anytime you need assistance.";
        }

        // Who are you
        if (lowerMessage.includes('who are you') || lowerMessage.includes('what are you')) {
            return "I'm the NCA AI Assistant, designed to help you with Noah Christian Academy's school management system. I can assist with student information, results, attendance, lesson planning, and any other questions you have.";
        }

        // Time/date queries
        if (lowerMessage.includes('time') || lowerMessage.includes('date') || lowerMessage.includes('today')) {
            const now = new Date();
            return `It's currently ${now.toLocaleDateString()} at ${now.toLocaleTimeString()}. How can I help you?`;
        }

        // Not a local query - needs AI
        return null;
    }

    /**
     * Get help response based on user role
     */
    getHelpResponse() {
        let response = "I can help you with the following:\n\n";

        if (this.userRole === 'teacher') {
            response += "• Search and view student information\n";
            response += "• Check attendance records\n";
            response += "• View and analyze student results\n";
            response += "• Generate lesson plans\n";
            response += "• Create homework assignments\n";
            response += "• Generate examination papers\n";
            response += "• Analyze class performance\n";
            response += "• View announcements\n\n";
            response += "Just ask me something like \"Show me my class performance\" or \"Which students have low attendance?\"";
        } else if (this.userRole === 'admin') {
            response += "• Search and view all student data\n";
            response += "• View fee balances and payments\n";
            response += "• Manage teacher information\n";
            response += "• Generate school-wide reports\n";
            response += "• Analyze attendance statistics\n";
            response += "• Financial summaries\n";
            response += "• Performance reports\n\n";
            response += "Just ask me something like \"Show me students with outstanding fees\" or \"Generate a school performance report\"";
        } else {
            response += "• View your information\n";
            response += "• Check announcements\n";
            response += "• General system help\n\n";
            response += "What would you like to know?";
        }

        return response;
    }

    ask(question) {
        this.chatInput.value = question;
        this.sendMessage();
    }

    addMessage(content, type, animate = true) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `ai-message ${type}`;

        const avatar = document.createElement('div');
        avatar.className = 'ai-message-avatar';
        avatar.innerHTML = type === 'user' ? '<i class="fas fa-user"></i>' : '<i class="fas fa-robot"></i>';

        const contentDiv = document.createElement('div');
        contentDiv.className = 'ai-message-content';
        contentDiv.innerHTML = this.formatMessage(content);

        messageDiv.appendChild(avatar);
        messageDiv.appendChild(contentDiv);

        this.chatBody.appendChild(messageDiv);

        if (animate) {
            this.scrollToBottom();
        }
    }

    formatMessage(content) {
        // Convert markdown-like syntax to HTML
        let formatted = content
            // Code blocks
            .replace(/```(\w+)?\n([\s\S]*?)```/g, '<pre><code>$2</code></pre>')
            // Inline code
            .replace(/`([^`]+)`/g, '<code>$1</code>')
            // Bold
            .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
            // Italic
            .replace(/\*([^*]+)\*/g, '<em>$1</em>')
            // Links
            .replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank">$1</a>')
            // Line breaks
            .replace(/\n/g, '<br>');

        // Detect action confirmation requests
        if (formatted.includes('[CONFIRMATION REQUIRED]')) {
            formatted = this.addConfirmationButtons(formatted);
        }

        return formatted;
    }

    addConfirmationButtons(content) {
        // Extract action details
        const actionMatch = content.match(/Action: (.*?)\n/);
        const action = actionMatch ? actionMatch[1] : 'this action';

        const buttonsHtml = `
            <div class="ai-confirmation">
                <p><strong>⚠️ Confirmation Required</strong></p>
                <p>Are you sure you want to: ${action}?</p>
                <div class="ai-action-buttons">
                    <button class="ai-action-btn" onclick="aiChat.confirmAction(true)">Confirm</button>
                    <button class="ai-action-btn secondary" onclick="aiChat.confirmAction(false)">Cancel</button>
                </div>
            </div>
        `;

        return content.replace('[CONFIRMATION REQUIRED]', buttonsHtml);
    }

    confirmAction(confirmed) {
        // Send confirmation to backend
        fetch(`${this.apiBase}?action=confirm_action`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action_id: this.pendingActionId,
                confirmed: confirmed,
                user_id: this.userId
            })
        }).then(response => response.json()).then(data => {
            if (data.success) {
                this.addMessage(confirmed ? 'Action confirmed.' : 'Action cancelled.', 'ai');
            }
        });

        this.pendingActionId = null;
    }

    showTyping() {
        const typingDiv = document.createElement('div');
        typingDiv.className = 'ai-message ai';
        typingDiv.id = 'aiTyping';
        typingDiv.innerHTML = `
            <div class="ai-message-avatar"><i class="fas fa-robot"></i></div>
            <div class="ai-typing">
                <div class="ai-typing-dot"></div>
                <div class="ai-typing-dot"></div>
                <div class="ai-typing-dot"></div>
            </div>
        `;
        this.chatBody.appendChild(typingDiv);
        this.scrollToBottom();
    }

    hideTyping() {
        const typing = document.getElementById('aiTyping');
        if (typing) typing.remove();
    }

    showError(message) {
        const errorDiv = document.createElement('div');
        errorDiv.className = 'ai-error';
        errorDiv.innerHTML = `<i class="fas fa-exclamation-circle"></i> ${message}`;
        this.chatBody.appendChild(errorDiv);
        this.scrollToBottom();

        // Remove after 5 seconds
        setTimeout(() => errorDiv.remove(), 5000);
    }

    scrollToBottom() {
        this.chatBody.scrollTop = this.chatBody.scrollHeight;
    }

    clearChat() {
        if (confirm('Clear this conversation?')) {
            this.chatBody.innerHTML = `
                <div class="ai-welcome">
                    <div class="ai-welcome-icon"><i class="fas fa-robot"></i></div>
                    <h4>Hello! I'm your school AI assistant.</h4>
                    <p>I can help you with students, results, attendance, lesson plans, and more.</p>
                    <div class="ai-suggestions" id="aiSuggestions"></div>
                </div>
            `;
            this.history = [];
            this.conversationId = null;
            this.suggestionsContainer = document.getElementById('aiSuggestions');
            this.addSuggestions();
        }
    }

    async handleFileUpload(event) {
        const file = event.target.files[0];
        if (!file) return;

        // Show loading
        this.addMessage(`Uploading ${file.name}...`, 'user');

        const formData = new FormData();
        formData.append('file', file);
        formData.append('action', 'upload');
        formData.append('user_id', this.userId);
        formData.append('user_role', this.userRole);

        try {
            const response = await fetch(this.apiBase, {
                method: 'POST',
                body: formData
            });

            const rawText = await response.text();
            console.log('Upload response:', rawText);

            let data;
            try {
                data = JSON.parse(rawText);
            } catch (error) {
                console.error('Invalid JSON response:', rawText);
                this.showError('Upload failed - server error');
                return;
            }

            if (data.success) {
                const content = data.data.content;
                const fileType = data.data.file_type;

                // Handle different file types
                if (fileType === 'txt' || fileType === 'csv') {
                    // Text files - show content preview
                    this.addMessage(`✅ File uploaded successfully! Content preview:`, 'ai');
                    this.addMessage(content.substring(0, 500) + (content.length > 500 ? '...' : ''), 'ai');
                } else if (content.startsWith('[Error:') || content.startsWith('[DOCX Error:')) {
                    // Extraction error - show as warning
                    this.addMessage(`⚠️ File uploaded but content extraction failed:`, 'ai');
                    this.addMessage(content, 'ai');
                } else if (content.startsWith('[') && content.includes('not yet implemented')) {
                    // Format not supported yet
                    this.addMessage(`✅ File uploaded successfully!`, 'ai');
                    this.addMessage(content, 'ai');
                } else {
                    // Other cases
                    this.addMessage(`✅ File uploaded successfully!`, 'ai');
                    this.addMessage(content, 'ai');
                }
            } else {
                this.showError(data.message || 'Failed to upload file');
            }
        } catch (error) {
            this.showError('Failed to upload file');
            console.error('Upload error:', error);
        }

        // Reset input
        this.uploadInput.value = '';
    }

    /**
     * Trigger file upload with specific type
     */
    triggerUpload(type) {
        this.attachMenu.classList.remove('show');

        let accept = '';
        switch(type) {
            case 'file':
                accept = '.pdf,.docx,.xlsx,.csv,.txt';
                break;
            case 'image':
                accept = '.jpg,.jpeg,.png,.gif,.webp';
                break;
            case 'pdf':
                accept = '.pdf';
                break;
        }

        this.uploadInput.accept = accept;
        this.uploadInput.click();
    }

    /**
     * Share location
     */
    shareLocation() {
        this.attachMenu.classList.remove('show');

        if (navigator.geolocation) {
            this.addMessage('Getting your location...', 'user');
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    const { latitude, longitude } = position.coords;
                    this.addMessage(`Location shared: ${latitude}, ${longitude}`, 'user');
                    this.addMessage('I can help you with location-based queries. What would you like to know?', 'ai');
                },
                (error) => {
                    this.showError('Could not get location: ' + error.message);
                }
            );
        } else {
            this.showError('Geolocation is not supported by your browser');
        }
    }

    /**
     * Create poll
     */
    createPoll() {
        this.attachMenu.classList.remove('show');

        const question = prompt('Enter your poll question:');
        if (!question) return;

        const options = [];
        for (let i = 1; i <= 4; i++) {
            const option = prompt(`Enter option ${i}:`);
            if (option) options.push(option);
        }

        if (options.length < 2) {
            this.showError('Poll needs at least 2 options');
            return;
        }

        this.addMessage(`📊 Poll: ${question}`, 'user');
        options.forEach((opt, i) => {
            this.addMessage(`${i + 1}. ${opt}`, 'ai');
        });
        this.addMessage('Poll created! To analyze poll results, I would need access to voting data from the system.', 'ai');
    }

    /**
     * Create event
     */
    createEvent() {
        this.attachMenu.classList.remove('show');

        const title = prompt('Event title:');
        if (!title) return;

        const date = prompt('Event date (YYYY-MM-DD):');
        const time = prompt('Event time (HH:MM):');
        const description = prompt('Event description:');

        this.addMessage(`📅 Event: ${title}`, 'user');
        this.addMessage(`Date: ${date || 'TBD'} | Time: ${time || 'TBD'}`, 'ai');
        if (description) {
            this.addMessage(`Description: ${description}`, 'ai');
        }
        this.addMessage('Event noted! Would you like me to help you schedule this in the school calendar system?', 'ai');
    }

    /**
     * Generate image using Hugging Face
     */
    async generateImage() {
        this.attachMenu.classList.remove('show');

        const prompt = prompt('Describe the image you want to generate:');
        if (!prompt) return;

        this.addMessage(`🎨 Generating image: "${prompt}"`, 'user');
        this.showTyping();

        try {
            const response = await fetch(this.apiBase, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    action: 'generate_image',
                    prompt: prompt,
                    user_id: this.userId,
                    user_role: this.userRole
                })
            });

            const data = await response.json();
            this.hideTyping();

            if (data.success) {
                // Display the generated image
                const imageUrl = data.data.image_url;
                this.addMessage(`✅ Image generated successfully!`, 'ai');
                this.addImageMessage(imageUrl, prompt);
            } else {
                this.showError(data.message || 'Failed to generate image');
            }
        } catch (error) {
            this.hideTyping();
            this.showError('Failed to generate image: ' + error.message);
            console.error('Image generation error:', error);
        }
    }

    /**
     * Add image message to chat
     */
    addImageMessage(imageUrl, prompt) {
        const messageDiv = document.createElement('div');
        messageDiv.className = 'ai-message ai';

        const avatar = document.createElement('div');
        avatar.className = 'ai-message-avatar';
        avatar.innerHTML = '<i class="fas fa-robot"></i>';

        const contentDiv = document.createElement('div');
        contentDiv.className = 'ai-message-content';
        contentDiv.innerHTML = `
            <div class="ai-generated-image">
                <img src="${imageUrl}" alt="${prompt}" onerror="this.src='data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>❌</text></svg>'">
                <div class="ai-image-prompt">${prompt}</div>
            </div>
        `;

        messageDiv.appendChild(avatar);
        messageDiv.appendChild(contentDiv);
        this.chatBody.appendChild(messageDiv);
        this.scrollToBottom();
    }
}

// Initialize when DOM is ready
let aiChat;

document.addEventListener('DOMContentLoaded', function() {
    // Check if user is logged in
    const userId = localStorage.getItem('teacher_id') || localStorage.getItem('admin_id');
    const userRole = localStorage.getItem('user_role');
    const userClass = localStorage.getItem('teacher_class');

    console.log('AI Chat Init:', { userId, userRole, userClass });

    if (userId && userRole) {
        try {
            aiChat = new AIChat({
                userId: userId,
                userRole: userRole,
                userClass: userClass
            });
            console.log('AI Chat initialized successfully');
        } catch (error) {
            console.error('Failed to initialize AI Chat:', error);
        }
    } else {
        console.log('User not logged in, AI Chat not initialized');
    }
});
