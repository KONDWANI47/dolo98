/**
 * Certificate Designer - Noah Christian Academy
 * Professional certificate design and generation system
 */

const CERTIFICATE_API = '../api/certificates.php';

// Canvas instance
let certificateCanvas = null;
let currentTemplate = null;
let selectedObject = null;
let allTemplates = [];
let currentFilter = 'all';

// Zoom state
let currentZoom = 1;
const MIN_ZOOM = 0.25;
const MAX_ZOOM = 3;
const ZOOM_STEP = 0.1;

// ===== CERTIFICATE NAVIGATION =====
function openCertificateDesigner() {
    // Show new document dialog first
    document.getElementById('newCertificateDocOverlay').classList.add('show');
    document.getElementById('newCertificateDocModal').classList.add('show');
    setupNewDocumentDialogListeners();
    updateCanvasPreview();
}

function closeNewCertificateDoc() {
    document.getElementById('newCertificateDocOverlay').classList.remove('show');
    document.getElementById('newCertificateDocModal').classList.remove('show');
}

function createCertificateCanvas() {
    const width = parseInt(document.getElementById('canvasWidth').value);
    const height = parseInt(document.getElementById('canvasHeight').value);
    const unit = document.getElementById('canvasUnit').value;
    const resolution = parseInt(document.getElementById('canvasResolution').value);

    // Convert to pixels based on unit and resolution
    let pixelWidth = width;
    let pixelHeight = height;

    if (unit === 'in') {
        pixelWidth = Math.round(width * resolution);
        pixelHeight = Math.round(height * resolution);
    } else if (unit === 'cm') {
        pixelWidth = Math.round((width / 2.54) * resolution);
        pixelHeight = Math.round((height / 2.54) * resolution);
    } else if (unit === 'mm') {
        pixelWidth = Math.round((width / 25.4) * resolution);
        pixelHeight = Math.round((height / 25.4) * resolution);
    }

    // Close dialog and open designer
    closeNewCertificateDoc();
    document.getElementById('certificateDesignerOverlay').classList.add('show');
    document.getElementById('certificateDesignerModal').classList.add('show');

    // Initialize canvas with specified dimensions
    initCertificateCanvas(pixelWidth, pixelHeight);
}

function openCertificateTemplates() {
    document.getElementById('templateBrowserOverlay').classList.add('show');
    document.getElementById('templateBrowserModal').classList.add('show');
    loadCertificateTemplates();
}

function closeCertificateDesigner() {
    document.getElementById('certificateDesignerOverlay').classList.remove('show');
    document.getElementById('certificateDesignerModal').classList.remove('show');

    // Reset zoom
    if (certificateCanvas) {
        resetZoom();
    }
}

function closeTemplateBrowser() {
    document.getElementById('templateBrowserOverlay').classList.remove('show');
    document.getElementById('templateBrowserModal').classList.remove('show');
}

function openMyCertificates() {
    loadRecentCertificates();
}

// ===== PRESET SIZES =====
function setPresetSize(preset) {
    const widthInput = document.getElementById('canvasWidth');
    const heightInput = document.getElementById('canvasHeight');
    const unitSelect = document.getElementById('canvasUnit');
    const orientationRadios = document.getElementsByName('orientation');

    let width, height, unit;

    switch (preset) {
        case 'a4_landscape':
            width = 297;
            height = 210;
            unit = 'mm';
            setOrientation('landscape');
            break;
        case 'a4_portrait':
            width = 210;
            height = 297;
            unit = 'mm';
            setOrientation('portrait');
            break;
        case 'letter_landscape':
            width = 11;
            height = 8.5;
            unit = 'in';
            setOrientation('landscape');
            break;
        case 'letter_portrait':
            width = 8.5;
            height = 11;
            unit = 'in';
            setOrientation('portrait');
            break;
        case 'custom':
            width = 1123;
            height = 794;
            unit = 'px';
            break;
    }

    widthInput.value = width;
    heightInput.value = height;
    unitSelect.value = unit;
    updateCanvasPreview();
}

function setOrientation(orientation) {
    const radios = document.getElementsByName('orientation');
    for (const radio of radios) {
        if (radio.value === orientation) {
            radio.checked = true;
        }
    }
}

function updateDimensionsForUnit() {
    const unit = document.getElementById('canvasUnit').value;
    const widthInput = document.getElementById('canvasWidth');
    const heightInput = document.getElementById('canvasHeight');
    const resolution = parseInt(document.getElementById('canvasResolution').value);

    // Store current pixel values
    const currentPixelWidth = parseInt(widthInput.value);
    const currentPixelHeight = parseInt(heightInput.value);

    let newWidth, newHeight;

    if (unit === 'px') {
        newWidth = currentPixelWidth;
        newHeight = currentPixelHeight;
    } else if (unit === 'in') {
        newWidth = (currentPixelWidth / resolution).toFixed(2);
        newHeight = (currentPixelHeight / resolution).toFixed(2);
    } else if (unit === 'cm') {
        newWidth = ((currentPixelWidth / resolution) * 2.54).toFixed(2);
        newHeight = ((currentPixelHeight / resolution) * 2.54).toFixed(2);
    } else if (unit === 'mm') {
        newWidth = ((currentPixelWidth / resolution) * 25.4).toFixed(1);
        newHeight = ((currentPixelHeight / resolution) * 25.4).toFixed(1);
    }

    widthInput.value = newWidth;
    heightInput.value = newHeight;
    updateCanvasPreview();
}

function updateCanvasPreview() {
    const width = parseFloat(document.getElementById('canvasWidth').value);
    const height = parseFloat(document.getElementById('canvasHeight').value);
    const unit = document.getElementById('canvasUnit').value;
    const resolution = parseInt(document.getElementById('canvasResolution').value);

    // Calculate pixel dimensions
    let pixelWidth, pixelHeight;
    if (unit === 'px') {
        pixelWidth = width;
        pixelHeight = height;
    } else if (unit === 'in') {
        pixelWidth = Math.round(width * resolution);
        pixelHeight = Math.round(height * resolution);
    } else if (unit === 'cm') {
        pixelWidth = Math.round((width / 2.54) * resolution);
        pixelHeight = Math.round((height / 2.54) * resolution);
    } else if (unit === 'mm') {
        pixelWidth = Math.round((width / 25.4) * resolution);
        pixelHeight = Math.round((height / 25.4) * resolution);
    }

    // Calculate print size in mm
    const printWidthMm = ((pixelWidth / resolution) * 25.4).toFixed(1);
    const printHeightMm = ((pixelHeight / resolution) * 25.4).toFixed(1);

    // Update preview
    document.getElementById('canvasSizePreview').textContent =
        `${pixelWidth} x ${pixelHeight} pixels`;
    document.getElementById('printSizePreview').textContent =
        `${printWidthMm} x ${printHeightMm} mm @ ${resolution} DPI`;
}

// Add event listeners for live preview
function setupNewDocumentDialogListeners() {
    const inputs = ['canvasWidth', 'canvasHeight', 'canvasUnit', 'canvasResolution'];
    inputs.forEach(id => {
        const element = document.getElementById(id);
        if (element) {
            element.addEventListener('input', updateCanvasPreview);
            element.addEventListener('change', updateCanvasPreview);
        }
    });

    const orientationRadios = document.getElementsByName('orientation');
    orientationRadios.forEach(radio => {
        radio.addEventListener('change', function() {
            const widthInput = document.getElementById('canvasWidth');
            const heightInput = document.getElementById('canvasHeight');
            const temp = widthInput.value;
            widthInput.value = heightInput.value;
            heightInput.value = temp;
            updateCanvasPreview();
        });
    });
}

// ===== ZOOM FUNCTIONS =====
function zoomIn() {
    if (currentZoom < MAX_ZOOM) {
        currentZoom = Math.min(currentZoom + ZOOM_STEP, MAX_ZOOM);
        applyZoom();
    }
}

function zoomOut() {
    if (currentZoom > MIN_ZOOM) {
        currentZoom = Math.max(currentZoom - ZOOM_STEP, MIN_ZOOM);
        applyZoom();
    }
}

function resetZoom() {
    currentZoom = 1;
    applyZoom();
}

function fitToScreen() {
    const container = document.querySelector('#certificateDesignerModal .progress-modal-body');
    const canvasContainer = document.getElementById('canvasContainer');
    if (!container || !canvasContainer || !certificateCanvas) return;

    const containerWidth = container.clientWidth - 40; // minus padding
    const containerHeight = container.clientHeight - 40;

    const scaleX = containerWidth / certificateCanvas.width;
    const scaleY = containerHeight / certificateCanvas.height;
    const scale = Math.min(scaleX, scaleY, 1);

    currentZoom = Math.max(scale, MIN_ZOOM);
    applyZoom();
}

function applyZoom() {
    const canvasContainer = document.getElementById('canvasContainer');
    if (!canvasContainer) return;

    canvasContainer.style.transform = `scale(${currentZoom})`;
    updateZoomDisplay();
}

function updateZoomDisplay() {
    const zoomDisplay = document.getElementById('zoomLevel');
    if (zoomDisplay) {
        zoomDisplay.textContent = Math.round(currentZoom * 100) + '%';
    }
}

// ===== KEYBOARD SHORTCUTS FOR ZOOM =====
function setupZoomKeyboardShortcuts() {
    const modal = document.getElementById('certificateDesignerModal');
    if (!modal) return;

    modal.addEventListener('keydown', function(e) {
        // Check for Ctrl/Cmd key
        const isCtrl = e.ctrlKey || e.metaKey;

        if (isCtrl) {
            switch (e.key) {
                case '+':
                case '=':
                    e.preventDefault();
                    zoomIn();
                    break;
                case '-':
                case '_':
                    e.preventDefault();
                    zoomOut();
                    break;
                case '0':
                    e.preventDefault();
                    resetZoom();
                    break;
            }
        }
    });
}

// ===== MOUSE WHEEL ZOOM =====
function setupMouseWheelZoom() {
    const modal = document.getElementById('certificateDesignerModal');
    if (!modal) return;

    modal.addEventListener('wheel', function(e) {
        // Check if Ctrl/Cmd is pressed
        const isCtrl = e.ctrlKey || e.metaKey;

        if (isCtrl) {
            e.preventDefault();

            if (e.deltaY < 0) {
                // Scroll up - zoom in
                zoomIn();
            } else {
                // Scroll down - zoom out
                zoomOut();
            }
        }
    }, { passive: false });
}

// ===== CANVAS INITIALIZATION =====
function initCertificateCanvas(width = 1123, height = 794) {
    const canvasElement = document.getElementById('certificateCanvas');
    if (!canvasElement) return;

    // Initialize Fabric.js canvas
    certificateCanvas = new fabric.Canvas('certificateCanvas', {
        width: width,
        height: height,
        backgroundColor: '#ffffff',
        preserveObjectStacking: true
    });

    // Add event listeners
    certificateCanvas.on('selection:created', handleObjectSelected);
    certificateCanvas.on('selection:updated', handleObjectSelected);
    certificateCanvas.on('selection:cleared', handleSelectionCleared);
    certificateCanvas.on('object:modified', handleObjectModified);

    // Add white background
    certificateCanvas.backgroundColor = '#ffffff';
    certificateCanvas.renderAll();

    // Reset zoom
    resetZoom();

    // Setup keyboard shortcuts
    setupZoomKeyboardShortcuts();

    // Setup mouse wheel zoom
    setupMouseWheelZoom();
}

// ===== ELEMENT ADDITION =====
function addTextElement() {
    if (!certificateCanvas) return;

    const text = new fabric.IText('Certificate of Achievement', {
        left: certificateCanvas.width / 2,
        top: 100,
        fontFamily: 'Times New Roman',
        fontSize: 48,
        fill: '#085636',
        originX: 'center',
        originY: 'center'
    });

    certificateCanvas.add(text);
    certificateCanvas.setActiveObject(text);
    certificateCanvas.renderAll();
}

function addImageElement() {
    if (!certificateCanvas) return;

    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = function(e) {
        const file = e.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = function(event) {
            fabric.Image.fromURL(event.target.result, function(img) {
                // Scale image to fit canvas
                const scale = Math.min(
                    (certificateCanvas.width * 0.3) / img.width,
                    (certificateCanvas.height * 0.3) / img.height
                );
                img.set({
                    left: certificateCanvas.width / 2,
                    top: certificateCanvas.height / 2,
                    scaleX: scale,
                    scaleY: scale,
                    originX: 'center',
                    originY: 'center'
                });
                certificateCanvas.add(img);
                certificateCanvas.setActiveObject(img);
                certificateCanvas.renderAll();
            });
        };
        reader.readAsDataURL(file);
    };
    input.click();
}

function addShapeElement(type) {
    if (!certificateCanvas) return;

    let shape;
    const centerX = certificateCanvas.width / 2;
    const centerY = certificateCanvas.height / 2;

    if (type === 'rect') {
        shape = new fabric.Rect({
            left: centerX,
            top: centerY,
            width: 200,
            height: 100,
            fill: '#085636',
            originX: 'center',
            originY: 'center'
        });
    } else if (type === 'circle') {
        shape = new fabric.Circle({
            left: centerX,
            top: centerY,
            radius: 50,
            fill: '#085636',
            originX: 'center',
            originY: 'center'
        });
    }

    if (shape) {
        certificateCanvas.add(shape);
        certificateCanvas.setActiveObject(shape);
        certificateCanvas.renderAll();
    }
}

function addDynamicField(fieldName) {
    if (!certificateCanvas) return;

    const fieldLabels = {
        'student_name': 'Student Name',
        'student_class': 'Class',
        'school_name': 'School Name',
        'award_title': 'Award Title',
        'date': 'Date',
        'certificate_number': 'Certificate Number'
    };

    const text = new fabric.IText('{{' + fieldName + '}}', {
        left: certificateCanvas.width / 2,
        top: 200,
        fontFamily: 'Arial',
        fontSize: 24,
        fill: '#333333',
        originX: 'center',
        originY: 'center',
        data: { isDynamic: true, fieldName: fieldName }
    });

    certificateCanvas.add(text);
    certificateCanvas.setActiveObject(text);
    certificateCanvas.renderAll();
}

// ===== OBJECT MANIPULATION =====
function deleteSelectedElement() {
    if (!certificateCanvas) return;
    const activeObjects = certificateCanvas.getActiveObjects();
    if (activeObjects.length) {
        certificateCanvas.discardActiveObject();
        activeObjects.forEach(function(object) {
            certificateCanvas.remove(object);
        });
        certificateCanvas.renderAll();
    }
}

function duplicateSelectedElement() {
    if (!certificateCanvas) return;
    const activeObject = certificateCanvas.getActiveObject();
    if (!activeObject) return;

    activeObject.clone(function(cloned) {
        cloned.set({
            left: cloned.left + 20,
            top: cloned.top + 20
        });
        certificateCanvas.add(cloned);
        certificateCanvas.setActiveObject(cloned);
        certificateCanvas.renderAll();
    });
}

function bringToFront() {
    if (!certificateCanvas) return;
    const activeObject = certificateCanvas.getActiveObject();
    if (activeObject) {
        activeObject.bringToFront();
        certificateCanvas.renderAll();
    }
}

function sendToBack() {
    if (!certificateCanvas) return;
    const activeObject = certificateCanvas.getActiveObject();
    if (activeObject) {
        activeObject.sendToBack();
        certificateCanvas.renderAll();
    }
}

// ===== SELECTION HANDLERS =====
function handleObjectSelected(e) {
    selectedObject = e.selected[0];
    updatePropertiesPanel(selectedObject);
}

function handleSelectionCleared() {
    selectedObject = null;
    document.getElementById('propertiesPanel').innerHTML =
        '<p class="text-muted" style="font-size:12px;">Select an element to edit properties</p>';
}

function handleObjectModified() {
    if (selectedObject) {
        updatePropertiesPanel(selectedObject);
    }
}

// ===== PROPERTIES PANEL =====
function updatePropertiesPanel(obj) {
    const panel = document.getElementById('propertiesPanel');
    if (!obj) return;

    let html = '';

    // Common properties
    html += `
        <div class="t-form-group">
            <label>X Position</label>
            <input type="number" class="t-form-control" value="${Math.round(obj.left)}" onchange="updateObjectProperty('left', this.value)">
        </div>
        <div class="t-form-group">
            <label>Y Position</label>
            <input type="number" class="t-form-control" value="${Math.round(obj.top)}" onchange="updateObjectProperty('top', this.value)">
        </div>
        <div class="t-form-group">
            <label>Rotation</label>
            <input type="number" class="t-form-control" value="${Math.round(obj.angle)}" onchange="updateObjectProperty('angle', this.value)">
        </div>
        <div class="t-form-group">
            <label>Opacity</label>
            <input type="range" min="0" max="1" step="0.1" value="${obj.opacity}" onchange="updateObjectProperty('opacity', this.value)">
        </div>
    `;

    // Text-specific properties
    if (obj.type === 'i-text' || obj.type === 'text') {
        html += `
            <div class="t-form-group">
                <label>Text</label>
                <input type="text" class="t-form-control" value="${obj.text}" onchange="updateObjectProperty('text', this.value)">
            </div>
            <div class="t-form-group">
                <label>Font Size</label>
                <input type="number" class="t-form-control" value="${obj.fontSize}" onchange="updateObjectProperty('fontSize', this.value)">
            </div>
            <div class="t-form-group">
                <label>Color</label>
                <input type="color" class="t-form-control" value="${obj.fill}" onchange="updateObjectProperty('fill', this.value)">
            </div>
        `;
    }

    // Shape-specific properties
    if (obj.type === 'rect') {
        html += `
            <div class="t-form-group">
                <label>Width</label>
                <input type="number" class="t-form-control" value="${Math.round(obj.width * obj.scaleX)}" onchange="updateObjectProperty('width', this.value)">
            </div>
            <div class="t-form-group">
                <label>Height</label>
                <input type="number" class="t-form-control" value="${Math.round(obj.height * obj.scaleY)}" onchange="updateObjectProperty('height', this.value)">
            </div>
            <div class="t-form-group">
                <label>Fill Color</label>
                <input type="color" class="t-form-control" value="${obj.fill}" onchange="updateObjectProperty('fill', this.value)">
            </div>
        `;
    }

    if (obj.type === 'circle') {
        html += `
            <div class="t-form-group">
                <label>Radius</label>
                <input type="number" class="t-form-control" value="${Math.round(obj.radius * obj.scaleX)}" onchange="updateObjectProperty('radius', this.value)">
            </div>
            <div class="t-form-group">
                <label>Fill Color</label>
                <input type="color" class="t-form-control" value="${obj.fill}" onchange="updateObjectProperty('fill', this.value)">
            </div>
        `;
    }

    panel.innerHTML = html;
}

function updateObjectProperty(prop, value) {
    if (!certificateCanvas || !selectedObject) return;

    if (prop === 'left' || prop === 'top' || prop === 'angle' || prop === 'fontSize' || prop === 'width' || prop === 'height' || prop === 'radius') {
        value = parseFloat(value);
    } else if (prop === 'opacity') {
        value = parseFloat(value);
    }

    selectedObject.set(prop, value);
    certificateCanvas.renderAll();
}

// ===== SAVE TEMPLATE =====
async function saveCertificateTemplate() {
    if (!certificateCanvas) return;

    const templateName = prompt('Enter template name:');
    if (!templateName) return;

    const canvasJSON = certificateCanvas.toJSON();
    const dataURL = certificateCanvas.toDataURL({ format: 'png', multiplier: 1 });

    const templateData = {
        name: templateName,
        description: 'Custom certificate template',
        category: 'Academic',
        canvas_width: certificateCanvas.width,
        canvas_height: certificateCanvas.height,
        unit: 'px',
        orientation: certificateCanvas.width > certificateCanvas.height ? 'landscape' : 'portrait',
        design_json: JSON.stringify(canvasJSON),
        preview_image: dataURL,
        created_by: currentTeacher ? currentTeacher.id : null,
        created_by_name: currentTeacher ? (currentTeacher.firstName + ' ' + currentTeacher.lastName) : 'Teacher'
    };

    try {
        const response = await fetch(CERTIFICATE_API + '?action=save_template', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(templateData)
        });

        const result = await response.json();
        if (result.success) {
            showToast('Template saved successfully!', 'success');
        } else {
            showToast(result.message || 'Failed to save template', 'error');
        }
    } catch (error) {
        showToast('Error saving template: ' + error.message, 'error');
    }
}

// ===== PREVIEW =====
function previewCertificate() {
    if (!certificateCanvas) return;

    const dataURL = certificateCanvas.toDataURL({ format: 'png', multiplier: 1 });
    const win = window.open();
    win.document.write('<img src="' + dataURL + '" style="max-width:100%;"/>');
}

// ===== PDF EXPORT =====
function exportCertificatePDF() {
    if (!certificateCanvas) return;

    // Load PDF libraries if not already loaded
    loadPdfLibraries();

    setTimeout(() => {
        if (!window.jspdf) {
            showToast('PDF libraries not loaded. Please try again.', 'error');
            return;
        }

        const { jsPDF } = window.jspdf;
        const dataURL = certificateCanvas.toDataURL({ format: 'png', multiplier: 2 });

        const pdf = new jsPDF({
            orientation: certificateCanvas.width > certificateCanvas.height ? 'landscape' : 'portrait',
            unit: 'px',
            format: [certificateCanvas.width, certificateCanvas.height]
        });

        pdf.addImage(dataURL, 'PNG', 0, 0, certificateCanvas.width, certificateCanvas.height);
        pdf.save('certificate.pdf');
    }, 500);
}

// ===== LOAD TEMPLATES =====
async function loadCertificateTemplates() {
    try {
        const response = await fetch(CERTIFICATE_API + '?action=get_templates&teacher_id=' + (currentTeacher ? currentTeacher.id : 0));
        const result = await response.json();

        if (result.success && result.data) {
            allTemplates = result.data.items || [];
            renderTemplateGrid(allTemplates);
        } else {
            document.getElementById('templateGrid').innerHTML =
                '<div class="text-center text-muted" style="grid-column:1/-1;padding:40px;">No templates available</div>';
        }
    } catch (error) {
        console.error('Error loading templates:', error);
        document.getElementById('templateGrid').innerHTML =
            '<div class="text-center text-muted" style="grid-column:1/-1;padding:40px;">Error loading templates</div>';
    }
}

function renderTemplateGrid(templates) {
    const grid = document.getElementById('templateGrid');
    if (!grid) return;

    if (!templates || templates.length === 0) {
        grid.innerHTML = '<div class="text-center text-muted" style="grid-column:1/-1;padding:40px;">No templates found</div>';
        return;
    }

    grid.innerHTML = templates.map(template => `
        <div class="template-card" style="background:#fff;border:1px solid #ddd;border-radius:8px;overflow:hidden;transition:transform 0.2s,box-shadow 0.2s;cursor:pointer;" onmouseover="this.style.transform='translateY(-4px)';this.style.boxShadow='0 8px 20px rgba(0,0,0,0.15)'" onmouseout="this.style.transform='translateY(0)';this.style.boxShadow='none'">
            <div style="height:180px;background:#f8f9fa;display:flex;align-items:center;justify-content:center;overflow:hidden;">
                ${template.preview_image ?
                    `<img src="${template.preview_image}" alt="${template.name}" style="max-width:100%;max-height:100%;object-fit:contain;">` :
                    `<div style="text-align:center;color:#999;">
                        <i class="fas fa-certificate" style="font-size:48px;margin-bottom:10px;"></i>
                        <p style="font-size:12px;">No Preview</p>
                    </div>`
                }
            </div>
            <div style="padding:15px;">
                <h5 style="margin:0 0 8px 0;font-size:14px;font-weight:600;color:#085636;">${template.name}</h5>
                <p style="margin:0 0 8px 0;font-size:12px;color:#666;">${template.description || 'No description'}</p>
                <div style="display:flex;gap:5px;flex-wrap:wrap;margin-bottom:10px;">
                    <span style="background:#085636;color:#fff;padding:2px 8px;border-radius:10px;font-size:10px;">${template.category || 'General'}</span>
                    <span style="background:#e0e0e0;color:#666;padding:2px 8px;border-radius:10px;font-size:10px;">${template.orientation || 'landscape'}</span>
                    ${template.is_system_template ? '<span style="background:#f39c12;color:#fff;padding:2px 8px;border-radius:10px;font-size:10px;">System</span>' : ''}
                </div>
                <div style="display:flex;gap:8px;">
                    <button class="teacher-btn teacher-btn-sm teacher-btn-primary" style="flex:1;" onclick="useTemplate(${template.id})"><i class="fas fa-edit"></i> Use</button>
                    <button class="teacher-btn teacher-btn-sm teacher-btn-secondary" onclick="previewTemplate(${template.id})"><i class="fas fa-eye"></i></button>
                    ${!template.is_system_template ? `<button class="teacher-btn teacher-btn-sm teacher-btn-danger" onclick="deleteTemplate(${template.id})"><i class="fas fa-trash"></i></button>` : ''}
                </div>
            </div>
        </div>
    `).join('');
}

function filterTemplates() {
    const searchTerm = document.getElementById('templateSearchInput').value.toLowerCase();
    const category = document.getElementById('templateCategoryFilter').value;

    let filtered = allTemplates.filter(template => {
        const matchesSearch = template.name.toLowerCase().includes(searchTerm) ||
                            (template.description && template.description.toLowerCase().includes(searchTerm));
        const matchesCategory = !category || template.category === category;
        const matchesSource = currentFilter === 'all' ||
                            (currentFilter === 'system' && template.is_system_template) ||
                            (currentFilter === 'my' && !template.is_system_template);

        return matchesSearch && matchesCategory && matchesSource;
    });

    renderTemplateGrid(filtered);
}

function filterBySource(source) {
    currentFilter = source;
    filterTemplates();
}

// ===== USE TEMPLATE =====
async function useTemplate(templateId) {
    try {
        const response = await fetch(CERTIFICATE_API + '?action=get_template&id=' + templateId);
        const result = await response.json();

        if (result.success && result.data) {
            closeTemplateBrowser();

            // Open designer directly (bypass new document dialog)
            document.getElementById('certificateDesignerOverlay').classList.add('show');
            document.getElementById('certificateDesignerModal').classList.add('show');

            // Initialize canvas with template dimensions
            const templateWidth = result.data.canvas_width || 1123;
            const templateHeight = result.data.canvas_height || 794;
            initCertificateCanvas(templateWidth, templateHeight);

            // Load template into canvas
            if (result.data.design_json) {
                const designJSON = JSON.parse(result.data.design_json);
                certificateCanvas.loadFromJSON(designJSON, function() {
                    certificateCanvas.renderAll();
                    showToast('Template loaded successfully!', 'success');
                });
            }
        } else {
            showToast('Failed to load template', 'error');
        }
    } catch (error) {
        console.error('Error loading template:', error);
        showToast('Error loading template', 'error');
    }
}

async function previewTemplate(templateId) {
    try {
        const response = await fetch(CERTIFICATE_API + '?action=get_template&id=' + templateId);
        const result = await response.json();

        if (result.success && result.data && result.data.preview_image) {
            const win = window.open();
            win.document.write('<img src="' + result.data.preview_image + '" style="max-width:100%;"/>');
        } else {
            showToast('No preview available', 'info');
        }
    } catch (error) {
        showToast('Error previewing template', 'error');
    }
}

async function deleteTemplate(templateId) {
    if (!confirm('Are you sure you want to delete this template? This action cannot be undone.')) {
        return;
    }

    try {
        const response = await fetch(CERTIFICATE_API + '?action=delete_template&id=' + templateId, {
            method: 'DELETE'
        });
        const result = await response.json();

        if (result.success) {
            showToast('Template deleted successfully!', 'success');
            loadCertificateTemplates();
        } else {
            showToast(result.message || 'Failed to delete template', 'error');
        }
    } catch (error) {
        showToast('Error deleting template', 'error');
    }
}

// ===== LOAD RECENT CERTIFICATES =====
async function loadRecentCertificates() {
    try {
        const response = await fetch(CERTIFICATE_API + '?action=get_recent_certificates&teacher_id=' + (currentTeacher ? currentTeacher.id : 0));
        const result = await response.json();

        if (result.success && result.data) {
            renderRecentCertificates(result.data);
        }
    } catch (error) {
        console.error('Error loading certificates:', error);
    }
}

function renderRecentCertificates(certificates) {
    const tbody = document.getElementById('recentCertificatesBody');
    if (!tbody) return;

    if (!certificates || certificates.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No certificates generated yet.</td></tr>';
        return;
    }

    tbody.innerHTML = certificates.map(cert => `
        <tr>
            <td>${cert.certificate_number || 'N/A'}</td>
            <td>${cert.student_name || 'N/A'}</td>
            <td>${cert.award_title || 'N/A'}</td>
            <td>${cert.date_issued || 'N/A'}</td>
            <td><span class="status-badge ${cert.status === 'active' ? 'good' : 'inactive'}">${cert.status || 'Active'}</span></td>
            <td>
                <button class="teacher-btn teacher-btn-sm teacher-btn-info" onclick="viewCertificate(${cert.id})"><i class="fas fa-eye"></i></button>
                <button class="teacher-btn teacher-btn-sm teacher-btn-primary" onclick="downloadCertificate(${cert.id})"><i class="fas fa-download"></i></button>
            </td>
        </tr>
    `).join('');
}

function viewCertificate(id) {
    showToast('View certificate feature coming soon!', 'info');
}

function downloadCertificate(id) {
    showToast('Download certificate feature coming soon!', 'info');
}
