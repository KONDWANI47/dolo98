// Parent Dashboard JavaScript - Noah Christian Academy

const API_BASE = '../api/index.php';

// ===== AUTHENTICATION =====
let currentParent = null;
let myChildren = [];
let currentWorkflowReport = null;
let currentReceipt = { id: null, url: null };
let parentClockInterval = null;

// ===== AUTH TAB SWITCHING =====
function switchAuthTab(tab, button) {
    const tabs = document.querySelectorAll('.auth-tab');
    tabs.forEach(t => t.classList.remove('active'));
    button.classList.add('active');

    const loginForm = document.getElementById('loginFormDiv');
    const registerForm = document.getElementById('registerFormDiv');

    if (tab === 'login') {
        loginForm.style.display = 'block';
        registerForm.style.display = 'none';
    } else {
        loginForm.style.display = 'none';
        registerForm.style.display = 'block';
        showRegStep1();
    }
}

// ===== REGISTRATION STEPS =====
function showRegStep1() {
    document.getElementById('regStep1').style.display = 'block';
    document.getElementById('regStep2').style.display = 'none';
    if (document.getElementById('regStep3')) document.getElementById('regStep3').style.display = 'none';
}

function showRegStep2() {
    const email = document.getElementById('regEmail').value.trim();
    const password = document.getElementById('regPassword').value;
    const errorEl = document.getElementById('registerError');

    if (!email || !password) {
        if (errorEl) {
            errorEl.textContent = 'Please enter both email and password';
            errorEl.classList.add('show');
        }
        return;
    }
    if (!email.includes('@') || !email.includes('.')) {
        if (errorEl) {
            errorEl.textContent = 'Please enter a valid email address';
            errorEl.classList.add('show');
        }
        return;
    }
    if (password.length < 8) {
        if (errorEl) {
            errorEl.textContent = 'Password must be at least 8 characters';
            errorEl.classList.add('show');
        }
        return;
    }

    document.getElementById('regStep1').style.display = 'none';
    document.getElementById('regStep2').style.display = 'block';
    if (errorEl) {
        errorEl.classList.remove('show');
        errorEl.textContent = '';
    }
}

async function apiParent(action, body = null) {
    const opts = {
        method: body ? 'POST' : 'GET',
        headers: { 'Content-Type': 'application/json' }
    };
    if (body) opts.body = JSON.stringify(body);
    try {
        const res = await fetch(`${API_BASE}?type=parent&action=${action}`, opts);
        const data = await res.json();
        return data;
    } catch (err) {
        console.error('API error:', err);
        return { success: false, message: 'Network error' };
    }
}

async function apiAuth(action, body = null) {
    const opts = {
        method: body ? 'POST' : 'GET',
        headers: { 'Content-Type': 'application/json' }
    };
    if (body) opts.body = JSON.stringify(body);
    try {
        const res = await fetch(`${API_BASE}?type=auth&action=${action}`, opts);
        const data = await res.json();
        return data;
    } catch (err) {
        console.error('Auth API error:', err);
        return { success: false, message: 'Network error' };
    }
}

// ===== SHARED HELPERS =====
function esc(value) {
    return String(value ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function setText(id, value) {
    const el = document.getElementById(id);
    if (el) el.textContent = value ?? '-';
}

function showToast(message, type = 'success') {
    const container = document.getElementById('toastContainer');
    if (!container) return;
    const toast = document.createElement('div');
    const colors = { success: '#085636', error: '#dc3545', info: '#17a2b8', warning: '#f39c12' };
    toast.style.cssText = `background:${colors[type] || colors.info};color:#fff;padding:12px 18px;border-radius:8px;box-shadow:0 6px 20px rgba(0,0,0,.2);font-size:14px;max-width:320px;opacity:0;transition:opacity .3s;`;
    toast.textContent = message;
    container.appendChild(toast);
    requestAnimationFrame(() => { toast.style.opacity = '1'; });
    setTimeout(() => {
        toast.style.opacity = '0';
        setTimeout(() => toast.remove(), 350);
    }, 4000);
}

function setAuthMessage(id, message, isError = true) {
    const el = document.getElementById(id);
    if (!el) return;
    el.textContent = message || '';
    el.classList.toggle('show', !!message);
    el.style.color = isError ? '#dc3545' : '#085636';
}

// ===== PASSWORD VISIBILITY TOGGLE =====
function togglePasswordVisibility(inputId, iconId) {
    const input = document.getElementById(inputId);
    const icon = document.getElementById(iconId);
    if (!input) return;
    const showing = input.type === 'text';
    input.type = showing ? 'password' : 'text';
    if (icon) icon.className = showing ? 'fas fa-eye' : 'fas fa-eye-slash';
}

// ===== SESSION =====
function saveParentSession(parent, remember = false) {
    const session = {
        id: parent.id,
        firstName: parent.firstName,
        lastName: parent.lastName,
        email: parent.email,
        phone: parent.phone,
        username: parent.username,
        studentIds: parent.studentIds,
        accessToken: parent.accessToken
    };
    if (remember) {
        localStorage.setItem('parent_session', JSON.stringify(session));
    } else {
        sessionStorage.setItem('parent_session', JSON.stringify(session));
    }
}

function loadParentSession() {
    try {
        const local = localStorage.getItem('parent_session');
        const session = local ? JSON.parse(local) : JSON.parse(sessionStorage.getItem('parent_session') || 'null');
        if (session && session.id) {
            currentParent = session;
            return true;
        }
    } catch (e) {
        console.error('Session parse error:', e);
    }
    return false;
}

function clearParentSession() {
    localStorage.removeItem('parent_session');
    sessionStorage.removeItem('parent_session');
    currentParent = null;
}

function showParentDashboard() {
    const auth = document.getElementById('authScreen');
    const dash = document.getElementById('parentDashboard');
    if (auth) auth.style.display = 'none';
    if (dash) dash.style.display = 'block';
    setText('parentDisplayName', ((currentParent.firstName || '') + ' ' + (currentParent.lastName || '')).trim() || 'Parent');
    setText('parentWelcomeName', currentParent.firstName || 'Parent');
    startParentClock();
}

// ===== PARENT LOGIN =====
async function handleParentLogin(event) {
    if (event) event.preventDefault();

    const usernameEl = document.getElementById('parentUsername');
    const passwordEl = document.getElementById('parentPassword');
    const rememberEl = document.getElementById('parentRememberMe');
    const username = usernameEl ? usernameEl.value.trim() : '';
    const password = passwordEl ? passwordEl.value : '';

    setAuthMessage('loginError', '');

    if (!username || !password) {
        setAuthMessage('loginError', 'Please enter your email/username and password');
        return false;
    }

    const result = await apiAuth('parent_login', { username, password });

    if (result.success && result.data) {
        const remember = rememberEl ? rememberEl.checked : false;
        saveParentSession(result.data, remember);
        currentParent = result.data;
        if (usernameEl) usernameEl.value = '';
        if (passwordEl) passwordEl.value = '';
        showParentDashboard();
        loadParentDashboard();
        setTimeout(() => checkPendingDeletion(), 150);
        initializeParentOnboarding();
        showToast('Welcome back, ' + (currentParent.firstName || 'Parent') + '!', 'success');
    } else {
        setAuthMessage('loginError', result.message || 'Login failed. Please try again.');
    }
    return false;
}

// ===== AUTO LOGIN (session restore) =====
async function autoLogin() {
    if (!loadParentSession()) return false;

    // Refresh profile from the server; keep the session on network errors
    const profile = await apiParent('parent_profile', { parent_id: currentParent.id });
    if (profile.success && profile.data) {
        currentParent = { ...currentParent, ...profile.data };
        saveParentSession(currentParent, !!localStorage.getItem('parent_session'));
    } else if (profile.message && /not found/i.test(profile.message)) {
        clearParentSession();
        return false;
    }

    showParentDashboard();
    loadParentDashboard();
    setTimeout(() => checkPendingDeletion(), 150);
    initializeParentOnboarding();
    return true;
}

// ===== PARENT REGISTRATION =====
async function handleParentRegister(event) {
    if (event) {
        event.preventDefault();
    }

    const fullName = document.getElementById('regFullName')?.value.trim();
    const email = document.getElementById('regEmail')?.value.trim();
    const password = document.getElementById('regPassword')?.value.trim();
    const confirmPassword = document.getElementById('regConfirmPassword')?.value.trim();
    const errorEl = document.getElementById('registerError');

    // Split full name into first and last name
    let firstName = '';
    let lastName = '';
    if (fullName) {
        const nameParts = fullName.trim().split(/\s+/);
        firstName = nameParts[0] || '';
        lastName = nameParts.slice(1).join(' ') || '';
    }

    // Validation
    if (!firstName || !lastName || !email || !password || !confirmPassword) {
        if (errorEl) {
            errorEl.textContent = 'All fields are required';
            errorEl.classList.add('show');
        }
        return false;
    }

    if (password !== confirmPassword) {
        if (errorEl) {
            errorEl.textContent = 'Passwords do not match';
            errorEl.classList.add('show');
        }
        return false;
    }

    if (password.length < 8) {
        if (errorEl) {
            errorEl.textContent = 'Password must be at least 8 characters';
            errorEl.classList.add('show');
        }
        return false;
    }

    const result = await apiAuth('parent_register', {
        firstName,
        lastName,
        email,
        password
    });

    if (result.success) {
        if (result.requiresCode) {
            // Show verification code step
            showRegStep3();
            if (errorEl) {
                errorEl.classList.remove('show');
            }

            // Always show the code on screen (for now, since email might be flaky)
            if (result.code) {
                const codeDisplay = document.getElementById('regCodeDisplay');
                const codeValue = document.getElementById('regCodeValue');
                if (codeDisplay && codeValue) {
                    codeValue.textContent = result.code;
                    codeDisplay.style.display = 'block';
                }
                showToast('Your verification code is: ' + result.code, 'success');
            } else {
                showToast('Account created! Please enter the verification code sent to your email.', 'success');
            }
        } else {
            showToast('Account created successfully! You can now log in.', 'success');
            const firstTab = document.querySelector('.auth-tab:first-child');
            if (firstTab) switchAuthTab('login', firstTab);
            document.getElementById('registerFormDiv').querySelector('form').reset();
            showRegStep1();
        }
    } else {
        if (errorEl) {
            errorEl.textContent = result.message || 'Registration failed';
            errorEl.classList.add('show');
        }
    }
    return false;
}

function showRegStep3() {
    document.getElementById('regStep1').style.display = 'none';
    document.getElementById('regStep2').style.display = 'none';
    document.getElementById('regStep3').style.display = 'block';
}

async function verifyParentCode() {
    const code = document.getElementById('regCode')?.value.trim().toUpperCase();
    const errorEl = document.getElementById('verifyError');

    if (!code) {
        if (errorEl) {
            errorEl.textContent = 'Please enter the verification code';
            errorEl.classList.add('show');
        }
        return;
    }

    const result = await apiAuth('verify_code', { code: code, type: 'parent' });

    if (result.success) {
        showToast('Account verified successfully! You can now log in.', 'success');
        const firstTab = document.querySelector('.auth-tab:first-child');
        if (firstTab) switchAuthTab('login', firstTab);
        document.getElementById('registerFormDiv').querySelector('form').reset();
        showRegStep1();
        if (errorEl) {
            errorEl.classList.remove('show');
        }
    } else {
        if (errorEl) {
            errorEl.textContent = result.message || 'Invalid code';
            errorEl.classList.add('show');
        }
    }
}

// ===== SIDEBAR TOGGLE =====
function toggleSidebar() {
    const sidebar = document.getElementById('parentSidebar');
    const mainContent = document.querySelector('.parent-main');

    if (sidebar) {
        sidebar.classList.toggle('open');
    }
    if (mainContent) {
        mainContent.classList.toggle('shifted');
    }
}

// ===== SIDEBAR NAVIGATION =====
function showSection(sectionName) {
    const sections = document.querySelectorAll('.content-section');
    sections.forEach(section => {
        section.style.display = 'none';
        section.classList.remove('active');
    });

    const targetSection = document.getElementById(`section-${sectionName}`);
    if (targetSection) {
        targetSection.style.display = 'block';
        targetSection.classList.add('active');
    }

    const navButtons = document.querySelectorAll('.sidebar-nav-btn');
    navButtons.forEach(btn => {
        btn.classList.remove('active');
        if (btn.dataset.section === sectionName) {
            btn.classList.add('active');
        }
    });

    if (sectionName === 'dashboard') {
        loadParentDashboard();
    } else if (sectionName === 'register') {
        loadRegistration();
    } else if (sectionName === 'payments') {
        loadPayments();
    } else if (sectionName === 'results') {
        loadResultsChildren();
    } else if (sectionName === 'workflow_reports') {
        loadWorkflowReports();
    } else if (sectionName === 'settings') {
        loadSettings();
    } else if (sectionName === 'complaints') {
        loadMyComplaints();
    } else if (sectionName === 'profile') {
        loadProfile();
    } else if (sectionName === 'devices') {
        loadLoginHistory();
    } else {
        console.log('Unknown section:', sectionName);
    }

    if (window.innerWidth <= 992) toggleSidebar();
}

// ===== DASHBOARD =====
async function loadParentDashboard() {
    if (!currentParent) return;
    const childrenRes = await apiParent('my_children', { parent_id: currentParent.id });
    myChildren = childrenRes.success ? (childrenRes.data?.items || []) : [];

    renderMyChildren();
    updateParentStats();
    renderAnnouncements();
    renderUpcomingEvents();
    loadMyNotifications();
}

function renderMyChildren() {
    const body = document.getElementById('myChildrenBody');
    if (!body) return;

    if (!myChildren.length) {
        body.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No children linked to your account yet. Register a child or contact admin.</td></tr>';
        return;
    }

    body.innerHTML = myChildren.map((c, i) => `
        <tr>
            <td>${i + 1}</td>
            <td><strong>${esc(c.firstName)} ${esc(c.lastName)}</strong></td>
            <td>${esc(c.grade)}</td>
            <td>${c.avgScore ? esc(c.avgScore) + '%' : '-'}</td>
            <td>${c.totalDaysThisMonth ? esc(c.presentThisMonth) + '/' + esc(c.totalDaysThisMonth) : '-'}</td>
            <td>
                <button class="parent-btn parent-btn-info parent-btn-sm" onclick="viewChildProgress(${c.id}, '${esc(c.firstName)} ${esc(c.lastName)}')"><i class="fas fa-chart-line"></i> Progress</button>
                <button class="parent-btn parent-btn-primary parent-btn-sm" onclick="viewChildReport(${c.id}, '${esc(c.firstName)} ${esc(c.lastName)}')"><i class="fas fa-file-alt"></i> Report</button>
            </td>
        </tr>
    `).join('');
}

function updateParentStats() {
    setText('pStatStudents', myChildren.length);
    const good = myChildren.filter(c => (c.avgScore || 0) >= 75).length;
    const attention = myChildren.filter(c => c.avgScore > 0 && c.avgScore < 50).length;
    const present = myChildren.reduce((sum, c) => sum + (c.presentThisMonth || 0), 0);
    setText('pStatGood', good);
    setText('pStatAverage', attention);
    setText('pStatAttendance', present);
}

async function renderAnnouncements() {
    const wrap = document.getElementById('announcementsFeed');
    if (!wrap) return;
    const res = await apiParent('announcements');
    const items = res.success ? (res.data?.items || []) : [];
    if (!items.length) {
        wrap.innerHTML = '<p class="text-muted">No announcements right now.</p>';
        return;
    }
    wrap.innerHTML = items.map(a => {
        const priority = (a.priority || '').toLowerCase();
        const color = priority === 'urgent' ? '#dc3545' : (priority === 'important' ? '#f39c12' : '#085636');
        return `
            <div style="border-left:4px solid ${color};background:#f8f9fa;padding:12px 14px;border-radius:6px;margin-bottom:10px;">
                <strong style="color:${color};">${esc(a.title)}</strong>
                <p style="margin:6px 0 0;font-size:14px;color:#555;">${esc(a.content)}</p>
                <small style="color:#999;">${a.createdAt ? new Date(a.createdAt).toLocaleString() : ''}</small>
            </div>`;
    }).join('');
}

async function renderUpcomingEvents() {
    const body = document.getElementById('eventsBody');
    if (!body) return;
    const res = await apiParent('upcoming_events');
    const items = res.success ? (res.data?.items || []) : [];
    if (!items.length) {
        body.innerHTML = '<tr><td colspan="4" class="text-center text-muted">No upcoming events.</td></tr>';
        return;
    }
    body.innerHTML = items.map(e => `
        <tr>
            <td>${esc(e.title)}</td>
            <td>${esc(e.date)}</td>
            <td>${esc(e.time) || '-'}</td>
            <td>${esc(e.location) || '-'}</td>
        </tr>
    `).join('');
}

async function loadMyNotifications() {
    const wrap = document.getElementById('notificationsList');
    if (!wrap || !currentParent) return;
    const res = await apiParent('my_notifications', { parent_id: currentParent.id });
    const items = res.success ? (res.data?.items || []) : [];
    if (!items.length) {
        wrap.innerHTML = '<p class="text-muted">You have no notifications.</p>';
        return;
    }
    wrap.innerHTML = items.map(n => `
        <div style="display:flex;gap:10px;padding:10px 0;border-bottom:1px solid #eee;">
            <i class="fas fa-bell" style="color:#085636;margin-top:3px;"></i>
            <div>
                <strong style="font-size:14px;">${esc(n.title)}</strong>
                <p style="margin:4px 0 0;font-size:13px;color:#666;">${esc(n.message)}</p>
                <small style="color:#999;">${n.createdAt ? new Date(n.createdAt).toLocaleString() : ''}</small>
            </div>
        </div>
    `).join('');
}

// ===== CHILD PROGRESS / REPORT MODALS =====
function openProgressModal(title, html) {
    setText('progressModalTitle', title);
    const body = document.getElementById('progressModalBody');
    if (body) body.innerHTML = html;
    const overlay = document.getElementById('progressModalOverlay');
    const modal = document.getElementById('progressModal');
    if (overlay) overlay.style.display = 'block';
    if (modal) modal.style.display = 'block';
}

function closeProgressModal() {
    const overlay = document.getElementById('progressModalOverlay');
    const modal = document.getElementById('progressModal');
    if (overlay) overlay.style.display = 'none';
    if (modal) modal.style.display = 'none';
}

async function viewChildProgress(studentId, studentName) {
    openProgressModal('<i class="fas fa-chart-bar"></i> ' + esc(studentName), '<p class="text-muted">Loading progress...</p>');
    const res = await apiParent('child_progress', { parent_id: currentParent.id, student_id: studentId });
    if (!res.success) {
        openProgressModal('<i class="fas fa-chart-bar"></i> ' + esc(studentName), `<p class="text-muted">${esc(res.message || 'Could not load progress.')}</p>`);
        return;
    }
    const d = res.data;
    const assessmentRows = (d.assessments || []).length
        ? d.assessments.map(a => `
            <tr>
                <td>${esc(a.subject)}</td>
                <td>${esc(a.type)}</td>
                <td>${esc(a.score)}%</td>
                <td>${esc(a.date)}</td>
                <td>${esc(a.remarks) || '-'}</td>
            </tr>`).join('')
        : '<tr><td colspan="5" class="text-center text-muted">No assessments recorded yet.</td></tr>';

    openProgressModal('<i class="fas fa-chart-bar"></i> ' + esc(studentName), `
        <div style="display:flex;gap:15px;flex-wrap:wrap;margin-bottom:16px;">
            <div style="flex:1;min-width:140px;background:#e8f5e9;padding:14px;border-radius:8px;text-align:center;">
                <h3 style="margin:0;color:#085636;">${esc(d.averageScore)}%</h3>
                <p style="margin:4px 0 0;font-size:13px;color:#555;">Average Score</p>
            </div>
            <div style="flex:1;min-width:140px;background:#e3f2fd;padding:14px;border-radius:8px;text-align:center;">
                <h3 style="margin:0;color:#1565c0;">${esc(d.totalAssessments)}</h3>
                <p style="margin:4px 0 0;font-size:13px;color:#555;">Assessments</p>
            </div>
        </div>
        <div class="table-responsive">
            <table class="parent-table">
                <thead><tr><th>Subject</th><th>Type</th><th>Score</th><th>Date</th><th>Remarks</th></tr></thead>
                <tbody>${assessmentRows}</tbody>
            </table>
        </div>
    `);
}

async function viewChildReport(studentId, studentName) {
    const selection = document.getElementById('resultsSelection');
    const container = document.getElementById('reportCardContainer');
    const content = document.getElementById('reportCardContent');
    if (!container || !content) return;
    content.innerHTML = '<p class="text-muted">Loading report card...</p>';
    if (selection) selection.style.display = 'none';
    container.style.display = 'block';

    const res = await apiParent('child_report', { parent_id: currentParent.id, student_id: studentId });
    if (!res.success) {
        content.innerHTML = `<p class="text-muted">${esc(res.message || 'Could not load report card.')}</p>`;
        return;
    }
    const d = res.data;
    const attendance = d.attendance || {};
    const subjectRows = Object.keys(d.subjects || {}).length
        ? Object.entries(d.subjects).map(([subj, s]) => `
            <tr>
                <td><strong>${esc(subj)}</strong></td>
                <td>${esc(s.average)}%</td>
                <td>${esc(s.count)}</td>
            </tr>`).join('')
        : '<tr><td colspan="3" class="text-center text-muted">No subject data yet.</td></tr>';

    content.innerHTML = `
        <div style="border:2px solid #085636;border-radius:12px;overflow:hidden;">
            <div style="background:#085636;color:#fff;padding:18px;text-align:center;">
                <h3 style="margin:0;">Noah Christian Academy</h3>
                <p style="margin:4px 0 0;">Student Report Card</p>
            </div>
            <div style="padding:20px;">
                <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;margin-bottom:18px;">
                    <div><strong>Student:</strong> ${esc(d.student.firstName)} ${esc(d.student.lastName)}</div>
                    <div><strong>Class:</strong> ${esc(d.student.grade)}</div>
                    <div><strong>Status:</strong> ${esc(d.student.status)}</div>
                    <div><strong>Overall Average:</strong> ${esc(d.overallAverage)}%</div>
                </div>
                <table class="parent-table">
                    <thead><tr><th>Subject</th><th>Average</th><th>Assessments</th></tr></thead>
                    <tbody>${subjectRows}</tbody>
                </table>
                <div style="display:flex;gap:20px;margin-top:18px;flex-wrap:wrap;">
                    <div style="background:#e8f5e9;padding:12px 18px;border-radius:8px;">Present: <strong>${esc(attendance.present)}</strong></div>
                    <div style="background:#fff3e0;padding:12px 18px;border-radius:8px;">Late: <strong>${esc(attendance.late)}</strong></div>
                    <div style="background:#ffebee;padding:12px 18px;border-radius:8px;">Absent: <strong>${esc(attendance.absent)}</strong></div>
                </div>
            </div>
        </div>
    `;
}

function closeReportCard() {
    const selection = document.getElementById('resultsSelection');
    const container = document.getElementById('reportCardContainer');
    if (selection) selection.style.display = 'block';
    if (container) container.style.display = 'none';
    loadResultsChildren();
}

async function loadResultsChildren() {
    const wrap = document.getElementById('resultsChildrenList');
    if (!wrap) return;
    if (!myChildren.length && currentParent) {
        const childrenRes = await apiParent('my_children', { parent_id: currentParent.id });
        myChildren = childrenRes.success ? (childrenRes.data?.items || []) : [];
    }
    if (!myChildren.length) {
        wrap.innerHTML = '<p class="text-muted">No children linked to your account yet.</p>';
        return;
    }
    wrap.innerHTML = myChildren.map(c => `
        <button class="parent-btn parent-btn-primary" onclick="viewChildReport(${c.id}, '${esc(c.firstName)} ${esc(c.lastName)}')">
            <i class="fas fa-user-graduate"></i> ${esc(c.firstName)} ${esc(c.lastName)} (${esc(c.grade)})
        </button>
    `).join('');
}

// ===== REGISTER CHILD =====
async function loadRegistration() {
    if (!currentParent) return;
    const res = await apiParent('my_registrations', { parent_id: currentParent.id });
    const body = document.getElementById('myRegistrationsBody');
    if (!body) return;
    const items = res.success ? (res.data?.items || []) : [];
    if (!items.length) {
        body.innerHTML = '<tr><td colspan="5" class="text-center text-muted">No registrations found.</td></tr>';
        return;
    }
    body.innerHTML = items.map((r, i) => {
        const statusColor = r.status === 'Approved' ? '#2ecc71' : (r.status === 'Rejected' ? '#e74c3c' : '#f39c12');
        return `
        <tr>
            <td>${i + 1}</td>
            <td>${esc(r.studentName)}</td>
            <td>${esc(r.grade)}</td>
            <td>${r.createdAt ? new Date(r.createdAt).toLocaleDateString() : '-'}</td>
            <td><span style="background:${statusColor};color:#fff;padding:3px 10px;border-radius:12px;font-size:12px;">${esc(r.status)}</span></td>
        </tr>`;
    }).join('');
}

function clearRegisterChildForm() {
    const form = document.getElementById('registerChildForm');
    if (form) form.reset();
    setAuthMessage('registerChildError', '');
    setAuthMessage('registerChildSuccess', '', false);
}

function attachParentFormHandlers() {
    const registerForm = document.getElementById('registerChildForm');
    if (registerForm) {
        registerForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            setAuthMessage('registerChildError', '');
            setAuthMessage('registerChildSuccess', '', false);

            const firstName = document.getElementById('childFirstName').value.trim();
            const lastName = document.getElementById('childLastName').value.trim();
            const grade = document.getElementById('childGrade').value;

            if (!firstName || !lastName || !grade) {
                setAuthMessage('registerChildError', 'First name, last name and class are required');
                return;
            }

            const res = await apiParent('register_child', {
                parent_id: currentParent.id,
                firstName,
                lastName,
                grade,
                gender: document.getElementById('childGender').value,
                dob: document.getElementById('childDob').value || null,
                phone: document.getElementById('childPhone').value.trim(),
                address: document.getElementById('childAddress').value.trim(),
                emergencyContact: document.getElementById('childEmergencyContact').value.trim(),
                emergencyPhone: document.getElementById('childEmergencyPhone').value.trim(),
                medicalInfo: document.getElementById('childMedicalInfo').value.trim()
            });

            if (res.success) {
                setAuthMessage('registerChildSuccess', res.message || 'Registration submitted!', false);
                showToast(res.message || 'Child registration submitted.', 'success');
                registerForm.reset();
                loadRegistration();
            } else {
                setAuthMessage('registerChildError', res.message || 'Registration failed');
            }
        });
    }

    const paymentForm = document.getElementById('makePaymentForm');
    if (paymentForm) {
        paymentForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            setAuthMessage('paymentError', '');
            setAuthMessage('paymentSuccess', '', false);

            const studentName = document.getElementById('payStudentName').value.trim();
            const paymentType = document.getElementById('payType').value;
            const amount = parseFloat(document.getElementById('payAmount').value);
            const paymentMethod = document.getElementById('payMethod').value;

            if (!studentName || !paymentType || !paymentMethod || !(amount > 0)) {
                setAuthMessage('paymentError', 'Please fill in all required fields with a valid amount');
                return;
            }

            const res = await apiParent('make_payment', {
                parent_id: currentParent.id,
                studentName,
                paymentType,
                amount,
                paymentMethod,
                phone: document.getElementById('payPhone').value.trim(),
                notes: document.getElementById('payNotes').value.trim()
            });

            if (res.success) {
                setAuthMessage('paymentSuccess', res.message || 'Payment submitted!', false);
                showToast(res.message || 'Payment submitted.', 'success');
                paymentForm.reset();
                loadPayments();
            } else {
                setAuthMessage('paymentError', res.message || 'Payment failed');
            }
        });
    }

    const complaintForm = document.getElementById('complaintForm');
    if (complaintForm) {
        complaintForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            setAuthMessage('complaintError', '');
            setAuthMessage('complaintSuccess', '', false);

            const studentName = document.getElementById('complaintStudentName').value.trim();
            const className = document.getElementById('complaintClass').value;
            const complaintText = document.getElementById('complaintText').value.trim();

            if (!studentName || !className || !complaintText) {
                setAuthMessage('complaintError', 'Please fill in all required fields');
                return;
            }

            const res = await apiParent('submit_complaint', {
                parent_id: currentParent.id,
                studentName,
                className,
                complaintText
            });

            if (res.success) {
                setAuthMessage('complaintSuccess', res.message || 'Complaint submitted!', false);
                showToast(res.message || 'Complaint submitted.', 'success');
                complaintForm.reset();
                loadMyComplaints();
            } else {
                setAuthMessage('complaintError', res.message || 'Submission failed');
            }
        });
    }
}

function clearPaymentForm() {
    const form = document.getElementById('makePaymentForm');
    if (form) form.reset();
    setAuthMessage('paymentError', '');
    setAuthMessage('paymentSuccess', '', false);
}

// ===== PAYMENTS =====
async function loadPayments() {
    if (!currentParent) return;
    const res = await apiParent('my_payments', { parent_id: currentParent.id });
    const body = document.getElementById('myPaymentsBody');
    if (!body) return;
    const items = res.success ? (res.data?.items || []) : [];
    if (!items.length) {
        body.innerHTML = '<tr><td colspan="8" class="text-center text-muted">No payments found.</td></tr>';
        return;
    }
    body.innerHTML = items.map((p, i) => {
        const statusColor = p.status === 'Paid' ? '#2ecc71' : (p.status === 'Failed' ? '#e74c3c' : '#f39c12');
        return `
        <tr>
            <td>${i + 1}</td>
            <td>${esc(p.studentName)}</td>
            <td>${esc(p.paymentType)}</td>
            <td>${Number(p.amount).toLocaleString()}</td>
            <td>${esc(p.paymentMethod)}</td>
            <td>${p.createdAt ? new Date(p.createdAt).toLocaleDateString() : '-'}</td>
            <td><span style="background:${statusColor};color:#fff;padding:3px 10px;border-radius:12px;font-size:12px;">${esc(p.status)}</span></td>
            <td><button class="parent-btn parent-btn-info parent-btn-sm" onclick="viewReceipt(${p.id})"><i class="fas fa-receipt"></i> Receipt</button></td>
        </tr>`;
    }).join('');
}

async function viewReceipt(paymentId) {
    currentReceipt = { id: paymentId, url: null };
    const wrap = document.getElementById('receiptContent');
    if (wrap) wrap.innerHTML = '<p>Loading receipt...</p>';
    const overlay = document.getElementById('receiptOverlay');
    const modal = document.getElementById('receiptModal');
    if (overlay) overlay.style.display = 'block';
    if (modal) modal.style.display = 'block';

    try {
        const res = await fetch(`../api/generate_receipt.php?action=generate&id=${paymentId}`);
        const data = await res.json();
        if (data.success && data.data && data.data.url) {
            currentReceipt.url = data.data.url;
            if (wrap) {
                wrap.innerHTML = `
                    <p>Receipt generated: <strong>${esc(data.data.filename)}</strong></p>
                    <iframe src="${esc(data.data.url)}" style="width:100%;height:420px;border:1px solid #ddd;border-radius:8px;"></iframe>
                    <p style="margin-top:10px;"><a href="${esc(data.data.url)}" target="_blank" rel="noopener">Open receipt in a new tab</a></p>
                `;
            }
        } else if (wrap) {
            wrap.innerHTML = `<p class="text-muted">${esc(data.message || 'Receipt unavailable.')}</p>`;
        }
    } catch (err) {
        if (wrap) wrap.innerHTML = '<p class="text-muted">Could not load the receipt. Please try again.</p>';
    }
}

function closeReceiptModal() {
    const overlay = document.getElementById('receiptOverlay');
    const modal = document.getElementById('receiptModal');
    if (overlay) overlay.style.display = 'none';
    if (modal) modal.style.display = 'none';
}

function printReceipt() {
    if (currentReceipt.url) {
        window.open(currentReceipt.url, '_blank');
        return;
    }
    const content = document.getElementById('receiptContent');
    if (!content) return;
    const win = window.open('', '_blank', 'width=800,height=600');
    if (!win) {
        showToast('Please allow pop-ups to print the receipt.', 'warning');
        return;
    }
    win.document.write('<html><head><title>Receipt</title></head><body onload="window.print()">' + content.innerHTML + '</body></html>');
    win.document.close();
}

function openEmailReceiptModal() {
    if (!currentReceipt.id) return;
    const overlay = document.getElementById('emailReceiptOverlay');
    const modal = document.getElementById('emailReceiptModal');
    const emailInput = document.getElementById('receiptEmail');
    if (emailInput && currentParent && currentParent.email) emailInput.value = currentParent.email;
    setAuthMessage('emailReceiptError', '');
    setAuthMessage('emailReceiptSuccess', '', false);
    if (overlay) overlay.style.display = 'block';
    if (modal) modal.style.display = 'block';
}

function closeEmailReceiptModal() {
    const overlay = document.getElementById('emailReceiptOverlay');
    const modal = document.getElementById('emailReceiptModal');
    if (overlay) overlay.style.display = 'none';
    if (modal) modal.style.display = 'none';
}

async function sendReceiptEmail() {
    if (!currentReceipt.id) return;
    const emailInput = document.getElementById('receiptEmail');
    const messageInput = document.getElementById('receiptMessage');
    const email = emailInput ? emailInput.value.trim() : '';
    setAuthMessage('emailReceiptError', '');
    setAuthMessage('emailReceiptSuccess', '', false);

    if (!email) {
        setAuthMessage('emailReceiptError', 'Email address is required');
        return;
    }

    try {
        const res = await fetch(`../api/generate_receipt.php?action=send_email&id=${currentReceipt.id}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, message: messageInput ? messageInput.value.trim() : '' })
        });
        const data = await res.json();
        if (data.success) {
            setAuthMessage('emailReceiptSuccess', data.message || 'Receipt emailed!', false);
            showToast(data.message || 'Receipt sent by email.', 'success');
            setTimeout(closeEmailReceiptModal, 1200);
        } else {
            setAuthMessage('emailReceiptError', data.message || 'Failed to send email');
        }
    } catch (err) {
        setAuthMessage('emailReceiptError', 'Network error. Please try again.');
    }
}

// ===== SCHOOL (WORKFLOW) REPORTS =====
async function loadWorkflowReports() {
    const wrap = document.getElementById('workflowReportsList');
    if (!wrap || !currentParent) return;
    wrap.innerHTML = '<p class="text-muted">Loading reports...</p>';

    const res = await apiParent('workflow_reports', { parent_id: currentParent.id });
    const items = res.success ? (res.data?.items || []) : [];
    if (!items.length) {
        wrap.innerHTML = '<p class="text-muted">No school reports have been shared with you yet.</p>';
        return;
    }
    wrap.innerHTML = items.map(r => `
        <div style="border:1px solid #e0e0e0;border-radius:10px;padding:16px;margin-bottom:12px;display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;align-items:center;">
            <div>
                <strong style="color:#085636;">${esc(r.studentName)} — ${esc(r.className)}</strong>
                <p style="margin:4px 0 0;font-size:13px;color:#666;">Term: ${esc(r.term)} · Teacher: ${esc(r.teacherName)} · Overall: ${esc(r.overallGrade) || '-'}</p>
                <small style="color:#999;">Status: ${esc(r.status)}${r.grantedAt ? ' · ' + new Date(r.grantedAt).toLocaleDateString() : ''}</small>
            </div>
            <button class="parent-btn parent-btn-primary parent-btn-sm" onclick="viewWorkflowReport(${r.accessId}, ${r.id})">
                <i class="fas fa-eye"></i> View
            </button>
        </div>
    `).join('');
}

async function viewWorkflowReport(accessId, reportId) {
    const overlay = document.getElementById('workflowReportOverlay');
    const modal = document.getElementById('workflowReportModal');
    if (overlay) overlay.style.display = 'block';
    if (modal) modal.style.display = 'block';

    const res = await apiParent('view_workflow_report', { accessId, parentId: currentParent.id });
    if (!res.success) {
        showToast(res.message || 'Could not load the report', 'error');
        return;
    }

    const report = res.data.report || {};
    currentWorkflowReport = { reportId: report.id || reportId, accessId };

    setText('workflowReportStudentName', report.studentName);
    setText('workflowReportClass', report.className);
    setText('workflowReportTerm', report.term);
    setText('workflowReportYear', report.academicYear);
    setText('workflowReportTeacher', report.teacherName);
    setText('workflowReportOverallGrade', report.overallGrade);
    setText('workflowReportComment', report.overallComment || '-');

    const subjects = document.getElementById('workflowReportSubjects');
    const data = report.reportData || [];
    if (subjects) {
        if (Array.isArray(data) && data.length) {
            subjects.innerHTML = `
                <table class="parent-table">
                    <thead><tr><th>Subject</th><th>Score / Grade</th><th>Remarks</th></tr></thead>
                    <tbody>${data.map(s => `
                        <tr>
                            <td>${esc(s.subject || s.name || '-')}</td>
                            <td>${esc(s.score ?? s.grade ?? s.mark ?? '-')}</td>
                            <td>${esc(s.remarks || s.comment || '-')}</td>
                        </tr>`).join('')}
                    </tbody>
                </table>`;
        } else {
            subjects.innerHTML = '<p class="text-muted">No subject details available.</p>';
        }
    }

    const signature = document.getElementById('workflowReportSignature');
    if (signature) {
        if (report.signatureImg) {
            signature.src = report.signatureImg;
            signature.style.display = 'inline-block';
        } else {
            signature.style.display = 'none';
        }
    }

    const feedback = document.getElementById('workflowReportFeedback');
    if (feedback) feedback.value = '';
}

function closeWorkflowReportModal() {
    const overlay = document.getElementById('workflowReportOverlay');
    const modal = document.getElementById('workflowReportModal');
    if (overlay) overlay.style.display = 'none';
    if (modal) modal.style.display = 'none';
}

async function submitReportFeedback() {
    if (!currentWorkflowReport) {
        showToast('Open a report first', 'warning');
        return;
    }
    const feedback = document.getElementById('workflowReportFeedback');
    const text = feedback ? feedback.value.trim() : '';
    if (!text) {
        showToast('Please write some feedback first', 'warning');
        return;
    }

    const res = await apiParent('submit_report_feedback', {
        reportId: currentWorkflowReport.reportId,
        parentId: currentParent.id,
        feedback: text
    });

    if (res.success) {
        showToast(res.message || 'Feedback submitted', 'success');
        if (feedback) feedback.value = '';
        closeWorkflowReportModal();
    } else {
        showToast(res.message || 'Could not submit feedback', 'error');
    }
}

// ===== COMPLAINTS =====
function clearComplaintForm() {
    const form = document.getElementById('complaintForm');
    if (form) form.reset();
    setAuthMessage('complaintError', '');
    setAuthMessage('complaintSuccess', '', false);
}

async function loadMyComplaints() {
    const body = document.getElementById('myComplaintsBody');
    if (!body || !currentParent) return;
    const res = await apiParent('my_complaints', { parent_id: currentParent.id });
    const items = res.success ? (res.data?.items || []) : [];
    if (!items.length) {
        body.innerHTML = '<tr><td colspan="8" class="text-center text-muted">No complaints submitted yet.</td></tr>';
        return;
    }
    body.innerHTML = items.map((c, i) => {
        const statusColor = c.status === 'resolved' || c.status === 'Resolved' ? '#2ecc71' : (c.status === 'rejected' || c.status === 'Rejected' ? '#e74c3c' : '#f39c12');
        const canEdit = (c.status || '').toLowerCase() === 'pending';
        return `
        <tr>
            <td>${i + 1}</td>
            <td>${esc(c.parentName)}</td>
            <td>${esc(c.className)}</td>
            <td style="max-width:220px;">${esc(c.complaintText)}</td>
            <td><span style="background:${statusColor};color:#fff;padding:3px 10px;border-radius:12px;font-size:12px;">${esc(c.status)}</span></td>
            <td>${c.createdAt ? new Date(c.createdAt).toLocaleDateString() : '-'}</td>
            <td style="max-width:200px;">${esc(c.teacherResponse) || '-'}</td>
            <td>
                ${canEdit ? `<button class="parent-btn parent-btn-warning parent-btn-sm" onclick="editComplaint(${c.id})"><i class="fas fa-edit"></i></button>` : ''}
                <button class="parent-btn parent-btn-danger parent-btn-sm" onclick="deleteComplaint(${c.id})"><i class="fas fa-trash"></i></button>
            </td>
        </tr>`;
    }).join('');
}

async function editComplaint(id) {
    const items = document.getElementById('myComplaintsBody');
    const current = items ? items.querySelector(`tr[data-complaint-id="${id}"]`) : null;
    const existing = current ? current.getAttribute('data-text') : null;
    const text = prompt('Edit your complaint:', existing || '');
    if (text === null) return;

    const res = await apiParent('edit_complaint', {
        parent_id: currentParent.id,
        complaint_id: id,
        complaint_text: text.trim()
    });
    if (res.success) {
        showToast(res.message || 'Complaint updated', 'success');
        loadMyComplaints();
    } else {
        showToast(res.message || 'Could not update complaint', 'error');
    }
}

async function deleteComplaint(id) {
    if (!confirm('Delete this complaint? This cannot be undone.')) return;
    const res = await apiParent('delete_complaint', { parent_id: currentParent.id, complaint_id: id });
    if (res.success) {
        showToast(res.message || 'Complaint deleted', 'success');
        loadMyComplaints();
    } else {
        showToast(res.message || 'Could not delete complaint', 'error');
    }
}

// ===== PROFILE =====
async function loadProfile() {
    if (!currentParent) return;
    const res = await apiParent('parent_profile', { parent_id: currentParent.id });
    const p = res.success && res.data ? res.data : currentParent;

    setText('profileFullName', `${p.firstName || ''} ${p.lastName || ''}`.trim() || 'Parent');
    setText('profileUsername', '@' + (p.username || '-'));
    setText('profileUsernameDisplay', p.username || '-');
    setText('profileEmail', p.email || '-');
    setText('profilePhone', p.phone || '-');
    setText('profileStudentIds', p.studentIds || '-');
    setText('profileCreatedAt', p.createdAt ? new Date(p.createdAt).toLocaleDateString() : '-');
    setText('profileStatus', p.approved === false ? 'Pending' : 'Active');

    const childrenWrap = document.getElementById('profileChildrenList');
    if (childrenWrap) {
        if (!myChildren.length) {
            const childrenRes = await apiParent('my_children', { parent_id: currentParent.id });
            myChildren = childrenRes.success ? (childrenRes.data?.items || []) : [];
        }
        childrenWrap.innerHTML = myChildren.length
            ? myChildren.map(c => `<span style="display:inline-block;background:#e8f5e9;color:#085636;padding:6px 14px;border-radius:16px;margin:4px 6px 0 0;">${esc(c.firstName)} ${esc(c.lastName)} — ${esc(c.grade)}</span>`).join('')
            : '<p class="text-muted">No linked children yet.</p>';
    }
}

function openEditProfileModal() {
    if (!currentParent) return;
    setText('editFirstName', '');
    const setVal = (id, val) => { const el = document.getElementById(id); if (el) el.value = val || ''; };
    setVal('editFirstName', currentParent.firstName);
    setVal('editLastName', currentParent.lastName);
    setVal('editUsername', currentParent.username);
    setVal('editEmail', currentParent.email);
    setVal('editPhone', currentParent.phone);
    setVal('editStudentIds', currentParent.studentIds);
    const pw = document.getElementById('editPassword');
    if (pw) pw.value = '';
    setAuthMessage('editProfileError', '');
    setAuthMessage('editProfileSuccess', '', false);

    const overlay = document.getElementById('editProfileOverlay');
    const modal = document.getElementById('editProfileModal');
    if (overlay) overlay.style.display = 'block';
    if (modal) modal.style.display = 'block';
}

function closeEditProfileModal() {
    const overlay = document.getElementById('editProfileOverlay');
    const modal = document.getElementById('editProfileModal');
    if (overlay) overlay.style.display = 'none';
    if (modal) modal.style.display = 'none';
}

async function saveProfileChanges() {
    setAuthMessage('editProfileError', '');
    setAuthMessage('editProfileSuccess', '', false);

    const val = id => { const el = document.getElementById(id); return el ? el.value.trim() : ''; };
    const payload = {
        parent_id: currentParent.id,
        first_name: val('editFirstName'),
        last_name: val('editLastName'),
        username: val('editUsername'),
        email: val('editEmail'),
        phone: val('editPhone'),
        student_ids: val('editStudentIds')
    };
    const password = val('editPassword');
    if (password) payload.password = password;

    if (!payload.first_name || !payload.last_name || !payload.username || !payload.email) {
        setAuthMessage('editProfileError', 'Name, username and email are required');
        return;
    }

    const res = await apiParent('update_profile', payload);
    if (res.success) {
        Object.assign(currentParent, {
            firstName: payload.first_name,
            lastName: payload.last_name,
            username: payload.username,
            email: payload.email,
            phone: payload.phone,
            studentIds: payload.student_ids
        });
        saveParentSession(currentParent, !!localStorage.getItem('parent_session'));
        setText('parentDisplayName', `${currentParent.firstName} ${currentParent.lastName}`.trim() || 'Parent');
        setAuthMessage('editProfileSuccess', res.message || 'Profile updated', false);
        showToast(res.message || 'Profile updated', 'success');
        loadProfile();
        setTimeout(closeEditProfileModal, 900);
    } else {
        setAuthMessage('editProfileError', res.message || 'Update failed');
    }
}

// ===== SETTINGS =====
function loadSettings() {
    if (!currentParent) return;
    setText('settingsParentName', `${currentParent.firstName || ''} ${currentParent.lastName || ''}`.trim() || '-');
    setText('settingsParentEmail', currentParent.email || '-');
    setText('settingsParentPhone', currentParent.phone || '-');
}

// ===== DEVICES / LOGIN HISTORY / AUTHORIZED ACCESS =====
async function loadLoginHistory() {
    if (!currentParent) return;
    setText('deviceAccountEmail', currentParent.email || '-');
    setText('deviceUsername', currentParent.username || '-');

    const body = document.getElementById('loginHistoryBody');
    if (body) {
        const res = await apiParent('login_history', { parent_id: currentParent.id });
        const items = res.success ? (res.data?.items || []) : [];
        if (!items.length) {
            body.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No login history yet.</td></tr>';
        } else {
            body.innerHTML = items.map(l => {
                const statusColor = (l.loginStatus || '').toLowerCase() === 'success' ? '#2ecc71' : '#e74c3c';
                return `
                <tr>
                    <td>${l.loginAt ? new Date(l.loginAt).toLocaleString() : '-'}</td>
                    <td>${esc(l.ipAddress)}</td>
                    <td>${esc(l.device)}</td>
                    <td>${esc(l.os)}</td>
                    <td>${esc(l.browser)}</td>
                    <td><span style="background:${statusColor};color:#fff;padding:3px 10px;border-radius:12px;font-size:12px;">${esc(l.loginStatus)}</span></td>
                </tr>`;
            }).join('');
        }
    }

    const ipWrap = document.getElementById('authorizedIpsList');
    if (ipWrap) {
        const res = await apiParent('get_authorized_ips', { parent_id: currentParent.id });
        const items = res.success ? (res.data?.items || []) : [];
        ipWrap.innerHTML = items.length
            ? items.map(ip => `
                <div style="display:flex;justify-content:space-between;align-items:center;background:#f8f9fa;padding:10px 12px;border-radius:6px;margin-bottom:8px;">
                    <div><strong>${esc(ip.ipAddress)}</strong><br><small style="color:#888;">${esc(ip.description) || 'No description'}</small></div>
                    <button class="parent-btn parent-btn-danger parent-btn-sm" onclick="revokeAuthorizedIp(${ip.id})"><i class="fas fa-times"></i></button>
                </div>`).join('')
            : '<p class="text-muted">No authorized IPs yet.</p>';
    }

    const emailWrap = document.getElementById('authorizedEmailsList');
    if (emailWrap) {
        const res = await apiParent('get_authorized_emails', { parent_id: currentParent.id });
        const items = res.success ? (res.data?.items || []) : [];
        emailWrap.innerHTML = items.length
            ? items.map(em => `
                <div style="display:flex;justify-content:space-between;align-items:center;background:#f8f9fa;padding:10px 12px;border-radius:6px;margin-bottom:8px;">
                    <div><strong>${esc(em.email)}</strong><br><small style="color:#888;">${esc(em.description) || 'No description'}</small></div>
                    <button class="parent-btn parent-btn-danger parent-btn-sm" onclick="revokeAuthorizedEmail(${em.id})"><i class="fas fa-times"></i></button>
                </div>`).join('')
            : '<p class="text-muted">No authorized emails yet.</p>';
    }
}

function openAddIpModal() {
    setAuthMessage('addIpError', '');
    setAuthMessage('addIpSuccess', '', false);
    const form = document.getElementById('addIpForm');
    if (form) form.reset();
    const overlay = document.getElementById('addIpOverlay');
    const modal = document.getElementById('addIpModal');
    if (overlay) overlay.style.display = 'block';
    if (modal) modal.style.display = 'block';
}

function closeAddIpModal() {
    const overlay = document.getElementById('addIpOverlay');
    const modal = document.getElementById('addIpModal');
    if (overlay) overlay.style.display = 'none';
    if (modal) modal.style.display = 'none';
}

async function addAuthorizedIp() {
    const ip = document.getElementById('newIpAddress');
    const desc = document.getElementById('newIpDescription');
    setAuthMessage('addIpError', '');
    setAuthMessage('addIpSuccess', '', false);

    if (!ip || !ip.value.trim()) {
        setAuthMessage('addIpError', 'IP address is required');
        return;
    }

    const res = await apiParent('add_authorized_ip', {
        parent_id: currentParent.id,
        ip_address: ip.value.trim(),
        description: desc ? desc.value.trim() : ''
    });

    if (res.success) {
        setAuthMessage('addIpSuccess', res.message || 'IP added', false);
        showToast(res.message || 'Authorized IP added', 'success');
        if (ip) ip.value = '';
        if (desc) desc.value = '';
        loadLoginHistory();
        setTimeout(closeAddIpModal, 900);
    } else {
        setAuthMessage('addIpError', res.message || 'Failed to add IP');
    }
}

async function revokeAuthorizedIp(ipId) {
    if (!confirm('Revoke this authorized IP?')) return;
    const res = await apiParent('revoke_authorized_ip', { ip_id: ipId });
    if (res.success) {
        showToast(res.message || 'IP revoked', 'success');
        loadLoginHistory();
    } else {
        showToast(res.message || 'Failed to revoke IP', 'error');
    }
}

function openAddEmailModal() {
    setAuthMessage('addEmailError', '');
    setAuthMessage('addEmailSuccess', '', false);
    const form = document.getElementById('addEmailForm');
    if (form) form.reset();
    const overlay = document.getElementById('addEmailOverlay');
    const modal = document.getElementById('addEmailModal');
    if (overlay) overlay.style.display = 'block';
    if (modal) modal.style.display = 'block';
}

function closeAddEmailModal() {
    const overlay = document.getElementById('addEmailOverlay');
    const modal = document.getElementById('addEmailModal');
    if (overlay) overlay.style.display = 'none';
    if (modal) modal.style.display = 'none';
}

async function addAuthorizedEmail() {
    const emailInput = document.getElementById('newEmailAddress');
    const desc = document.getElementById('newEmailDescription');
    setAuthMessage('addEmailError', '');
    setAuthMessage('addEmailSuccess', '', false);

    if (!emailInput || !emailInput.value.trim()) {
        setAuthMessage('addEmailError', 'Email address is required');
        return;
    }

    const res = await apiParent('add_authorized_email', {
        parent_id: currentParent.id,
        email: emailInput.value.trim(),
        description: desc ? desc.value.trim() : ''
    });

    if (res.success) {
        setAuthMessage('addEmailSuccess', res.message || 'Email added', false);
        showToast(res.message || 'Authorized email added', 'success');
        if (emailInput) emailInput.value = '';
        if (desc) desc.value = '';
        loadLoginHistory();
        setTimeout(closeAddEmailModal, 900);
    } else {
        setAuthMessage('addEmailError', res.message || 'Failed to add email');
    }
}

async function revokeAuthorizedEmail(emailId) {
    if (!confirm('Revoke this authorized email?')) return;
    const res = await apiParent('revoke_authorized_email', { email_id: emailId });
    if (res.success) {
        showToast(res.message || 'Email revoked', 'success');
        loadLoginHistory();
    } else {
        showToast(res.message || 'Failed to revoke email', 'error');
    }
}

// ===== ACCOUNT DELETION =====
async function requestAccountDeletion(userType) {
    if (!currentParent) return;
    if (!confirm('Request account deletion? Your account will be deleted in 24 hours. You can cancel the request during that time.')) return;

    const res = await apiAuth('request_account_deletion', { userType, userId: currentParent.id });
    if (res.success) {
        showToast(res.message || 'Deletion request submitted', 'warning');
        showDeletionWarning(res.data?.scheduledDeletionAt);
    } else {
        showToast(res.message || 'Could not submit the request', 'error');
    }
}

function showDeletionWarning(scheduledAt) {
    const modal = document.getElementById('deletionWarningModal');
    if (!modal) return;
    setText('modalDeletionDate', scheduledAt ? new Date(scheduledAt).toLocaleString() : 'within 24 hours');
    modal.style.display = 'block';
}

async function checkPendingDeletion() {
    if (!currentParent) return;
    const res = await apiAuth('check_deletion_status', { userType: 'parent', userId: currentParent.id });
    if (res.success && res.data && res.data.status === 'pending') {
        showDeletionWarning(res.data.scheduledDeletionAt);
    } else {
        const modal = document.getElementById('deletionWarningModal');
        if (modal) modal.style.display = 'none';
    }
}

async function cancelAccountDeletion(userType) {
    if (!currentParent) return;
    const res = await apiAuth('cancel_deletion_request', { userType, userId: currentParent.id });
    if (res.success) {
        showToast(res.message || 'Deletion request cancelled', 'success');
        const modal = document.getElementById('deletionWarningModal');
        if (modal) modal.style.display = 'none';
    } else {
        showToast(res.message || 'Could not cancel the request', 'error');
    }
}

// ===== ONBOARDING =====
let onboardingStep = 1;
const ONBOARDING_TOTAL = 5;

function initializeParentOnboarding() {
    const helpBtn = document.getElementById('parentHelpButton');
    if (helpBtn) helpBtn.style.display = 'block';
    const done = localStorage.getItem('parentOnboardingDone');
    if (!done) openParentOnboarding();
}

function renderOnboardingStep() {
    setText('parentOnboardingStep', onboardingStep);
    const fill = document.getElementById('parentOnboardingProgress');
    if (fill) fill.style.width = Math.round((onboardingStep / ONBOARDING_TOTAL) * 100) + '%';

    for (let i = 1; i <= ONBOARDING_TOTAL; i++) {
        const step = document.getElementById('parentStep' + i);
        if (step) step.style.display = i === onboardingStep ? 'block' : 'none';
    }

    const back = document.getElementById('parentOnboardingBack');
    const next = document.getElementById('parentOnboardingNext');
    const complete = document.getElementById('parentOnboardingComplete');
    if (back) back.style.display = onboardingStep > 1 ? 'inline-block' : 'none';
    if (next) next.style.display = onboardingStep < ONBOARDING_TOTAL ? 'inline-block' : 'none';
    if (complete) complete.style.display = onboardingStep === ONBOARDING_TOTAL ? 'inline-block' : 'none';
}

function openParentOnboarding() {
    const modal = document.getElementById('parentOnboardingModal');
    if (!modal) return;
    onboardingStep = 1;
    renderOnboardingStep();
    modal.style.display = 'block';
}

function closeParentOnboarding() {
    const modal = document.getElementById('parentOnboardingModal');
    if (modal) modal.style.display = 'none';
}

function nextParentOnboardingStep() {
    if (onboardingStep < ONBOARDING_TOTAL) {
        onboardingStep++;
        renderOnboardingStep();
    }
}

function prevParentOnboardingStep() {
    if (onboardingStep > 1) {
        onboardingStep--;
        renderOnboardingStep();
    }
}

function completeParentOnboarding() {
    localStorage.setItem('parentOnboardingDone', '1');
    closeParentOnboarding();
    showToast('You are all set! Use the ? button anytime to reopen this guide.', 'info');
}

function skipParentOnboarding() {
    localStorage.setItem('parentOnboardingDone', '1');
    closeParentOnboarding();
}

// ===== CLOCK =====
function startParentClock() {
    const update = () => {
        const el = document.getElementById('parentDateTime');
        if (el) el.textContent = new Date().toLocaleString();
    };
    update();
    if (parentClockInterval) clearInterval(parentClockInterval);
    parentClockInterval = setInterval(update, 1000);
}

// ===== PARENT LOGOUT =====
function handleParentLogout() {
    currentParent = null;
    clearParentSession();

    // Clear AI chat session
    localStorage.removeItem('teacher_id');
    localStorage.removeItem('admin_id');
    localStorage.removeItem('user_role');
    localStorage.removeItem('teacher_class');

    document.getElementById('authScreen').style.display = 'flex';
    document.getElementById('parentDashboard').style.display = 'none';
}

// ===== INIT =====
document.addEventListener('DOMContentLoaded', async function() {
    attachParentFormHandlers();

    // Try auto-login first (async to handle OAuth token refresh)
    const loggedIn = await autoLogin();
    if (!loggedIn) {
        const auth = document.getElementById('authScreen');
        const dash = document.getElementById('parentDashboard');
        if (auth) auth.style.display = 'flex';
        if (dash) dash.style.display = 'none';
    }
});

// Handle OAuth callback on page load
window.addEventListener('load', async function() {
    const urlParams = new URLSearchParams(window.location.search);
    const oauthToken = urlParams.get('oauth_token');
    if (oauthToken) {
        const result = await apiAuth('oauth_exchange', { token: oauthToken });
        if (result.success && result.data) {
            currentParent = result.data;
            saveParentSession(result.data, true);
            showParentDashboard();
            loadParentDashboard();
            setTimeout(() => checkPendingDeletion(), 100);
            initializeParentOnboarding();
            window.history.replaceState({}, document.title, window.location.pathname);
        } else {
            setAuthMessage('loginError', result.message || 'Google login failed');
        }
    }
});

// Window exports (inline onclick handlers)
window.showSection = showSection;
window.loadParentDashboard = loadParentDashboard;
window.switchAuthTab = switchAuthTab;
window.showRegStep1 = showRegStep1;
window.showRegStep2 = showRegStep2;
window.handleParentRegister = handleParentRegister;
window.handleParentLogin = handleParentLogin;
window.showRegStep3 = showRegStep3;
window.verifyParentCode = verifyParentCode;
window.handleParentLogout = handleParentLogout;
window.toggleSidebar = toggleSidebar;
window.togglePasswordVisibility = togglePasswordVisibility;
window.loadMyNotifications = loadMyNotifications;
window.clearRegisterChildForm = clearRegisterChildForm;
window.clearPaymentForm = clearPaymentForm;
window.clearComplaintForm = clearComplaintForm;
window.closeReportCard = closeReportCard;
window.loadWorkflowReports = loadWorkflowReports;
window.loadMyComplaints = loadMyComplaints;
window.editComplaint = editComplaint;
window.deleteComplaint = deleteComplaint;
window.openEditProfileModal = openEditProfileModal;
window.closeEditProfileModal = closeEditProfileModal;
window.saveProfileChanges = saveProfileChanges;
window.loadLoginHistory = loadLoginHistory;
window.openAddIpModal = openAddIpModal;
window.closeAddIpModal = closeAddIpModal;
window.addAuthorizedIp = addAuthorizedIp;
window.revokeAuthorizedIp = revokeAuthorizedIp;
window.openAddEmailModal = openAddEmailModal;
window.closeAddEmailModal = closeAddEmailModal;
window.addAuthorizedEmail = addAuthorizedEmail;
window.revokeAuthorizedEmail = revokeAuthorizedEmail;
window.requestAccountDeletion = requestAccountDeletion;
window.cancelAccountDeletion = cancelAccountDeletion;
window.closeProgressModal = closeProgressModal;
window.viewChildProgress = viewChildProgress;
window.viewChildReport = viewChildReport;
window.closeWorkflowReportModal = closeWorkflowReportModal;
window.submitReportFeedback = submitReportFeedback;
window.viewWorkflowReport = viewWorkflowReport;
window.viewReceipt = viewReceipt;
window.closeReceiptModal = closeReceiptModal;
window.printReceipt = printReceipt;
window.openEmailReceiptModal = openEmailReceiptModal;
window.closeEmailReceiptModal = closeEmailReceiptModal;
window.sendReceiptEmail = sendReceiptEmail;
window.openParentOnboarding = openParentOnboarding;
window.closeParentOnboarding = closeParentOnboarding;
window.nextParentOnboardingStep = nextParentOnboardingStep;
window.prevParentOnboardingStep = prevParentOnboardingStep;
window.completeParentOnboarding = completeParentOnboarding;
window.skipParentOnboarding = skipParentOnboarding;
window.showToast = showToast;
