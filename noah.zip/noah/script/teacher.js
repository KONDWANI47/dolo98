/**
 * TEACHER DASHBOARD SCRIPT - Noah Christian Academy
 * Uses MySQL API backend
 */

const API_BASE = '../api/index.php';

// ===== AUTH TAB SWITCHING =====
function switchAuthTab(tab, button) {
    const tabs = document.querySelectorAll('.auth-tab');
    tabs.forEach(t => t.classList.remove('active'));
    button.classList.add('active');

    const loginForm = document.getElementById('loginFormDiv');
    const registerForm = document.getElementById('registerFormDiv');

    if (tab === 'login') {
        loginForm.style.display = 'block';
        registerForm.style.display = 'none';
    } else {
        loginForm.style.display = 'none';
        registerForm.style.display = 'block';
        showRegStep1();
    }
}

// ===== REGISTRATION STEPS =====
function showRegStep1() {
    document.getElementById('regStep1').style.display = 'block';
    document.getElementById('regStep2').style.display = 'none';
    document.getElementById('registerError').classList.remove('show');
}

function showRegStep2() {
    const email = document.getElementById('regEmail').value.trim();
    const password = document.getElementById('regPassword').value;
    const errorEl = document.getElementById('registerError');

    if (!email || !password) {
        if (errorEl) {
            errorEl.textContent = 'Please enter both email and password';
            errorEl.classList.add('show');
        }
        return;
    }
    if (!email.includes('@') || !email.includes('.')) {
        if (errorEl) {
            errorEl.textContent = 'Please enter a valid email address';
            errorEl.classList.add('show');
        }
        return;
    }
    if (password.length < 8) {
        if (errorEl) {
            errorEl.textContent = 'Password must be at least 8 characters';
            errorEl.classList.add('show');
        }
        return;
    }

    document.getElementById('regStep1').style.display = 'none';
    document.getElementById('regStep2').style.display = 'block';
    if (errorEl) {
        errorEl.classList.remove('show');
        errorEl.textContent = '';
    }
}

// ===== SIDEBAR NAVIGATION =====
function showSection(sectionId) {
    // Hide all sections
    const sections = document.querySelectorAll('.content-section');
    sections.forEach(section => {
        section.style.display = 'none';
        section.classList.remove('active');
    });

    // Show selected section
    const targetSection = document.getElementById(`section-${sectionId}`);
    if (targetSection) {
        targetSection.style.display = 'block';
        targetSection.classList.add('active');
    }

    // Update active state on sidebar buttons
    const navButtons = document.querySelectorAll('.sidebar-nav-btn');
    navButtons.forEach(btn => {
        btn.classList.remove('active');
        if (btn.dataset.section === sectionId) {
            btn.classList.add('active');
        }
    });

    // Load section-specific data
    if (sectionId === 'timetable') {
        loadTimetableDocuments();
    } else if (sectionId === 'complaints') {
        loadClassComplaints();
    } else if (sectionId === 'devices') {
        loadLoginHistory();
    } else if (sectionId === 'class_breakdown') {
        loadTeacherClassBreakdown();
    } else if (sectionId === 'courses') {
        loadTeacherClassBreakdown();
        loadTeacherClassCourses();
    } else if (sectionId === 'content') {
        loadTeacherContent();
    } else if (sectionId === 'messages') {
        loadTeacherInbox();
    } else if (sectionId === 'scheme_work') {
        loadSchemesOfWork();
    } else if (sectionId === 'lesson_plans') {
        loadLessonPlans();
    } else if (sectionId === 'students') {
        // Load appropriate view based on current toggle state
        if (currentTeacherStudentView === 'breakdown') {
            loadTeacherStudentsBreakdown();
        } else {
            renderMyStudents();
        }
    } else if (sectionId === 'certificates') {
        loadRecentCertificates();
    }

    // Close sidebar on mobile after selection
    if (window.innerWidth <= 992) {
        const sidebar = document.getElementById('teacherSidebar');
        const mainContent = document.querySelector('.teacher-main');
        if (sidebar) {
            sidebar.classList.remove('open');
        }
        if (mainContent) {
            mainContent.classList.remove('shifted');
        }
    }
}


function toggleSidebar() {
    const sidebar = document.getElementById('teacherSidebar');
    const mainContent = document.querySelector('.teacher-main');
    
    if (sidebar) {
        sidebar.classList.toggle('open');
    }
    if (mainContent) {
        mainContent.classList.toggle('shifted');
    }
}

// ===== SAFE FETCH HELPER =====
async function safeFetch(response) {
    if (!response.ok) {
        const text = await response.text();
        try {
            return JSON.parse(text);
        } catch {
            return { success: false, message: `HTTP ${response.status}: ${text || 'No response body'}` };
        }
    }
    
    const text = await response.text();
    if (!text.trim()) {
        return { success: false, message: 'Empty response from server' };
    }
    
    try {
        return JSON.parse(text);
    } catch (parseErr) {
        return { success: false, message: 'Invalid JSON response from server' };
    }
}

// ===== API HELPERS =====
async function apiAuth(action, body) {
    try {
        const res = await fetch(`${API_BASE}?type=auth&action=${action}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body)
        });
        return await safeFetch(res);
    } catch (e) {
        return { success: false, message: e.message };
    }
}

async function apiTeacher(action, params = {}, body = null) {
    let url = `${API_BASE}?type=teacher&action=${action}`;
    for (const [k, v] of Object.entries(params)) url += `&${k}=${encodeURIComponent(v)}`;
    const opts = {
        method: body ? 'POST' : 'GET'
    };
    if (body) {
        opts.headers = { 'Content-Type': 'application/json' };
        opts.body = JSON.stringify(body);
    }
    try {
        const res = await fetch(url, opts);
        return await safeFetch(res);
    } catch (e) {
        return { success: false, message: e.message };
    }
}

async function apiAdmin(collection, method = 'GET', body = null, id = null) {
    let url = `${API_BASE}?type=admin&collection=${collection}`;
    if (id) url += `&id=${id}`;
    const opts = {
        method
    };
    if (body && (method === 'POST' || method === 'PUT')) {
        opts.headers = { 'Content-Type': 'application/json' };
        opts.body = JSON.stringify(body);
    }
    try {
        const res = await fetch(url, opts);
        return await res.json();
    } catch (e) {
        return { success: false, message: e.message };
    }
}

async function apiCollaboration(action, params = {}, body = null) {
    let url = '../api/collaboration.php?action=' + action;
    for (const [k, v] of Object.entries(params)) url += `&${k}=${encodeURIComponent(v)}`;
    const opts = {
        method: body ? 'POST' : 'GET'
    };
    if (body) {
        opts.headers = { 'Content-Type': 'application/json' };
        opts.body = JSON.stringify(body);
    }
    try {
        const res = await fetch(url, opts);
        const text = await res.text();
        if (!text || text.trim() === '') {
            return { success: false, message: 'Server returned empty response' };
        }
        try {
            return JSON.parse(text);
        } catch (parseErr) {
            return { success: false, message: 'Invalid server response' };
        }
    } catch (e) {
        return { success: false, message: e.message };
    }
}

// ===== STATE =====
let currentTeacher = null;
let myStudents = [];
let myAssessments = [];
let teacherClassStudents = []; // Students for teacher's assigned class
let currentTeacherStudentView = 'table'; // 'table' or 'breakdown'
let reportSignatureData = null; // Store signature data for report

// ===== ONBOARDING STATE =====
let teacherOnboardingStep = 1;
const teacherTotalOnboardingSteps = 5;
let teacherOnboardingCompleted = false;

// ===== TOAST =====
function showToast(message, type = 'success') {
    const container = document.getElementById('toastContainer');
    if (!container) return;
    const toast = document.createElement('div');
    const icons = { success: 'fa-check-circle', error: 'fa-times-circle', info: 'fa-info-circle', warning: 'fa-exclamation-triangle' };
    toast.innerHTML = `<i class="fas ${icons[type] || icons.info}"></i> ${message}`;
    Object.assign(toast.style, {
        padding: '12px 18px', borderRadius: '8px', color: '#fff', fontSize: '14px', fontWeight: '500',
        boxShadow: '0 6px 20px rgba(0,0,0,0.15)', animation: 'slideInRight 0.3s ease',
        display: 'flex', alignItems: 'center', gap: '10px', minWidth: '250px', maxWidth: '380px',
        background: type === 'success' ? '#085636' : type === 'error' ? '#e74c3c' : type === 'info' ? '#3498db' : '#f39c12'
    });
    container.appendChild(toast);
    setTimeout(() => {
        toast.style.animation = 'slideOutRight 0.3s ease forwards';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// Inject animations
const styleSheet = document.createElement('style');
styleSheet.textContent = `
    @keyframes slideInRight { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
    @keyframes slideOutRight { from { transform: translateX(0); opacity: 1; } to { transform: translateX(100%); opacity: 0; } }
`;
document.head.appendChild(styleSheet);

// ===== SHOW PASSWORD TOGGLE =====
function togglePasswordVisibility(inputId, iconId) {
    const input = document.getElementById(inputId);
    const icon = document.getElementById(iconId);
    if (!input || !icon) return;
    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        input.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}

// ===== SESSION PERSISTENCE =====
function saveTeacherSession(userData, remember) {
    if (remember) {
        localStorage.setItem('noh_teacher_session', JSON.stringify(userData));
    } else {
        sessionStorage.setItem('noh_teacher_session', JSON.stringify(userData));
    }
}

function loadTeacherSession() {
    let data = localStorage.getItem('noh_teacher_session');
    if (data) return JSON.parse(data);
    data = sessionStorage.getItem('noh_teacher_session');
    if (data) return JSON.parse(data);
    return null;
}

function clearTeacherSession() {
    localStorage.removeItem('noh_teacher_session');
    sessionStorage.removeItem('noh_teacher_session');
}

// ===== AUTO LOGIN ON PAGE LOAD =====
async function autoLogin() {
    // Check for OAuth token in URL first
    const urlParams = new URLSearchParams(window.location.search);
    const oauthToken = urlParams.get('oauth_token');

    if (oauthToken) {
        // Exchange OAuth token for session
        const result = await apiAuth('oauth_exchange', { token: oauthToken });
        if (result.success && result.data) {
            currentTeacher = result.data;
            saveTeacherSession(result.data, true);
            document.getElementById('authScreen').style.display = 'none';
            document.getElementById('teacherDashboard').style.display = 'block';
            document.getElementById('teacherDisplayName').textContent = currentTeacher.firstName + ' ' + currentTeacher.lastName;
            document.getElementById('teacherWelcomeName').textContent = currentTeacher.firstName;

            loadTeacherDashboard();
            startTeacherClock();

            // Check for pending deletion request after dashboard loads
            setTimeout(() => checkTeacherPendingDeletion(), 100);

            // Initialize onboarding for first-time users
            initializeTeacherOnboarding();

            // Clean URL
            window.history.replaceState({}, document.title, window.location.pathname);
            return true;
        } else {
            const errorEl = document.getElementById('loginError');
            if (errorEl) {
                errorEl.textContent = result.message || 'Google login failed';
                errorEl.classList.add('show');
            }
            return false;
        }
    }

    const savedUser = loadTeacherSession();
    if (savedUser && savedUser.username) {
        currentTeacher = savedUser;

        // Save for AI chat
        localStorage.setItem('teacher_id', savedUser.id);
        localStorage.setItem('user_role', 'teacher');
        localStorage.setItem('teacher_class', savedUser.class || savedUser.classAssigned || '');

        document.getElementById('authScreen').style.display = 'none';
        document.getElementById('teacherDashboard').style.display = 'block';
        document.getElementById('teacherDisplayName').textContent = savedUser.firstName + ' ' + savedUser.lastName;
        document.getElementById('teacherWelcomeName').textContent = savedUser.firstName;

        loadTeacherDashboard();
        startTeacherClock();

        // Check for pending deletion request after dashboard loads
        setTimeout(() => checkTeacherPendingDeletion(), 100);

        // Initialize onboarding for first-time users
        initializeTeacherOnboarding();

        return true;
    }
    return false;
}

// ===== AUTH =====
function switchAuthTab(tab, btn) {
    document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById('loginFormDiv').style.display = tab === 'login' ? 'block' : 'none';
    document.getElementById('registerFormDiv').style.display = tab === 'register' ? 'block' : 'none';
    document.getElementById('loginError').classList.remove('show');
    document.getElementById('registerError').classList.remove('show');
    document.getElementById('registerSuccess').classList.remove('show');
}

async function handleTeacherRegister(event) {
    if (event) {
        event.preventDefault();
    }

    const fullName = document.getElementById('regFullName')?.value.trim();
    const email = document.getElementById('regEmail')?.value.trim();
    const password = document.getElementById('regPassword')?.value.trim();
    const confirmPassword = document.getElementById('regConfirmPassword')?.value.trim();
    const errorEl = document.getElementById('registerError');

    // Split full name into first and last name
    let firstName = '';
    let lastName = '';
    if (fullName) {
        const nameParts = fullName.trim().split(/\s+/);
        firstName = nameParts[0] || '';
        lastName = nameParts.slice(1).join(' ') || '';
    }

    // Validation
    if (!firstName || !lastName || !email || !password || !confirmPassword) {
        if (errorEl) {
            errorEl.textContent = 'All fields are required';
            errorEl.classList.add('show');
        }
        return false;
    }

    if (password !== confirmPassword) {
        if (errorEl) {
            errorEl.textContent = 'Passwords do not match';
            errorEl.classList.add('show');
        }
        return false;
    }

    if (password.length < 8) {
        if (errorEl) {
            errorEl.textContent = 'Password must be at least 8 characters';
            errorEl.classList.add('show');
        }
        return false;
    }

    const result = await apiAuth('teacher_register', {
        firstName,
        lastName,
        email,
        password
    });

    if (result.success) {
        if (result.requiresCode) {
            // Show verification code step
            showRegStep3();
            if (errorEl) {
                errorEl.classList.remove('show');
            }

            // Always show the code on screen (for now, since email might be flaky)
            if (result.code) {
                const codeDisplay = document.getElementById('regCodeDisplay');
                const codeValue = document.getElementById('regCodeValue');
                if (codeDisplay && codeValue) {
                    codeValue.textContent = result.code;
                    codeDisplay.style.display = 'block';
                }
                showToast('Your verification code is: ' + result.code, 'success');
            } else {
                showToast('Account created! Please enter the verification code sent to your email.', 'success');
            }
        } else {
            showToast('Account created successfully! You can now log in.', 'success');
            switchAuthTab('login', document.querySelector('.auth-tab:first-child'));
            document.getElementById('registerFormDiv').querySelector('form').reset();
            showRegStep1();
        }
    } else {
        if (errorEl) {
            errorEl.textContent = result.message || 'Registration failed';
            errorEl.classList.add('show');
        }
    }
    return false;
}

function showRegStep3() {
    document.getElementById('regStep1').style.display = 'none';
    document.getElementById('regStep2').style.display = 'none';
    document.getElementById('regStep3').style.display = 'block';
}

async function verifyTeacherCode() {
    const code = document.getElementById('regCode')?.value.trim().toUpperCase();
    const errorEl = document.getElementById('verifyError');

    if (!code) {
        if (errorEl) {
            errorEl.textContent = 'Please enter the verification code';
            errorEl.classList.add('show');
        }
        return;
    }

    const result = await apiAuth('verify_code', { code: code, type: 'teacher' });

    if (result.success) {
        showToast('Account verified successfully! You can now log in.', 'success');
        switchAuthTab('login', document.querySelector('.auth-tab:first-child'));
        document.getElementById('registerFormDiv').querySelector('form').reset();
        showRegStep1();
        if (errorEl) {
            errorEl.classList.remove('show');
        }
    } else {
        if (errorEl) {
            errorEl.textContent = result.message || 'Invalid code';
            errorEl.classList.add('show');
        }
    }
}

async function handleTeacherLogin(event) {
    event.preventDefault();
    const username = document.getElementById('teacherUsername').value.trim();
    const password = document.getElementById('teacherPassword').value.trim();
    const errorEl = document.getElementById('loginError');
    const rememberMe = document.getElementById('teacherRememberMe') ? document.getElementById('teacherRememberMe').checked : false;

    const result = await apiAuth('teacher_login', { username, password });
    if (!result.success) {
        errorEl.textContent = result.message;
        errorEl.classList.add('show');
        return false;
    }

    currentTeacher = result.data;
    saveTeacherSession(result.data, rememberMe);

    // Save for AI chat
    localStorage.setItem('teacher_id', result.data.id);
    localStorage.setItem('user_role', 'teacher');
    localStorage.setItem('teacher_class', result.data.class || result.data.classAssigned || '');

    document.getElementById('authScreen').style.display = 'none';
    document.getElementById('teacherDashboard').style.display = 'block';
    document.getElementById('teacherDisplayName').textContent = currentTeacher.firstName + ' ' + currentTeacher.lastName;
    document.getElementById('teacherWelcomeName').textContent = currentTeacher.firstName;

    loadTeacherDashboard();
    startTeacherClock();
    
    // Check for pending deletion request after dashboard loads
    setTimeout(() => checkTeacherPendingDeletion(), 100);
    
    // Initialize onboarding for first-time users
    initializeTeacherOnboarding();
    
    return false;
}

function handleTeacherLogout() {
    currentTeacher = null;
    clearTeacherSession();

    // Clear AI chat session
    localStorage.removeItem('teacher_id');
    localStorage.removeItem('user_role');
    localStorage.removeItem('teacher_class');
    
    // Hide deletion modal and reset dashboard
    const modal = document.getElementById('teacherDeletionWarningModal');
    if (modal) modal.style.display = 'none';
    
    const mainContent = document.querySelector('.teacher-main');
    if (mainContent) mainContent.style.display = 'block';
    
    document.getElementById('authScreen').style.display = 'flex';
    document.getElementById('teacherDashboard').style.display = 'none';
    document.getElementById('teacherUsername').value = '';
    document.getElementById('teacherPassword').value = '';
    document.getElementById('loginError').classList.remove('show');
}

async function checkTeacherPendingDeletion() {
    if (!currentTeacher) return;
    
    try {
        const result = await apiAuth('check_deletion_status', { userType: 'teacher', userId: currentTeacher.id });
        
        if (result.success && result.data && result.data.status === 'pending') {
            // Show deletion warning modal
            const modal = document.getElementById('teacherDeletionWarningModal');
            const dateEl = document.getElementById('teacherModalDeletionDate');
            
            if (modal) modal.style.display = 'flex';
            if (dateEl) {
                const deletionDate = new Date(result.data.scheduledDeletionAt);
                dateEl.textContent = deletionDate.toLocaleString();
            }
            
            // Hide the main dashboard content
            const mainContent = document.querySelector('.teacher-main');
            if (mainContent) mainContent.style.display = 'none';
        }
    } catch (error) {
        console.error('Error checking pending deletion:', error);
    }
}

// ===== CLOCK =====
function startTeacherClock() {
    function update() {
        const now = new Date();
        document.getElementById('teacherDateTime').textContent = now.toLocaleString('en-US', {
            weekday: 'short', year: 'numeric', month: 'short', day: 'numeric',
            hour: '2-digit', minute: '2-digit', second: '2-digit'
        });
    }
    update();
    setInterval(update, 1000);
}

// ===== DASHBOARD =====
async function loadTeacherDashboard() {
    if (!currentTeacher) return;
    const studentsRes = await apiTeacher('my_students', { teacher_id: currentTeacher.id });
    myStudents = studentsRes.success ? (studentsRes.data?.items || []) : [];
    
    const assessmentsRes = await apiTeacher('my_assessments', { teacher_id: currentTeacher.id });
    myAssessments = assessmentsRes.success ? (assessmentsRes.data?.items || []) : [];
    
    renderMyStudents();
    renderAssessments();
    updateTeacherStats();
    renderAnnouncements();
    await renderProfile();
    renderMySubjects();
    renderSchedule();
    renderPerformanceCharts();
    loadAttendanceHistory();
    renderHomework();
    renderMessages();
    renderLessonPlans();
    renderBehaviorLog();
    await renderResources();
    renderExams();
    renderReports();
    loadCollaborationData();
    loadSentFilesToAdmin();
}

function formatDate(dateStr) {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    return d.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}

function getGrade(score) {
    if (score >= 80) return 'A';
    if (score >= 70) return 'B';
    if (score >= 60) return 'C';
    if (score >= 50) return 'D';
    return 'F';
}

function getGradeClass(grade) {
    const classes = { 'A': 'grade-a', 'B': 'grade-b', 'C': 'grade-c', 'D': 'grade-d', 'F': 'grade-f' };
    return classes[grade] || '';
}

// ===== MY STUDENTS =====
function renderMyStudents() {
    const tbody = document.getElementById('myStudentsBody');
    if (!tbody) return;
    const searchTerm = (document.getElementById('tStudentSearch')?.value || '').toLowerCase();
    const filtered = myStudents.filter(s =>
        (s.firstName + ' ' + s.lastName).toLowerCase().includes(searchTerm)
    );

    if (filtered.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" class="text-center text-muted">No students found' +
            (!currentTeacher?.class ? '. Your class has not been assigned yet.' : '.') + '</td></tr>';
        return;
    }

    tbody.innerHTML = filtered.map(s => {
        const studentAssessments = myAssessments.filter(a => a.studentId === s.id);
        const count = studentAssessments.length;
        const avgScore = count > 0 ? Math.round(studentAssessments.reduce((sum, a) => sum + a.score, 0) / count) : 0;
        let status = 'No Data';
        let statusClass = 'inactive';
        if (count > 0) {
            if (avgScore >= 75) { status = 'Good'; statusClass = 'good'; }
            else if (avgScore >= 50) { status = 'Average'; statusClass = 'average'; }
            else { status = 'Needs Improvement'; statusClass = 'needs-improvement'; }
        }
        return `<tr>
            <td>${s.id}</td>
            <td><strong>${s.firstName} ${s.lastName}</strong></td>
            <td>${s.gender || '-'}</td>
            <td>${count}</td>
            <td>${count > 0 ? avgScore + '%' : '-'}</td>
            <td><span class="status-badge ${statusClass}">${status}</span></td>
            <td>
                <button class="teacher-btn teacher-btn-info teacher-btn-sm" onclick="viewStudentProgress(${s.id})" title="Progress"><i class="fas fa-chart-bar"></i></button>
                <button class="teacher-btn teacher-btn-primary teacher-btn-sm" onclick="openAssessmentForStudent(${s.id})" title="Add Assessment"><i class="fas fa-plus"></i></button>
            </td>
        </tr>`;
    }).join('');
}

function updateTeacherStats() {
    const studentAssessments = myStudents.map(s => {
        const sa = myAssessments.filter(a => a.studentId === s.id);
        const avg = sa.length > 0 ? Math.round(sa.reduce((sum, a) => sum + a.score, 0) / sa.length) : 0;
        return { student: s, avg, count: sa.length };
    });
    document.getElementById('tStatStudents').textContent = myStudents.length;
    document.getElementById('tStatGood').textContent = studentAssessments.filter(s => s.count > 0 && s.avg >= 75).length;
    document.getElementById('tStatAverage').textContent = studentAssessments.filter(s => s.count > 0 && s.avg < 75).length;
    document.getElementById('tStatAssessments').textContent = myAssessments.length;
}

// ===== ASSESSMENTS =====
function renderAssessments() {
    const tbody = document.getElementById('assessmentsBody');
    if (!tbody) return;
    if (myAssessments.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted">No assessments recorded yet.</td></tr>';
        return;
    }
    myAssessments.sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));
    tbody.innerHTML = myAssessments.slice(0, 50).map(a => {
        const grade = getGrade(a.score);
        const gradeClass = getGradeClass(grade);
        return `<tr>
            <td><strong>${a.studentName || '-'}</strong></td>
            <td>${a.subject || '-'}</td>
            <td>${a.type || '-'}</td>
            <td><strong>${a.score}%</strong></td>
            <td><span class="${gradeClass}">${grade}</span></td>
            <td>${formatDate(a.date || a.createdAt)}</td>
            <td>
                <button class="teacher-btn teacher-btn-info teacher-btn-sm" onclick="viewAssessment(${a.id})"><i class="fas fa-eye"></i></button>
                <button class="teacher-btn teacher-btn-primary teacher-btn-sm" onclick="editAssessment(${a.id})"><i class="fas fa-edit"></i></button>
                <button class="teacher-btn teacher-btn-danger teacher-btn-sm" onclick="deleteAssessment(${a.id})"><i class="fas fa-trash"></i></button>
            </td>
        </tr>`;
    }).join('');
}

function openAssessmentModal() {
    document.getElementById('assessmentModalTitle').innerHTML = '<i class="fas fa-clipboard-list"></i> New Assessment';
    document.getElementById('assessmentEditId').value = '';
    document.getElementById('assessmentStudentId').value = '';
    document.getElementById('assessmentForm').reset();
    document.getElementById('assessmentDate').value = new Date().toISOString().slice(0, 10);

    const select = document.getElementById('assessmentStudent');
    select.innerHTML = '<option value="">Select Student</option>';
    myStudents.forEach(s => {
        const opt = document.createElement('option');
        opt.value = s.id;
        opt.textContent = s.firstName + ' ' + s.lastName;
        select.appendChild(opt);
    });

    document.getElementById('assessmentModalOverlay').classList.add('show');
    document.getElementById('assessmentModal').classList.add('show');
}

function openAssessmentForStudent(studentId) {
    openAssessmentModal();
    document.getElementById('assessmentStudent').value = studentId;
    document.getElementById('assessmentStudentId').value = studentId;
}

function openAssessmentFromProgress() {
    closeProgressModal();
    const sid = document.getElementById('progressStudentId')?.value;
    if (sid) {
        openAssessmentModal();
        document.getElementById('assessmentStudent').value = sid;
        document.getElementById('assessmentStudentId').value = sid;
    } else {
        openAssessmentModal();
    }
}

function closeAssessmentModal() {
    document.getElementById('assessmentModalOverlay').classList.remove('show');
    document.getElementById('assessmentModal').classList.remove('show');
}

async function saveAssessment(event) {
    event.preventDefault();
    if (!currentTeacher) { showToast('Please login first!', 'error'); return false; }

    const editId = document.getElementById('assessmentEditId').value;
    const studentSelect = document.getElementById('assessmentStudent');
    const studentId = parseInt(studentSelect.value);
    const student = myStudents.find(s => s.id === studentId);
    if (!student) { showToast('Please select a student!', 'error'); return false; }

    const data = {
        teacherId: currentTeacher.id,
        studentId: studentId,
        studentName: student.firstName + ' ' + student.lastName,
        className: currentTeacher.class || '',
        subject: document.getElementById('assessmentSubject').value.trim(),
        type: document.getElementById('assessmentType').value,
        score: parseInt(document.getElementById('assessmentScore').value),
        date: document.getElementById('assessmentDate').value,
        remarks: document.getElementById('assessmentRemarks').value.trim()
    };

    if (!data.subject) { showToast('Please enter a subject!', 'error'); return false; }
    if (isNaN(data.score) || data.score < 0 || data.score > 100) { showToast('Score must be 0-100!', 'error'); return false; }

    if (editId) {
        data.id = parseInt(editId);
        const result = await apiTeacher('save_assessment', {}, data);
        if (result.success) showToast('Assessment updated!');
        else showToast(result.message, 'error');
    } else {
        const result = await apiTeacher('save_assessment', {}, data);
        if (result.success) showToast('Assessment saved!');
        else showToast(result.message, 'error');
    }

    closeAssessmentModal();
    loadTeacherDashboard();
    return false;
}

function viewAssessment(id) {
    const a = myAssessments.find(ass => ass.id === id);
    if (!a) return;
    const grade = getGrade(a.score);
    showToast(`[${a.type}] ${a.studentName}: ${a.score}% (${grade})`, 'info');
}

function editAssessment(id) {
    const a = myAssessments.find(ass => ass.id === id);
    if (!a) return;
    document.getElementById('assessmentModalTitle').innerHTML = '<i class="fas fa-clipboard-list"></i> Edit Assessment';
    document.getElementById('assessmentEditId').value = id;
    document.getElementById('assessmentStudentId').value = a.studentId;

    const select = document.getElementById('assessmentStudent');
    select.innerHTML = '<option value="">Select Student</option>';
    myStudents.forEach(s => {
        const opt = document.createElement('option');
        opt.value = s.id;
        opt.textContent = s.firstName + ' ' + s.lastName;
        if (s.id === a.studentId) opt.selected = true;
        select.appendChild(opt);
    });

    document.getElementById('assessmentSubject').value = a.subject || '';
    document.getElementById('assessmentType').value = a.type || 'Quiz';
    document.getElementById('assessmentScore').value = a.score || 0;
    document.getElementById('assessmentDate').value = a.date || new Date().toISOString().slice(0, 10);
    document.getElementById('assessmentRemarks').value = a.remarks || '';

    document.getElementById('assessmentModalOverlay').classList.add('show');
    document.getElementById('assessmentModal').classList.add('show');
}

async function deleteAssessment(id) {
    if (!confirm('Are you sure you want to delete this assessment? This cannot be undone.')) return;
    const result = await apiTeacher('delete_assessment', {}, { id, teacherId: currentTeacher.id });
    if (result.success) {
        showToast('Assessment deleted successfully!', 'success');
        loadTeacherDashboard();
    } else {
        showToast(result.message || 'Failed to delete assessment', 'error');
    }
}

// ===== STUDENT PROGRESS =====
async function viewStudentProgress(studentId) {
    const student = myStudents.find(s => s.id === studentId);
    if (!student) { showToast('Student not found!', 'error'); return; }

    const result = await apiTeacher('student_progress', { teacher_id: currentTeacher.id, student_id: studentId });
    if (!result.success) { showToast(result.message, 'error'); return; }
    const data = result.data;

    const assessments = data.assessments || [];
    const avgScore = data.averageScore || 0;
    const grade = getGrade(avgScore);
    const gradeClass = getGradeClass(grade);
    const subjects = data.subjectBreakdown || {};

    let body = `
        <div style="margin-bottom:15px;">
            <h3 style="margin-bottom:5px;">${student.firstName} ${student.lastName}</h3>
            <p>Grade: ${student.grade || '-'} | Gender: ${student.gender || '-'} | Overall: <strong>${assessments.length > 0 ? avgScore + '% (' + grade + ')' : 'No Data'}</strong></p>
        </div>
        <input type="hidden" id="progressStudentId" value="${studentId}">`;

    if (assessments.length === 0) {
        body += '<p class="text-muted">No assessments recorded yet.</p>';
    } else {
        body += `
            <div style="display:flex;gap:10px;margin-bottom:15px;">
                <div style="background:#e8f8f5;padding:10px;border-radius:8px;flex:1;text-align:center;"><strong>${assessments.length}</strong><br><small>Total</small></div>
                <div style="background:#fef9e7;padding:10px;border-radius:8px;flex:1;text-align:center;"><strong>${avgScore}%</strong><br><small>Average</small></div>
                <div style="background:#fdedec;padding:10px;border-radius:8px;flex:1;text-align:center;"><strong class="${gradeClass}">${grade}</strong><br><small>Grade</small></div>
            </div>`;

        if (Object.keys(subjects).length > 0) {
            body += '<h4 style="margin-bottom:8px;">Subject Breakdown</h4><div style="margin-bottom:15px;display:flex;flex-wrap:wrap;gap:8px;">';
            for (const [subj, info] of Object.entries(subjects)) {
                const subjAvg = Math.round(info.total / info.count);
                body += `<span style="background:#eee;padding:4px 12px;border-radius:15px;font-size:12px;">${subj}: <strong>${subjAvg}%</strong> (${info.count})</span>`;
            }
            body += '</div>';
        }

        body += '<h4 style="margin-bottom:8px;">Assessment History</h4>';
        body += '<div class="table-responsive"><table class="teacher-table"><thead><tr><th>Subject</th><th>Type</th><th>Score</th><th>Grade</th><th>Date</th><th>Remarks</th></tr></thead><tbody>';
        assessments.forEach(a => {
            const g = getGrade(a.score);
            const gc = getGradeClass(g);
            body += `<tr><td>${a.subject}</td><td>${a.type}</td><td><strong>${a.score}%</strong></td><td><span class="${gc}">${g}</span></td><td>${formatDate(a.date)}</td><td>${a.remarks || '-'}</td></tr>`;
        });
        body += '</tbody></table></div>';
    }

    document.getElementById('progressModalBody').innerHTML = body;
    document.getElementById('progressModalTitle').innerHTML = '<i class="fas fa-chart-bar"></i> Student Progress';
    document.getElementById('progressModalOverlay').classList.add('show');
    document.getElementById('progressModal').classList.add('show');
}

function closeProgressModal() {
    document.getElementById('progressModalOverlay').classList.remove('show');
    document.getElementById('progressModal').classList.remove('show');
}

// ===== ANNOUNCEMENTS =====
async function renderAnnouncements() {
    const container = document.getElementById('announcementsFeed');
    if (!container) return;
    const result = await apiTeacher('announcements', {});
    const announcements = result.success ? (result.data?.items || []) : [];
    if (announcements.length === 0) {
        container.innerHTML = '<p class="text-muted">No announcements yet.</p>';
        return;
    }
    container.innerHTML = announcements.map(a => {
        const pClass = a.priority || 'normal';
        const icons = { normal: 'fa-info-circle', important: 'fa-exclamation-circle', urgent: 'fa-exclamation-triangle' };
        const colors = { normal: '#3498db', important: '#f39c12', urgent: '#e74c3c' };
        return `<div style="padding:10px 14px;margin-bottom:8px;border-radius:8px;border-left:4px solid ${colors[pClass] || '#3498db'};background:#f8f9fa;">
            <div style="display:flex;justify-content:space-between;align-items:start;">
                <div><strong>${a.pinned ? '<i class="fas fa-thumbtack" style="color:#f39c12;"></i> ' : ''}${a.title}</strong> <span style="font-size:11px;color:#999;">${formatDate(a.createdAt)}</span></div>
                <span style="font-size:11px;padding:2px 8px;border-radius:10px;background:${colors[pClass]};color:#fff;">${a.priority}</span>
            </div>
            <p style="margin:5px 0 0;font-size:13px;white-space:pre-wrap;">${a.content}</p>
        </div>`;
    }).join('');
}

// ===== PROFILE =====
async function renderProfile() {
    if (!currentTeacher) return;
    document.getElementById('profileName').textContent = `${currentTeacher.firstName} ${currentTeacher.lastName}`;
    document.getElementById('profileEmail').textContent = currentTeacher.email || '-';
    document.getElementById('profilePhone').textContent = currentTeacher.phone || '-';
    document.getElementById('profileSubject').textContent = currentTeacher.subject || '-';
    document.getElementById('profileQualification').textContent = currentTeacher.qualification || '-';
    document.getElementById('profileClass').textContent = currentTeacher.class || 'Not Assigned';
    document.getElementById('profileDateOfEmployment').textContent = currentTeacher.dateOfEmployment || '-';
    document.getElementById('profileNationalId').textContent = currentTeacher.nationalId || '-';
    document.getElementById('profileResidentialAddress').textContent = currentTeacher.residentialAddress || '-';
    document.getElementById('profileNextOfKin').textContent = currentTeacher.nextOfKin || '-';
    document.getElementById('profileNextOfKinRelationship').textContent = currentTeacher.nextOfKinRelationship || '-';
    document.getElementById('profileNextOfKinPhone').textContent = currentTeacher.nextOfKinPhone || '-';
    
    // Check for deletion status
    await checkTeacherPendingDeletion();
}

function openProfileModal() {
    if (!currentTeacher) return;
    document.getElementById('profileFirstName').value = currentTeacher.firstName || '';
    document.getElementById('profileLastName').value = currentTeacher.lastName || '';
    document.getElementById('profileEmailInput').value = currentTeacher.email || '';
    document.getElementById('profilePhoneInput').value = currentTeacher.phone || '';
    document.getElementById('profileSubjectInput').value = currentTeacher.subject || '';
    document.getElementById('profileQualificationInput').value = currentTeacher.qualification || '';
    document.getElementById('profileDateOfEmploymentInput').value = currentTeacher.dateOfEmployment || '';
    document.getElementById('profileNationalIdInput').value = currentTeacher.nationalId || '';
    document.getElementById('profileResidentialAddressInput').value = currentTeacher.residentialAddress || '';
    document.getElementById('profileNextOfKinInput').value = currentTeacher.nextOfKin || '';
    document.getElementById('profileNextOfKinRelationshipInput').value = currentTeacher.nextOfKinRelationship || '';
    document.getElementById('profileNextOfKinPhoneInput').value = currentTeacher.nextOfKinPhone || '';
    document.getElementById('profileClassAssignedInput').value = currentTeacher.class || '';
    document.getElementById('profileModalOverlay').classList.add('show');
    document.getElementById('profileModal').classList.add('show');
}

function closeProfileModal() {
    document.getElementById('profileModalOverlay').classList.remove('show');
    document.getElementById('profileModal').classList.remove('show');
}

async function saveProfile(event) {
    event.preventDefault();
    if (!currentTeacher) return;
    
    const data = {
        firstName: document.getElementById('profileFirstName').value.trim(),
        lastName: document.getElementById('profileLastName').value.trim(),
        email: document.getElementById('profileEmailInput').value.trim(),
        phone: document.getElementById('profilePhoneInput').value.trim(),
        subject: document.getElementById('profileSubjectInput').value.trim(),
        qualification: document.getElementById('profileQualificationInput').value.trim(),
        dateOfEmployment: document.getElementById('profileDateOfEmploymentInput').value,
        nationalId: document.getElementById('profileNationalIdInput').value.trim(),
        residentialAddress: document.getElementById('profileResidentialAddressInput').value.trim(),
        nextOfKin: document.getElementById('profileNextOfKinInput').value.trim(),
        nextOfKinRelationship: document.getElementById('profileNextOfKinRelationshipInput').value.trim(),
        nextOfKinPhone: document.getElementById('profileNextOfKinPhoneInput').value.trim(),
        classAssigned: document.getElementById('profileClassAssignedInput').value
    };
    
    const result = await apiAdmin('teachers', 'PUT', data, currentTeacher.id);
    if (result.success) {
        showToast('Profile updated successfully!');
        currentTeacher = { ...currentTeacher, ...data, class: data.classAssigned || currentTeacher.class };
        // Update class badges
        const newClass = currentTeacher.class || '';
        const classBadge = document.getElementById('teacherClassBadge');
        const welcomeClass = document.getElementById('teacherWelcomeClass');
        if (classBadge) classBadge.textContent = newClass || 'No Class Assigned';
        if (welcomeClass) welcomeClass.innerHTML = `<i class="fas fa-users"></i> Class: ${newClass || 'Not Assigned'}`;
        await renderProfile();
        closeProfileModal();
    } else {
        showToast(result.message || 'Failed to update profile', 'error');
    }
}

// ===== SUBJECTS =====
let mySubjects = [];

async function renderMySubjects() {
    const container = document.getElementById('mySubjectsList');
    if (!container) return;
    
    // Get courses assigned to this teacher
    const result = await apiAdmin('courses', 'GET');
    if (!result.success || !result.data) {
        container.innerHTML = '<p class="text-muted">No subjects added yet.</p>';
        return;
    }
    
    // Handle both array and object responses
    const coursesData = Array.isArray(result.data) ? result.data : (result.data.items || []);
    mySubjects = coursesData.filter(c => c.teacherId == currentTeacher.id);
    
    if (mySubjects.length === 0) {
        container.innerHTML = '<p class="text-muted">No subjects assigned to you yet. Contact admin to assign subjects.</p>';
        return;
    }
    
    container.innerHTML = mySubjects.map(s => `
        <div class="subject-card" style="background:#f8f9fa;padding:15px;border-radius:8px;border-left:4px solid #085636;">
            <div style="display:flex;justify-content:space-between;align-items:start;">
                <div>
                    <strong>${s.title}</strong> <span style="background:#085636;color:#fff;padding:2px 8px;border-radius:10px;font-size:11px;">${s.code || 'N/A'}</span>
                    <p style="margin:5px 0;font-size:13px;color:#666;">${s.description || 'No description'}</p>
                    <p style="margin:0;font-size:12px;"><strong>Grade:</strong> ${s.gradeLevel || '-'} | <strong>Credits:</strong> ${s.credits || 0}</p>
                </div>
                <div style="display:flex;gap:5px;">
                    <button class="teacher-btn teacher-btn-sm teacher-btn-secondary" onclick="editSubject(${s.id})"><i class="fas fa-edit"></i></button>
                    <button class="teacher-btn teacher-btn-sm teacher-btn-danger" onclick="deleteSubject(${s.id})"><i class="fas fa-trash"></i></button>
                </div>
            </div>
        </div>
    `).join('');
}

function openSubjectModal() {
    document.getElementById('subjectEditId').value = '';
    document.getElementById('subjectForm').reset();
    document.getElementById('subjectModalTitle').innerHTML = '<i class="fas fa-book"></i> Add Subject';
    document.getElementById('subjectModalOverlay').classList.add('show');
    document.getElementById('subjectModal').classList.add('show');

    // Hide delete button when adding new subject
    const deleteBtn = document.getElementById('subjectDeleteBtn');
    if (deleteBtn) {
        deleteBtn.style.display = 'none';
    }
}

function closeSubjectModal() {
    document.getElementById('subjectModalOverlay').classList.remove('show');
    document.getElementById('subjectModal').classList.remove('show');

    // Hide delete button when closing modal
    const deleteBtn = document.getElementById('subjectDeleteBtn');
    if (deleteBtn) {
        deleteBtn.style.display = 'none';
    }
}

async function editSubject(id) {
    const result = await apiAdmin('courses', 'GET', null, id);
    if (!result.success || !result.data) return;

    const s = result.data;
    document.getElementById('subjectEditId').value = id;
    document.getElementById('subjectName').value = s.title || '';
    document.getElementById('subjectCode').value = s.code || '';
    document.getElementById('subjectGrade').value = s.gradeLevel || '';
    document.getElementById('subjectDescription').value = s.description || '';
    document.getElementById('subjectModalTitle').innerHTML = '<i class="fas fa-book"></i> Edit Subject';
    document.getElementById('subjectModalOverlay').classList.add('show');
    document.getElementById('subjectModal').classList.add('show');

    // Show delete button when editing
    const deleteBtn = document.getElementById('subjectDeleteBtn');
    if (deleteBtn) {
        deleteBtn.style.display = 'inline-block';
        deleteBtn.dataset.subjectId = id;
    }
}

async function saveSubject(event) {
    event.preventDefault();

    const editId = document.getElementById('subjectEditId').value;
    const data = {
        title: document.getElementById('subjectName').value.trim(),
        code: document.getElementById('subjectCode').value.trim(),
        gradeLevel: document.getElementById('subjectGrade').value,
        description: document.getElementById('subjectDescription').value.trim(),
        teacherId: currentTeacher.id,
        status: 'Active'
    };

    let result;
    if (editId) {
        result = await apiAdmin('courses', 'PUT', data, editId);
    } else {
        result = await apiAdmin('courses', 'POST', data);
    }

    if (result.success) {
        showToast('Subject saved successfully!');
        closeSubjectModal();
        renderMySubjects();
    } else {
        showToast(result.message || 'Failed to save subject', 'error');
    }
}

async function handleSubjectDelete() {
    const deleteBtn = document.getElementById('subjectDeleteBtn');
    const subjectId = deleteBtn?.dataset.subjectId;

    if (!subjectId) {
        showToast('Cannot delete: No subject ID found', 'error');
        return;
    }

    if (!confirm('Are you sure you want to delete this subject? This action cannot be undone.')) {
        return;
    }

    const result = await apiAdmin('courses', 'DELETE', null, subjectId);
    if (result.success) {
        showToast('Subject deleted successfully!');
        closeSubjectModal();
        renderMySubjects();
    } else {
        showToast(result.message || 'Failed to delete subject', 'error');
    }
}

async function deleteSubject(id) {
    if (!confirm('Are you sure you want to delete this subject? This action cannot be undone.')) {
        return;
    }

    const result = await apiAdmin('courses', 'DELETE', null, id);
    if (result.success) {
        showToast('Subject deleted successfully!');
        renderMySubjects();
    } else {
        showToast(result.message || 'Failed to delete subject', 'error');
    }
}

// ===== SCHEDULE =====
let mySchedule = [];

async function renderSchedule() {
    const tbody = document.getElementById('scheduleBody');
    if (!tbody) return;
    
    // For now, store schedule in localStorage as a simple implementation
    const stored = localStorage.getItem(`teacher_schedule_${currentTeacher.id}`);
    mySchedule = stored ? JSON.parse(stored) : [];
    
    if (mySchedule.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No schedule added yet.</td></tr>';
        return;
    }
    
    tbody.innerHTML = mySchedule.map((s, idx) => `
        <tr>
            <td>${s.day}</td>
            <td>Period ${s.period}</td>
            <td>${s.subject}</td>
            <td>${s.class}</td>
            <td>${s.startTime} - ${s.endTime}</td>
            <td>
                <button class="teacher-btn teacher-btn-sm teacher-btn-secondary" onclick="editSchedule(${idx})"><i class="fas fa-edit"></i></button>
                <button class="teacher-btn teacher-btn-sm teacher-btn-danger" onclick="deleteSchedule(${idx})"><i class="fas fa-trash"></i></button>
            </td>
        </tr>
    `).join('');
}

function openScheduleModal() {
    document.getElementById('scheduleEditId').value = '';
    document.getElementById('scheduleForm').reset();
    loadSubjectsForSchedule();
    document.getElementById('scheduleModalTitle').innerHTML = '<i class="fas fa-calendar-plus"></i> Add Teaching Period';
    document.getElementById('scheduleModalOverlay').classList.add('show');
    document.getElementById('scheduleModal').classList.add('show');
}

function closeScheduleModal() {
    document.getElementById('scheduleModalOverlay').classList.remove('show');
    document.getElementById('scheduleModal').classList.remove('show');
}

async function loadSubjectsForSchedule() {
    const select = document.getElementById('scheduleSubject');
    select.innerHTML = '<option value="">Select Subject</option>';
    
    const result = await apiAdmin('courses', 'GET');
    if (result.success && result.data && Array.isArray(result.data)) {
        const teacherSubjects = result.data.filter(c => c.teacherId == currentTeacher.id);
        teacherSubjects.forEach(s => {
            select.innerHTML += `<option value="${s.title}">${s.title} (${s.code || 'N/A'})</option>`;
        });
    } else if (!result.success) {
        console.error('Failed to load subjects:', result.message || 'Unknown error');
    }
    
    // Also add manual subject entry option
    select.innerHTML += '<option value="other">Other (enter manually)</option>';
}

async function editSchedule(idx) {
    const s = mySchedule[idx];
    document.getElementById('scheduleEditId').value = idx;
    document.getElementById('scheduleDay').value = s.day;
    document.getElementById('schedulePeriod').value = s.period;
    await loadSubjectsForSchedule();
    document.getElementById('scheduleSubject').value = s.subject;
    document.getElementById('scheduleClass').value = s.class;
    document.getElementById('scheduleStartTime').value = s.startTime;
    document.getElementById('scheduleEndTime').value = s.endTime;
    document.getElementById('scheduleRoom').value = s.room || '';
    document.getElementById('scheduleModalTitle').innerHTML = '<i class="fas fa-calendar-edit"></i> Edit Teaching Period';
    document.getElementById('scheduleModalOverlay').classList.add('show');
    document.getElementById('scheduleModal').classList.add('show');
}

async function saveSchedule(event) {
    event.preventDefault();
    
    const editId = document.getElementById('scheduleEditId').value;
    const data = {
        day: document.getElementById('scheduleDay').value,
        period: document.getElementById('schedulePeriod').value,
        subject: document.getElementById('scheduleSubject').value,
        class: document.getElementById('scheduleClass').value,
        startTime: document.getElementById('scheduleStartTime').value,
        endTime: document.getElementById('scheduleEndTime').value,
        room: document.getElementById('scheduleRoom').value.trim()
    };
    
    if (editId !== '') {
        mySchedule[parseInt(editId)] = data;
    } else {
        mySchedule.push(data);
    }
    
    localStorage.setItem(`teacher_schedule_${currentTeacher.id}`, JSON.stringify(mySchedule));
    showToast(editId !== '' ? 'Schedule updated!' : 'Schedule added!');
    closeScheduleModal();
    renderSchedule();
    return false;
}

function deleteSchedule(idx) {
    if (!confirm('Are you sure you want to delete this schedule?')) return;
    mySchedule.splice(idx, 1);
    localStorage.setItem(`teacher_schedule_${currentTeacher.id}`, JSON.stringify(mySchedule));
    showToast('Schedule deleted!');
    renderSchedule();
}

// ===== TIMETABLE =====
let myTimetable = [];

async function openTimetableModal() {
    document.getElementById('timetableEditId').value = '';
    document.getElementById('timetableForm').reset();
    document.getElementById('timetableModalOverlay').classList.add('show');
    document.getElementById('timetableModal').classList.add('show');
}

function closeTimetableModal() {
    document.getElementById('timetableModalOverlay').classList.remove('show');
    document.getElementById('timetableModal').classList.remove('show');
}

async function saveTimetable(event) {
    event.preventDefault();
    
    const editId = document.getElementById('timetableEditId').value;
    const data = {
        day: document.getElementById('timetableDay').value,
        time: document.getElementById('timetableTime').value,
        endTime: document.getElementById('timetableEndTime').value,
        period: document.getElementById('timetablePeriod').value,
        subject: document.getElementById('timetableSubject').value,
        className: document.getElementById('timetableClass').value,
        room: document.getElementById('timetableRoom').value,
        teacher: currentTeacher ? `${currentTeacher.firstName} ${currentTeacher.lastName}` : ''
    };
    
    if (editId !== '') {
        myTimetable[parseInt(editId)] = data;
    } else {
        myTimetable.push(data);
    }
    
    localStorage.setItem(`teacher_timetable_${currentTeacher.id}`, JSON.stringify(myTimetable));
    showToast(editId !== '' ? 'Schedule updated!' : 'Schedule added!');
    closeTimetableModal();
    renderTimetable();
    return false;
}

async function renderTimetable() {
    const tbody = document.getElementById('timetableBody');
    if (!tbody) return;
    
    const stored = localStorage.getItem(`teacher_timetable_${currentTeacher.id}`);
    myTimetable = stored ? JSON.parse(stored) : [];
    
    if (myTimetable.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted">No timetable entries yet. Click "Add Schedule" to add one.</td></tr>';
        return;
    }
    
    tbody.innerHTML = myTimetable.map((s, idx) => `
        <tr>
            <td>${s.day}</td>
            <td>${s.time}${s.endTime ? ' - ' + s.endTime : ''}</td>
            <td>${s.period || '-'}</td>
            <td>${s.subject}</td>
            <td>${s.className}</td>
            <td>${s.room}</td>
            <td>
                <button class="teacher-btn teacher-btn-sm teacher-btn-warning" onclick="editTimetable(${idx})"><i class="fas fa-edit"></i></button>
                <button class="teacher-btn teacher-btn-sm teacher-btn-danger" onclick="deleteTimetable(${idx})"><i class="fas fa-trash"></i></button>
            </td>
        </tr>
    `).join('');
}

async function editTimetable(idx) {
    const s = myTimetable[idx];
    document.getElementById('timetableEditId').value = idx;
    document.getElementById('timetableDay').value = s.day;
    document.getElementById('timetableTime').value = s.time;
    document.getElementById('timetableEndTime').value = s.endTime || '';
    document.getElementById('timetablePeriod').value = s.period || '';
    document.getElementById('timetableSubject').value = s.subject;
    document.getElementById('timetableClass').value = s.className;
    document.getElementById('timetableRoom').value = s.room;
    document.getElementById('timetableModalOverlay').classList.add('show');
    document.getElementById('timetableModal').classList.add('show');
}

function deleteTimetable(idx) {
    if (!confirm('Are you sure you want to delete this schedule?')) return;
    myTimetable.splice(idx, 1);
    localStorage.setItem(`teacher_timetable_${currentTeacher.id}`, JSON.stringify(myTimetable));
    showToast('Schedule deleted!');
    renderTimetable();
}

// ===== CLASS COLLEAGUES =====
async function loadClassColleagues() {
    if (!currentTeacher) return;
    const container = document.getElementById('classColleaguesList');
    if (!container) return;
    container.innerHTML = '<p class="text-muted">Loading colleagues...</p>';
    const result = await apiCollaboration('my_class_colleagues', { teacher_id: currentTeacher.id });
    if (result.success && result.data) {
        const colleagues = result.data.items || [];
        const className = result.data.className || '';
        if (colleagues.length === 0 && !className) {
            container.innerHTML = '<p class="text-muted">No class assigned. Contact admin to assign you to a class.</p>';
        } else if (colleagues.length === 0) {
            container.innerHTML = '<p class="text-muted">No other teachers assigned to your class yet.</p>';
        } else {
            renderClassColleagues(colleagues, className);
        }
    } else {
        container.innerHTML = '<p class="text-muted">Failed to load colleagues. ' + (result.message || 'Please try again.') + '</p>';
    }
}

function sendTeacherMessage(teacherId, teacherName) {
    // Open teacher message modal with recipient pre-selected
    openTeacherMessageModal();
    const recipientSelect = document.getElementById('teacherMessageRecipient');
    if (recipientSelect) {
        recipientSelect.value = teacherId;
        recipientSelect.innerHTML = `<option value="${teacherId}">${teacherName}</option>`;
    }
}

// ===== COLLABORATION DATA =====
async function loadCollaborationData() {
    // Load class colleagues
    await loadClassColleagues();
    
    // Load shared reports
    await loadSharedReports();
    
    // Load teacher messages
    await loadTeacherMessages();
}

async function loadSharedReports() {
    const tbody = document.getElementById('sharedReportsBody');
    if (!tbody) return;
    
    try {
        // For now, show empty state as this feature needs backend implementation
        tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No shared reports yet.</td></tr>';
    } catch (error) {
        console.error('Error loading shared reports:', error);
        tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">Failed to load shared reports.</td></tr>';
    }
}

async function loadTeacherMessages() {
    const container = document.getElementById('messageCenterList');
    if (!container) return;
    
    try {
        // For now, show empty state as this feature needs backend implementation
        container.innerHTML = '<p class="text-muted">No messages yet.</p>';
    } catch (error) {
        console.error('Error loading teacher messages:', error);
        container.innerHTML = '<p class="text-muted">Failed to load messages.</p>';
    }
}

// ===== COMPLAINTS =====
async function loadClassComplaints() {
    if (!currentTeacher) return;
    
    const result = await apiTeacher('class_complaints', { teacher_id: currentTeacher.id });
    const complaints = result.success ? (result.data?.items || []) : [];
    
    const tbody = document.getElementById('complaintsBody');
    if (!tbody) return;
    
    if (complaints.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted">No complaints for your class yet.</td></tr>';
        return;
    }
    
    tbody.innerHTML = complaints.map((c, i) => {
        const statusClass = c.status === 'resolved' ? 'payment-status confirmed' : 
                            c.status === 'in_progress' ? 'payment-status pending' : 'payment-status rejected';
        const complaintPreview = c.complaintText.substring(0, 50) + (c.complaintText.length > 50 ? '...' : '');
        const responsePreview = c.teacherResponse ? c.teacherResponse.substring(0, 30) + (c.teacherResponse.length > 30 ? '...' : '') : '-';
        
        return `<tr>
            <td>${i + 1}</td>
            <td><strong>${c.parentName}</strong></td>
            <td>${c.className}</td>
            <td>${complaintPreview}</td>
            <td><span class="${statusClass}">${c.status}</span></td>
            <td>${formatDate(c.createdAt)}</td>
            <td>
                <button class="teacher-btn teacher-btn-primary teacher-btn-sm" onclick="openComplaintResponseModal(${c.id})" title="Respond">
                    <i class="fas fa-reply"></i>
                </button>
                <button class="teacher-btn teacher-btn-info teacher-btn-sm" onclick="editComplaint(${c.id})" title="Edit">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="teacher-btn teacher-btn-warning teacher-btn-sm" onclick="rejectComplaint(${c.id})" title="Reject">
                    <i class="fas fa-times"></i>
                </button>
                <button class="teacher-btn teacher-btn-danger teacher-btn-sm" onclick="deleteComplaint(${c.id})" title="Delete">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        </tr>`;
    }).join('');
}

function openComplaintResponseModal(complaintId) {
    const modal = document.getElementById('complaintResponseModal');
    const overlay = document.getElementById('complaintResponseModalOverlay');
    
    if (!modal || !overlay) return;
    
    // Find the complaint data
    const tbody = document.getElementById('complaintsBody');
    const rows = tbody.querySelectorAll('tr');
    let complaint = null;
    
    // In a real implementation, you'd store complaint data or fetch it
    // For now, we'll set the ID and let the form handle the rest
    document.getElementById('complaintResponseId').value = complaintId;
    
    // Show modal
    overlay.classList.add('show');
    modal.classList.add('show');
}

function closeComplaintResponseModal() {
    const modal = document.getElementById('complaintResponseModal');
    const overlay = document.getElementById('complaintResponseModalOverlay');
    
    if (modal) modal.classList.remove('show');
    if (overlay) overlay.classList.remove('show');
    
    // Clear form
    document.getElementById('complaintResponseForm').reset();
    document.getElementById('complaintResponseId').value = '';
}

async function submitComplaintResponse(event) {
    event.preventDefault();
    if (!currentTeacher) { showToast('You must be logged in!', 'error'); return; }
    
    const complaintId = parseInt(document.getElementById('complaintResponseId').value);
    const response = document.getElementById('complaintResponseContent').value.trim();
    const status = document.getElementById('complaintResponseStatus').value;
    
    if (!complaintId) { showToast('Invalid complaint!', 'error'); return; }
    if (!response) { showToast('Response is required!', 'error'); return; }
    
    const payload = {
        teacher_id: currentTeacher.id,
        complaint_id: complaintId,
        response: response,
        status: status
    };
    
    const result = await apiTeacher('respond_complaint', {}, payload);
    if (result.success) {
        showToast(result.message || 'Response submitted successfully!', 'success');
        closeComplaintResponseModal();
        loadClassComplaints();
    } else {
        showToast(result.message || 'Failed to submit response', 'error');
    }
}

// Make functions globally accessible
window.loadClassComplaints = loadClassComplaints;
window.openComplaintResponseModal = openComplaintResponseModal;
window.closeComplaintResponseModal = closeComplaintResponseModal;
window.submitComplaintResponse = submitComplaintResponse;
window.editComplaint = editComplaint;
window.deleteComplaint = deleteComplaint;
window.rejectComplaint = rejectComplaint;

async function editComplaint(complaintId) {
    const newComplaintText = prompt('Enter the updated complaint text:');
    if (newComplaintText === null) return; // User cancelled
    if (!newComplaintText.trim()) {
        showToast('Complaint text cannot be empty!', 'error');
        return;
    }
    
    const payload = {
        teacher_id: currentTeacher.id,
        complaint_id: complaintId,
        complaint_text: newComplaintText.trim()
    };
    
    const result = await apiTeacher('edit_complaint', {}, payload);
    if (result.success) {
        showToast('Complaint updated successfully!', 'success');
        loadClassComplaints();
    } else {
        showToast(result.message || 'Failed to update complaint', 'error');
    }
}

async function deleteComplaint(complaintId) {
    if (!confirm('Are you sure you want to delete this complaint? This action cannot be undone.')) {
        return;
    }
    
    const payload = {
        teacher_id: currentTeacher.id,
        complaint_id: complaintId
    };
    
    const result = await apiTeacher('delete_complaint', {}, payload);
    if (result.success) {
        showToast('Complaint deleted successfully!', 'success');
        loadClassComplaints();
    } else {
        showToast(result.message || 'Failed to delete complaint', 'error');
    }
}

async function rejectComplaint(complaintId) {
    const rejectionReason = prompt('Enter the reason for rejecting this complaint:');
    if (rejectionReason === null) return; // User cancelled
    if (!rejectionReason.trim()) {
        showToast('Rejection reason is required!', 'error');
        return;
    }
    
    const payload = {
        teacher_id: currentTeacher.id,
        complaint_id: complaintId,
        rejection_reason: rejectionReason.trim()
    };
    
    const result = await apiTeacher('reject_complaint', {}, payload);
    if (result.success) {
        showToast('Complaint rejected successfully! Parent will be notified.', 'success');
        loadClassComplaints();
    } else {
        showToast(result.message || 'Failed to reject complaint', 'error');
    }
}

// ===== INIT =====
document.addEventListener('DOMContentLoaded', function() {
    // Try auto-login first
    if (!autoLogin()) {
        document.getElementById('authScreen').style.display = 'flex';
        document.getElementById('teacherDashboard').style.display = 'none';
    }
    
    // Setup note type change event listener
    const noteTypeSelect = document.getElementById('noteType');
    if (noteTypeSelect) {
        noteTypeSelect.addEventListener('change', function() {
            const noteStudentGroup = document.getElementById('noteStudentGroup');
            if (noteStudentGroup) {
                noteStudentGroup.style.display = this.value === 'student' ? 'block' : 'none';
            }
        });
    }
    
    // Setup radio button listeners for send report modal
    const sendToAdminBtn = document.getElementById('sendToAdminBtn');
    const sendToParentBtn = document.getElementById('sendToParentBtn');
    const parentSelectGroup = document.getElementById('parentSelectGroup');
    const priorityGroup = document.getElementById('priorityGroup');
    
    if (sendToAdminBtn && parentSelectGroup && priorityGroup) {
        sendToAdminBtn.addEventListener('change', function() {
            parentSelectGroup.style.display = 'none';
            priorityGroup.style.display = 'block';
        });
    }
    
    if (sendToParentBtn && parentSelectGroup && priorityGroup) {
        sendToParentBtn.addEventListener('change', function() {
            parentSelectGroup.style.display = 'block';
            priorityGroup.style.display = 'none';
        });
    }
});

// Load timetable when teacher dashboard is shown
function onTeacherLoginSuccess() {
    renderTimetable();
    loadTimetableDocuments();
}

// Load timetable documents from admin
async function loadTimetableDocuments() {
    const listContainer = document.getElementById('timetableDocumentsList');
    if (!listContainer) {
        console.error('timetableDocumentsList element not found');
        return;
    }

    // Set loading state
    listContainer.innerHTML = '<p class="text-muted">Loading timetable documents...</p>';

    try {
        const response = await fetch('../api/index.php?type=admin&collection=timetable_documents');
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const result = await response.json();
        console.log('Timetable documents response:', result);

        if (result.success && result.data && result.data.items && result.data.items.length > 0) {
            // Filter documents to show only those shared with teachers
            const documents = result.data.items.filter(doc => 
                !doc.target || doc.target === 'teachers' || doc.target === 'all'
            );
            
            if (documents.length === 0) {
                listContainer.innerHTML = '<p class="text-muted">No timetable documents shared with teachers yet.</p>';
                return;
            }
            
            listContainer.innerHTML = documents.map(doc => `
                <div class="teacher-card" style="margin-bottom: 12px; padding: 12px; border-left: 4px solid #085636; background: #f9fafb;">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <div>
                            <h5 style="margin: 0 0 4px 0; color: #085636;">
                                <i class="fas fa-file"></i> ${doc.title}
                            </h5>
                            <p style="margin: 0; font-size: 12px; color: #666;">
                                ${doc.term} ${doc.class ? ' - ' + doc.class : ' - All Classes'}
                            </p>
                            ${doc.description ? `<p style="margin: 4px 0 0 0; font-size: 11px; color: #999;">${doc.description}</p>` : ''}
                            <p style="margin: 4px 0 0 0; font-size: 11px; color: #999;">
                                Uploaded: ${new Date(doc.created_at).toLocaleDateString()}
                            </p>
                        </div>
                        <div>
                            <a href="${doc.file_url}" target="_blank" class="teacher-btn teacher-btn-sm teacher-btn-primary">
                                <i class="fas fa-download"></i> Download
                            </a>
                        </div>
                    </div>
                </div>
            `).join('');
        } else {
            listContainer.innerHTML = '<p class="text-muted">No timetable documents shared by admin yet.</p>';
        }
    } catch (error) {
        console.error('Error loading timetable documents:', error);
        listContainer.innerHTML = '<p class="text-muted">Error loading documents. Please try again later.</p>';
    }
}

// Handle teacher file upload to admin
async function handleTeacherFileUpload(e) {
    e.preventDefault();

    const form = document.getElementById('teacherFileUploadForm');
    const fileInput = document.getElementById('teacherFile');
    const files = fileInput.files;

    if (!files || files.length === 0) {
        showToast('Please select at least one file to upload', 'error');
        return false;
    }

    // Validate all files
    const allowedTypes = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'image/jpeg', 'image/png', 'image/jpg'];
    const maxSize = 10 * 1024 * 1024; // 10MB

    for (let i = 0; i < files.length; i++) {
        const file = files[i];
        if (file.size > maxSize) {
            showToast(`File "${file.name}" exceeds 10MB limit`, 'error');
            return false;
        }
        if (!allowedTypes.includes(file.type)) {
            showToast(`File "${file.name}" has invalid type. Please upload PDF, DOC, DOCX, XLS, XLSX, JPG, or PNG files`, 'error');
            return false;
        }
    }

    const title = document.getElementById('teacherFileTitle').value;
    const category = document.getElementById('teacherFileCategory').value;
    const description = document.getElementById('teacherFileDescription').value;

    const formData = new FormData();
    formData.append('action', 'upload_file_to_admin');
    formData.append('teacher_id', currentTeacher.id);
    formData.append('title', title);
    formData.append('category', category);
    formData.append('description', description);

    // Add all files
    for (let i = 0; i < files.length; i++) {
        formData.append('file[]', files[i]);
    }

    try {
        const response = await fetch(`${API_BASE}?type=teacher`, {
            method: 'POST',
            body: formData
        });

        const result = await safeFetch(response);

        if (result.success) {
            showToast(`${result.data?.uploadedCount || files.length} file(s) sent to admin successfully!`, 'success');
            form.reset();
        } else {
            showToast(result.message || 'Failed to send files to admin', 'error');
        }
    } catch (error) {
        showToast('Error sending files: ' + error.message, 'error');
    }

    return false;
}

// ===== ATTENDANCE MANAGEMENT =====
let attendanceRecords = [];

function openAttendanceModal() {
    if (myStudents.length === 0) {
        showToast('No students assigned to your class!', 'error');
        return;
    }
    
    document.getElementById('attendanceDate').value = new Date().toISOString().slice(0, 10);
    
    const listDiv = document.getElementById('attendanceStudentList');
    listDiv.innerHTML = myStudents.map(s => `
        <div style="display:flex;align-items:center;gap:10px;padding:10px;border-bottom:1px solid #eee;">
            <strong style="min-width:150px;">${s.firstName} ${s.lastName}</strong>
            <label style="display:flex;align-items:center;gap:5px;cursor:pointer;">
                <input type="radio" name="att_${s.id}" value="Present" checked> Present
            </label>
            <label style="display:flex;align-items:center;gap:5px;cursor:pointer;">
                <input type="radio" name="att_${s.id}" value="Absent"> Absent
            </label>
            <label style="display:flex;align-items:center;gap:5px;cursor:pointer;">
                <input type="radio" name="att_${s.id}" value="Late"> Late
            </label>
        </div>
    `).join('');
    
    document.getElementById('attendanceModalOverlay').classList.add('show');
    document.getElementById('attendanceModal').classList.add('show');
}

function closeAttendanceModal() {
    document.getElementById('attendanceModalOverlay').classList.remove('show');
    document.getElementById('attendanceModal').classList.remove('show');
}

async function saveAttendance(event) {
    event.preventDefault();
    if (!currentTeacher) { showToast('Please login first!', 'error'); return false; }
    
    const date = document.getElementById('attendanceDate').value;
    const records = [];
    
    myStudents.forEach(s => {
        const radio = document.querySelector(`input[name="att_${s.id}"]:checked`);
        if (radio) {
            records.push({
                studentId: s.id,
                studentName: s.firstName + ' ' + s.lastName,
                className: currentTeacher.class || '',
                status: radio.value
            });
        }
    });
    
    if (records.length === 0) {
        showToast('No attendance records to save!', 'error');
        return false;
    }
    
    const result = await apiTeacher('bulk_attendance', {}, { records, date });
    if (result.success) {
        showToast(`Attendance saved for ${records.length} students!`);
        closeAttendanceModal();
        loadAttendanceHistory();
    } else {
        showToast(result.message || 'Failed to save attendance', 'error');
    }
    return false;
}

async function loadAttendanceHistory() {
    if (!currentTeacher) return;
    
    const result = await apiTeacher('class_attendance', { teacher_id: currentTeacher.id });
    if (!result.success) {
        showToast(result.message || 'Failed to load attendance', 'error');
        return;
    }
    
    attendanceRecords = result.data?.items || [];
    renderAttendanceHistory();
}

function renderAttendanceHistory() {
    const tbody = document.getElementById('attendanceBody');
    const statsDiv = document.getElementById('attendanceStats');
    
    if (attendanceRecords.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No attendance records found.</td></tr>';
        statsDiv.innerHTML = '';
        return;
    }
    
    // Group by date
    const byDate = {};
    attendanceRecords.forEach(r => {
        if (!byDate[r.date]) byDate[r.date] = [];
        byDate[r.date].push(r);
    });
    
    // Calculate stats
    let totalPresent = 0, totalAbsent = 0, totalLate = 0;
    attendanceRecords.forEach(r => {
        if (r.status === 'Present') totalPresent++;
        else if (r.status === 'Absent') totalAbsent++;
        else if (r.status === 'Late') totalLate++;
    });
    
    const totalRecords = attendanceRecords.length;
    const attendanceRate = totalRecords > 0 ? Math.round((totalPresent + totalLate) / totalRecords * 100) : 0;
    
    statsDiv.innerHTML = `
        <div style="background:#e8f8f5;padding:12px 20px;border-radius:8px;flex:1;min-width:120px;text-align:center;">
            <div style="font-size:24px;font-weight:700;color:#085636;">${totalPresent}</div>
            <div style="font-size:12px;color:#666;">Present</div>
        </div>
        <div style="background:#fdedec;padding:12px 20px;border-radius:8px;flex:1;min-width:120px;text-align:center;">
            <div style="font-size:24px;font-weight:700;color:#e74c3c;">${totalAbsent}</div>
            <div style="font-size:12px;color:#666;">Absent</div>
        </div>
        <div style="background:#fef9e7;padding:12px 20px;border-radius:8px;flex:1;min-width:120px;text-align:center;">
            <div style="font-size:24px;font-weight:700;color:#f39c12;">${totalLate}</div>
            <div style="font-size:12px;color:#666;">Late</div>
        </div>
        <div style="background:#e3f2fd;padding:12px 20px;border-radius:8px;flex:1;min-width:120px;text-align:center;">
            <div style="font-size:24px;font-weight:700;color:#2196f3;">${attendanceRate}%</div>
            <div style="font-size:12px;color:#666;">Attendance Rate</div>
        </div>
    `;
    
    tbody.innerHTML = Object.entries(byDate).sort((a, b) => b[0].localeCompare(a[0])).slice(0, 20).map(([date, records]) => {
        const present = records.filter(r => r.status === 'Present').length;
        const absent = records.filter(r => r.status === 'Absent').length;
        const late = records.filter(r => r.status === 'Late').length;
        const total = records.length;
        const rate = Math.round((present + late) / total * 100);
        
        return `<tr>
            <td><strong>${formatDate(date)}</strong></td>
            <td><span style="color:#085636;font-weight:600;">${present}</span></td>
            <td><span style="color:#e74c3c;font-weight:600;">${absent}</span></td>
            <td><span style="color:#f39c12;font-weight:600;">${late}</span></td>
            <td>${total}</td>
            <td>
                <div style="display:flex;align-items:center;gap:8px;">
                    <div style="flex:1;background:#e0e0e0;border-radius:10px;height:8px;overflow:hidden;">
                        <div style="width:${rate}%;height:100%;background:${rate >= 90 ? '#085636' : rate >= 75 ? '#f39c12' : '#e74c3c'};"></div>
                    </div>
                    <strong>${rate}%</strong>
                </div>
            </td>
        </tr>`;
    }).join('');
}

// ===== CHANGE PASSWORD =====
function openPasswordModal() {
    document.getElementById('passwordForm').reset();
    document.getElementById('passwordFormUsername').value = currentTeacher.email || currentTeacher.username;
    document.getElementById('passwordModalOverlay').classList.add('show');
    document.getElementById('passwordModal').classList.add('show');
}

function closePasswordModal() {
    document.getElementById('passwordModalOverlay').classList.remove('show');
    document.getElementById('passwordModal').classList.remove('show');
}

async function changePassword(event) {
    event.preventDefault();
    if (!currentTeacher) { showToast('Please login first!', 'error'); return false; }
    
    const current = document.getElementById('currentPassword').value;
    const newPass = document.getElementById('newPassword').value;
    const confirm = document.getElementById('confirmPassword').value;
    
    if (newPass.length < 4) {
        showToast('New password must be at least 4 characters!', 'error');
        return false;
    }
    
    if (newPass !== confirm) {
        showToast('New passwords do not match!', 'error');
        return false;
    }
    
    const result = await apiTeacher('change_password', {}, {
        teacherId: currentTeacher.id,
        currentPassword: current,
        newPassword: newPass
    });
    
    if (result.success) {
        showToast('Password changed successfully!');
        closePasswordModal();
    } else {
        showToast(result.message || 'Failed to change password', 'error');
    }
    return false;
}

// ===== PERFORMANCE ANALYTICS =====
function renderPerformanceCharts() {
    const container = document.getElementById('performanceCharts');
    if (!container || myStudents.length === 0) {
        container.innerHTML = '<p class="text-muted">No student data available for analytics.</p>';
        return;
    }
    
    // Calculate grade distribution
    const gradeDist = { A: 0, B: 0, C: 0, D: 0, F: 0 };
    const studentAvgs = [];
    
    myStudents.forEach(s => {
        const assessments = myAssessments.filter(a => a.studentId === s.id);
        if (assessments.length > 0) {
            const avg = Math.round(assessments.reduce((sum, a) => sum + a.score, 0) / assessments.length);
            studentAvgs.push({ name: s.firstName + ' ' + s.lastName, avg });
            const grade = getGrade(avg);
            gradeDist[grade]++;
        }
    });
    
    if (studentAvgs.length === 0) {
        container.innerHTML = '<p class="text-muted">No assessment data available for analytics.</p>';
        return;
    }
    
    // Grade Distribution Chart
    const maxGrade = Math.max(...Object.values(gradeDist), 1);
    const gradeChart = `
        <div style="flex:1;min-width:280px;">
            <h4 style="margin-bottom:15px;text-align:center;">Grade Distribution</h4>
            <div style="display:flex;align-items:flex-end;justify-content:space-around;height:200px;gap:10px;padding:10px;">
                ${Object.entries(gradeDist).map(([grade, count]) => {
                    const height = (count / maxGrade) * 150;
                    const colors = { A: '#085636', B: '#2196f3', C: '#f39c12', D: '#ff9800', F: '#e74c3c' };
                    return `<div style="display:flex;flex-direction:column;align-items:center;gap:5px;">
                        <div style="font-weight:700;">${count}</div>
                        <div style="width:40px;height:${height}px;background:${colors[grade]};border-radius:4px 4px 0 0;transition:all 0.3s;"></div>
                        <div style="font-weight:600;">${grade}</div>
                    </div>`;
                }).join('')}
            </div>
        </div>
    `;
    
    // Top Performers Chart
    const topStudents = studentAvgs.sort((a, b) => b.avg - a.avg).slice(0, 5);
    const topChart = `
        <div style="flex:1;min-width:280px;">
            <h4 style="margin-bottom:15px;text-align:center;">Top Performers</h4>
            <div style="display:flex;flex-direction:column;gap:12px;padding:10px;">
                ${topStudents.map((s, idx) => {
                    const colors = ['#f39c12', '#95a5a6', '#cd7f32', '#085636', '#2196f3'];
                    return `<div style="display:flex;align-items:center;gap:10px;">
                        <div style="width:30px;height:30px;border-radius:50%;background:${colors[idx]};color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;">${idx + 1}</div>
                        <div style="flex:1;">
                            <div style="font-weight:600;margin-bottom:3px;">${s.name}</div>
                            <div style="background:#e0e0e0;border-radius:10px;height:8px;overflow:hidden;">
                                <div style="width:${s.avg}%;height:100%;background:${s.avg >= 75 ? '#085636' : s.avg >= 50 ? '#f39c12' : '#e74c3c'};"></div>
                            </div>
                        </div>
                        <div style="font-weight:700;min-width:45px;text-align:right;">${s.avg}%</div>
                    </div>`;
                }).join('')}
            </div>
        </div>
    `;
    
    container.innerHTML = gradeChart + topChart;
}

function generateReport() {
    if (myStudents.length === 0 || myAssessments.length === 0) {
        showToast('No data available to generate report!', 'error');
        return;
    }
    
    // Generate a simple text report
    let report = 'NOAH CHRISTIAN ACADEMY - STUDENT PERFORMANCE REPORT\n';
    report += '='.repeat(60) + '\n';
    report += `Teacher: ${currentTeacher.firstName} ${currentTeacher.lastName}\n`;
    report += `Class: ${currentTeacher.class || 'Not Assigned'}\n`;
    report += `Date: ${new Date().toLocaleDateString()}\n`;
    report += '='.repeat(60) + '\n\n';
    
    // Add contact details
    report += 'CONTACT INFORMATION:\n';
    report += '-'.repeat(60) + '\n';
    report += '📧 info@noahacademy.com\n';
    report += '📞 +265 999 123 456\n';
    report += '📍 Lilongwe, Malawi\n';
    report += `Generated on: ${new Date().toLocaleDateString()}\n`;
    report += '='.repeat(60) + '\n\n';
    
    report += 'STUDENT PERFORMANCE SUMMARY:\n';
    report += '-'.repeat(60) + '\n';
    
    myStudents.forEach(s => {
        const assessments = myAssessments.filter(a => a.studentId === s.id);
        const count = assessments.length;
        const avg = count > 0 ? Math.round(assessments.reduce((sum, a) => sum + a.score, 0) / count) : 0;
        const grade = count > 0 ? getGrade(avg) : 'N/A';
        
        report += `\n${s.firstName} ${s.lastName}\n`;
        report += `  Assessments: ${count} | Average: ${count > 0 ? avg + '%' : 'N/A'} | Grade: ${grade}\n`;
        
        if (count > 0) {
            report += '  Recent Assessments:\n';
            assessments.slice(0, 3).forEach(a => {
                report += `    - ${a.subject} (${a.type}): ${a.score}% - ${formatDate(a.date)}\n`;
            });
        }
    });
    
    report += '\n' + '='.repeat(60) + '\n';
    report += 'End of Report\n';
    
    // Download as text file
    const blob = new Blob([report], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `performance_report_${new Date().toISOString().slice(0, 10)}.txt`;
    a.click();
    URL.revokeObjectURL(url);
    
    showToast('Report generated and downloaded!');
}

// ===== HOMEWORK MANAGER =====
let homeworkList = [];

function getHomework() {
    const stored = localStorage.getItem(`teacher_homework_${currentTeacher.id}`);
    return stored ? JSON.parse(stored) : [];
}

function renderHomework() {
    if (!currentTeacher) return;
    const tbody = document.getElementById('homeworkBody');
    if (!tbody) return;
    homeworkList = getHomework();
    if (homeworkList.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No homework assigned yet.</td></tr>';
        return;
    }
    tbody.innerHTML = homeworkList.map((h, idx) => {
        const statusColor = h.status === 'Completed' ? '#085636' : h.status === 'In Progress' ? '#f39c12' : '#95a5a6';
        return `<tr>
            <td><strong>${h.title}</strong></td>
            <td>${h.subject}</td>
            <td>${h.className}</td>
            <td>${formatDate(h.dueDate)}</td>
            <td><span style="color:${statusColor};font-weight:600;">${h.status}</span></td>
            <td>
                <button class="teacher-btn teacher-btn-sm teacher-btn-secondary" onclick="editHomework(${idx})"><i class="fas fa-edit"></i></button>
                <button class="teacher-btn teacher-btn-sm teacher-btn-danger" onclick="deleteHomework(${idx})"><i class="fas fa-trash"></i></button>
            </td>
        </tr>`;
    }).join('');
}

function openHomeworkModal() {
    document.getElementById('homeworkEditId').value = '';
    document.getElementById('homeworkForm').reset();
    document.getElementById('homeworkDueDate').value = new Date(Date.now() + 7 * 86400000).toISOString().slice(0, 10);
    if (currentTeacher && currentTeacher.class) {
        document.getElementById('homeworkClass').value = currentTeacher.class;
    }
    document.getElementById('homeworkModalTitle').innerHTML = '<i class="fas fa-tasks"></i> Add Homework';
    document.getElementById('homeworkModalOverlay').classList.add('show');
    document.getElementById('homeworkModal').classList.add('show');
}

function closeHomeworkModal() {
    document.getElementById('homeworkModalOverlay').classList.remove('show');
    document.getElementById('homeworkModal').classList.remove('show');
}

function editHomework(idx) {
    homeworkList = getHomework();
    const h = homeworkList[idx];
    document.getElementById('homeworkEditId').value = idx;
    document.getElementById('homeworkTitle').value = h.title;
    document.getElementById('homeworkSubject').value = h.subject;
    document.getElementById('homeworkClass').value = h.className;
    document.getElementById('homeworkDueDate').value = h.dueDate;
    document.getElementById('homeworkStatus').value = h.status;
    document.getElementById('homeworkDescription').value = h.description || '';
    document.getElementById('homeworkModalTitle').innerHTML = '<i class="fas fa-tasks"></i> Edit Homework';
    document.getElementById('homeworkModalOverlay').classList.add('show');
    document.getElementById('homeworkModal').classList.add('show');
}

function saveHomework(event) {
    event.preventDefault();
    homeworkList = getHomework();
    const editId = document.getElementById('homeworkEditId').value;
    const data = {
        title: document.getElementById('homeworkTitle').value.trim(),
        subject: document.getElementById('homeworkSubject').value.trim(),
        className: document.getElementById('homeworkClass').value,
        dueDate: document.getElementById('homeworkDueDate').value,
        status: document.getElementById('homeworkStatus').value,
        description: document.getElementById('homeworkDescription').value.trim(),
        createdAt: new Date().toISOString()
    };
    if (editId !== '') {
        homeworkList[parseInt(editId)] = { ...homeworkList[parseInt(editId)], ...data };
    } else {
        homeworkList.push(data);
    }
    localStorage.setItem(`teacher_homework_${currentTeacher.id}`, JSON.stringify(homeworkList));
    showToast(editId !== '' ? 'Homework updated!' : 'Homework added!');
    closeHomeworkModal();
    renderHomework();
    return false;
}

function deleteHomework(idx) {
    if (!confirm('Delete this homework?')) return;
    homeworkList = getHomework();
    homeworkList.splice(idx, 1);
    localStorage.setItem(`teacher_homework_${currentTeacher.id}`, JSON.stringify(homeworkList));
    showToast('Homework deleted!');
    renderHomework();
}

// ===== MESSAGE CENTER =====
let messagesList = [];

function getMessages() {
    const stored = localStorage.getItem(`teacher_messages_${currentTeacher.id}`);
    return stored ? JSON.parse(stored) : [];
}

function renderMessages() {
    if (!currentTeacher) return;
    const container = document.getElementById('messageCenterList');
    if (!container) return;
    messagesList = getMessages();
    if (messagesList.length === 0) {
        container.innerHTML = '<p class="text-muted">No messages yet. Click "New Message" to send one.</p>';
        return;
    }
    container.innerHTML = messagesList.slice().reverse().map((m, idx) => {
        const priorityColor = m.priority === 'Urgent' ? '#e74c3c' : m.priority === 'Important' ? '#f39c12' : '#3498db';
        const origIdx = messagesList.length - 1 - idx;
        return `<div style="padding:12px 16px;margin-bottom:10px;border-radius:8px;border-left:4px solid ${priorityColor};background:#f8f9fa;">
            <div style="display:flex;justify-content:space-between;align-items:start;">
                <div>
                    <strong>${m.subject}</strong>
                    <span style="font-size:11px;padding:2px 8px;border-radius:10px;background:${priorityColor};color:#fff;margin-left:8px;">${m.priority}</span>
                </div>
                <div style="display:flex;gap:5px;">
                    <button class="teacher-btn teacher-btn-sm teacher-btn-info" onclick="viewMessage(${origIdx})" title="View"><i class="fas fa-eye"></i></button>
                    <button class="teacher-btn teacher-btn-sm teacher-btn-danger" onclick="deleteMessage(${origIdx})" title="Delete"><i class="fas fa-trash"></i></button>
                </div>
            </div>
            <p style="margin:5px 0 0;font-size:13px;color:#666;"><i class="fas fa-user"></i> To: ${m.recipient} | <i class="fas fa-clock"></i> ${formatDate(m.sentAt)}</p>
        </div>`;
    }).join('');
}

function openMessageModal() {
    document.getElementById('messageForm').reset();
    document.getElementById('messageModalOverlay').classList.add('show');
    document.getElementById('messageModal').classList.add('show');
}

function closeMessageModal() {
    document.getElementById('messageModalOverlay').classList.remove('show');
    document.getElementById('messageModal').classList.remove('show');
}

function viewMessage(idx) {
    messagesList = getMessages();
    const m = messagesList[idx];
    if (!m) return;
    showToast(`[${m.recipient}] ${m.subject}: ${m.content.substring(0, 80)}...`, 'info');
}

function saveMessage(event) {
    event.preventDefault();
    messagesList = getMessages();
    const data = {
        recipient: document.getElementById('messageRecipient').value,
        subject: document.getElementById('messageSubject').value.trim(),
        content: document.getElementById('messageContent').value.trim(),
        priority: document.getElementById('messagePriority').value,
        sentAt: new Date().toISOString(),
        senderId: currentTeacher.id,
        senderName: currentTeacher.firstName + ' ' + currentTeacher.lastName
    };
    messagesList.push(data);
    localStorage.setItem(`teacher_messages_${currentTeacher.id}`, JSON.stringify(messagesList));
    showToast('Message sent!');
    closeMessageModal();
    renderMessages();
    return false;
}

function deleteMessage(idx) {
    if (!confirm('Delete this message?')) return;
    messagesList = getMessages();
    messagesList.splice(idx, 1);
    localStorage.setItem(`teacher_messages_${currentTeacher.id}`, JSON.stringify(messagesList));
    showToast('Message deleted!');
    renderMessages();
}

// ===== LESSON PLANS =====
let lessonPlansList = [];

async function renderLessonPlans() {
    if (!currentTeacher) return;
    const tbody = document.getElementById('lessonPlanBody');
    if (!tbody) return;

    try {
        const result = await apiTeacher('my_lesson_plans', { teacher_id: currentTeacher.id });

        if (result.success) {
            lessonPlansList = result.data?.items || [];

            if (lessonPlansList.length === 0) {
                tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No lesson plans created yet.</td></tr>';
                return;
            }

            tbody.innerHTML = lessonPlansList.map((lp) => {
                const statusColor = lp.status === 'Completed' ? '#085636' : lp.status === 'In Progress' ? '#f39c12' : '#95a5a6';
                return `<tr>
                    <td><strong>${lp.week}</strong></td>
                    <td>${lp.subject}</td>
                    <td>${lp.topic}</td>
                    <td style="max-width:200px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;" title="${(lp.objectives || '').replace(/"/g, '&quot;')}">${(lp.objectives || '').substring(0, 60)}...</td>
                    <td><span style="color:${statusColor};font-weight:600;">${lp.status}</span></td>
                    <td>
                        <button class="teacher-btn teacher-btn-sm teacher-btn-info" onclick="viewLessonPlan(${lp.id})"><i class="fas fa-eye"></i></button>
                        <button class="teacher-btn teacher-btn-sm teacher-btn-secondary" onclick="editLessonPlan(${lp.id})"><i class="fas fa-edit"></i></button>
                        <button class="teacher-btn teacher-btn-sm teacher-btn-danger" onclick="deleteLessonPlan(${lp.id})"><i class="fas fa-trash"></i></button>
                    </td>
                </tr>`;
            }).join('');
        } else {
            tbody.innerHTML = `<tr><td colspan="6" class="text-center text-muted">Failed to load lesson plans: ${result.message}</td></tr>`;
        }
    } catch (error) {
        tbody.innerHTML = `<tr><td colspan="6" class="text-center text-muted">Error loading lesson plans: ${error.message}</td></tr>`;
    }
}

async function deleteLessonPlan(lessonPlanId) {
    if (!confirm('Delete this lesson plan?')) return;

    try {
        const result = await apiTeacher('delete_lesson_plan', {}, {
            id: lessonPlanId,
            teacherId: currentTeacher.id
        });

        if (result.success) {
            showToast('Lesson plan deleted successfully!', 'success');
            renderLessonPlans();
        } else {
            showToast(result.message || 'Failed to delete lesson plan', 'error');
        }
    } catch (error) {
        showToast('Error deleting lesson plan: ' + error.message, 'error');
    }
}

async function viewLessonPlan(lessonPlanId) {
    try {
        const result = await apiTeacher('get_lesson_plan', { lesson_plan_id: lessonPlanId, teacher_id: currentTeacher.id });

        if (result.success && result.data) {
            const lp = result.data;
            const paper = document.getElementById('lessonPlanPaper');

            // Populate the paper template
            paper.querySelector('.info-value.lp-class').value = lp.class_name || lp.className || '';
            paper.querySelector('.info-value.lp-date').value = lp.lesson_date || lp.date || '';
            paper.querySelector('.info-value.lp-time').value = lp.start_time || lp.time || '';
            paper.querySelector('.info-value.lp-subject').value = lp.subject || '';

            // Parse objectives for success criteria
            const objectives = lp.objectives || lp.topic || '';
            paper.querySelector('.success .dash').textContent = objectives || '-';

            // Materials (if available in data)
            paper.querySelector('.materials .materials-dash').textContent = lp.materials || '-';

            // For now, we'll keep the table empty as the detailed activities need to be stored separately
            // You can enhance this later by parsing the lesson plan data for teacher/learner activities

            document.getElementById('lessonPlanViewModalOverlay').classList.add('show');
            document.getElementById('lessonPlanViewModal').classList.add('show');
        } else {
            showToast(result.message || 'Failed to load lesson plan', 'error');
        }
    } catch (error) {
        showToast('Error loading lesson plan: ' + error.message, 'error');
    }
}

function closeLessonPlanViewModal() {
    document.getElementById('lessonPlanViewModalOverlay').classList.remove('show');
    document.getElementById('lessonPlanViewModal').classList.remove('show');
}

function clearLessonPlan() {
    if (!confirm("Clear all lesson plan information?")) {
        return;
    }

    document.querySelectorAll(
        ".lesson-plan input"
    ).forEach(input => input.value = "");

    document.querySelectorAll(
        '.lesson-plan [contenteditable="true"]'
    ).forEach(area => area.textContent = "");

    showToast('Lesson plan cleared!', 'info');
}

// ===== STUDENT BEHAVIOR LOG =====
let behaviorLog = [];

function getBehaviorLog() {
    const stored = localStorage.getItem(`teacher_behavior_${currentTeacher.id}`);
    return stored ? JSON.parse(stored) : [];
}

function renderBehaviorLog() {
    if (!currentTeacher) return;
    const tbody = document.getElementById('behaviorBody');
    if (!tbody) return;
    behaviorLog = getBehaviorLog();
    if (behaviorLog.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted">No behavior records yet.</td></tr>';
        return;
    }
    tbody.innerHTML = behaviorLog.slice().reverse().map((b, revIdx) => {
        const origIdx = behaviorLog.length - 1 - revIdx;
        const typeColor = b.type === 'Positive' ? '#085636' : b.type === 'Negative' ? '#e74c3c' : '#f39c12';
        const typeBg = b.type === 'Positive' ? '#e8f8f5' : b.type === 'Negative' ? '#fdedec' : '#fef9e7';
        
        // Format send to display (handle legacy records)
        const sendToDisplay = b.sendTo === 'admin' ? 'Admin' : 
                              b.sendTo === 'parent' ? 'Parent' : 
                              b.sendTo === 'both' ? 'Admin & Parent' : 
                              b.sendTo === 'none' ? 'None (Parent not registered)' : 'N/A';
        
        // Attachment display (handle legacy records)
        const attachmentDisplay = b.attachment ? 
            `<span style="color:#085636;"><i class="fas fa-file-pdf"></i> ${b.attachmentName || 'PDF'}</span>` : 
            '<span style="color:#999;">None</span>';
        
        return `<tr>
            <td><strong>${b.studentName}</strong></td>
            <td><span style="background:${typeBg};color:${typeColor};padding:3px 10px;border-radius:12px;font-size:11px;font-weight:600;">${b.type}</span></td>
            <td>${b.description}</td>
            <td><span style="font-size:12px;font-weight:500;">${sendToDisplay}</span></td>
            <td>${attachmentDisplay}</td>
            <td>${formatDate(b.date)}</td>
            <td>
                <button class="teacher-btn teacher-btn-sm teacher-btn-danger" onclick="deleteBehavior(${origIdx})"><i class="fas fa-trash"></i></button>
            </td>
        </tr>`;
    }).join('');
}

function openBehaviorModal() {
    document.getElementById('behaviorForm').reset();
    document.getElementById('behaviorDate').value = new Date().toISOString().slice(0, 10);
    const select = document.getElementById('behaviorStudent');
    select.innerHTML = '<option value="">Select Student</option>';
    if (myStudents) {
        myStudents.forEach(s => {
            select.innerHTML += `<option value="${s.id}">${s.firstName} ${s.lastName}</option>`;
        });
    }
    // Reset new fields
    document.getElementById('behaviorSendTo').value = '';
    document.getElementById('behaviorFile').value = '';
    document.getElementById('behaviorModalOverlay').classList.add('show');
    document.getElementById('behaviorModal').classList.add('show');
}

function closeBehaviorModal() {
    document.getElementById('behaviorModalOverlay').classList.remove('show');
    document.getElementById('behaviorModal').classList.remove('show');
}

async function saveBehavior(event) {
    event.preventDefault();
    behaviorLog = getBehaviorLog();
    const studentSelect = document.getElementById('behaviorStudent');
    const studentId = parseInt(studentSelect.value);
    const student = myStudents ? myStudents.find(s => s.id === studentId) : null;
    if (!student) { showToast('Please select a student!', 'error'); return false; }
    
    const sendTo = document.getElementById('behaviorSendTo').value;
    if (!sendTo) { showToast('Please select recipient!', 'error'); return false; }
    
    // Handle file upload
    const fileInput = document.getElementById('behaviorFile');
    let fileData = null;
    let fileName = null;
    
    if (fileInput.files.length > 0) {
        const file = fileInput.files[0];
        if (file.type !== 'application/pdf') {
            showToast('Please upload a PDF file only!', 'error');
            return false;
        }
        
        // Convert file to base64
        try {
            fileData = await convertFileToBase64(file);
            fileName = file.name;
        } catch (error) {
            console.error('Error converting file:', error);
            showToast('Error processing file upload', 'error');
            return false;
        }
    }
    
    const data = {
        studentId: studentId,
        studentName: student.firstName + ' ' + student.lastName,
        type: document.getElementById('behaviorType').value,
        description: document.getElementById('behaviorDescription').value.trim(),
        date: document.getElementById('behaviorDate').value,
        loggedAt: new Date().toISOString(),
        loggedBy: currentTeacher.firstName + ' ' + currentTeacher.lastName,
        sendTo: sendTo,
        attachment: fileData,
        attachmentName: fileName
    };
    
    // Check if parent is registered if sending to parent
    if (sendTo === 'parent' || sendTo === 'both') {
        try {
            const parentsResult = await apiAdmin('parents', 'GET');
            if (parentsResult.success) {
                const parents = parentsResult.data?.items || [];
                const parentRegistered = parents.some(p => 
                    (p.firstName + ' ' + p.lastName === student.parent) ||
                    (p.firstName === student.parent)
                );
                
                if (!parentRegistered) {
                    showToast('Warning: Parent is not registered. Behavior report will only be sent to admin.', 'warning');
                    data.sendTo = sendTo === 'both' ? 'admin' : 'none';
                    data.parentNotRegistered = true;
                }
            }
        } catch (error) {
            console.error('Error checking parent registration:', error);
        }
    }
    
    behaviorLog.push(data);
    localStorage.setItem(`teacher_behavior_${currentTeacher.id}`, JSON.stringify(behaviorLog));
    
    // Show appropriate success message
    let successMessage = 'Behavior logged!';
    if (data.sendTo === 'admin') {
        successMessage += ' Sent to admin.';
    } else if (data.sendTo === 'parent') {
        successMessage += ' Sent to parent.';
    } else if (data.sendTo === 'both') {
        successMessage += ' Sent to admin and parent.';
    }
    
    if (fileData) {
        successMessage += ' File attached.';
    }
    
    showToast(successMessage);
    closeBehaviorModal();
    renderBehaviorLog();
    return false;
}

function convertFileToBase64(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result);
        reader.onerror = error => reject(error);
    });
}

function deleteBehavior(idx) {
    if (!confirm('Delete this behavior record?')) return;
    behaviorLog = getBehaviorLog();
    behaviorLog.splice(idx, 1);
    localStorage.setItem(`teacher_behavior_${currentTeacher.id}`, JSON.stringify(behaviorLog));
    showToast('Behavior record deleted!');
    renderBehaviorLog();
}

// ===== TEACHING RESOURCES =====
let resourcesList = [];
let sharedResourcesList = [];

async function renderResources() {
    if (!currentTeacher) return;
    const container = document.getElementById('teachingResourcesList');
    if (!container) return;

    // Get own resources from API
    const myResourcesRes = await apiTeacher('my_resources', { teacher_id: currentTeacher.id });
    resourcesList = myResourcesRes.success ? (myResourcesRes.data?.items || []) : [];

    // Get shared resources from API
    const sharedResourcesRes = await apiTeacher('shared_resources', { teacher_id: currentTeacher.id });
    sharedResourcesList = sharedResourcesRes.success ? (sharedResourcesRes.data?.items || []) : [];

    const allResources = [...resourcesList, ...sharedResourcesList];

    if (allResources.length === 0) {
        container.innerHTML = '<p class="text-muted">No resources added yet. Click "Add Resource" to get started.</p>';
        return;
    }

    const categoryIcons = {
        'Worksheet': 'fa-file-alt', 'Video': 'fa-video', 'Article': 'fa-newspaper',
        'Presentation': 'fa-file-powerpoint', 'Quiz': 'fa-question-circle', 'Other': 'fa-folder'
    };
    const categoryColors = {
        'Worksheet': '#085636', 'Video': '#e74c3c', 'Article': '#3498db',
        'Presentation': '#f39c12', 'Quiz': '#9b59b6', 'Other': '#95a5a6'
    };

    container.innerHTML = allResources.map((r, idx) => {
        const icon = categoryIcons[r.category] || 'fa-folder';
        const color = categoryColors[r.category] || '#95a5a6';
        const isShared = r.teacherId !== currentTeacher.id;
        const shareBadge = isShared ?
            `<span style="background:#e8f8f5;color:#085636;padding:2px 8px;border-radius:10px;font-size:10px;font-weight:600;margin-left:8px;">Shared by ${r.teacherName}</span>` :
            (r.shareWith === 'class' ? '<span style="background:#fff3cd;color:#856404;padding:2px 8px;border-radius:10px;font-size:10px;font-weight:600;margin-left:8px;">Shared with Class</span>' :
             r.shareWith === 'all' ? '<span style="background:#d1ecf1;color:#0c5460;padding:2px 8px;border-radius:10px;font-size:10px;font-weight:600;margin-left:8px;">Shared with All</span>' : '');

        const fileBadge = r.fileUrl ?
            `<span style="color:#085636;font-size:11px;margin-left:8px;"><i class="fas fa-paperclip"></i> ${r.fileName || 'File'}</span>` : '';

        const canEdit = !isShared;
        const resourceId = r.id;

        return `<div style="display:flex;align-items:center;gap:14px;padding:14px;margin-bottom:10px;border-radius:8px;border:1px solid #e0e0e0;background:#f8f9fa;">
            <div style="width:45px;height:45px;border-radius:10px;background:${color};color:#fff;display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0;">
                <i class="fas ${icon}"></i>
            </div>
            <div style="flex:1;">
                <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
                    <strong>${r.title}</strong>
                    <span style="font-size:11px;padding:2px 8px;border-radius:10px;background:${color};color:#fff;">${r.category}</span>
                    ${shareBadge}
                    ${fileBadge}
                </div>
                <p style="margin:4px 0 0;font-size:12px;color:#666;">${r.subject || 'General'} ${r.url ? '| <a href="' + r.url + '" target="_blank" style="color:#3498db;">Open Link</a>' : ''}</p>
                ${r.description ? '<p style="margin:3px 0 0;font-size:12px;color:#999;">' + r.description + '</p>' : ''}
            </div>
            <div style="display:flex;gap:5px;">
                ${r.fileUrl ? '<button class="teacher-btn teacher-btn-sm teacher-btn-info" onclick="downloadResourceFile(\'' + r.fileUrl + '\', \'' + (r.fileName || 'download') + '\')"><i class="fas fa-download"></i></button>' : ''}
                ${r.url ? '<button class="teacher-btn teacher-btn-sm teacher-btn-secondary" onclick="window.open(\'' + r.url + '\', \'_blank\')"><i class="fas fa-external-link-alt"></i></button>' : ''}
                ${canEdit ? '<button class="teacher-btn teacher-btn-sm teacher-btn-secondary" onclick="editResource(' + resourceId + ')"><i class="fas fa-edit"></i></button>' : ''}
                ${canEdit ? '<button class="teacher-btn teacher-btn-sm teacher-btn-danger" onclick="deleteResource(' + resourceId + ')"><i class="fas fa-trash"></i></button>' : ''}
            </div>
        </div>`;
    }).join('');
}

function downloadResourceFile(fileUrl, fileName) {
    if (!fileUrl) return;
    
    try {
        const link = document.createElement('a');
        link.href = fileUrl;
        link.download = fileName || 'download';
        link.target = '_blank';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        showToast('File downloaded successfully!', 'success');
    } catch (error) {
        console.error('Error downloading file:', error);
        showToast('Error downloading file', 'error');
    }
}

function openResourceModal() {
    document.getElementById('resourceEditId').value = '';
    document.getElementById('resourceForm').reset();
    document.getElementById('resourceModalTitle').innerHTML = '<i class="fas fa-folder-open"></i> Add Resource';
    // Reset new fields
    document.getElementById('resourceShareWith').value = 'private';
    document.getElementById('resourceFile').value = '';
    document.getElementById('resourceModalOverlay').classList.add('show');
    document.getElementById('resourceModal').classList.add('show');
}

function closeResourceModal() {
    document.getElementById('resourceModalOverlay').classList.remove('show');
    document.getElementById('resourceModal').classList.remove('show');
}

function editResource(resourceId) {
    const resource = resourcesList.find(r => r.id === resourceId);
    if (!resource) {
        showToast('Resource not found', 'error');
        return;
    }
    
    document.getElementById('resourceEditId').value = resourceId;
    document.getElementById('resourceTitle').value = resource.title;
    document.getElementById('resourceCategory').value = resource.category;
    document.getElementById('resourceSubject').value = resource.subject || '';
    document.getElementById('resourceUrl').value = resource.url || '';
    document.getElementById('resourceDescription').value = resource.description || '';
    document.getElementById('resourceShareWith').value = resource.shareWith || 'private';
    document.getElementById('resourceFile').value = ''; // Don't pre-fill file input
    document.getElementById('resourceModalTitle').innerHTML = '<i class="fas fa-folder-open"></i> Edit Resource';
    document.getElementById('resourceModalOverlay').classList.add('show');
    document.getElementById('resourceModal').classList.add('show');
}

async function saveResource(event) {
    event.preventDefault();
    if (!currentTeacher) { showToast('Please login first!', 'error'); return false; }
    
    const editId = document.getElementById('resourceEditId').value;
    const fileInput = document.getElementById('resourceFile');
    
    // Check if a file is being uploaded
    const hasFile = fileInput.files.length > 0;
    
    if (hasFile) {
        // Use multipart form data for file upload
        const formData = new FormData();
        formData.append('teacher_id', currentTeacher.id);
        formData.append('title', document.getElementById('resourceTitle').value.trim());
        formData.append('category', document.getElementById('resourceCategory').value);
        formData.append('subject', document.getElementById('resourceSubject').value.trim());
        formData.append('url', document.getElementById('resourceUrl').value.trim());
        formData.append('description', document.getElementById('resourceDescription').value.trim());
        formData.append('shareWith', document.getElementById('resourceShareWith').value);
        formData.append('editId', editId);
        
        if (fileInput.files.length > 0) {
            formData.append('resourceFile', fileInput.files[0]);
        }
        
        try {
            const response = await fetch(`${API_BASE}?type=teacher&action=save_resource`, {
                method: 'POST',
                body: formData
            });
            
            const result = await response.json();
            
            if (result.success) {
                showToast(result.message || 'Resource saved successfully!');
                closeResourceModal();
                await renderResources();
            } else {
                showToast(result.message || 'Failed to save resource', 'error');
            }
        } catch (error) {
            console.error('Error saving resource:', error);
            showToast('Error saving resource', 'error');
        }
    } else {
        // Use JSON for resources without file upload
        const data = {
            teacherId: currentTeacher.id,
            title: document.getElementById('resourceTitle').value.trim(),
            category: document.getElementById('resourceCategory').value,
            subject: document.getElementById('resourceSubject').value.trim(),
            url: document.getElementById('resourceUrl').value.trim(),
            description: document.getElementById('resourceDescription').value.trim(),
            shareWith: document.getElementById('resourceShareWith').value
        };
        
        if (editId) {
            data.id = parseInt(editId);
        }
        
        const result = await apiTeacher('save_resource', {}, data);
        
        if (result.success) {
            showToast(result.message || 'Resource saved successfully!');
            closeResourceModal();
            await renderResources();
        } else {
            showToast(result.message || 'Failed to save resource', 'error');
        }
    }
    
    return false;
}

async function deleteResource(resourceId) {
    if (!confirm('Delete this resource?')) return;
    
    const result = await apiTeacher('delete_resource', {}, { id: resourceId, teacherId: currentTeacher.id });
    
    if (result.success) {
        showToast('Resource deleted successfully!');
        await renderResources();
    } else {
        showToast(result.message || 'Failed to delete resource', 'error');
    }
}

// ===== EXAM PAPERS =====
let myExams = [];

async function renderExams() {
    if (!currentTeacher) return;
    const tbody = document.getElementById('examBody');
    if (!tbody) return;

    const result = await apiTeacher('my_exams', { teacher_id: currentTeacher.id });
    myExams = result.success ? (result.data?.items || []) : [];

    if (myExams.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted">No exams uploaded yet. Click "Upload Exam" to get started.</td></tr>';
        return;
    }

    tbody.innerHTML = myExams.map(e => {
        const statusColors = { 'Pending': '#f39c12', 'Approved': '#085636', 'Rejected': '#e74c3c' };
        const statusBg = { 'Pending': '#fef9e7', 'Approved': '#e8f8f5', 'Rejected': '#fdedec' };
        const color = statusColors[e.status] || '#95a5a6';
        const bg = statusBg[e.status] || '#f8f9fa';
        return `<tr>
            <td><strong>${e.title}</strong></td>
            <td>${e.subject || '-'}</td>
            <td>${e.className || '-'}</td>
            <td>${e.term || '-'}</td>
            <td><span style="background:${bg};color:${color};padding:3px 10px;border-radius:12px;font-size:11px;font-weight:600;">${e.status}</span></td>
            <td><a href="${e.fileUrl}" target="_blank" class="teacher-btn teacher-btn-info teacher-btn-sm"><i class="fas fa-eye"></i> View</a></td>
            <td>
                <button class="teacher-btn teacher-btn-sm teacher-btn-danger" onclick="deleteExam(${e.id})" title="Delete"><i class="fas fa-trash"></i></button>
            </td>
        </tr>`;
    }).join('');
}

function openExamModal() {
    document.getElementById('examForm').reset();
    document.getElementById('examFilePreview').innerHTML = '';
    if (currentTeacher && currentTeacher.class) {
        document.getElementById('examClass').value = currentTeacher.class;
    }
    if (currentTeacher && currentTeacher.subject) {
        document.getElementById('examSubject').value = currentTeacher.subject;
    }
    document.getElementById('examSubmitBtn').disabled = false;
    document.getElementById('examSubmitBtn').innerHTML = '<i class="fas fa-upload"></i> Upload & Send to Admin';
    document.getElementById('examModalOverlay').classList.add('show');
    document.getElementById('examModal').classList.add('show');
}

function closeExamModal() {
    document.getElementById('examModalOverlay').classList.remove('show');
    document.getElementById('examModal').classList.remove('show');
}

async function uploadExam(event) {
    event.preventDefault();
    if (!currentTeacher) { showToast('Please login first!', 'error'); return false; }

    const fileInput = document.getElementById('examFile');
    const file = fileInput.files[0];
    if (!file) { showToast('Please select a PDF file!', 'error'); return false; }

    // Validate file type
    if (file.type !== 'application/pdf') {
        showToast('Only PDF files are allowed!', 'error');
        return false;
    }
    // Validate size (10MB)
    if (file.size > 10 * 1024 * 1024) {
        showToast('File too large! Maximum size is 10MB.', 'error');
        return false;
    }

    const btn = document.getElementById('examSubmitBtn');
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Uploading...';

    const formData = new FormData();
    formData.append('examFile', file);
    formData.append('teacherId', currentTeacher.id);
    formData.append('teacherName', currentTeacher.firstName + ' ' + currentTeacher.lastName);
    formData.append('title', document.getElementById('examTitle').value.trim());
    formData.append('subject', document.getElementById('examSubject').value.trim());
    formData.append('className', document.getElementById('examClass').value);
    formData.append('term', document.getElementById('examTerm').value);
    formData.append('description', document.getElementById('examDescription').value.trim());

    try {
        const res = await fetch(`${API_BASE}?type=teacher&action=upload_exam`, {
            method: 'POST',
            body: formData
        });
        const result = await res.json();

        if (result.success) {
            showToast('Exam uploaded! Waiting for admin approval.', 'success');
            closeExamModal();
            renderExams();
        } else {
            showToast(result.message || 'Upload failed', 'error');
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-upload"></i> Upload & Send to Admin';
        }
    } catch (e) {
        showToast('Upload error: ' + e.message, 'error');
        btn.disabled = false;
        btn.innerHTML = '<i class="fas fa-upload"></i> Upload & Send to Admin';
    }
    return false;
}

async function deleteExam(id) {
    if (!confirm('Delete this exam? The file will also be removed.')) return;
    const result = await apiTeacher('delete_exam', {}, { id, teacherId: currentTeacher.id });
    if (result.success) {
        showToast('Exam deleted!');
        renderExams();
    } else {
        showToast(result.message || 'Failed to delete exam', 'error');
    }
}

// ===== SCHOOL REPORTS =====
let myReports = [];
let signatureReportId = null;

async function renderReports() {
    if (!currentTeacher) return;
    const tbody = document.getElementById('reportBody');
    if (!tbody) return;

    const result = await apiTeacher('my_reports', { teacher_id: currentTeacher.id });
    myReports = result.success ? (result.data?.items || []) : [];

    if (myReports.length === 0) {
        tbody.innerHTML = '<tr><td colspan="9" class="text-center text-muted">No reports created yet. Click "New Report" to get started.</td></tr>';
        return;
    }

    tbody.innerHTML = myReports.map(r => {
        const statusColors = { 'Draft': '#f39c12', 'Signed': '#085636', 'Pending': '#3498db', 'Approved': '#2ecc71', 'Rejected': '#e74c3c', 'Published': '#9b59b6' };
        const statusBg = { 'Draft': '#fef9e7', 'Signed': '#e8f8f5', 'Pending': '#ebf5fb', 'Approved': '#e8f8f5', 'Rejected': '#fdedec', 'Published': '#f4ecf7' };
        const workflowStatus = r.workflowStatus || r.status;
        const color = statusColors[workflowStatus] || '#95a5a6';
        const bg = statusBg[workflowStatus] || '#f8f9fa';
        const fmtDate = r.updatedAt ? new Date(r.updatedAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) : '-';
        const isDraft = r.status === 'Draft';
        // Allow sending from any status
        const canSend = true;
        return `<tr>
            <td><strong>${r.studentName}</strong></td>
            <td>${r.className || '-'}</td>
            <td>${r.term || '-'}</td>
            <td>${r.academicYear || '-'}</td>
            <td>${r.overallGrade || '-'}</td>
            <td><span style="background:${bg};color:${color};padding:3px 10px;border-radius:12px;font-size:11px;font-weight:600;">${workflowStatus}</span></td>
            <td>${r.currentLocation || 'Teacher'}</td>
            <td>${fmtDate}</td>
            <td>
                <button class="teacher-btn teacher-btn-sm teacher-btn-info" onclick="viewPrintReport(${r.id})" title="View/Print Report"><i class="fas fa-file-alt"></i></button>
                <button class="teacher-btn teacher-btn-sm teacher-btn-secondary" onclick="downloadReportPDF(${r.id})" title="Download PDF"><i class="fas fa-file-pdf"></i></button>
                ${isDraft ? `<button class="teacher-btn teacher-btn-sm teacher-btn-primary" onclick="editReport(${r.id})" title="Edit"><i class="fas fa-edit"></i></button>
                <button class="teacher-btn teacher-btn-sm teacher-btn-success" onclick="openSignatureModal(${r.id})" title="Sign"><i class="fas fa-signature"></i></button>` : ''}
                ${canSend ? `<button class="teacher-btn teacher-btn-sm teacher-btn-info" onclick="openSendReportModal(${r.id})" title="Send"><i class="fas fa-paper-plane"></i></button>` : ''}
                ${r.signatureImg ? `<button class="teacher-btn teacher-btn-sm teacher-btn-info" onclick="viewReportSignature(${r.id})" title="View Signature"><i class="fas fa-eye"></i></button>` : ''}
                <button class="teacher-btn teacher-btn-sm teacher-btn-danger" onclick="deleteReport(${r.id})" title="Delete"><i class="fas fa-trash"></i></button>
            </td>
        </tr>`;
    }).join('');
}

function openReportModal(reportData) {
    document.getElementById('reportForm').reset();
    document.getElementById('reportEditId').value = '';
    document.getElementById('reportModalTitle').innerHTML = '<i class="fas fa-file-alt"></i> New School Report';
    document.getElementById('reportSubjectsContainer').innerHTML = '';
    document.getElementById('reportYear').value = '2025-2026';

    // Reset total marks and signature
    document.getElementById('totalMarksObtained').value = '';
    document.getElementById('totalMarksPossible').value = '';
    document.getElementById('overallPercentage').value = '';
    document.getElementById('overallStatus').value = '-';
    document.getElementById('overallStatus').style.color = '#666';
    document.getElementById('overallStatus').style.background = '#e9ecef';
    document.getElementById('teacherComments').value = '';
    document.getElementById('signatureStatusText').textContent = 'No signature added';
    reportSignatureData = null;

    // Reset school contact information to defaults
    document.getElementById('reportSchoolAddress').value = 'P.O.BOX 30458, Area 24 PHA (Behind chilungamo investment), Lilongwe, Malawi';
    document.getElementById('reportSchoolEmail').value = 'noahchristianacademy2021@gmail.com';
    document.getElementById('reportPrincipalPhone').value = '+265 999 608 570';
    document.getElementById('reportAdminPhone').value = '+265 999 693 134';

    // Set default date to today
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('reportDate').value = today;

    // Set teacher name
    if (currentTeacher) {
        document.getElementById('teacherName').value = currentTeacher.firstName + ' ' + currentTeacher.lastName;
    }

    // Generate QR code for website
    generateQRCode();

    // Populate student dropdown
    const sel = document.getElementById('reportStudent');
    sel.innerHTML = '<option value="">Select Student</option>';
    if (myStudents && myStudents.length) {
        myStudents.forEach(s => {
            sel.innerHTML += `<option value="${s.id}" data-name="${s.firstName} ${s.lastName}" data-grade="${s.grade || ''}">${s.firstName} ${s.lastName} (${s.grade || 'N/A'})</option>`;
        });
    }

    // Auto-select class from teacher
    if (currentTeacher && currentTeacher.class) {
        document.getElementById('reportClass').value = currentTeacher.class;
    }

    // Add 3 default subject rows
    addReportSubjectRow();
    addReportSubjectRow();
    addReportSubjectRow();

    document.getElementById('reportModalOverlay').classList.add('show');
    document.getElementById('reportModal').classList.add('show');

    // Adjust grid based on screen size
    adjustSubjectGrid();
}

function generateQRCode() {
    // Get the current base URL (will work with localhost or any domain)
    const baseUrl = window.location.origin + '/noah';
    const qrCodeImg = document.getElementById('reportQRCode');

    // Use QR Server API to generate QR code
    const qrApiUrl = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(baseUrl)}&bgcolor=ffffff&color=000000`;

    if (qrCodeImg) {
        qrCodeImg.src = qrApiUrl;
        qrCodeImg.alt = 'Scan to visit ' + baseUrl;
    }
}

function adjustSubjectGrid() {
    const header = document.getElementById('subjectTableHeader');
    const rows = document.querySelectorAll('.report-subject-row');
    const screenWidth = window.innerWidth;

    let gridTemplate;
    if (screenWidth <= 480) {
        gridTemplate = '1fr';
    } else if (screenWidth <= 768) {
        gridTemplate = '1fr 1fr';
    } else if (screenWidth <= 1024) {
        gridTemplate = '1.5fr 0.8fr 0.8fr 0.8fr 0.8fr 1.5fr 50px';
    } else {
        gridTemplate = '2fr 1fr 1fr 1fr 1fr 2fr 50px';
    }

    if (header) {
        header.style.gridTemplateColumns = gridTemplate;
    }
    rows.forEach(row => {
        row.style.gridTemplateColumns = gridTemplate;
    });
}

// Add resize listener
window.addEventListener('resize', () => {
    if (document.getElementById('reportModal').classList.contains('show')) {
        adjustSubjectGrid();
    }
});

function closeReportModal() {
    document.getElementById('reportModalOverlay').classList.remove('show');
    document.getElementById('reportModal').classList.remove('show');
}

function addReportSubjectRow(data) {
    const container = document.getElementById('reportSubjectsContainer');
    const idx = container.children.length;
    const row = document.createElement('div');
    row.className = 'report-subject-row';
    row.style.cssText = 'display: grid; grid-template-columns: 2fr 1fr 1fr 1fr 1fr 2fr 50px; gap: 8px; padding: 12px 15px; background: ' + (idx % 2 === 0 ? '#fff' : '#f8f9fa') + '; border: 1px solid #e0e0e0; border-top: none; font-size: 12px; align-items: center;';
    row.innerHTML = `
        <input type="text" class="t-form-control report-subj-name" placeholder="Subject (e.g. Mathematics)" value="${data?.subject || ''}" style="padding: 8px 10px; border: 1px solid #ddd; border-radius: 4px; font-size: 12px;">
        <input type="number" class="t-form-control report-subj-outof" placeholder="0" min="0" value="${data?.outOf || ''}" style="padding: 8px 10px; border: 1px solid #ddd; border-radius: 4px; font-size: 12px;" oninput="calculateScore(this)">
        <input type="number" class="t-form-control report-subj-marks" placeholder="0" min="0" value="${data?.marks || ''}" style="padding: 8px 10px; border: 1px solid #ddd; border-radius: 4px; font-size: 12px;" oninput="calculateScore(this)">
        <select class="t-form-control report-subj-grade" style="padding: 8px 10px; border: 1px solid #ddd; border-radius: 4px; font-size: 12px;">
            <option value="">Grade</option>
            <option value="A" ${data?.grade === 'A' ? 'selected' : ''}>A</option>
            <option value="B" ${data?.grade === 'B' ? 'selected' : ''}>B</option>
            <option value="C" ${data?.grade === 'C' ? 'selected' : ''}>C</option>
            <option value="D" ${data?.grade === 'D' ? 'selected' : ''}>D</option>
            <option value="E" ${data?.grade === 'E' ? 'selected' : ''}>E</option>
            <option value="F" ${data?.grade === 'F' ? 'selected' : ''}>F</option>
        </select>
        <input type="number" class="t-form-control report-subj-score" placeholder="0-100" min="0" max="100" value="${data?.score || ''}" style="padding: 8px 10px; border: 1px solid #ddd; border-radius: 4px; font-size: 12px;" readonly>
        <input type="text" class="t-form-control report-subj-comment" placeholder="Enter remarks" value="${data?.comment || ''}" style="padding: 8px 10px; border: 1px solid #ddd; border-radius: 4px; font-size: 12px;">
        <button type="button" class="teacher-btn teacher-btn-sm teacher-btn-danger" onclick="this.parentElement.remove()" title="Remove" style="padding: 6px 10px; border-radius: 4px; border: none; background: #dc3545; color: white;"><i class="fas fa-times"></i></button>
    `;
    container.appendChild(row);
}

function calculateScore(input) {
    const row = input.closest('.report-subject-row');
    const outOf = row.querySelector('.report-subj-outof');
    const marks = row.querySelector('.report-subj-marks');
    const score = row.querySelector('.report-subj-score');

    const outOfValue = parseFloat(outOf.value) || 0;
    const marksValue = parseFloat(marks.value) || 0;

    if (outOfValue > 0) {
        const percentage = (marksValue / outOfValue) * 100;
        score.value = Math.round(percentage * 100) / 100; // Round to 2 decimal places
    } else {
        score.value = '';
    }

    // Calculate total marks and pass/fail status
    calculateTotalMarks();
}

function calculateTotalMarks() {
    const outOfs = document.querySelectorAll('.report-subj-outof');
    const marks = document.querySelectorAll('.report-subj-marks');

    let totalObtained = 0;
    let totalPossible = 0;

    outOfs.forEach((outOf, i) => {
        const outOfValue = parseFloat(outOf.value) || 0;
        const marksValue = parseFloat(marks[i]?.value) || 0;
        totalObtained += marksValue;
        totalPossible += outOfValue;
    });

    // Update total marks fields
    document.getElementById('totalMarksObtained').value = totalObtained.toFixed(2);
    document.getElementById('totalMarksPossible').value = totalPossible.toFixed(2);

    // Calculate overall percentage
    let overallPercentage = 0;
    if (totalPossible > 0) {
        overallPercentage = (totalObtained / totalPossible) * 100;
    }
    document.getElementById('overallPercentage').value = overallPercentage.toFixed(2) + '%';

    // Determine pass/fail status (50% is passing)
    const statusEl = document.getElementById('overallStatus');
    if (totalPossible > 0) {
        if (overallPercentage >= 50) {
            statusEl.value = 'PASSED';
            statusEl.style.color = '#28a745';
            statusEl.style.background = '#d4edda';
        } else {
            statusEl.value = 'FAILED';
            statusEl.style.color = '#dc3545';
            statusEl.style.background = '#f8d7da';
        }
    } else {
        statusEl.value = '-';
        statusEl.style.color = '#666';
        statusEl.style.background = '#e9ecef';
    }
}

async function saveReport(event) {
    event.preventDefault();
    if (!currentTeacher) { showToast('Please login first!', 'error'); return false; }

    const sel = document.getElementById('reportStudent');
    const opt = sel.options[sel.selectedIndex];
    const studentId = sel.value;
    const studentName = opt.getAttribute('data-name') || opt.textContent.trim();
    const editId = document.getElementById('reportEditId').value;

    // Gather subject data
    const names = document.querySelectorAll('.report-subj-name');
    const outOfs = document.querySelectorAll('.report-subj-outof');
    const marks = document.querySelectorAll('.report-subj-marks');
    const grades = document.querySelectorAll('.report-subj-grade');
    const scores = document.querySelectorAll('.report-subj-score');
    const comments = document.querySelectorAll('.report-subj-comment');
    const reportData = [];
    names.forEach((n, i) => {
        if (n.value.trim()) {
            reportData.push({
                subject: n.value.trim(),
                outOf: outOfs[i]?.value || '',
                marks: marks[i]?.value || '',
                grade: grades[i]?.value || '',
                score: scores[i]?.value || '',
                comment: comments[i]?.value || ''
            });
        }
    });

    const payload = {
        teacherId: currentTeacher.id,
        teacherName: currentTeacher.firstName + ' ' + currentTeacher.lastName,
        studentId: studentId || null,
        studentName: studentName,
        className: document.getElementById('reportClass').value,
        term: document.getElementById('reportTerm').value,
        academicYear: document.getElementById('reportYear').value.trim(),
        reportData: reportData,
        teacherComments: document.getElementById('teacherComments').value.trim(),
        reportDate: document.getElementById('reportDate').value,
        totalMarksObtained: document.getElementById('totalMarksObtained').value,
        totalMarksPossible: document.getElementById('totalMarksPossible').value,
        overallPercentage: document.getElementById('overallPercentage').value,
        overallStatus: document.getElementById('overallStatus').value,
        signatureImg: reportSignatureData || null,
        schoolAddress: document.getElementById('reportSchoolAddress').value.trim(),
        schoolEmail: document.getElementById('reportSchoolEmail').value.trim(),
        principalPhone: document.getElementById('reportPrincipalPhone').value.trim(),
        adminPhone: document.getElementById('reportAdminPhone').value.trim()
    };

    if (editId) payload.id = parseInt(editId);

    const btn = document.getElementById('reportSaveBtn');
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';

    try {
        const result = await apiTeacher('save_report', {}, payload);
        if (result.success) {
            showToast(result.message || 'Report saved!', 'success');
            closeReportModal();
            renderReports();
        } else {
            showToast(result.message || 'Failed to save report', 'error');
        }
    } catch(e) {
        showToast('Error saving report', 'error');
    }
    btn.disabled = false;
    btn.innerHTML = '<i class="fas fa-save"></i> Save Report';
    return false;
}

function editReport(id) {
    const report = myReports.find(r => r.id === id);
    if (!report) return;
    if (report.status !== 'Draft') { showToast('Only draft reports can be edited', 'warning'); return; }

    openReportModal();
    document.getElementById('reportEditId').value = report.id;
    document.getElementById('reportModalTitle').innerHTML = '<i class="fas fa-edit"></i> Edit Report - ' + report.studentName;
    adjustSubjectGrid();

    // Set fields
    if (report.studentId) document.getElementById('reportStudent').value = report.studentId;
    if (report.className) document.getElementById('reportClass').value = report.className;
    if (report.term) document.getElementById('reportTerm').value = report.term;
    if (report.academicYear) document.getElementById('reportYear').value = report.academicYear;

    // Load new fields
    if (report.teacherComments) document.getElementById('teacherComments').value = report.teacherComments;
    if (report.reportDate) document.getElementById('reportDate').value = report.reportDate;
    if (report.totalMarksObtained) document.getElementById('totalMarksObtained').value = report.totalMarksObtained;
    if (report.totalMarksPossible) document.getElementById('totalMarksPossible').value = report.totalMarksPossible;
    if (report.overallPercentage) document.getElementById('overallPercentage').value = report.overallPercentage;
    if (report.overallStatus) {
        document.getElementById('overallStatus').value = report.overallStatus;
        if (report.overallStatus === 'PASSED') {
            document.getElementById('overallStatus').style.color = '#28a745';
            document.getElementById('overallStatus').style.background = '#d4edda';
        } else if (report.overallStatus === 'FAILED') {
            document.getElementById('overallStatus').style.color = '#dc3545';
            document.getElementById('overallStatus').style.background = '#f8d7da';
        }
    }
    if (report.signatureImg) {
        reportSignatureData = report.signatureImg;
        document.getElementById('signatureStatusText').textContent = 'Signature loaded';
        document.getElementById('signatureStatusText').style.color = '#28a745';
    }

    // Load school contact information
    if (report.schoolAddress) document.getElementById('reportSchoolAddress').value = report.schoolAddress;
    if (report.schoolEmail) document.getElementById('reportSchoolEmail').value = report.schoolEmail;
    if (report.principalPhone) document.getElementById('reportPrincipalPhone').value = report.principalPhone;
    if (report.adminPhone) document.getElementById('reportAdminPhone').value = report.adminPhone;

    // Regenerate QR code
    generateQRCode();

    // Load subject rows
    document.getElementById('reportSubjectsContainer').innerHTML = '';
    if (report.reportData && report.reportData.length) {
        report.reportData.forEach(d => addReportSubjectRow(d));
    } else {
        addReportSubjectRow();
    }
}

async function deleteReport(id) {
    if (!confirm('Delete this report permanently?')) return;
    const result = await apiTeacher('delete_report', {}, { id, teacherId: currentTeacher.id });
    if (result.success) {
        showToast('Report deleted!', 'success');
        renderReports();
    } else {
        showToast(result.message || 'Failed to delete report', 'error');
    }
}

// ===== SIGNATURE PAD =====
let sigDrawing = false;
let sigCtx = null;
let sigHasContent = false;

function openSignatureModal(reportId) {
    signatureReportId = reportId;
    document.getElementById('signatureStatus').textContent = '';
    document.getElementById('signatureSubmitBtn').disabled = false;

    const canvas = document.getElementById('signatureCanvas');
    sigCtx = canvas.getContext('2d');
    sigCtx.clearRect(0, 0, canvas.width, canvas.height);
    sigCtx.strokeStyle = '#1a237e';
    sigCtx.lineWidth = 2;
    sigCtx.lineCap = 'round';
    sigCtx.lineJoin = 'round';
    sigHasContent = false;

    // Mouse events
    canvas.onmousedown = (e) => { sigDrawing = true; sigCtx.beginPath(); sigCtx.moveTo(e.offsetX, e.offsetY); };
    canvas.onmousemove = (e) => { if (sigDrawing) { sigCtx.lineTo(e.offsetX, e.offsetY); sigCtx.stroke(); sigHasContent = true; } };
    canvas.onmouseup = () => { sigDrawing = false; };
    canvas.onmouseleave = () => { sigDrawing = false; };

    // Touch events
    canvas.ontouchstart = (e) => {
        e.preventDefault();
        const t = e.touches[0];
        const rect = canvas.getBoundingClientRect();
        sigDrawing = true;
        sigCtx.beginPath();
        sigCtx.moveTo(t.clientX - rect.left, t.clientY - rect.top);
    };
    canvas.ontouchmove = (e) => {
        e.preventDefault();
        if (sigDrawing) {
            const t = e.touches[0];
            const rect = canvas.getBoundingClientRect();
            sigCtx.lineTo(t.clientX - rect.left, t.clientY - rect.top);
            sigCtx.stroke();
            sigHasContent = true;
        }
    };
    canvas.ontouchend = () => { sigDrawing = false; };

    document.getElementById('signatureModalOverlay').classList.add('show');
    document.getElementById('signatureModal').classList.add('show');
}

function closeSignatureModal() {
    document.getElementById('signatureModalOverlay').classList.remove('show');
    document.getElementById('signatureModal').classList.remove('show');
    sigDrawing = false;
}

function openSignatureModalForReport() {
    // Reset signatureReportId to indicate we're adding signature to new report
    signatureReportId = null;
    document.getElementById('signatureStatus').textContent = '';
    document.getElementById('signatureSubmitBtn').disabled = false;

    const canvas = document.getElementById('signatureCanvas');
    sigCtx = canvas.getContext('2d');
    sigCtx.clearRect(0, 0, canvas.width, canvas.height);
    sigCtx.strokeStyle = '#1a237e';
    sigCtx.lineWidth = 2;
    sigCtx.lineCap = 'round';
    sigCtx.lineJoin = 'round';
    sigHasContent = false;

    // Mouse events
    canvas.onmousedown = (e) => { sigDrawing = true; sigCtx.beginPath(); sigCtx.moveTo(e.offsetX, e.offsetY); };
    canvas.onmousemove = (e) => { if (sigDrawing) { sigCtx.lineTo(e.offsetX, e.offsetY); sigCtx.stroke(); sigHasContent = true; } };
    canvas.onmouseup = () => { sigDrawing = false; };
    canvas.onmouseleave = () => { sigDrawing = false; };

    // Touch events
    canvas.ontouchstart = (e) => {
        e.preventDefault();
        sigDrawing = true;
        const t = e.touches[0];
        const rect = canvas.getBoundingClientRect();
        sigCtx.beginPath();
        sigCtx.moveTo(t.clientX - rect.left, t.clientY - rect.top);
    };
    canvas.ontouchmove = (e) => {
        e.preventDefault();
        if (sigDrawing) {
            const t = e.touches[0];
            const rect = canvas.getBoundingClientRect();
            sigCtx.lineTo(t.clientX - rect.left, t.clientY - rect.top);
            sigCtx.stroke();
            sigHasContent = true;
        }
    };
    canvas.ontouchend = () => { sigDrawing = false; };

    document.getElementById('signatureModalOverlay').classList.add('show');
    document.getElementById('signatureModal').classList.add('show');
}

function clearSignature() {
    const canvas = document.getElementById('signatureCanvas');
    sigCtx.clearRect(0, 0, canvas.width, canvas.height);
    sigHasContent = false;
    document.getElementById('signatureStatus').textContent = 'Cleared';
}

async function submitSignature() {
    if (!sigHasContent) { showToast('Please draw your signature first!', 'warning'); return; }

    const canvas = document.getElementById('signatureCanvas');
    const signatureImg = canvas.toDataURL('image/png');

    // Check if we're signing an existing report or adding signature to new report
    if (signatureReportId) {
        // Sign existing report
        const btn = document.getElementById('signatureSubmitBtn');
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Signing...';

        try {
            const result = await apiTeacher('sign_report', {}, {
                id: signatureReportId,
                teacherId: currentTeacher.id,
                signatureImg: signatureImg
            });
            if (result.success) {
                showToast('Report signed successfully!', 'success');
                closeSignatureModal();
                renderReports();
            } else {
                showToast(result.message || 'Failed to sign report', 'error');
            }
        } catch(e) {
            showToast('Error signing report', 'error');
        }
        btn.disabled = false;
        btn.innerHTML = '<i class="fas fa-check"></i> Sign & Submit';
    } else {
        // Add signature to new report being created
        reportSignatureData = signatureImg;
        document.getElementById('signatureStatusText').textContent = 'Signature added';
        document.getElementById('signatureStatusText').style.color = '#28a745';
        showToast('Signature added to report!', 'success');
        closeSignatureModal();
    }
}

function viewReportSignature(id) {
    const report = myReports.find(r => r.id === id);
    if (!report || !report.signatureImg) return;
    const w = window.open('', '_blank');
    w.document.write(`<img src="${report.signatureImg}" style="max-width:100%;border:1px solid #ddd;padding:10px;">`);
    w.document.close();
}

// ===== COLLABORATION API =====
async function apiCollaboration(action, params = {}, body = null) {
    let url = `${API_BASE}?type=collaboration&action=${action}`;
    for (const [k, v] of Object.entries(params)) url += `&${k}=${encodeURIComponent(v)}`;
    const opts = {
        method: body ? 'POST' : 'GET',
        headers: { 'Content-Type': 'application/json' }
    };
    if (body) opts.body = JSON.stringify(body);
    try {
        const res = await fetch(url, opts);
        const text = await res.text();
        if (!text || text.trim() === '') {
            return { success: false, message: 'Server returned empty response' };
        }
        try {
            return JSON.parse(text);
        } catch (parseErr) {
            return { success: false, message: 'Invalid server response' };
        }
    } catch (e) {
        return { success: false, message: e.message };
    }
}

// ===== REPORT WORKFLOW API =====
async function apiReportWorkflow(action, params = {}, body = null) {
    let url = `${API_BASE}?type=report_workflow&action=${action}`;
    for (const [k, v] of Object.entries(params)) url += `&${k}=${encodeURIComponent(v)}`;
    const opts = {
        method: body ? 'POST' : 'GET',
        headers: { 'Content-Type': 'application/json' }
    };
    if (body) opts.body = JSON.stringify(body);
    try {
        const res = await fetch(url, opts);
        const text = await res.text();
        if (!text || text.trim() === '') {
            return { success: false, message: 'Server returned empty response' };
        }
        try {
            return JSON.parse(text);
        } catch (parseErr) {
            return { success: false, message: 'Invalid server response' };
        }
    } catch (e) {
        return { success: false, message: e.message };
    }
}

// ===== REPORT WORKFLOW FUNCTIONS =====
let currentReportId = null;

function openSendReportModal(reportId) {
    currentReportId = reportId;
    const report = myReports.find(r => r.id === reportId);
    if (!report) return;

    document.getElementById('sendReportModalTitle').innerHTML = `<i class="fas fa-paper-plane"></i> Send Report: ${report.studentName}`;
    document.getElementById('sendReportStudentName').textContent = report.studentName;
    document.getElementById('sendReportClass').textContent = report.className || 'N/A';
    document.getElementById('sendReportTerm').textContent = report.term || 'N/A';
    document.getElementById('sendReportMessage').value = '';

    // Load available parents for this student
    loadParentsForStudent(report.studentId);

    // Load class colleagues for teacher sharing
    loadClassColleaguesForSharing();

    // Reset to admin by default
    const sendToAdminBtn = document.getElementById('sendToAdminBtn');
    const sendToTeacherBtn = document.getElementById('sendToTeacherBtn');
    const sendToParentBtn = document.getElementById('sendToParentBtn');
    const teacherSelectGroup = document.getElementById('teacherSelectGroup');
    const parentSelectGroup = document.getElementById('parentSelectGroup');
    const priorityGroup = document.getElementById('priorityGroup');

    if (sendToAdminBtn) sendToAdminBtn.checked = true;
    if (teacherSelectGroup) teacherSelectGroup.style.display = 'none';
    if (parentSelectGroup) parentSelectGroup.style.display = 'none';
    if (priorityGroup) priorityGroup.style.display = 'block';

    document.getElementById('sendReportModalOverlay').classList.add('show');
    document.getElementById('sendReportModal').classList.add('show');
}

function handleSendReportSubmit() {
    const sendTo = document.querySelector('input[name="sendTo"]:checked').value;
    if (sendTo === 'admin') {
        sendReportToAdmin();
    } else if (sendTo === 'teacher') {
        sendReportToTeacher();
    } else {
        sendReportToParent();
    }
}

function closeSendReportModal() {
    document.getElementById('sendReportModalOverlay').classList.remove('show');
    document.getElementById('sendReportModal').classList.remove('show');
    currentReportId = null;
}

async function loadParentsForStudent(studentId) {
    if (!studentId) return;

    // Get student from teacher's assigned class only
    const student = myStudents.find(s => s.id === studentId);
    if (student && student.parent) {
        // Parse parent name and try to find parent record
        const parentResult = await apiAdmin('parents', 'GET');
        if (parentResult.success) {
            const parent = parentResult.data.items.find(p =>
                p.firstName + ' ' + p.lastName === student.parent ||
                p.firstName === student.parent
            );
            const select = document.getElementById('sendReportParent');
            select.innerHTML = '<option value="">Select Parent</option>';
            if (parent) {
                select.innerHTML += `<option value="${parent.id}">${parent.firstName} ${parent.lastName}</option>`;
            }
        }
    }
}

async function loadClassColleaguesForSharing() {
    if (!currentTeacher) return;

    const result = await apiCollaboration('my_class_colleagues', { teacher_id: currentTeacher.id });
    if (result.success) {
        const select = document.getElementById('sendReportTeacher');
        select.innerHTML = '<option value="">Select Teacher</option>';
        if (result.data.items && result.data.items.length > 0) {
            result.data.items.forEach(teacher => {
                select.innerHTML += `<option value="${teacher.id}">${teacher.firstName} ${teacher.lastName} (${teacher.subject || 'Teacher'})</option>`;
            });
        }
    }
}

async function sendReportToAdmin() {
    if (!currentReportId || !currentTeacher) return;

    const message = document.getElementById('sendReportMessage').value.trim();
    const priority = document.getElementById('sendReportPriority').value;

    const result = await apiReportWorkflow('send_to_admin', {}, {
        reportId: currentReportId,
        teacherId: currentTeacher.id,
        message: message,
        priority: priority
    });

    if (result.success) {
        showToast('Report sent to admin successfully!', 'success');
        closeSendReportModal();
        renderReports();
    } else {
        showToast(result.message || 'Failed to send report to admin', 'error');
    }
}

async function sendReportToTeacher() {
    if (!currentReportId || !currentTeacher) return;

    const teacherId = parseInt(document.getElementById('sendReportTeacher').value);
    const message = document.getElementById('sendReportMessage').value.trim();

    if (!teacherId) {
        showToast('Please select a teacher', 'error');
        return;
    }

    const report = myReports.find(r => r.id === currentReportId);
    if (!report) return;

    const result = await apiCollaboration('share_report', {}, {
        reportId: currentReportId,
        ownerTeacherId: currentTeacher.id,
        sharedWithTeacherId: teacherId,
        accessLevel: 'view',
        comments: message
    });

    if (result.success) {
        showToast('Report shared with teacher successfully!', 'success');
        closeSendReportModal();
        renderReports();
    } else {
        showToast(result.message || 'Failed to share report with teacher', 'error');
    }
}

async function sendReportToParent() {
    if (!currentReportId || !currentTeacher) return;

    const parentId = parseInt(document.getElementById('sendReportParent').value);
    const message = document.getElementById('sendReportMessage').value.trim();

    if (!parentId) {
        showToast('Please select a parent', 'error');
        return;
    }

    const report = myReports.find(r => r.id === currentReportId);
    if (!report) return;

    // Generate PDF before sending
    showToast('Generating PDF for parent...', 'info');

    try {
        // Generate PDF and convert to base64
        const pdfBase64 = await generateReportPDFBase64(report);

        const result = await apiReportWorkflow('send_to_parent', {}, {
            reportId: currentReportId,
            teacherId: currentTeacher.id,
            parentId: parentId,
            studentId: report.studentId,
            message: message,
            pdfData: pdfBase64
        });

        if (result.success) {
            showToast('Report PDF sent to parent successfully!', 'success');
            closeSendReportModal();
            renderReports();
        } else {
            showToast(result.message || 'Failed to send report to parent', 'error');
        }
    } catch (error) {
        console.error('Error generating PDF:', error);
        showToast('Failed to generate PDF. Report sent without PDF.', 'warning');
        
        // Fallback: send without PDF
        const result = await apiReportWorkflow('send_to_parent', {}, {
            reportId: currentReportId,
            teacherId: currentTeacher.id,
            parentId: parentId,
            studentId: report.studentId,
            message: message
        });

        if (result.success) {
            showToast('Report sent to parent successfully (without PDF)', 'success');
            closeSendReportModal();
            renderReports();
        } else {
            showToast(result.message || 'Failed to send report to parent', 'error');
        }
    }
}

// Helper function to generate PDF as base64
async function generateReportPDFBase64(report) {
    const schoolName = 'Noah Christian Academy';
    const schoolAddress = report.schoolAddress || 'P.O.BOX 30458, Area 24 PHA (Behind chilungamo investment), Lilongwe, Malawi';
    const schoolEmail = report.schoolEmail || 'noahchristianacademy2021@gmail.com';
    const principalPhone = report.principalPhone || '+265 999 608 570';
    const adminPhone = report.adminPhone || '+265 999 693 134';
    const logoUrl = '../images/logo.jpg';

    const barcodeValue = `NCA-${report.id}-${report.studentId}`;
    const barcodePattern = generateSimpleBarcode(barcodeValue);

    const subjectsHtml = report.reportData && report.reportData.length > 0
        ? report.reportData.map(sub => `
            <tr>
                <td style="padding: 8px; border: 1px solid #ddd;">${sub.subject || '-'}</td>
                <td style="padding: 8px; border: 1px solid #ddd; text-align: center;">${sub.grade || '-'}</td>
                <td style="padding: 8px; border: 1px solid #ddd;">${sub.comment || '-'}</td>
            </tr>
        `).join('')
        : '<tr><td colspan="3" style="padding: 8px; border: 1px solid #ddd; text-align: center;">No subjects recorded</td></tr>';

    const reportHtml = `
<!DOCTYPE html>
<html>
<head>
    <title>School Report - ${report.studentName}</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 20px;
            background: #f5f5f5;
        }
        .report-container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            padding: 40px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .report-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 30px;
            border-bottom: 3px solid #085636;
            padding-bottom: 20px;
        }
        .school-logo {
            width: 100px;
            height: 100px;
            object-fit: contain;
        }
        .school-info {
            text-align: center;
            flex: 1;
        }
        .school-info h1 {
            color: #085636;
            margin: 0 0 10px 0;
            font-size: 24px;
        }
        .school-info h2 {
            color: #333;
            margin: 0;
            font-size: 18px;
            font-weight: normal;
        }
        .contact-info {
            text-align: right;
            font-size: 12px;
            color: #666;
        }
        .contact-info div {
            margin: 5px 0;
        }
        .student-info {
            background: #f8f9fa;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 8px;
        }
        .student-info h3 {
            color: #085636;
            margin-top: 0;
            margin-bottom: 15px;
            border-bottom: 2px solid #085636;
            padding-bottom: 10px;
        }
        .info-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
        }
        .info-item {
            display: flex;
            flex-direction: column;
        }
        .info-item label {
            font-weight: bold;
            color: #333;
            font-size: 12px;
            margin-bottom: 5px;
        }
        .info-item span {
            color: #555;
            font-size: 14px;
        }
        .section-title {
            color: #085636;
            font-size: 18px;
            margin: 25px 0 15px 0;
            padding-bottom: 8px;
            border-bottom: 2px solid #085636;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th {
            background: #085636;
            color: white;
            padding: 10px;
            text-align: left;
            font-weight: bold;
        }
        td {
            padding: 8px;
            border: 1px solid #ddd;
        }
        .grade-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 12px;
            font-weight: bold;
            font-size: 12px;
        }
        .grade-A { background: #d4edda; color: #155724; }
        .grade-B { background: #cce5ff; color: #004085; }
        .grade-C { background: #fff3cd; color: #856404; }
        .grade-D { background: #f8d7da; color: #721c24; }
        .grade-E { background: #f5c6cb; color: #721c24; }
        .grade-F { background: #dc3545; color: white; }
        .overall-grade {
            text-align: center;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 8px;
            margin: 20px 0;
        }
        .overall-grade .grade {
            font-size: 48px;
            font-weight: bold;
            color: #085636;
        }
        .comment-section {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin: 20px 0;
        }
        .comment-section h4 {
            color: #085636;
            margin-top: 0;
            margin-bottom: 10px;
        }
        .comment-section p {
            color: #333;
            line-height: 1.6;
            margin: 0;
        }
        .signature-section {
            display: flex;
            justify-content: space-between;
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
        }
        .signature-box {
            text-align: center;
            width: 45%;
        }
        .signature-box img {
            max-width: 150px;
            max-height: 60px;
            margin-bottom: 10px;
        }
        .signature-box .label {
            font-size: 12px;
            color: #666;
            margin-top: 5px;
        }
        .barcode-section {
            text-align: center;
            margin-top: 30px;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 8px;
        }
        .barcode {
            font-family: 'Courier New', monospace;
            font-size: 12px;
            letter-spacing: 2px;
            white-space: pre;
            line-height: 1.2;
            margin: 10px 0;
        }
        .barcode-text {
            font-size: 11px;
            color: #666;
            margin-top: 5px;
        }
        .footer {
            text-align: center;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            font-size: 11px;
            color: #888;
        }
    </style>
</head>
<body>
    <div class="report-container" id="reportContent">
        <div class="report-header">
            <img src="${logoUrl}" alt="School Logo" class="school-logo" onerror="this.style.display='none'">
            <div class="school-info">
                <h1>${schoolName}</h1>
                <h2>Student Progress Report</h2>
            </div>
            <div class="contact-info">
                <div><i class="fas fa-envelope"></i> ${schoolEmail}</div>
                <div><i class="fas fa-map-marker-alt"></i> ${schoolAddress}</div>
                <div><i class="fas fa-user-tie"></i> Principal: ${principalPhone}</div>
                <div><i class="fas fa-user-shield"></i> Administrator: ${adminPhone}</div>
            </div>
        </div>
        <div class="student-info">
            <h3>Student Information</h3>
            <div class="info-grid">
                <div class="info-item">
                    <label>Student Name</label>
                    <span>${report.studentName}</span>
                </div>
                <div class="info-item">
                    <label>Class</label>
                    <span>${report.className}</span>
                </div>
                <div class="info-item">
                    <label>Term</label>
                    <span>${report.term}</span>
                </div>
                <div class="info-item">
                    <label>Academic Year</label>
                    <span>${report.academicYear}</span>
                </div>
            </div>
        </div>
        <div class="section-title">Subject Performance</div>
        <table>
            <thead>
                <tr>
                    <th>Subject</th>
                    <th>Grade</th>
                    <th>Remarks</th>
                </tr>
            </thead>
            <tbody>
                ${subjectsHtml}
            </tbody>
        </table>
        <div class="overall-grade">
            <div style="font-size: 14px; color: #666; margin-bottom: 5px;">Overall Performance Grade</div>
            <div class="grade-badge grade-${report.overallGrade || 'F'} grade">${report.overallGrade || '-'}</div>
        </div>
        <div class="comment-section">
            <h4>Teacher's Comments</h4>
            <p>${report.teacherComments || 'No comments provided.'}</p>
        </div>
        <div class="signature-section">
            <div class="signature-box">
                ${report.signatureImg ? `<img src="${report.signatureImg}" alt="Teacher Signature">` : '<div style="height: 60px; display: flex; align-items: center; justify-content: center; color: #999; font-style: italic;">No signature</div>'}
                <div class="label">Teacher's Signature</div>
                <div class="label">${currentTeacher ? currentTeacher.firstName + ' ' + currentTeacher.lastName : ''}</div>
            </div>
            <div class="signature-box">
                <div style="height: 60px; display: flex; align-items: center; justify-content: center; color: #999; font-style: italic;">Principal's Signature</div>
                <div class="label">Principal's Signature</div>
                <div class="label">Noah Christian Academy</div>
            </div>
        </div>
        <div class="barcode-section">
            <div class="barcode">${barcodePattern}</div>
            <div class="barcode-text">${barcodeValue}</div>
        </div>
        <div class="footer">
            <p>This report is officially generated by Noah Christian Academy Management System</p>
            <p>Generated on: ${new Date().toLocaleString()}</p>
        </div>
    </div>
</body>
</html>`;

    const container = document.createElement('div');
    container.style.position = 'absolute';
    container.style.left = '-9999px';
    container.style.top = '0';
    container.style.width = '800px';
    document.body.appendChild(container);
    container.innerHTML = reportHtml;

    await new Promise(resolve => setTimeout(resolve, 1000));

    const canvas = await html2canvas(container, {
        scale: 2,
        useCORS: true,
        logging: false
    });

    const { jsPDF } = window.jspdf;
    const pdf = new jsPDF('p', 'mm', 'a4');
    
    const imgData = canvas.toDataURL('image/png');
    const imgWidth = 210;
    const pageHeight = 297;
    const imgHeight = (canvas.height * imgWidth) / canvas.width;
    
    pdf.addImage(imgData, 'PNG', 0, 0, imgWidth, imgHeight);
    
    const pdfBase64 = pdf.output('datauristring').split(',')[1];
    
    document.body.removeChild(container);
    
    return pdfBase64;
}

// Make functions globally accessible
window.loadTeacherInbox = async function() {
    if (!currentTeacher) return;
    
    document.getElementById('teacherInboxList').style.display = 'block';
    document.getElementById('teacherOutboxList').style.display = 'none';
    
    const result = await apiReportWorkflow('teacher_get_inbox', { teacher_id: currentTeacher.id });
    if (result.success) {
        renderTeacherInbox(result.data.items);
    } else {
        document.getElementById('teacherInboxList').innerHTML = '<p class="text-muted">Failed to load inbox.</p>';
    }
};

function renderTeacherInbox(items) {
    const container = document.getElementById('teacherInboxList');
    if (!container) return;
    
    if (!items || items.length === 0) {
        container.innerHTML = '<p class="text-muted">No returned reports in inbox.</p>';
        return;
    }
    
    container.innerHTML = items.map(item => `
        <div style="padding:12px;border:1px solid #e0e0e0;border-radius:8px;margin-bottom:10px;background:#f9f9f9;">
            <div style="font-weight:600;color:#085636;">${item.studentName}</div>
            <div style="font-size:13px;color:#666;">${item.className} - ${item.term}</div>
            <div style="font-size:12px;color:#888;margin-top:4px;">Status: ${item.workflowStatus}</div>
            ${item.returnMessage ? `<div style="font-size:12px;color:#e74c3c;margin-top:4px;"><strong>Feedback:</strong> ${item.returnMessage}</div>` : ''}
            <div style="margin-top:8px;">
                <button class="teacher-btn teacher-btn-sm teacher-btn-primary" onclick="editReport(${item.id})">
                    <i class="fas fa-edit"></i> Edit & Resubmit
                </button>
            </div>
        </div>
    `).join('');
}

// Make functions globally accessible
window.loadTeacherOutbox = async function() {
    if (!currentTeacher) return;
    
    document.getElementById('teacherInboxList').style.display = 'none';
    document.getElementById('teacherOutboxList').style.display = 'block';
    
    const result = await apiReportWorkflow('teacher_get_outbox', { teacher_id: currentTeacher.id });
    if (result.success) {
        renderTeacherOutbox(result.data.items);
    } else {
        document.getElementById('teacherOutboxList').innerHTML = '<p class="text-muted">Failed to load outbox.</p>';
    }
};

function renderTeacherOutbox(items) {
    const container = document.getElementById('teacherOutboxList');
    if (!container) return;
    
    if (!items || items.length === 0) {
        container.innerHTML = '<p class="text-muted">No sent reports in outbox.</p>';
        return;
    }
    
    container.innerHTML = items.map(item => `
        <div style="padding:12px;border:1px solid #e0e0e0;border-radius:8px;margin-bottom:10px;background:#f9f9f9;">
            <div style="font-weight:600;color:#085636;">${item.studentName}</div>
            <div style="font-size:13px;color:#666;">${item.className} - ${item.term}</div>
            <div style="font-size:12px;color:#888;margin-top:4px;">
                Sent to: ${item.recipientName} (${item.sentToType})
            </div>
            <div style="font-size:12px;color:#888;">Action: ${item.action} - Status: ${item.sharingStatus}</div>
            <div style="font-size:11px;color:#aaa;margin-top:4px;">Sent: ${new Date(item.sentAt).toLocaleDateString()}</div>
        </div>
    `).join('');
}

// ===== CLASS COLLEAGUES (renderClassColleagues & loadColleagueMessages) =====
function renderClassColleagues(colleagues, className) {
    const container = document.getElementById('classColleaguesList');
    if (!container) return;
    if (!colleagues || colleagues.length === 0) {
        container.innerHTML = `<p class="text-muted">No colleagues found for class: ${className || 'Not assigned'}</p>`;
        return;
    }
    let html = `<div style="margin-bottom:10px;"><strong>Class:</strong> ${className}</div>`;
    html += '<div style="display:flex;flex-wrap:wrap;gap:10px;margin-bottom:16px;">';
    colleagues.forEach(c => {
        html += `
            <div style="flex:1;min-width:200px;padding:12px;border:1px solid #e0e0e0;border-radius:8px;background:#f9f9f9;">
                <div style="font-weight:600;color:#085636;">${c.firstName} ${c.lastName}</div>
                <div style="font-size:13px;color:#666;margin-top:4px;">${c.subject || 'N/A'}</div>
                <div style="font-size:12px;color:#888;margin-top:2px;">${c.role || 'Teacher'}</div>
                <div style="margin-top:8px;display:flex;gap:6px;">
                    <button class="teacher-btn teacher-btn-sm teacher-btn-info" onclick="openColleagueMessage(${c.id}, '${c.firstName} ${c.lastName}')">
                        <i class="fas fa-envelope"></i> Message
                    </button>
                    ${c.email ? `<a href="mailto:${c.email}" class="teacher-btn teacher-btn-sm teacher-btn-secondary" title="Email"><i class="fas fa-at"></i></a>` : ''}
                </div>
            </div>
        `;
    });
    html += '</div>';
    // Interaction table header
    html += `
        <div style="margin-top:10px;">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
                <strong><i class="fas fa-comments"></i> Message History</strong>
                <button class="teacher-btn teacher-btn-sm teacher-btn-info" onclick="loadColleagueMessages()"><i class="fas fa-sync"></i> Refresh</button>
            </div>
            <div id="colleagueMessagesTable"><p class="text-muted">Loading message history...</p></div>
        </div>
    `;
    container.innerHTML = html;
    loadColleagueMessages();
}

async function loadColleagueMessages() {
    if (!currentTeacher) return;
    const container = document.getElementById('colleagueMessagesTable');
    if (!container) return;
    container.innerHTML = '<p class="text-muted">Loading...</p>';
    const result = await apiCollaboration('teacher_messages', { teacher_id: currentTeacher.id, limit: 50 });
    if (result.success && result.data) {
        renderColleagueMessages(result.data.items || []);
    } else {
        container.innerHTML = '<p class="text-muted">No messages yet.</p>';
    }
}

function renderColleagueMessages(messages) {
    const container = document.getElementById('colleagueMessagesTable');
    if (!container) return;
    if (!messages || messages.length === 0) {
        container.innerHTML = '<p class="text-muted">No messages exchanged yet.</p>';
        return;
    }
    let html = '<div style="overflow-x:auto;"><table style="width:100%;border-collapse:collapse;font-size:13px;">';
    html += '<thead><tr style="background:#085636;color:#fff;">';
    html += '<th style="padding:8px 10px;text-align:left;">From</th>';
    html += '<th style="padding:8px 10px;text-align:left;">To</th>';
    html += '<th style="padding:8px 10px;text-align:left;">Subject</th>';
    html += '<th style="padding:8px 10px;text-align:left;">Message</th>';
    html += '<th style="padding:8px 10px;text-align:left;">Date</th>';
    html += '<th style="padding:8px 10px;text-align:left;">Status</th>';
    html += '</tr></thead><tbody>';
    messages.forEach(m => {
        const isMine = m.senderId == currentTeacher.id;
        const rowBg = isMine ? '#f0f9f0' : '#fff';
        const badge = m.readStatus ? '<span style="color:#28a745;font-size:11px;">Read</span>' : '<span style="color:#ffc107;font-size:11px;font-weight:600;">Unread</span>';
        html += `<tr style="background:${rowBg};border-bottom:1px solid #eee;">`;
        html += `<td style="padding:8px 10px;">${m.senderName || 'Unknown'}</td>`;
        html += `<td style="padding:8px 10px;">${m.receiverName || 'Unknown'}</td>`;
        html += `<td style="padding:8px 10px;">${m.subject || '—'}</td>`;
        html += `<td style="padding:8px 10px;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="${m.message}">${m.message}</td>`;
        html += `<td style="padding:8px 10px;white-space:nowrap;">${m.createdAt ? new Date(m.createdAt).toLocaleDateString() : '—'}</td>`;
        html += `<td style="padding:8px 10px;">${badge}</td>`;
        html += '</tr>';
    });
    html += '</tbody></table></div>';
    container.innerHTML = html;
}

function openColleagueMessage(teacherId, teacherName) {
    openTeacherMessageModal();
    setTimeout(() => {
        const sel = document.getElementById('messageReceiver');
        if (sel) sel.value = teacherId;
        const subj = document.getElementById('messageSubject');
        if (subj && !subj.value) subj.value = 'Hello ' + teacherName;
    }, 100);
}

function sendMessageToTeacher(teacherId) {
    openTeacherMessageModal();
    const el = document.getElementById('messageReceiver');
    if (el) el.value = teacherId;
}

// ===== SHARED REPORTS =====
async function loadSharedReports() {
    if (!currentTeacher) return;
    const result = await apiCollaboration('shared_reports', { teacher_id: currentTeacher.id });
    if (result.success) {
        renderSharedReports(result.data.items);
    }
}

function renderSharedReports(reports) {
    const tbody = document.getElementById('sharedReportsBody');
    if (!reports || reports.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No shared reports yet.</td></tr>';
        return;
    }
    
    tbody.innerHTML = reports.map(r => `
        <tr>
            <td>${r.studentName}</td>
            <td>${r.className}</td>
            <td>${r.sharedWithName}</td>
            <td><span class="badge ${r.accessLevel === 'edit' ? 'badge-success' : 'badge-info'}">${r.accessLevel}</span></td>
            <td>${r.status}</td>
            <td>
                <button class="teacher-btn teacher-btn-sm teacher-btn-info" onclick="viewSharedReport(${r.id})"><i class="fas fa-eye"></i></button>
                <button class="teacher-btn teacher-btn-sm teacher-btn-warning" onclick="editSharedReportAccess(${r.id})"><i class="fas fa-edit"></i></button>
            </td>
        </tr>
    `).join('');
}

function openShareReportModal() {
    document.getElementById('shareReportModalOverlay').classList.add('show');
    document.getElementById('shareReportModal').classList.add('show');
    loadReportsForSharing();
    loadTeachersForSharing();
}

function closeShareReportModal() {
    document.getElementById('shareReportModalOverlay').classList.remove('show');
    document.getElementById('shareReportModal').classList.remove('show');
    document.getElementById('shareReportForm').reset();
}

async function loadReportsForSharing() {
    if (!currentTeacher) return;
    const result = await apiTeacher('my_reports', { teacher_id: currentTeacher.id });
    if (result.success) {
        const select = document.getElementById('shareReportSelect');
        select.innerHTML = '<option value="">Select Report</option>';
        result.data.items.forEach(r => {
            select.innerHTML += `<option value="${r.id}">${r.studentName} - ${r.term} (${r.className})</option>`;
        });
    }
}

async function loadTeachersForSharing() {
    if (!currentTeacher) return;
    const result = await apiCollaboration('my_class_colleagues', { teacher_id: currentTeacher.id });
    if (result.success) {
        const select = document.getElementById('shareWithTeacher');
        select.innerHTML = '<option value="">Select Teacher</option>';
        result.data.items.forEach(t => {
            select.innerHTML += `<option value="${t.id}">${t.firstName} ${t.lastName}</option>`;
        });
    }
}

async function shareReport(event) {
    event.preventDefault();
    if (!currentTeacher) return;
    
    const reportId = parseInt(document.getElementById('shareReportSelect').value);
    const sharedWithTeacherId = parseInt(document.getElementById('shareWithTeacher').value);
    const accessLevel = document.getElementById('shareAccessLevel').value;
    const comments = document.getElementById('shareComments').value;
    
    const result = await apiCollaboration('share_report', {}, {
        reportId: reportId,
        ownerTeacherId: currentTeacher.id,
        sharedWithTeacherId: sharedWithTeacherId,
        accessLevel: accessLevel,
        comments: comments
    });
    
    if (result.success) {
        showToast('Report shared successfully!', 'success');
        closeShareReportModal();
        loadSharedReports();
    } else {
        showToast(result.message || 'Failed to share report', 'error');
    }
    return false;
}

// ===== TEACHER MESSAGES =====
async function loadTeacherMessages() {
    if (!currentTeacher) return;
    const result = await apiCollaboration('teacher_messages', { teacher_id: currentTeacher.id });
    if (result.success) {
        renderTeacherMessages(result.data.items);
    }
}

function renderTeacherMessages(messages) {
    const container = document.getElementById('teacherMessagesList');
    if (!messages || messages.length === 0) {
        container.innerHTML = '<p class="text-muted">No messages yet.</p>';
        return;
    }
    
    let html = '<div style="max-height:400px;overflow-y:auto;">';
    messages.forEach(m => {
        const isFromMe = m.senderId === currentTeacher.id;
        html += `
            <div style="padding:10px;margin-bottom:8px;border-radius:8px;background:${isFromMe ? '#e8f8f5' : '#f5f5f5'};border-left:3px solid ${isFromMe ? '#085636' : '#999'};">
                <div style="font-weight:600;font-size:13px;">
                    ${isFromMe ? 'To: ' + m.receiverName : 'From: ' + m.senderName}
                    ${!m.readStatus && !isFromMe ? '<span style="background:#e74c3c;color:#fff;padding:2px 6px;border-radius:10px;font-size:10px;margin-left:5px;">New</span>' : ''}
                </div>
                ${m.subject ? `<div style="font-size:12px;color:#666;margin-top:2px;"><strong>${m.subject}</strong></div>` : ''}
                <div style="font-size:13px;margin-top:4px;color:#fff;">${m.message}</div>
                <div style="font-size:11px;color:#888;margin-top:4px;">${new Date(m.createdAt).toLocaleString()}</div>
                ${!m.readStatus && !isFromMe ? `<button class="teacher-btn teacher-btn-sm teacher-btn-info" style="margin-top:5px;" onclick="markMessageAsRead(${m.id})">Mark as Read</button>` : ''}
            </div>
        `;
    });
    html += '</div>';
    container.innerHTML = html;
}

function openTeacherMessageModal() {
    document.getElementById('teacherMessageModalOverlay').classList.add('show');
    document.getElementById('teacherMessageModal').classList.add('show');
    loadTeachersForMessaging();
}

function closeTeacherMessageModal() {
    document.getElementById('teacherMessageModalOverlay').classList.remove('show');
    document.getElementById('teacherMessageModal').classList.remove('show');
    document.getElementById('teacherMessageForm').reset();
}

async function loadTeachersForMessaging() {
    if (!currentTeacher) return;
    const result = await apiCollaboration('my_class_colleagues', { teacher_id: currentTeacher.id });
    if (result.success) {
        const select = document.getElementById('messageReceiver');
        select.innerHTML = '<option value="">Select Teacher</option>';
        result.data.items.forEach(t => {
            select.innerHTML += `<option value="${t.id}">${t.firstName} ${t.lastName}</option>`;
        });
    }
}

async function sendTeacherMessage(event) {
    event.preventDefault();
    if (!currentTeacher) return;
    
    const receiverId = parseInt(document.getElementById('messageReceiver').value);
    const subject = document.getElementById('messageSubject').value;
    const message = document.getElementById('messageContent').value;
    
    const result = await apiCollaboration('send_teacher_message', {}, {
        senderId: currentTeacher.id,
        receiverId: receiverId,
        subject: subject,
        message: message
    });
    
    if (result.success) {
        showToast('Message sent successfully!', 'success');
        closeTeacherMessageModal();
        loadTeacherMessages();
    } else {
        showToast(result.message || 'Failed to send message', 'error');
    }
    return false;
}

async function markMessageAsRead(messageId) {
    const result = await apiCollaboration('mark_message_read', {}, { id: messageId });
    if (result.success) {
        loadTeacherMessages();
    }
}

// ===== TEACHER NOTES =====
async function loadTeacherNotes() {
    if (!currentTeacher) return;
    const result = await apiCollaboration('teacher_notes', { teacher_id: currentTeacher.id });
    if (result.success) {
        renderTeacherNotes(result.data.items);
    }
}

function renderTeacherNotes(notes) {
    const container = document.getElementById('teacherNotesList');
    if (!notes || notes.length === 0) {
        container.innerHTML = '<p class="text-muted">No notes yet.</p>';
        return;
    }
    
    let html = '<div style="display:flex;flex-direction:column;gap:8px;">';
    notes.forEach(n => {
        html += `
            <div style="padding:12px;border:1px solid #e0e0e0;border-radius:8px;background:#fff;">
                <div style="display:flex;justify-content:space-between;align-items:flex-start;">
                    <div>
                        <span style="font-size:12px;background:${n.noteType === 'general' ? '#3498db' : n.noteType === 'student' ? '#e67e22' : n.noteType === 'class' ? '#9b59b6' : '#1abc9c'};color:#fff;padding:3px 8px;border-radius:4px;">${n.noteType}</span>
                        ${n.isPrivate ? '<span style="font-size:11px;color:#888;margin-left:5px;"><i class="fas fa-lock"></i> Private</span>' : ''}
                    </div>
                    <div>
                        <button class="teacher-btn teacher-btn-sm teacher-btn-info" onclick="editTeacherNote(${n.id})"><i class="fas fa-edit"></i></button>
                        <button class="teacher-btn teacher-btn-sm teacher-btn-danger" onclick="deleteTeacherNote(${n.id})"><i class="fas fa-trash"></i></button>
                    </div>
                </div>
                <div style="margin-top:8px;font-size:14px;">${n.noteContent}</div>
                <div style="margin-top:6px;font-size:11px;color:#888;">${new Date(n.createdAt).toLocaleString()}</div>
            </div>
        `;
    });
    html += '</div>';
    container.innerHTML = html;
}

function openTeacherNoteModal() {
    document.getElementById('teacherNoteModalOverlay').classList.add('show');
    document.getElementById('teacherNoteModal').classList.add('show');
    document.getElementById('noteEditId').value = '';
    document.getElementById('teacherNoteForm').reset();
    loadStudentsForNotes();
}

function closeTeacherNoteModal() {
    document.getElementById('teacherNoteModalOverlay').classList.remove('show');
    document.getElementById('teacherNoteModal').classList.remove('show');
    document.getElementById('teacherNoteForm').reset();
}

async function loadStudentsForNotes() {
    if (!currentTeacher) return;
    const result = await apiTeacher('my_students', { teacher_id: currentTeacher.id });
    if (result.success) {
        const select = document.getElementById('noteStudent');
        select.innerHTML = '<option value="">Select Student</option>';
        result.data.items.forEach(s => {
            select.innerHTML += `<option value="${s.id}">${s.firstName} ${s.lastName}</option>`;
        });
    }
}

async function saveTeacherNote(event) {
    event.preventDefault();
    if (!currentTeacher) return;
    
    const editId = document.getElementById('noteEditId').value;
    const noteType = document.getElementById('noteType').value;
    const studentId = document.getElementById('noteStudent').value;
    const noteContent = document.getElementById('noteContent').value;
    const isPrivate = document.getElementById('noteIsPrivate').checked;
    
    const result = await apiCollaboration('save_teacher_note', {}, {
        id: editId || null,
        teacherId: currentTeacher.id,
        className: currentTeacher.class || '',
        studentId: studentId || null,
        noteContent: noteContent,
        noteType: noteType,
        isPrivate: isPrivate
    });
    
    if (result.success) {
        showToast('Note saved successfully!', 'success');
        closeTeacherNoteModal();
        loadTeacherNotes();
    } else {
        showToast(result.message || 'Failed to save note', 'error');
    }
    return false;
}

function editTeacherNote(noteId) {
    // Load note data and open modal for editing
    // For simplicity, just open modal - in production, load note data first
    openTeacherNoteModal();
    document.getElementById('noteEditId').value = noteId;
}

async function deleteTeacherNote(noteId) {
    if (!confirm('Are you sure you want to delete this note?')) return;
    if (!currentTeacher) return;
    
    const result = await apiCollaboration('delete_teacher_note', {}, {
        id: noteId,
        teacherId: currentTeacher.id
    });
    
    if (result.success) {
        showToast('Note deleted successfully!', 'success');
        loadTeacherNotes();
    } else {
        showToast(result.message || 'Failed to delete note', 'error');
    }
}

// ===== SHARED RESOURCES =====
async function loadSharedResources() {
    if (!currentTeacher) return;
    const result = await apiCollaboration('shared_resources', { teacher_id: currentTeacher.id });
    if (result.success) {
        renderSharedResources(result.data.items);
    }
}

function renderSharedResources(resources) {
    const tbody = document.getElementById('sharedResourcesBody');
    if (!resources || resources.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No shared resources yet.</td></tr>';
        return;
    }
    
    tbody.innerHTML = resources.map(r => `
        <tr>
            <td>${r.title}</td>
            <td><span class="badge badge-info">${r.resourceType}</span></td>
            <td>${r.teacherName}</td>
            <td>${r.sharedWithAll ? 'All Teachers' : r.sharedWithClass || 'N/A'}</td>
            <td>${r.downloadCount}</td>
            <td>
                <a href="${r.fileUrl}" target="_blank" class="teacher-btn teacher-btn-sm teacher-btn-info"><i class="fas fa-download"></i></a>
                ${r.teacherId === currentTeacher.id ? `<button class="teacher-btn teacher-btn-sm teacher-btn-danger" onclick="deleteSharedResource(${r.id})"><i class="fas fa-trash"></i></button>` : ''}
            </td>
        </tr>
    `).join('');
}

function openSharedResourceModal() {
    document.getElementById('sharedResourceModalOverlay').classList.add('show');
    document.getElementById('sharedResourceModal').classList.add('show');
}

function closeSharedResourceModal() {
    document.getElementById('sharedResourceModalOverlay').classList.remove('show');
    document.getElementById('sharedResourceModal').classList.remove('show');
    document.getElementById('sharedResourceForm').reset();
}

async function uploadSharedResource(event) {
    event.preventDefault();
    if (!currentTeacher) return;
    
    const form = document.getElementById('sharedResourceForm');
    const formData = new FormData(form);
    formData.append('teacherId', currentTeacher.id);
    
    const btn = form.querySelector('button[type="submit"]');
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Uploading...';
    
    try {
        const res = await fetch('../api/collaboration.php?action=upload_shared_resource', {
            method: 'POST',
            body: formData
        });
        const result = await res.json();
        
        if (result.success) {
            showToast('Resource uploaded successfully!', 'success');
            closeSharedResourceModal();
            loadSharedResources();
        } else {
            showToast(result.message || 'Failed to upload resource', 'error');
        }
    } catch (e) {
        showToast('Error uploading resource', 'error');
    }
    
    btn.disabled = false;
    btn.innerHTML = '<i class="fas fa-upload"></i> Upload Resource';
    return false;
}

async function deleteSharedResource(resourceId) {
    if (!confirm('Are you sure you want to delete this resource?')) return;
    if (!currentTeacher) return;
    
    const result = await apiCollaboration('delete_shared_resource', {}, {
        id: resourceId,
        teacherId: currentTeacher.id
    });
    
    if (result.success) {
        showToast('Resource deleted successfully!', 'success');
        loadSharedResources();
    } else {
        showToast(result.message || 'Failed to delete resource', 'error');
    }
}

// ===== CALENDAR EVENTS =====
async function loadCalendarEvents() {
    if (!currentTeacher) return;
    const result = await apiCollaboration('calendar_events', { 
        teacher_id: currentTeacher.id,
        target_audience: 'teachers',
        class_name: currentTeacher.class || ''
    });
    if (result.success) {
        renderCalendarEvents(result.data.items);
    }
}

function renderCalendarEvents(events) {
    const container = document.getElementById('calendarEventsList');
    if (!events || events.length === 0) {
        container.innerHTML = '<p class="text-muted">No calendar events scheduled.</p>';
        return;
    }
    
    let html = '<div style="max-height:400px;overflow-y:auto;">';
    events.forEach(e => {
        const typeColors = {
            general: '#3498db',
            meeting: '#9b59b6',
            deadline: '#e74c3c',
            exam: '#e67e22',
            event: '#1abc9c',
            collaboration: '#085636'
        };
        const color = typeColors[e.eventType] || '#3498db';
        
        html += `
            <div style="padding:12px;margin-bottom:8px;border-radius:8px;background:#fff;border-left:4px solid ${color};border:1px solid #e0e0e0;">
                <div style="display:flex;justify-content:space-between;align-items:flex-start;">
                    <div>
                        <span style="font-size:12px;background:${color};color:#fff;padding:3px 8px;border-radius:4px;">${e.eventType}</span>
                    </div>
                    <div>
                        <button class="teacher-btn teacher-btn-sm teacher-btn-info" onclick="editCalendarEvent(${e.id})"><i class="fas fa-edit"></i></button>
                        <button class="teacher-btn teacher-btn-sm teacher-btn-danger" onclick="deleteCalendarEvent(${e.id})"><i class="fas fa-trash"></i></button>
                    </div>
                </div>
                <div style="font-weight:600;margin-top:6px;">${e.title}</div>
                <div style="font-size:13px;color:#666;margin-top:2px;">
                    <i class="fas fa-calendar"></i> ${new Date(e.eventDate).toLocaleDateString()}
                    ${e.eventTime ? `<span style="margin-left:10px;"><i class="fas fa-clock"></i> ${e.eventTime}</span>` : ''}
                </div>
                ${e.location ? `<div style="font-size:12px;color:#888;margin-top:2px;"><i class="fas fa-map-marker-alt"></i> ${e.location}</div>` : ''}
                ${e.description ? `<div style="font-size:13px;margin-top:4px;">${e.description}</div>` : ''}
            </div>
        `;
    });
    html += '</div>';
    container.innerHTML = html;
}

function openCalendarEventModal() {
    document.getElementById('calendarEventModalOverlay').classList.add('show');
    document.getElementById('calendarEventModal').classList.add('show');
    document.getElementById('calendarEventEditId').value = '';
    document.getElementById('calendarEventForm').reset();
}

function closeCalendarEventModal() {
    document.getElementById('calendarEventModalOverlay').classList.remove('show');
    document.getElementById('calendarEventModal').classList.remove('show');
    document.getElementById('calendarEventForm').reset();
}

async function saveCalendarEvent(event) {
    event.preventDefault();
    if (!currentTeacher) return;
    
    const editId = document.getElementById('calendarEventEditId').value;
    const title = document.getElementById('calendarEventTitle').value;
    const eventType = document.getElementById('calendarEventType').value;
    const eventDate = document.getElementById('calendarEventDate').value;
    const eventTime = document.getElementById('calendarEventTime').value;
    const endTime = document.getElementById('calendarEventEndTime').value;
    const location = document.getElementById('calendarEventLocation').value;
    const description = document.getElementById('calendarEventDescription').value;
    
    const action = editId ? 'update_calendar_event' : 'create_calendar_event';
    const body = {
        title: title,
        eventType: eventType,
        eventDate: eventDate,
        eventTime: eventTime,
        endTime: endTime,
        location: location,
        description: description,
        createdBy: currentTeacher.firstName + ' ' + currentTeacher.lastName,
        createdById: currentTeacher.id,
        targetAudience: 'teachers',
        className: currentTeacher.class || ''
    };
    
    if (editId) body.id = parseInt(editId);
    
    const result = await apiCollaboration(action, {}, body);
    
    if (result.success) {
        showToast('Calendar event saved successfully!', 'success');
        closeCalendarEventModal();
        loadCalendarEvents();
    } else {
        showToast(result.message || 'Failed to save event', 'error');
    }
    return false;
}

function editCalendarEvent(eventId) {
    // Load event data and open modal for editing
    // For simplicity, just open modal - in production, load event data first
    openCalendarEventModal();
    document.getElementById('calendarEventEditId').value = eventId;
}

async function deleteCalendarEvent(eventId) {
    if (!confirm('Are you sure you want to delete this event?')) return;
    
    const result = await apiCollaboration('delete_calendar_event', {}, { id: eventId });
    
    if (result.success) {
        showToast('Event deleted successfully!', 'success');
        loadCalendarEvents();
    } else {
        showToast(result.message || 'Failed to delete event', 'error');
    }
}

// ===== LOAD COLLABORATION DATA ON DASHBOARD LOAD =====
function loadCollaborationData() {
    loadClassColleagues();
    loadSharedReports();
    loadTeacherMessages();
    loadTeacherNotes();
    loadSharedResources();
    loadCalendarEvents();
}

function viewReportSignature(id) {
    const report = myReports.find(r => r.id === id);
    if (!report || !report.signatureImg) return;
    const w = window.open('', '_blank');
    w.document.write(`<html><head><title>Signature - ${report.studentName}</title></head><body style="display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:100vh;font-family:sans-serif;background:#f5f5f5;">
        <h2 style="color:#085636;">Report Signature</h2>
        <p><strong>${report.studentName}</strong> - ${report.className} - ${report.term} ${report.academicYear}</p>
        <img src="${report.signatureImg}" style="max-width:500px;border:2px solid #085636;border-radius:8px;background:#fff;padding:20px;" />
        <p style="color:#666;font-size:13px;margin-top:10px;">Signed: ${report.signedAt ? new Date(report.signedAt).toLocaleString() : 'N/A'}</p>
    </body></html>`);
    w.document.close();
}

function viewPrintReport(id) {
    const report = myReports.find(r => r.id === id);
    if (!report) return;

    // School contact information from report data
    const schoolName = 'Noah Christian Academy';
    const schoolAddress = report.schoolAddress || 'P.O.BOX 30458, Area 24 PHA (Behind chilungamo investment), Lilongwe, Malawi';
    const schoolEmail = report.schoolEmail || 'noahchristianacademy2021@gmail.com';
    const principalPhone = report.principalPhone || '+265 999 608 570';
    const adminPhone = report.adminPhone || '+265 999 693 134';
    const logoUrl = '../images/logo.jpg';

    // Generate barcode using a simple pattern (in production, use a proper barcode library)
    const barcodeValue = `NCA-${report.id}-${report.studentId}`;
    const barcodePattern = generateSimpleBarcode(barcodeValue);

    // Generate subjects table HTML
    const subjectsHtml = report.subjects && report.subjects.length > 0 
        ? report.subjects.map(sub => `
            <tr>
                <td style="padding: 8px; border: 1px solid #ddd;">${sub.subject || '-'}</td>
                <td style="padding: 8px; border: 1px solid #ddd; text-align: center;">${sub.grade || '-'}</td>
                <td style="padding: 8px; border: 1px solid #ddd;">${sub.comment || '-'}</td>
            </tr>
        `).join('')
        : '<tr><td colspan="3" style="padding: 8px; border: 1px solid #ddd; text-align: center;">No subjects recorded</td></tr>';

    const reportHtml = `
<!DOCTYPE html>
<html>
<head>
    <title>School Report - ${report.studentName}</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 20px;
            background: #f5f5f5;
        }
        .report-container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            padding: 40px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .report-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 30px;
            border-bottom: 3px solid #085636;
            padding-bottom: 20px;
        }
        .school-logo {
            width: 100px;
            height: 100px;
            object-fit: contain;
        }
        .school-info {
            text-align: center;
            flex: 1;
        }
        .school-info h1 {
            color: #085636;
            margin: 0 0 10px 0;
            font-size: 24px;
        }
        .school-info h2 {
            color: #333;
            margin: 0;
            font-size: 18px;
            font-weight: normal;
        }
        .contact-info {
            text-align: right;
            font-size: 12px;
            color: #666;
        }
        .contact-info div {
            margin: 5px 0;
        }
        .student-info {
            background: #f8f9fa;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 8px;
        }
        .student-info h3 {
            color: #085636;
            margin-top: 0;
            margin-bottom: 15px;
            border-bottom: 2px solid #085636;
            padding-bottom: 10px;
        }
        .info-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
        }
        .info-item {
            display: flex;
            flex-direction: column;
        }
        .info-item label {
            font-weight: bold;
            color: #333;
            font-size: 12px;
            margin-bottom: 5px;
        }
        .info-item span {
            color: #555;
            font-size: 14px;
        }
        .section-title {
            color: #085636;
            font-size: 18px;
            margin: 25px 0 15px 0;
            padding-bottom: 8px;
            border-bottom: 2px solid #085636;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th {
            background: #085636;
            color: white;
            padding: 10px;
            text-align: left;
            font-weight: bold;
        }
        td {
            padding: 8px;
            border: 1px solid #ddd;
        }
        .grade-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 12px;
            font-weight: bold;
            font-size: 12px;
        }
        .grade-A { background: #d4edda; color: #155724; }
        .grade-B { background: #cce5ff; color: #004085; }
        .grade-C { background: #fff3cd; color: #856404; }
        .grade-D { background: #f8d7da; color: #721c24; }
        .grade-E { background: #f5c6cb; color: #721c24; }
        .grade-F { background: #dc3545; color: white; }
        .overall-grade {
            text-align: center;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 8px;
            margin: 20px 0;
        }
        .overall-grade .grade {
            font-size: 48px;
            font-weight: bold;
            color: #085636;
        }
        .comment-section {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin: 20px 0;
        }
        .comment-section h4 {
            color: #085636;
            margin-top: 0;
            margin-bottom: 10px;
        }
        .comment-section p {
            color: #333;
            line-height: 1.6;
            margin: 0;
        }
        .signature-section {
            display: flex;
            justify-content: space-between;
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
        }
        .signature-box {
            text-align: center;
            width: 45%;
        }
        .signature-box img {
            max-width: 150px;
            max-height: 60px;
            margin-bottom: 10px;
        }
        .signature-box .label {
            font-size: 12px;
            color: #666;
            margin-top: 5px;
        }
        .barcode-section {
            text-align: center;
            margin-top: 30px;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 8px;
        }
        .barcode {
            font-family: 'Courier New', monospace;
            font-size: 12px;
            letter-spacing: 2px;
            white-space: pre;
            line-height: 1.2;
            margin: 10px 0;
        }
        .barcode-text {
            font-size: 11px;
            color: #666;
            margin-top: 5px;
        }
        .footer {
            text-align: center;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            font-size: 11px;
            color: #888;
        }
        @media print {
            body { background: white; }
            .report-container { box-shadow: none; padding: 20px; }
            .no-print { display: none; }
        }
    </style>
</head>
<body>
    <div class="report-container">
        <!-- Header -->
        <div class="report-header">
            <img src="${logoUrl}" alt="School Logo" class="school-logo" onerror="this.style.display='none'">
            <div class="school-info">
                <h1>${schoolName}</h1>
                <h2>Student Progress Report</h2>
            </div>
            <div class="contact-info">
                <div><i class="fas fa-envelope"></i> ${schoolEmail}</div>
                <div><i class="fas fa-map-marker-alt"></i> ${schoolAddress}</div>
                <div><i class="fas fa-user-tie"></i> Principal: ${principalPhone}</div>
                <div><i class="fas fa-user-shield"></i> Administrator: ${adminPhone}</div>
            </div>
        </div>

        <!-- Student Information -->
        <div class="student-info">
            <h3>Student Information</h3>
            <div class="info-grid">
                <div class="info-item">
                    <label>Student Name</label>
                    <span>${report.studentName || '-'}</span>
                </div>
                <div class="info-item">
                    <label>Class</label>
                    <span>${report.className || '-'}</span>
                </div>
                <div class="info-item">
                    <label>Term</label>
                    <span>${report.term || '-'}</span>
                </div>
                <div class="info-item">
                    <label>Academic Year</label>
                    <span>${report.academicYear || '-'}</span>
                </div>
                <div class="info-item">
                    <label>Report Date</label>
                    <span>${report.updatedAt ? new Date(report.updatedAt).toLocaleDateString() : '-'}</span>
                </div>
                <div class="info-item">
                    <label>Status</label>
                    <span>${report.workflowStatus || report.status || '-'}</span>
                </div>
            </div>
        </div>

        <!-- Subject Grades -->
        <h3 class="section-title">Subject Performance</h3>
        <table>
            <thead>
                <tr>
                    <th>Subject</th>
                    <th style="text-align: center;">Grade</th>
                    <th>Teacher's Comment</th>
                </tr>
            </thead>
            <tbody>
                ${subjectsHtml}
            </tbody>
        </table>

        <!-- Overall Grade -->
        <div class="overall-grade">
            <div style="font-size: 14px; color: #666; margin-bottom: 5px;">Overall Performance Grade</div>
            <div class="grade-badge grade-${report.overallGrade || 'F'} grade">${report.overallGrade || '-'}</div>
        </div>

        <!-- Teacher's Comment -->
        <div class="comment-section">
            <h4>Teacher's Comments</h4>
            <p>${report.comment || 'No comments provided.'}</p>
        </div>

        <!-- Signature Section -->
        <div class="signature-section">
            <div class="signature-box">
                ${report.signatureImg ? `<img src="${report.signatureImg}" alt="Teacher Signature">` : '<div style="height: 60px; display: flex; align-items: center; justify-content: center; color: #999; font-style: italic;">No signature</div>'}
                <div class="label">Teacher's Signature</div>
                <div class="label">${currentTeacher ? currentTeacher.firstName + ' ' + currentTeacher.lastName : ''}</div>
            </div>
            <div class="signature-box">
                <div style="height: 60px; display: flex; align-items: center; justify-content: center; color: #999; font-style: italic;">Principal's Signature</div>
                <div class="label">Principal's Signature</div>
                <div class="label">Noah Christian Academy</div>
            </div>
        </div>

        <!-- Barcode -->
        <div class="barcode-section">
            <div class="barcode">${barcodePattern}</div>
            <div class="barcode-text">${barcodeValue}</div>
        </div>

        <!-- Footer -->
        <div class="footer">
            <p>This report is officially generated by Noah Christian Academy Management System</p>
            <p>Generated on: ${new Date().toLocaleString()}</p>
        </div>

        <!-- Print Button -->
        <div class="no-print" style="text-align: center; margin-top: 20px;">
            <button onclick="window.print()" style="padding: 12px 30px; background: #085636; color: white; border: none; border-radius: 6px; cursor: pointer; font-size: 16px;">
                <i class="fas fa-print"></i> Print Report
            </button>
            <button onclick="window.close()" style="padding: 12px 30px; background: #6c757d; color: white; border: none; border-radius: 6px; cursor: pointer; font-size: 16px; margin-left: 10px;">
                <i class="fas fa-times"></i> Close
            </button>
        </div>
    </div>
</body>
</html>`;

    const w = window.open('', '_blank');
    w.document.write(reportHtml);
    w.document.close();
}

// Download report as PDF
async function downloadReportPDF(id) {
    const report = myReports.find(r => r.id === id);
    if (!report) return;

    // School contact information from report data
    const schoolName = 'Noah Christian Academy';
    const schoolAddress = report.schoolAddress || 'P.O.BOX 30458, Area 24 PHA (Behind chilungamo investment), Lilongwe, Malawi';
    const schoolEmail = report.schoolEmail || 'noahchristianacademy2021@gmail.com';
    const principalPhone = report.principalPhone || '+265 999 608 570';
    const adminPhone = report.adminPhone || '+265 999 693 134';
    const logoUrl = '../images/logo.jpg';

    // Generate barcode using a simple pattern
    const barcodeValue = `NCA-${report.id}-${report.studentId}`;
    const barcodePattern = generateSimpleBarcode(barcodeValue);

    // Generate subjects table HTML
    const subjectsHtml = report.reportData && report.reportData.length > 0
        ? report.reportData.map(sub => `
            <tr>
                <td style="padding: 8px; border: 1px solid #ddd;">${sub.subject || '-'}</td>
                <td style="padding: 8px; border: 1px solid #ddd; text-align: center;">${sub.grade || '-'}</td>
                <td style="padding: 8px; border: 1px solid #ddd;">${sub.comment || '-'}</td>
            </tr>
        `).join('')
        : '<tr><td colspan="3" style="padding: 8px; border: 1px solid #ddd; text-align: center;">No subjects recorded</td></tr>';

    const reportHtml = `
<!DOCTYPE html>
<html>
<head>
    <title>School Report - ${report.studentName}</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 20px;
            background: #f5f5f5;
        }
        .report-container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            padding: 40px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .report-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 30px;
            border-bottom: 3px solid #085636;
            padding-bottom: 20px;
        }
        .school-logo {
            width: 100px;
            height: 100px;
            object-fit: contain;
        }
        .school-info {
            text-align: center;
            flex: 1;
        }
        .school-info h1 {
            color: #085636;
            margin: 0 0 10px 0;
            font-size: 24px;
        }
        .school-info h2 {
            color: #333;
            margin: 0;
            font-size: 18px;
            font-weight: normal;
        }
        .contact-info {
            text-align: right;
            font-size: 12px;
            color: #666;
        }
        .contact-info div {
            margin: 5px 0;
        }
        .student-info {
            background: #f8f9fa;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 8px;
        }
        .student-info h3 {
            color: #085636;
            margin-top: 0;
            margin-bottom: 15px;
            border-bottom: 2px solid #085636;
            padding-bottom: 10px;
        }
        .info-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
        }
        .info-item {
            display: flex;
            flex-direction: column;
        }
        .info-item label {
            font-weight: bold;
            color: #333;
            font-size: 12px;
            margin-bottom: 5px;
        }
        .info-item span {
            color: #555;
            font-size: 14px;
        }
        .section-title {
            color: #085636;
            font-size: 18px;
            margin: 25px 0 15px 0;
            padding-bottom: 8px;
            border-bottom: 2px solid #085636;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th {
            background: #085636;
            color: white;
            padding: 10px;
            text-align: left;
            font-weight: bold;
        }
        td {
            padding: 8px;
            border: 1px solid #ddd;
        }
        .grade-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 12px;
            font-weight: bold;
            font-size: 12px;
        }
        .grade-A { background: #d4edda; color: #155724; }
        .grade-B { background: #cce5ff; color: #004085; }
        .grade-C { background: #fff3cd; color: #856404; }
        .grade-D { background: #f8d7da; color: #721c24; }
        .grade-E { background: #f5c6cb; color: #721c24; }
        .grade-F { background: #dc3545; color: white; }
        .overall-grade {
            text-align: center;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 8px;
            margin: 20px 0;
        }
        .overall-grade .grade {
            font-size: 48px;
            font-weight: bold;
            color: #085636;
        }
        .comment-section {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin: 20px 0;
        }
        .comment-section h4 {
            color: #085636;
            margin-top: 0;
            margin-bottom: 10px;
        }
        .comment-section p {
            color: #333;
            line-height: 1.6;
            margin: 0;
        }
        .signature-section {
            display: flex;
            justify-content: space-between;
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
        }
        .signature-box {
            text-align: center;
            width: 45%;
        }
        .signature-box img {
            max-width: 150px;
            max-height: 60px;
            margin-bottom: 10px;
        }
        .signature-box .label {
            font-size: 12px;
            color: #666;
            margin-top: 5px;
        }
        .barcode-section {
            text-align: center;
            margin-top: 30px;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 8px;
        }
        .barcode {
            font-family: 'Courier New', monospace;
            font-size: 12px;
            letter-spacing: 2px;
            white-space: pre;
            line-height: 1.2;
            margin: 10px 0;
        }
        .barcode-text {
            font-size: 11px;
            color: #666;
            margin-top: 5px;
        }
        .footer {
            text-align: center;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            font-size: 11px;
            color: #888;
        }
    </style>
</head>
<body>
    <div class="report-container" id="reportContent">
        <!-- Header -->
        <div class="report-header">
            <img src="${logoUrl}" alt="School Logo" class="school-logo" onerror="this.style.display='none'">
            <div class="school-info">
                <h1>${schoolName}</h1>
                <h2>Student Progress Report</h2>
            </div>
            <div class="contact-info">
                <div><i class="fas fa-envelope"></i> ${schoolEmail}</div>
                <div><i class="fas fa-map-marker-alt"></i> ${schoolAddress}</div>
                <div><i class="fas fa-user-tie"></i> Principal: ${principalPhone}</div>
                <div><i class="fas fa-user-shield"></i> Administrator: ${adminPhone}</div>
            </div>
        </div>

        <!-- Student Information -->
        <div class="student-info">
            <h3>Student Information</h3>
            <div class="info-grid">
                <div class="info-item">
                    <label>Student Name</label>
                    <span>${report.studentName}</span>
                </div>
                <div class="info-item">
                    <label>Class</label>
                    <span>${report.className}</span>
                </div>
                <div class="info-item">
                    <label>Term</label>
                    <span>${report.term}</span>
                </div>
                <div class="info-item">
                    <label>Academic Year</label>
                    <span>${report.academicYear}</span>
                </div>
            </div>
        </div>

        <!-- Subjects Table -->
        <div class="section-title">Subject Performance</div>
        <table>
            <thead>
                <tr>
                    <th>Subject</th>
                    <th>Grade</th>
                    <th>Remarks</th>
                </tr>
            </thead>
            <tbody>
                ${subjectsHtml}
            </tbody>
        </table>

        <!-- Overall Grade -->
        <div class="overall-grade">
            <div style="font-size: 14px; color: #666; margin-bottom: 5px;">Overall Performance Grade</div>
            <div class="grade-badge grade-${report.overallGrade || 'F'} grade">${report.overallGrade || '-'}</div>
        </div>

        <!-- Teacher's Comment -->
        <div class="comment-section">
            <h4>Teacher's Comments</h4>
            <p>${report.teacherComments || 'No comments provided.'}</p>
        </div>

        <!-- Signature Section -->
        <div class="signature-section">
            <div class="signature-box">
                ${report.signatureImg ? `<img src="${report.signatureImg}" alt="Teacher Signature">` : '<div style="height: 60px; display: flex; align-items: center; justify-content: center; color: #999; font-style: italic;">No signature</div>'}
                <div class="label">Teacher's Signature</div>
                <div class="label">${currentTeacher ? currentTeacher.firstName + ' ' + currentTeacher.lastName : ''}</div>
            </div>
            <div class="signature-box">
                <div style="height: 60px; display: flex; align-items: center; justify-content: center; color: #999; font-style: italic;">Principal's Signature</div>
                <div class="label">Principal's Signature</div>
                <div class="label">Noah Christian Academy</div>
            </div>
        </div>

        <!-- Barcode -->
        <div class="barcode-section">
            <div class="barcode">${barcodePattern}</div>
            <div class="barcode-text">${barcodeValue}</div>
        </div>

        <!-- Footer -->
        <div class="footer">
            <p>This report is officially generated by Noah Christian Academy Management System</p>
            <p>Generated on: ${new Date().toLocaleString()}</p>
        </div>
    </div>
</body>
</html>`;

    // Create a temporary container to render the HTML
    const container = document.createElement('div');
    container.style.position = 'absolute';
    container.style.left = '-9999px';
    container.style.top = '0';
    container.style.width = '800px';
    document.body.appendChild(container);
    container.innerHTML = reportHtml;

    try {
        showToast('Generating PDF...', 'info');

        // Wait for images to load
        await new Promise(resolve => setTimeout(resolve, 1000));

        // Use html2canvas to capture the report
        const canvas = await html2canvas(container, {
            scale: 2,
            useCORS: true,
            logging: false
        });

        // Create PDF using jsPDF
        const { jsPDF } = window.jspdf;
        const pdf = new jsPDF('p', 'mm', 'a4');
        
        const imgData = canvas.toDataURL('image/png');
        const imgWidth = 210; // A4 width in mm
        const pageHeight = 297; // A4 height in mm
        const imgHeight = (canvas.height * imgWidth) / canvas.width;
        
        pdf.addImage(imgData, 'PNG', 0, 0, imgWidth, imgHeight);
        
        // Download the PDF
        const fileName = `Report_${report.studentName.replace(/\s+/g, '_')}_${report.className}_${report.term}.pdf`;
        pdf.save(fileName);
        
        showToast('PDF downloaded successfully!', 'success');
    } catch (error) {
        console.error('PDF generation error:', error);
        showToast('Failed to generate PDF. Please try printing instead.', 'error');
    } finally {
        // Remove the temporary container
        document.body.removeChild(container);
    }
}

// Simple barcode generator (placeholder - in production use a proper barcode library)
function generateSimpleBarcode(text) {
    // This is a simple visual representation - not a real barcode
    // For production, use libraries like JsBarcode
    const hash = text.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
    let pattern = '';
    for (let i = 0; i < 40; i++) {
        if ((hash + i) % 3 === 0) {
            pattern += '█';
        } else if ((hash + i) % 3 === 1) {
            pattern += '▀';
        } else {
            pattern += ' ';
        }
    }
    return pattern;
}

// ===== SEND FILE TO ADMIN =====
async function handleTeacherFileUpload(event) {
    event.preventDefault();
    
    if (!currentTeacher) {
        showToast('Please log in first', 'error');
        return false;
    }
    
    const form = document.getElementById('teacherFileUploadForm');
    const title = document.getElementById('teacherFileTitle').value.trim();
    const category = document.getElementById('teacherFileCategory').value;
    const description = document.getElementById('teacherFileDescription').value.trim();
    const fileInput = document.getElementById('teacherFile');
    
    if (!title) {
        showToast('Please enter a document title', 'error');
        return false;
    }
    
    if (!fileInput.files || fileInput.files.length === 0) {
        showToast('Please select at least one file to upload', 'error');
        return false;
    }
    
    // Validate file sizes (10MB max)
    const maxSize = 10 * 1024 * 1024;
    for (let i = 0; i < fileInput.files.length; i++) {
        if (fileInput.files[i].size > maxSize) {
            showToast(`File "${fileInput.files[i].name}" exceeds 10MB limit`, 'error');
            return false;
        }
    }
    
    // Create FormData for multipart upload
    const formData = new FormData();
    formData.append('teacher_id', currentTeacher.id);
    formData.append('title', title);
    formData.append('category', category);
    formData.append('description', description);
    
    // Append all files
    for (let i = 0; i < fileInput.files.length; i++) {
        formData.append('file', fileInput.files[i]);
    }
    
    try {
        const submitBtn = form.querySelector('button[type="submit"]');
        const originalText = submitBtn.innerHTML;
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Uploading...';
        
        const response = await fetch('../api/teacher.php?action=upload_file_to_admin', {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalText;
        
        if (result.success) {
            showToast(result.message || 'Files uploaded successfully!', 'success');
            form.reset();
        } else {
            showToast(result.message || 'Failed to upload files', 'error');
        }
    } catch (error) {
        console.error('Upload error:', error);
        showToast('Error uploading files. Please try again.', 'error');
    }
    
    return false;
}

// ===== LOAD SENT FILES TO ADMIN =====
async function loadSentFilesToAdmin() {
    if (!currentTeacher) return;
    
    const result = await apiTeacher('my_sent_files', { teacher_id: currentTeacher.id });
    if (result.success) {
        renderSentFiles(result.data.items);
    }
}

function renderSentFiles(files) {
    const container = document.getElementById('sentFilesList');
    if (!container) return;
    
    if (!files || files.length === 0) {
        container.innerHTML = '<p class="text-muted">No files sent to admin yet.</p>';
        return;
    }
    
    let html = '<div class="table-responsive"><table class="teacher-table"><thead><tr><th>Title</th><th>Category</th><th>File Name</th><th>Size</th><th>Status</th><th>Date</th><th>Actions</th></tr></thead><tbody>';
    
    files.forEach(file => {
        const fileSize = formatFileSize(file.fileSize);
        const statusClass = file.status === 'approved' ? 'good' : file.status === 'rejected' ? 'needs-improvement' : 'average';
        
        html += `
            <tr>
                <td><strong>${file.title}</strong></td>
                <td><span class="status-badge" style="background:#f0f0f0;color:#666;">${file.category}</span></td>
                <td>${file.fileName}</td>
                <td>${fileSize}</td>
                <td><span class="status-badge ${statusClass}">${file.status}</span></td>
                <td>${formatDate(file.createdAt)}</td>
                <td>
                    <a href="${file.fileUrl}" target="_blank" class="teacher-btn teacher-btn-sm teacher-btn-info" title="Download"><i class="fas fa-download"></i></a>
                    ${file.adminNotes ? `<button class="teacher-btn teacher-btn-sm teacher-btn-warning" onclick="showAdminNotes('${file.adminNotes.replace(/'/g, "\\'")}')" title="View Admin Notes"><i class="fas fa-sticky-note"></i></button>` : ''}
                </td>
            </tr>
        `;
    });
    
    html += '</tbody></table></div>';
    container.innerHTML = html;
}

function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
}

function showAdminNotes(notes) {
    alert('Admin Notes:\n\n' + notes);
}

async function cancelTeacherAccountDeletion(userType) {
    console.log('cancelTeacherAccountDeletion called');
    if (!confirm('Are you sure you want to cancel your account deletion request?')) {
        return;
    }
    
    try {
        const userId = currentTeacher.id;
        console.log('Cancelling deletion for user ID:', userId);
        const result = await apiAuth('cancel_deletion_request', { userType, userId });
        
        console.log('Cancel deletion result:', result);
        
        if (result.success) {
            showToast('Account deletion request cancelled successfully!', 'success');
            
            // Hide the deletion warning modal
            const modal = document.getElementById('teacherDeletionWarningModal');
            if (modal) modal.style.display = 'none';
            
            // Show the main dashboard content
            const mainContent = document.querySelector('.teacher-main');
            if (mainContent) mainContent.style.display = 'block';
            
            // Refresh the settings to hide the deletion section
            loadSettings();
        } else {
            showToast(result.message || 'Failed to cancel deletion request', 'error');
        }
    } catch (error) {
        console.error('Error cancelling deletion:', error);
        showToast('An error occurred while cancelling deletion request', 'error');
    }
}

async function requestAccountDeletion(userType) {
    console.log('requestAccountDeletion called with userType:', userType);
    if (!confirm('Are you sure you want to delete your account?\n\nThis action will take 24 hours to complete. During this time, you can cancel the request. The admin will be notified of your deletion request.\n\nDo you want to proceed?')) {
        return;
    }
    
    try {
        const userId = currentTeacher.id;
        const result = await apiAuth('request_account_deletion', { userType, userId });
        
        if (result.success) {
            showToast('Account deletion request submitted. Your account will be deleted in 24 hours.', 'success');
            // Check for pending deletion to show modal
            checkTeacherPendingDeletion();
        } else {
            showToast(result.message || 'Failed to submit deletion request', 'error');
            // Even if the request failed (like due to existing request), check status to show existing request
            checkTeacherPendingDeletion();
        }
    } catch (error) {
        console.error('Error requesting account deletion:', error);
        showToast('Error requesting account deletion', 'error');
    }
}

// Make functions globally accessible
window.requestAccountDeletion = requestAccountDeletion;
window.cancelTeacherAccountDeletion = cancelTeacherAccountDeletion;

// ===== LOGIN HISTORY & AUTHORIZED ACCESS =====
async function loadLoginHistory() {
    if (!currentTeacher) return;
    
    // Display account info
    document.getElementById('deviceAccountEmail').textContent = currentTeacher.email || '-';
    document.getElementById('deviceUsername').textContent = currentTeacher.username || '-';
    
    // Load login history
    const result = await apiAuth('login_history', { teacher_id: currentTeacher.id });
    const history = result.success ? (result.data?.items || []) : [];
    
    const tbody = document.getElementById('loginHistoryBody');
    if (!tbody) return;
    
    if (history.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No login history found.</td></tr>';
        return;
    }
    
    tbody.innerHTML = history.map((log, index) => {
        const statusClass = log.loginStatus === 'success' ? 'status-badge good' : 
                            log.loginStatus === 'failed' ? 'status-badge needs-improvement' : 
                            log.loginStatus === 'blocked' ? 'status-badge average' : 'status-badge';
        const statusText = log.loginStatus.charAt(0).toUpperCase() + log.loginStatus.slice(1);
        
        return `<tr>
            <td>${formatDateTime(log.loginAt)}</td>
            <td><strong>${log.ipAddress}</strong></td>
            <td>${log.device}</td>
            <td>${log.os}</td>
            <td>${log.browser}</td>
            <td><span class="${statusClass}">${statusText}</span></td>
        </tr>`;
    }).join('');
    
    // Load authorized IPs and emails
    loadAuthorizedAccess();
}

function formatDateTime(dateStr) {
    if (!dateStr) return '-';
    const d = new Date(dateStr);
    return d.toLocaleString('en-US', { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    });
}

async function loadAuthorizedAccess() {
    if (!currentTeacher) return;
    
    // Load authorized IPs
    const ipResult = await apiAuth('get_authorized_ips', { teacher_id: currentTeacher.id });
    const ips = ipResult.success ? (ipResult.data?.items || []) : [];
    
    const ipsList = document.getElementById('authorizedIpsList');
    if (ipsList) {
        if (ips.length === 0) {
            ipsList.innerHTML = '<p class="text-muted">No authorized IPs configured.</p>';
        } else {
            ipsList.innerHTML = ips.map(ip => `
                <div class="access-item">
                    <div class="access-item-info">
                        <div class="access-value">${ip.ipAddress}</div>
                        <div class="access-description">${ip.description || 'No description'}</div>
                    </div>
                    <div class="access-item-actions">
                        <button class="teacher-btn teacher-btn-danger teacher-btn-sm" onclick="revokeAuthorizedIp(${ip.id})">
                            <i class="fas fa-times"></i> Revoke
                        </button>
                    </div>
                </div>
            `).join('');
        }
    }
    
    // Load authorized emails
    const emailResult = await apiAuth('get_authorized_emails', { teacher_id: currentTeacher.id });
    const emails = emailResult.success ? (emailResult.data?.items || []) : [];
    
    const emailsList = document.getElementById('authorizedEmailsList');
    if (emailsList) {
        if (emails.length === 0) {
            emailsList.innerHTML = '<p class="text-muted">No authorized emails configured.</p>';
        } else {
            emailsList.innerHTML = emails.map(email => `
                <div class="access-item">
                    <div class="access-item-info">
                        <div class="access-value">${email.email}</div>
                        <div class="access-description">${email.description || 'No description'}</div>
                    </div>
                    <div class="access-item-actions">
                        <button class="teacher-btn teacher-btn-danger teacher-btn-sm" onclick="revokeAuthorizedEmail(${email.id})">
                            <i class="fas fa-times"></i> Revoke
                        </button>
                    </div>
                </div>
            `).join('');
        }
    }
}

function openAddIpModal() {
    document.getElementById('newIpAddress').value = '';
    document.getElementById('newIpDescription').value = '';
    document.getElementById('addIpError').classList.remove('show');
    document.getElementById('addIpSuccess').classList.remove('show');
    document.getElementById('addIpOverlay').classList.add('show');
    document.getElementById('addIpModal').classList.add('show');
}

function closeAddIpModal() {
    document.getElementById('addIpOverlay').classList.remove('show');
    document.getElementById('addIpModal').classList.remove('show');
}

async function addAuthorizedIp() {
    if (!currentTeacher) return;
    
    const ipAddress = document.getElementById('newIpAddress').value.trim();
    const description = document.getElementById('newIpDescription').value.trim();
    
    const errorEl = document.getElementById('addIpError');
    const successEl = document.getElementById('addIpSuccess');
    errorEl.classList.remove('show');
    successEl.classList.remove('show');
    
    if (!ipAddress) {
        errorEl.textContent = 'IP address is required!';
        errorEl.classList.add('show');
        return;
    }
    
    const payload = {
        teacher_id: currentTeacher.id,
        ip_address: ipAddress,
        description: description
    };
    
    const result = await apiAuth('add_authorized_ip', payload);
    if (result.success) {
        successEl.textContent = 'IP added successfully!';
        successEl.classList.add('show');
        showToast('Authorized IP added successfully!', 'success');
        setTimeout(() => {
            loadAuthorizedAccess();
            closeAddIpModal();
        }, 1000);
    } else {
        errorEl.textContent = result.message || 'Failed to add IP';
        errorEl.classList.add('show');
    }
}

async function revokeAuthorizedIp(ipId) {
    if (!confirm('Are you sure you want to revoke this IP address?')) return;
    
    const result = await apiAuth('revoke_authorized_ip', { ip_id: ipId });
    if (result.success) {
        showToast('IP revoked successfully!', 'success');
        loadAuthorizedAccess();
    } else {
        showToast(result.message || 'Failed to revoke IP', 'error');
    }
}

function openAddEmailModal() {
    document.getElementById('newEmailAddress').value = '';
    document.getElementById('newEmailDescription').value = '';
    document.getElementById('addEmailError').classList.remove('show');
    document.getElementById('addEmailSuccess').classList.remove('show');
    document.getElementById('addEmailOverlay').classList.add('show');
    document.getElementById('addEmailModal').classList.add('show');
}

function closeAddEmailModal() {
    document.getElementById('addEmailOverlay').classList.remove('show');
    document.getElementById('addEmailModal').classList.remove('show');
}

async function addAuthorizedEmail() {
    if (!currentTeacher) return;
    
    const email = document.getElementById('newEmailAddress').value.trim();
    const description = document.getElementById('newEmailDescription').value.trim();
    
    const errorEl = document.getElementById('addEmailError');
    const successEl = document.getElementById('addEmailSuccess');
    errorEl.classList.remove('show');
    successEl.classList.remove('show');
    
    if (!email) {
        errorEl.textContent = 'Email address is required!';
        errorEl.classList.add('show');
        return;
    }
    
    const payload = {
        teacher_id: currentTeacher.id,
        email: email,
        description: description
    };
    
    const result = await apiAuth('add_authorized_email', payload);
    if (result.success) {
        successEl.textContent = 'Email added successfully!';
        successEl.classList.add('show');
        showToast('Authorized email added successfully!', 'success');
        setTimeout(() => {
            loadAuthorizedAccess();
            closeAddEmailModal();
        }, 1000);
    } else {
        errorEl.textContent = result.message || 'Failed to add email';
        errorEl.classList.add('show');
    }
}

async function revokeAuthorizedEmail(emailId) {
    if (!confirm('Are you sure you want to revoke this email address?')) return;
    
    const result = await apiAuth('revoke_authorized_email', { email_id: emailId });
    if (result.success) {
        showToast('Email revoked successfully!', 'success');
        loadAuthorizedAccess();
    } else {
        showToast(result.message || 'Failed to revoke email', 'error');
    }
}

// ===== TEACHER STUDENTS VIEW TOGGLE =====
function toggleTeacherStudentView() {
    currentTeacherStudentView = currentTeacherStudentView === 'table' ? 'breakdown' : 'table';
    
    const tableView = document.getElementById('teacherStudentsTableView');
    const breakdownView = document.getElementById('teacherStudentsBreakdownView');
    
    if (currentTeacherStudentView === 'table') {
        tableView.style.display = 'block';
        breakdownView.style.display = 'none';
        renderMyStudents();
    } else {
        tableView.style.display = 'none';
        breakdownView.style.display = 'block';
        loadTeacherStudentsBreakdown();
    }
}

async function loadTeacherStudentsBreakdown() {
    const container = document.getElementById('teacherStudentsBreakdownContainer');
    if (!container) return;
    
    console.log('Loading teacher students breakdown...');
    console.log('Current teacher:', currentTeacher);
    
    if (!currentTeacher || !currentTeacher.class) {
        console.log('No class assigned to teacher');
        container.innerHTML = `
            <div class="class-breakdown-empty">
                <i class="fas fa-exclamation-triangle"></i>
                <p>No class assigned. Please contact admin to assign you to a class.</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = '<div class="text-center" style="padding:40px;"><i class="fas fa-spinner fa-spin" style="font-size:24px;"></i><p style="margin-top:12px;">Loading class breakdown...</p></div>';
    
    try {
        const assignedClass = currentTeacher.class;
        console.log('Assigned class:', assignedClass);
        
        // Fetch students from the teacher's assigned class
        const studentsResult = await apiAdmin('students', 'GET');
        console.log('Students API result:', studentsResult);
        
        const students = studentsResult.success ? (studentsResult.data?.items || []) : [];
        console.log('All students:', students);
        
        // Filter students for teacher's assigned class
        const classStudents = students.filter(s => s.grade === assignedClass);
        console.log('Class students:', classStudents);
        
        // Store for export functionality
        teacherClassStudents = classStudents;
        
        if (classStudents.length === 0) {
            console.log('No students found in class:', assignedClass);
            container.innerHTML = `
                <div class="class-breakdown-empty">
                    <i class="fas fa-users"></i>
                    <p>No students found in ${assignedClass}.</p>
                </div>
            `;
            return;
        }
        
        // Calculate class statistics
        const maleCount = classStudents.filter(s => s.gender === 'Male').length;
        const femaleCount = classStudents.filter(s => s.gender === 'Female').length;
        console.log('Gender counts - Male:', maleCount, 'Female:', femaleCount);
        
        // Render class breakdown card (similar to admin format)
        container.innerHTML = `
            <div class="class-breakdown-grid">
                ${renderTeacherClassBreakdownCard(assignedClass, maleCount, femaleCount)}
            </div>
        `;
        
        showToast(`Class breakdown loaded for ${assignedClass}!`, 'success');
    } catch (error) {
        console.error('Error loading teacher students breakdown:', error);
        container.innerHTML = `
            <div class="class-breakdown-empty">
                <i class="fas fa-exclamation-triangle"></i>
                <p>Error loading class breakdown. Please try again.</p>
            </div>
        `;
        showToast('Error loading class breakdown', 'error');
    }
}

// ===== TEACHER CONTRACT SHARING =====
let teacherContracts = [];

async function loadTeacherContent() {
    const tbody = document.getElementById('contentBody');
    if (!tbody) return;
    
    try {
        const result = await apiAdmin('teacher_contracts', 'GET');
        const contracts = result.success ? (result.data?.items || result.data || []) : [];
        
        // Filter contracts for current teacher
        teacherContracts = contracts.filter(c => c.teacherId == currentTeacher.id);
        
        if (teacherContracts.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No contracts uploaded yet.</td></tr>';
            return;
        }
        
        tbody.innerHTML = teacherContracts.map(c => {
            const expiryStatus = getContractStatus(c.expiryDate);
            const approvalStatus = getApprovalStatusClass(c.status);
            return `
            <tr>
                <td><strong>${c.title || 'Untitled Contract'}</strong></td>
                <td><span class="status-badge active">${c.type || 'Employment Contract'}</span></td>
                <td>${c.class || 'N/A'}</td>
                <td>${formatDate(c.expiryDate) || 'N/A'}</td>
                <td><span class="status-badge ${approvalStatus}">${c.status || 'Pending'}</span></td>
                <td>
                    <button class="teacher-btn teacher-btn-sm teacher-btn-info" onclick="viewContent(${c.id})" title="View"><i class="fas fa-eye"></i></button>
                    ${c.status === 'Rejected' ? '' : `<button class="teacher-btn teacher-btn-sm teacher-btn-danger" onclick="deleteContent(${c.id})" title="Delete"><i class="fas fa-trash"></i></button>`}
                </td>
            </tr>
        `}).join('');
        
    } catch (error) {
        console.error('Error loading teacher contracts:', error);
        tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">Error loading contracts.</td></tr>';
    }
}

function getContractStatus(expiryDate) {
    if (!expiryDate) return { text: 'No Expiry', class: 'active' };
    
    const today = new Date();
    const expiry = new Date(expiryDate);
    const daysUntilExpiry = Math.ceil((expiry - today) / (1000 * 60 * 60 * 24));
    
    if (daysUntilExpiry < 0) {
        return { text: 'Expired', class: 'inactive' };
    } else if (daysUntilExpiry <= 30) {
        return { text: 'Expiring Soon', class: 'pending' };
    } else {
        return { text: 'Active', class: 'active' };
    }
}

function getApprovalStatusClass(status) {
    switch(status?.toLowerCase()) {
        case 'approved': return 'active';
        case 'rejected': return 'inactive';
        case 'pending': return 'pending';
        default: return 'active';
    }
}

function openContentUploadModal() {
    document.getElementById('contentUploadModalTitle').innerHTML = '<i class="fas fa-file-contract"></i> Upload Contract';
    document.getElementById('contentUploadEditId').value = '';
    document.getElementById('contentUploadForm').reset();
    
    // Auto-select teacher's assigned class
    if (currentTeacher && currentTeacher.class) {
        const classSelect = document.getElementById('contentClass');
        classSelect.value = currentTeacher.class;
    }
    
    document.getElementById('contentUploadModalOverlay').classList.add('show');
    document.getElementById('contentUploadModal').classList.add('show');
}

function closeContentUploadModal() {
    document.getElementById('contentUploadModalOverlay').classList.remove('show');
    document.getElementById('contentUploadModal').classList.remove('show');
}

async function saveContentUpload(event) {
    event.preventDefault();
    
    const editId = document.getElementById('contentUploadEditId').value;
    const data = {
        title: document.getElementById('contentTitle').value.trim(),
        type: document.getElementById('contentType').value,
        class: document.getElementById('contentClass').value,
        description: document.getElementById('contentDescription').value.trim(),
        expiryDate: document.getElementById('contentExpiryDate').value,
        teacherId: currentTeacher.id,
        status: 'Pending' // Set to pending for admin approval
    };
    
    // Handle file upload (simplified - in real implementation would need file handling)
    const fileInput = document.getElementById('contentFile');
    if (fileInput.files.length > 0) {
        data.fileName = fileInput.files[0].name;
        data.fileSize = fileInput.files[0].size;
    }
    
    try {
        let result;
        if (editId) {
            result = await apiAdmin('teacher_contracts', 'PUT', data, editId);
        } else {
            data.uploadDate = new Date().toISOString();
            result = await apiAdmin('teacher_contracts', 'POST', data);
        }
        
        if (result.success) {
            showToast(editId ? 'Contract updated!' : 'Contract uploaded!');
            closeContentUploadModal();
            loadTeacherContent();
        } else {
            showToast(result.message || 'Failed to save contract', 'error');
        }
    } catch (error) {
        console.error('Error saving contract:', error);
        showToast('Error saving contract', 'error');
    }
    
    return false;
}

async function viewContent(contentId) {
    const contract = teacherContracts.find(c => c.id === contentId);
    if (!contract) {
        showToast('Contract not found', 'error');
        return;
    }
    
    const expiryStatus = getContractStatus(contract.expiryDate);
    
    // Create a simple modal to show contract details
    const modalHtml = `
        <div id="contentDetailsModal" class="teacher-modal" style="display:flex;">
            <div class="teacher-modal-content" style="max-width:600px;">
                <div class="teacher-modal-header">
                    <h3><i class="fas fa-file-contract"></i> Contract Details</h3>
                    <button class="teacher-modal-close" onclick="closeContentDetailsModal()">&times;</button>
                </div>
                <div class="teacher-modal-body">
                    <div class="form-group">
                        <label>Contract Title</label>
                        <div class="form-value">${contract.title || 'N/A'}</div>
                    </div>
                    <div class="form-group">
                        <label>Contract Type</label>
                        <div class="form-value">${contract.type || 'Employment Contract'}</div>
                    </div>
                    <div class="form-group">
                        <label>Class</label>
                        <div class="form-value">${contract.class || 'N/A'}</div>
                    </div>
                    <div class="form-group">
                        <label>Description</label>
                        <div class="form-value">${contract.description || 'No description'}</div>
                    </div>
                    <div class="form-group">
                        <label>Expiry Date</label>
                        <div class="form-value">${formatDate(contract.expiryDate) || 'N/A'}</div>
                    </div>
                    <div class="form-group">
                        <label>Contract Status</label>
                        <div class="form-value"><span class="status-badge ${expiryStatus.class}">${expiryStatus.text}</span></div>
                    </div>
                    <div class="form-group">
                        <label>Approval Status</label>
                        <div class="form-value"><span class="status-badge ${getApprovalStatusClass(contract.status)}">${contract.status || 'Pending'}</span></div>
                    </div>
                    ${contract.status === 'Rejected' && contract.rejectionReason ? `
                    <div class="form-group">
                        <label>Rejection Reason</label>
                        <div class="form-value" style="color: #e74c3c;">${contract.rejectionReason}</div>
                    </div>
                    ` : ''}
                    <div class="form-group">
                        <label>Contract File</label>
                        <div class="form-value">${contract.fileName || 'N/A'}</div>
                    </div>
                    <div class="form-group">
                        <label>Upload Date</label>
                        <div class="form-value">${formatDate(contract.uploadDate) || 'N/A'}</div>
                    </div>
                </div>
                <div class="teacher-modal-footer">
                    <button class="teacher-btn teacher-btn-secondary" onclick="closeContentDetailsModal()">Close</button>
                </div>
            </div>
        </div>
    `;
    
    const existingModal = document.getElementById('contentDetailsModal');
    if (existingModal) {
        existingModal.remove();
    }
    
    document.body.insertAdjacentHTML('beforeend', modalHtml);
}

function closeContentDetailsModal() {
    const modal = document.getElementById('contentDetailsModal');
    if (modal) {
        modal.remove();
    }
}

async function deleteContent(contentId) {
    if (!confirm('Are you sure you want to delete this contract?')) return;
    
    try {
        const result = await apiAdmin('teacher_contracts', 'DELETE', null, contentId);
        if (result.success) {
            showToast('Contract deleted!');
            loadTeacherContent();
        } else {
            showToast(result.message || 'Failed to delete contract', 'error');
        }
    } catch (error) {
        console.error('Error deleting contract:', error);
        showToast('Error deleting contract', 'error');
    }
}

function formatDate(dateString) {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString();
}

// ===== TEACHER MESSAGING =====
let teacherMessages = [];

async function loadTeacherInbox() {
    const container = document.getElementById('teacherMessageInbox');
    const outboxContainer = document.getElementById('teacherMessageOutbox');
    
    if (container) container.style.display = 'block';
    if (outboxContainer) outboxContainer.style.display = 'none';
    
    if (!container) return;
    
    try {
        const result = await apiAdmin('messages', 'GET');
        const allMessages = result.success ? (result.data?.items || result.data || []) : [];
        
        // Filter messages for this teacher (received messages)
        const inboxMessages = allMessages.filter(m => 
            m.recipient === 'All Teachers' || 
            m.recipient === currentTeacher?.firstName + ' ' + currentTeacher?.lastName ||
            m.recipientId === currentTeacher?.id
        );
        
        if (inboxMessages.length === 0) {
            container.innerHTML = '<p class="text-muted">No messages in your inbox.</p>';
            return;
        }
        
        container.innerHTML = inboxMessages.map(m => `
            <div class="message-card" style="background:#f8f9fa;padding:15px;border-radius:8px;margin-bottom:10px;border-left:4px solid ${m.priority === 'Urgent' ? '#e74c3c' : m.priority === 'Important' ? '#f39c12' : '#085636'};">
                <div style="display:flex;justify-content:space-between;align-items:start;">
                    <div>
                        <div style="font-weight:600;font-size:14px;">${m.subject || 'No Subject'}</div>
                        <div style="font-size:12px;color:#666;margin-top:4px;">From: ${m.sender || 'Admin'}</div>
                        <div style="font-size:11px;color:#999;margin-top:2px;">${formatDate(m.date)}</div>
                    </div>
                    <span class="status-badge ${m.priority === 'Urgent' ? 'inactive' : m.priority === 'Important' ? 'pending' : 'active'}">${m.priority || 'Normal'}</span>
                </div>
                <div style="margin-top:10px;font-size:13px;color:#333;">${m.content || 'No content'}</div>
                <div style="margin-top:10px;display:flex;gap:8px;">
                    <button class="teacher-btn teacher-btn-sm teacher-btn-primary" onclick="replyToMessage(${m.id})"><i class="fas fa-reply"></i> Reply</button>
                    <button class="teacher-btn teacher-btn-sm teacher-btn-danger" onclick="deleteMessage(${m.id})"><i class="fas fa-trash"></i> Delete</button>
                </div>
            </div>
        `).join('');
        
    } catch (error) {
        console.error('Error loading teacher inbox:', error);
        container.innerHTML = '<p class="text-muted">Error loading messages.</p>';
    }
}

async function loadTeacherOutbox() {
    const container = document.getElementById('teacherMessageInbox');
    const outboxContainer = document.getElementById('teacherMessageOutbox');
    
    if (container) container.style.display = 'none';
    if (outboxContainer) outboxContainer.style.display = 'block';
    
    if (!outboxContainer) return;
    
    try {
        const result = await apiAdmin('messages', 'GET');
        const allMessages = result.success ? (result.data?.items || result.data || []) : [];
        
        // Filter messages sent by this teacher
        const outboxMessages = allMessages.filter(m => m.senderId === currentTeacher?.id);
        
        if (outboxMessages.length === 0) {
            outboxContainer.innerHTML = '<p class="text-muted">No sent messages.</p>';
            return;
        }
        
        outboxContainer.innerHTML = outboxMessages.map(m => `
            <div class="message-card" style="background:#f8f9fa;padding:15px;border-radius:8px;margin-bottom:10px;border-left:4px solid #085636;">
                <div style="display:flex;justify-content:space-between;align-items:start;">
                    <div>
                        <div style="font-weight:600;font-size:14px;">${m.subject || 'No Subject'}</div>
                        <div style="font-size:12px;color:#666;margin-top:4px;">To: ${m.recipient || 'N/A'}</div>
                        <div style="font-size:11px;color:#999;margin-top:2px;">${formatDate(m.date)}</div>
                    </div>
                    <span class="status-badge active">${m.status || 'Sent'}</span>
                </div>
                <div style="margin-top:10px;font-size:13px;color:#333;">${m.content || 'No content'}</div>
                <div style="margin-top:10px;display:flex;gap:8px;">
                    <button class="teacher-btn teacher-btn-sm teacher-btn-danger" onclick="deleteMessage(${m.id})"><i class="fas fa-trash"></i> Delete</button>
                </div>
            </div>
        `).join('');
        
    } catch (error) {
        console.error('Error loading teacher outbox:', error);
        outboxContainer.innerHTML = '<p class="text-muted">Error loading sent messages.</p>';
    }
}

async function replyToMessage(messageId) {
    const message = teacherMessages.find(m => m.id === messageId);
    if (!message) {
        showToast('Message not found', 'error');
        return;
    }
    
    // Open message modal with pre-filled recipient
    openMessageModal();
    
    // Pre-fill with reply details
    const recipientSelect = document.getElementById('messageRecipient');
    const subjectInput = document.getElementById('messageSubject');
    const contentTextarea = document.getElementById('messageContent');
    
    if (message.sender) {
        // Try to find matching recipient
        for (let i = 0; i < recipientSelect.options.length; i++) {
            if (recipientSelect.options[i].text.includes(message.sender)) {
                recipientSelect.selectedIndex = i;
                break;
            }
        }
    }
    
    subjectInput.value = `Re: ${message.subject || ''}`;
    contentTextarea.value = `\n\n--- Original Message ---\nFrom: ${message.sender}\nDate: ${formatDate(message.date)}\n\n${message.content || ''}`;
}

async function deleteMessage(messageId) {
    if (!confirm('Are you sure you want to delete this message?')) return;
    
    try {
        const result = await apiAdmin('messages', 'DELETE', null, messageId);
        if (result.success) {
            showToast('Message deleted!');
            // Refresh current view
            const inboxVisible = document.getElementById('teacherMessageInbox').style.display !== 'none';
            if (inboxVisible) {
                loadTeacherInbox();
            } else {
                loadTeacherOutbox();
            }
        } else {
            showToast(result.message || 'Failed to delete message', 'error');
        }
    } catch (error) {
        console.error('Error deleting message:', error);
        showToast('Error deleting message', 'error');
    }
}

// ===== TEACHER CLASS COURSES =====
async function loadTeacherClassCourses() {
    const container = document.getElementById('teacherClassCoursesContainer');
    if (!container) return;
    
    if (!currentTeacher || !currentTeacher.class) {
        container.innerHTML = `
            <div class="class-breakdown-empty">
                <i class="fas fa-exclamation-triangle"></i>
                <p>No class assigned. Please contact admin to assign you to a class.</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = '<div class="text-center" style="padding:40px;"><i class="fas fa-spinner fa-spin" style="font-size:24px;"></i><p style="margin-top:12px;">Loading courses...</p></div>';
    
    try {
        const assignedClass = currentTeacher.class;
        
        // Fetch all courses
        const result = await apiAdmin('courses', 'GET');
        const allCourses = result.success ? (result.data?.items || result.data || []) : [];
        
        // Filter courses for the teacher's assigned class
        const classCourses = allCourses.filter(c => c.gradeLevel === assignedClass);
        
        if (classCourses.length === 0) {
            container.innerHTML = `
                <div class="class-breakdown-empty">
                    <i class="fas fa-book"></i>
                    <p>No courses found for ${assignedClass}.</p>
                </div>
            `;
            return;
        }
        
        // Render courses
        container.innerHTML = `
            <div class="courses-grid">
                ${classCourses.map(course => `
                    <div class="course-card">
                        <div class="course-header">
                            <div class="course-icon">
                                <i class="fas fa-book"></i>
                            </div>
                            <div class="course-info">
                                <h4 class="course-title">${course.title || 'Untitled Course'}</h4>
                                <span class="course-code">${course.code || 'N/A'}</span>
                            </div>
                        </div>
                        <div class="course-body">
                            <p class="course-description">${course.description || 'No description available.'}</p>
                            <div class="course-meta">
                                <span class="course-grade"><i class="fas fa-graduation-cap"></i> ${course.gradeLevel || 'N/A'}</span>
                                <span class="course-status status-badge ${course.status?.toLowerCase() === 'active' ? 'active' : 'inactive'}">${course.status || 'Active'}</span>
                            </div>
                        </div>
                        <div class="course-footer">
                            <button class="teacher-btn teacher-btn-sm teacher-btn-primary" onclick="viewCourseDetails(${course.id})">
                                <i class="fas fa-eye"></i> View Details
                            </button>
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
        
        showToast(`Loaded ${classCourses.length} courses for ${assignedClass}!`, 'success');
    } catch (error) {
        console.error('Error loading teacher class courses:', error);
        container.innerHTML = `
            <div class="class-breakdown-empty">
                <i class="fas fa-exclamation-triangle"></i>
                <p>Error loading courses. Please try again.</p>
            </div>
        `;
        showToast('Error loading courses', 'error');
    }
}

async function viewCourseDetails(courseId) {
    try {
        const result = await apiAdmin('courses', 'GET', null, courseId);
        if (!result.success || !result.data) {
            showToast('Failed to load course details', 'error');
            return;
        }
        
        const course = result.data;
        
        // Create a simple modal to show course details
        const modalHtml = `
            <div id="courseDetailsModal" class="teacher-modal" style="display:flex;">
                <div class="teacher-modal-content" style="max-width:600px;">
                    <div class="teacher-modal-header">
                        <h3><i class="fas fa-book"></i> Course Details</h3>
                        <button class="teacher-modal-close" onclick="closeCourseDetailsModal()">&times;</button>
                    </div>
                    <div class="teacher-modal-body">
                        <div class="form-group">
                            <label>Course Title</label>
                            <div class="form-value">${course.title || 'N/A'}</div>
                        </div>
                        <div class="form-group">
                            <label>Course Code</label>
                            <div class="form-value">${course.code || 'N/A'}</div>
                        </div>
                        <div class="form-group">
                            <label>Grade Level</label>
                            <div class="form-value">${course.gradeLevel || 'N/A'}</div>
                        </div>
                        <div class="form-group">
                            <label>Description</label>
                            <div class="form-value">${course.description || 'No description available.'}</div>
                        </div>
                        <div class="form-group">
                            <label>Status</label>
                            <div class="form-value">
                                <span class="status-badge ${course.status?.toLowerCase() === 'active' ? 'active' : 'inactive'}">${course.status || 'Active'}</span>
                            </div>
                        </div>
                    </div>
                    <div class="teacher-modal-footer">
                        <button class="teacher-btn teacher-btn-secondary" onclick="closeCourseDetailsModal()">Close</button>
                    </div>
                </div>
            </div>
        `;
        
        // Add modal to body
        const existingModal = document.getElementById('courseDetailsModal');
        if (existingModal) {
            existingModal.remove();
        }
        
        document.body.insertAdjacentHTML('beforeend', modalHtml);
        
    } catch (error) {
        console.error('Error loading course details:', error);
        showToast('Error loading course details', 'error');
    }
}

function closeCourseDetailsModal() {
    const modal = document.getElementById('courseDetailsModal');
    if (modal) {
        modal.remove();
    }
}

// ===== TEACHER ONBOARDING FUNCTIONS =====
function checkTeacherOnboardingStatus() {
    const onboardingStatus = localStorage.getItem('teacher_onboarding_completed');
    return onboardingStatus === 'true';
}

function initializeTeacherOnboarding() {
    if (!checkTeacherOnboardingStatus()) {
        setTimeout(() => {
            openTeacherOnboarding();
        }, 1000);
    } else {
        const helpButton = document.getElementById('teacherHelpButton');
        if (helpButton) {
            helpButton.style.display = 'flex';
        }
    }
}

function openTeacherOnboarding() {
    teacherOnboardingStep = 1;
    updateTeacherOnboardingUI();
    document.getElementById('teacherOnboardingModal').style.display = 'flex';
}

function closeTeacherOnboarding() {
    document.getElementById('teacherOnboardingModal').style.display = 'none';
}

function nextTeacherOnboardingStep() {
    if (teacherOnboardingStep < teacherTotalOnboardingSteps) {
        teacherOnboardingStep++;
        updateTeacherOnboardingUI();
    }
}

function prevTeacherOnboardingStep() {
    if (teacherOnboardingStep > 1) {
        teacherOnboardingStep--;
        updateTeacherOnboardingUI();
    }
}

function updateTeacherOnboardingUI() {
    // Update progress bar
    const progress = (teacherOnboardingStep / teacherTotalOnboardingSteps) * 100;
    document.getElementById('teacherOnboardingProgress').style.width = progress + '%';
    document.getElementById('teacherOnboardingStep').textContent = teacherOnboardingStep;

    // Hide all steps
    for (let i = 1; i <= teacherTotalOnboardingSteps; i++) {
        document.getElementById(`teacherStep${i}`).style.display = 'none';
    }

    // Show current step
    document.getElementById(`teacherStep${teacherOnboardingStep}`).style.display = 'block';

    // Update buttons
    document.getElementById('teacherOnboardingBack').style.display = teacherOnboardingStep > 1 ? 'inline-block' : 'none';
    document.getElementById('teacherOnboardingNext').style.display = teacherOnboardingStep < teacherTotalOnboardingSteps ? 'inline-block' : 'none';
    document.getElementById('teacherOnboardingComplete').style.display = teacherOnboardingStep === teacherTotalOnboardingSteps ? 'inline-block' : 'none';
}

function completeTeacherOnboarding() {
    localStorage.setItem('teacher_onboarding_completed', 'true');
    teacherOnboardingCompleted = true;
    closeTeacherOnboarding();
}

// ===== SCHEME OF WORK =====
let currentSchemeId = null;

function loadSchemesOfWork() {
    if (!currentTeacher || !currentTeacher.id) return;

    fetch(`${API_BASE}?type=scheme_work&action=list&teacher_id=${currentTeacher.id}`)
        .then(r => r.json())
        .then(response => {
            if (response.success) {
                renderSchemesOfWork(response.data);
            }
        })
        .catch(err => console.error('Error loading schemes:', err));
}

function renderSchemesOfWork(schemes) {
    const tbody = document.getElementById('schemeWorkBody');
    if (!schemes || schemes.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No schemes of work created yet.</td></tr>';
        return;
    }

    tbody.innerHTML = schemes.map(scheme => `
        <tr>
            <td>${scheme.title}</td>
            <td>${scheme.subject}</td>
            <td>${scheme.term}</td>
            <td>${scheme.learning_area || '-'}</td>
            <td>${new Date(scheme.created_at).toLocaleDateString()}</td>
            <td>
                <button class="teacher-btn teacher-btn-sm teacher-btn-primary" onclick="editSchemeOfWork(${scheme.id})"><i class="fas fa-edit"></i></button>
                <button class="teacher-btn teacher-btn-sm teacher-btn-warning" onclick="printSchemeOfWork(${scheme.id})"><i class="fas fa-print"></i></button>
                <button class="teacher-btn teacher-btn-sm teacher-btn-danger" onclick="deleteSchemeOfWork(${scheme.id})"><i class="fas fa-trash"></i></button>
            </td>
        </tr>
    `).join('');
}

function openSchemeOfWorkModal() {
    console.log('Opening new scheme modal');
    currentSchemeId = null;
    document.getElementById('schemeTitle').value = '';
    document.getElementById('schemeSubject').value = '';
    document.getElementById('schemeTerm').value = '';
    document.getElementById('schemePeriods').value = '';
    document.getElementById('schemeLearningArea').value = '';
    document.getElementById('schemeTerms').value = '';
    document.getElementById('schemeNumPeriods').value = '';
    document.getElementById('schemeLearningAreaDisplay').value = '';

    // Clear table data
    clearSchemeTables();

    document.getElementById('schemeOfWorkModal').style.display = 'flex';
}

function closeSchemeOfWorkModal() {
    document.getElementById('schemeOfWorkModal').style.display = 'none';
}

function clearSchemeTables() {
    const leftBody = document.getElementById('leftTableBody');
    const rightBody = document.getElementById('rightTableBody');

    leftBody.innerHTML = Array(20).fill('<tr><td contenteditable="true"></td><td contenteditable="true"></td><td contenteditable="true"></td><td contenteditable="true"></td></tr>').join('');
    rightBody.innerHTML = Array(20).fill('<tr><td contenteditable="true"></td><td contenteditable="true"></td><td contenteditable="true"></td><td contenteditable="true"></td></tr>').join('');
}

function addSchemeRow() {
    const leftBody = document.getElementById('leftTableBody');
    const rightBody = document.getElementById('rightTableBody');

    const leftRow = '<tr><td contenteditable="true"></td><td contenteditable="true"></td><td contenteditable="true"></td><td contenteditable="true"></td></tr>';
    const rightRow = '<tr><td contenteditable="true"></td><td contenteditable="true"></td><td contenteditable="true"></td><td contenteditable="true"></td></tr>';

    leftBody.insertAdjacentHTML('beforeend', leftRow);
    rightBody.insertAdjacentHTML('beforeend', rightRow);
}

function saveSchemeOfWork() {
    if (!currentTeacher || !currentTeacher.id) {
        alert('Teacher not logged in');
        return;
    }

    console.log('Saving scheme for teacher ID:', currentTeacher.id);

    const title = document.getElementById('schemeTitle').value.trim();
    const subject = document.getElementById('schemeSubject').value.trim();
    const term = document.getElementById('schemeTerm').value.trim();
    const numberOfPeriods = document.getElementById('schemePeriods').value || 0;
    const learningArea = document.getElementById('schemeLearningArea').value.trim();

    if (!title || !subject || !term) {
        alert('Title, Subject, and Term are required');
        return;
    }

    // Collect table data
    const leftRows = document.querySelectorAll('#leftTableBody tr');
    const rightRows = document.querySelectorAll('#rightTableBody tr');
    const rows = [];

    for (let i = 0; i < leftRows.length; i++) {
        const leftCells = leftRows[i].querySelectorAll('td');
        const rightCells = rightRows[i].querySelectorAll('td');

        rows.push({
            week_date: leftCells[0].textContent.trim(),
            success_criteria: leftCells[1].textContent.trim(),
            planned_activities: leftCells[2].textContent.trim(),
            teaching_methods: leftCells[3].textContent.trim(),
            resources: rightCells[0].textContent.trim(),
            references: rightCells[1].textContent.trim(),
            outcomes: rightCells[2].textContent.trim(),
            remarks: rightCells[3].textContent.trim()
        });
    }

    const data = {
        teacher_id: currentTeacher.id,
        title,
        subject,
        term,
        number_of_periods: numberOfPeriods,
        learning_area: learningArea,
        rows
    };

    const action = currentSchemeId ? 'update' : 'create';
    if (currentSchemeId) {
        data.id = currentSchemeId;
    }

    fetch(`${API_BASE}?type=scheme_work&action=${action}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    })
    .then(r => r.json())
    .then(response => {
        if (response.success) {
            alert('Scheme of work saved successfully!');
            closeSchemeOfWorkModal();
            loadSchemesOfWork();
        } else {
            alert('Error saving scheme: ' + response.message);
        }
    })
    .catch(err => {
        console.error('Error saving scheme:', err);
        alert('Error saving scheme');
    });
}

function editSchemeOfWork(id) {
    fetch(`${API_BASE}?type=scheme_work&action=get&id=${id}`)
        .then(r => r.json())
        .then(response => {
            if (response.success) {
                const scheme = response.data;
                currentSchemeId = scheme.id;

                document.getElementById('schemeTitle').value = scheme.title;
                document.getElementById('schemeSubject').value = scheme.subject;
                document.getElementById('schemeTerm').value = scheme.term;
                document.getElementById('schemePeriods').value = scheme.number_of_periods;
                document.getElementById('schemeLearningArea').value = scheme.learning_area || '';
                document.getElementById('schemeTerms').value = scheme.term;
                document.getElementById('schemeNumPeriods').value = scheme.number_of_periods;
                document.getElementById('schemeLearningAreaDisplay').value = scheme.learning_area || '';

                // Populate tables
                const leftBody = document.getElementById('leftTableBody');
                const rightBody = document.getElementById('rightTableBody');

                leftBody.innerHTML = '';
                rightBody.innerHTML = '';

                if (scheme.rows && scheme.rows.length > 0) {
                    scheme.rows.forEach(row => {
                        const leftRow = `<tr><td contenteditable="true">${row.week_date || ''}</td><td contenteditable="true">${row.success_criteria || ''}</td><td contenteditable="true">${row.planned_activities || ''}</td><td contenteditable="true">${row.teaching_methods || ''}</td></tr>`;
                        const rightRow = `<tr><td contenteditable="true">${row.resources || ''}</td><td contenteditable="true">${row.references || ''}</td><td contenteditable="true">${row.outcomes || ''}</td><td contenteditable="true">${row.remarks || ''}</td></tr>`;

                        leftBody.insertAdjacentHTML('beforeend', leftRow);
                        rightBody.insertAdjacentHTML('beforeend', rightRow);
                    });
                } else {
                    clearSchemeTables();
                }

                document.getElementById('schemeOfWorkModal').style.display = 'flex';
            }
        })
        .catch(err => console.error('Error loading scheme:', err));
}

function deleteSchemeOfWork(id) {
    if (!confirm('Are you sure you want to delete this scheme of work?')) return;

    fetch(`${API_BASE}?type=scheme_work&action=delete&id=${id}`, {
        method: 'DELETE'
    })
    .then(r => r.json())
    .then(response => {
        if (response.success) {
            alert('Scheme deleted successfully');
            loadSchemesOfWork();
        } else {
            alert('Error deleting scheme: ' + response.message);
        }
    })
    .catch(err => {
        console.error('Error deleting scheme:', err);
        alert('Error deleting scheme');
    });
}

function printSchemeOfWork(id) {
    // Load the scheme and print it
    fetch(`${API_BASE}?type=scheme_work&action=get&id=${id}`)
        .then(r => r.json())
        .then(response => {
            if (response.success) {
                const scheme = response.data;
                // Create a print-friendly version
                const printWindow = window.open('', '_blank');
                printWindow.document.write(`
                    <!DOCTYPE html>
                    <html>
                    <head>
                        <title>${scheme.title} - Scheme of Work</title>
                        <style>
                            body { font-family: Arial, sans-serif; margin: 20px; }
                            .scheme-book { width: 100%; display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
                            .page { min-width: 0; }
                            .left-page { border-right: 2px solid #ccc; padding-right: 10px; }
                            .right-page { padding-left: 10px; }
                            table { width: 100%; border-collapse: collapse; margin-top: 10px; }
                            th, td { border: 1px solid #666; padding: 8px; font-size: 11px; }
                            th { background: #f5f5f5; text-align: center; }
                            .header { margin-bottom: 20px; }
                            .header h1 { margin: 0; }
                            .header p { margin: 5px 0; }
                            @media print { body { margin: 0; } .scheme-book { gap: 0; } .left-page { border-right: 1px solid #666; } }
                        </style>
                    </head>
                    <body>
                        <div class="header">
                            <h1>${scheme.title}</h1>
                            <p><strong>Subject:</strong> ${scheme.subject} | <strong>Term:</strong> ${scheme.term} | <strong>Learning Area:</strong> ${scheme.learning_area || '-'}</p>
                        </div>
                        <div class="scheme-book">
                            <div class="page left-page">
                                <table>
                                    <thead>
                                        <tr><th>Week/Date</th><th>Success Criteria</th><th>Planned Activities</th><th>Methods</th></tr>
                                    </thead>
                                    <tbody>
                                        ${scheme.rows.map(row => `<tr><td>${row.week_date || ''}</td><td>${row.success_criteria || ''}</td><td>${row.planned_activities || ''}</td><td>${row.teaching_methods || ''}</td></tr>`).join('')}
                                    </tbody>
                                </table>
                            </div>
                            <div class="page right-page">
                                <table>
                                    <thead>
                                        <tr><th>Resources</th><th>References</th><th>Outcomes</th><th>Remarks</th></tr>
                                    </thead>
                                    <tbody>
                                        ${scheme.rows.map(row => `<tr><td>${row.resources || ''}</td><td>${row.references || ''}</td><td>${row.outcomes || ''}</td><td>${row.remarks || ''}</td></tr>`).join('')}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </body>
                    </html>
                `);
                printWindow.document.close();
                printWindow.print();
            }
        })
        .catch(err => console.error('Error printing scheme:', err));
}

function exportSchemeAsWord() {
    const title = document.getElementById('schemeTitle').value || 'Scheme of Work';
    const content = document.getElementById('schemeOfWorkEditor').innerHTML;

    const htmlContent = `
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <title>${title}</title>
        </head>
        <body>
            <h1>${title}</h1>
            ${content}
        </body>
        </html>
    `;

    const blob = new Blob([htmlContent], { type: 'application/msword' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${title}.doc`;
    a.click();
    URL.revokeObjectURL(url);
}

function exportSchemeAsPDF() {
    // Simple print to PDF
    const originalContent = document.body.innerHTML;
    const schemeContent = document.getElementById('schemeOfWorkEditor').innerHTML;
    const title = document.getElementById('schemeTitle').value || 'Scheme of Work';

    document.body.innerHTML = `
        <div style="padding: 20px;">
            <h1>${title}</h1>
            ${schemeContent}
        </div>
    `;

    window.print();

    document.body.innerHTML = originalContent;
    location.reload();
}

function exportSchemeAsExcel() {
    const leftRows = document.querySelectorAll('#leftTableBody tr');
    const rightRows = document.querySelectorAll('#rightTableBody tr');

    let csv = 'Week/Date,Success Criteria,Planned Activities,Teaching Methods,Resources,References,Outcomes,Remarks\n';

    for (let i = 0; i < leftRows.length; i++) {
        const leftCells = leftRows[i].querySelectorAll('td');
        const rightCells = rightRows[i] ? rightRows[i].querySelectorAll('td') : [];

        const row = [
            leftCells[0].textContent.trim(),
            leftCells[1].textContent.trim(),
            leftCells[2].textContent.trim(),
            leftCells[3].textContent.trim(),
            rightCells[0].textContent.trim(),
            rightCells[1].textContent.trim(),
            rightCells[2].textContent.trim(),
            rightCells[3].textContent.trim()
        ].map(cell => `"${cell.replace(/"/g, '""')}"`).join(',');

        csv += row + '\n';
    }

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'scheme_of_work.csv';
    a.click();
    URL.revokeObjectURL(url);
}

function completeTeacherOnboarding() {
    localStorage.setItem('teacher_onboarding_completed', 'true');
    teacherOnboardingCompleted = true;
    closeTeacherOnboarding();
    const helpButton = document.getElementById('teacherHelpButton');
    if (helpButton) {
        helpButton.style.display = 'flex';
    }
    showToast('Welcome aboard! You can always revisit this tutorial by clicking the help button.', 'success');
}

function skipTeacherOnboarding() {
    if (confirm('Are you sure you want to skip this tutorial? You can always access it later from the help button.')) {
        completeTeacherOnboarding();
    }
}

// ===== TEACHER CLASS BREAKDOWN =====
async function loadTeacherClassBreakdown() {
    const container = document.getElementById('teacherClassBreakdownContainer') || document.getElementById('teacherCoursesClassBreakdownContainer');
    if (!container) return;
    
    if (!currentTeacher || !currentTeacher.class) {
        container.innerHTML = `
            <div class="class-breakdown-empty">
                <i class="fas fa-exclamation-triangle"></i>
                <p>No class assigned. Please contact admin to assign you to a class.</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = '<div class="text-center" style="padding:40px;"><i class="fas fa-spinner fa-spin" style="font-size:24px;"></i><p style="margin-top:12px;">Loading class breakdown...</p></div>';
    
    try {
        const assignedClass = currentTeacher.class;
        
        // Fetch students from the teacher's assigned class
        const studentsResult = await apiAdmin('students', 'GET');
        const students = studentsResult.success ? (studentsResult.data?.items || []) : [];
        
        // Filter students for teacher's assigned class
        const classStudents = students.filter(s => s.grade === assignedClass);
        
        // Store for export functionality
        teacherClassStudents = classStudents;
        
        if (classStudents.length === 0) {
            container.innerHTML = `
                <div class="class-breakdown-empty">
                    <i class="fas fa-users"></i>
                    <p>No students found in ${assignedClass}.</p>
                </div>
            `;
            return;
        }
        
        // Calculate class statistics
        const maleCount = classStudents.filter(s => s.gender === 'Male').length;
        const femaleCount = classStudents.filter(s => s.gender === 'Female').length;
        
        // Render class breakdown card (similar to admin format)
        container.innerHTML = `
            <div class="class-breakdown-grid">
                ${renderTeacherClassBreakdownCard(assignedClass, maleCount, femaleCount)}
            </div>
        `;
        
        showToast(`Class breakdown loaded for ${assignedClass}!`, 'success');
    } catch (error) {
        console.error('Error loading teacher class breakdown:', error);
        container.innerHTML = `
            <div class="class-breakdown-empty">
                <i class="fas fa-exclamation-triangle"></i>
                <p>Error loading class breakdown. Please try again.</p>
            </div>
        `;
        showToast('Error loading class breakdown', 'error');
    }
}

function renderTeacherClassBreakdownCard(className, maleCount, femaleCount) {
    const students = teacherClassStudents || [];
    const totalStudents = students.length;
    
    // Create student list for the card
    const studentList = students.map((student, index) => `
        <div style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid #eee;">
            <div style="width:24px;height:24px;background:var(--primary);color:white;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:600;">
                ${index + 1}
            </div>
            <div style="flex:1;">
                <div style="font-weight:600;font-size:13px;">${student.firstName} ${student.lastName}</div>
                <div style="font-size:11px;color:#666;">${student.parent || 'No parent info'}</div>
            </div>
            <div style="font-size:11px;color:${student.gender === 'Male' ? '#3498db' : '#e74c3c'};font-weight:600;">
                ${student.gender}
            </div>
        </div>
    `).join('');
    
    return `
        <div class="class-breakdown-card">
            <div class="class-breakdown-header">
                <div class="class-breakdown-title">
                    <i class="fas fa-graduation-cap"></i>
                    ${className}
                </div>
                <span class="status-badge active">${totalStudents} Students</span>
            </div>
            
            <div class="class-breakdown-stats">
                <div class="class-breakdown-stat male">
                    <div class="class-breakdown-stat-value">${maleCount}</div>
                    <div class="class-breakdown-stat-label">Male</div>
                </div>
                <div class="class-breakdown-stat female">
                    <div class="class-breakdown-stat-value">${femaleCount}</div>
                    <div class="class-breakdown-stat-label">Female</div>
                </div>
                <div class="class-breakdown-stat total">
                    <div class="class-breakdown-stat-value">${totalStudents}</div>
                    <div class="class-breakdown-stat-label">Total</div>
                </div>
            </div>
            
            <div class="class-breakdown-teachers">
                <div style="font-size:13px;font-weight:600;color:var(--text-dark);margin-bottom:8px;">
                    <i class="fas fa-user-graduate"></i> Students in Class
                </div>
                <div style="max-height:300px;overflow-y:auto;padding-right:5px;">
                    ${studentList}
                </div>
            </div>
            
            <div style="margin-top:16px;display:flex;gap:8px;flex-wrap:wrap;">
                <button class="teacher-btn teacher-btn-primary teacher-btn-sm" onclick="showSection('students')" style="flex:1;min-width:120px;">
                    <i class="fas fa-users"></i> View All Students
                </button>
                <button class="teacher-btn teacher-btn-success teacher-btn-sm" onclick="exportTeacherClassData()" style="flex:1;min-width:120px;">
                    <i class="fas fa-download"></i> Export
                </button>
                <button class="teacher-btn teacher-btn-warning teacher-btn-sm" onclick="leaveTeacherClass()" style="flex:1;min-width:120px;">
                    <i class="fas fa-sign-out-alt"></i> Leave Class
                </button>
            </div>
        </div>
    `;
}

async function exportTeacherClassData() {
    if (!currentTeacher || !currentTeacher.class) {
        showToast('No class assigned to export', 'error');
        return;
    }
    
    try {
        showToast(`Exporting data for ${currentTeacher.class}...`, 'info');
        
        // Use stored class students if available, otherwise fetch from API
        let classStudents = teacherClassStudents || [];
        if (classStudents.length === 0) {
            const studentsResult = await apiAdmin('students', 'GET');
            const students = studentsResult.success ? (studentsResult.data?.items || []) : [];
            classStudents = students.filter(s => s.grade === currentTeacher.class);
        }
        
        if (classStudents.length === 0) {
            showToast('No students to export', 'error');
            return;
        }
        
        // Create CSV content
        const headers = ['Student ID', 'First Name', 'Last Name', 'Gender', 'Grade', 'Parent/Guardian', 'Contact Number', 'Address', 'Date of Birth'];
        const csvRows = [headers.join(',')];
        
        classStudents.forEach(student => {
            const row = [
                student.id || '',
                `"${(student.firstName || '').replace(/"/g, '""')}"`,
                `"${(student.lastName || '').replace(/"/g, '""')}"`,
                student.gender || '',
                `"${(student.grade || '').replace(/"/g, '""')}"`,
                `"${(student.parent || '').replace(/"/g, '""')}"`,
                `"${(student.parentPhone || student.contactNumber || '').replace(/"/g, '""')}"`,
                `"${(student.address || '').replace(/"/g, '""')}"`,
                student.dateOfBirth || ''
            ];
            csvRows.push(row.join(','));
        });
        
        const csvContent = csvRows.join('\n');
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        
        // Create filename with class name and date
        const date = new Date().toISOString().split('T')[0];
        const className = currentTeacher.class.replace(/\s+/g, '_');
        link.setAttribute('href', url);
        link.setAttribute('download', `${className}_students_${date}.csv`);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        showToast(`Successfully exported ${classStudents.length} students from ${currentTeacher.class}!`, 'success');
    } catch (error) {
        console.error('Error exporting class data:', error);
        showToast('Error exporting class data', 'error');
    }
}

async function leaveTeacherClass() {
    if (!currentTeacher || !currentTeacher.class) {
        showToast('No class assigned to leave', 'error');
        return;
    }
    
    const previousClass = currentTeacher.class;
    
    // Confirm the action
    if (!confirm(`Are you sure you want to leave ${previousClass}? This will remove your assignment to this class. You can contact admin to be reassigned to a different class.`)) {
        return;
    }

    try {
        showToast('Leaving class...', 'info');
        
        // Update teacher profile to remove class assignment
        const updateData = {
            classAssigned: '',
            class: ''
        };
        
        const result = await apiAdmin('teachers', 'PUT', updateData, currentTeacher.id);
        
        if (result.success) {
            // Update local teacher data
            currentTeacher.class = '';
            currentTeacher.classAssigned = '';
            teacherClassStudents = [];
            
            // Update UI elements
            const teacherClassBadge = document.getElementById('teacherClassBadge');
            if (teacherClassBadge) {
                teacherClassBadge.textContent = 'No Class Assigned';
            }
            
            const welcomeClass = document.getElementById('teacherWelcomeClass');
            if (welcomeClass) {
                welcomeClass.innerHTML = '<i class="fas fa-users"></i> Class: Not Assigned';
            }
            
            // Clear myStudents as they're no longer relevant
            myStudents = [];
            
            // Refresh the class breakdown section
            loadTeacherClassBreakdown();
            
            // Update session storage
            const savedUser = loadTeacherSession();
            if (savedUser) {
                savedUser.class = '';
                savedUser.classAssigned = '';
                if (localStorage.getItem('noh_teacher_session')) {
                    localStorage.setItem('noh_teacher_session', JSON.stringify(savedUser));
                } else {
                    sessionStorage.setItem('noh_teacher_session', JSON.stringify(savedUser));
                }
            }
            
            showToast(`Successfully left ${previousClass}. Contact admin for new class assignment.`, 'success');
        } else {
            showToast(result.message || 'Failed to leave class', 'error');
        }
    } catch (error) {
        console.error('Error leaving class:', error);
        showToast('Error leaving class', 'error');
    }
}

// Lesson plan functions for window exports
window.openLessonPlanModal = openLessonPlanModal;
window.closeLessonPlanModal = closeLessonPlanModal;
window.saveLessonPlan = saveLessonPlan;
window.loadLessonPlans = loadLessonPlans;
window.editLessonPlan = editLessonPlan;
window.deleteLessonPlan = deleteLessonPlan;
window.printLessonPlan = printLessonPlan;
window.printLessonPlanById = printLessonPlanById;
window.viewLessonPlan = viewLessonPlan;
window.closeLessonPlanViewModal = closeLessonPlanViewModal;

// Behavior log functions for window exports
window.openBehaviorModal = openBehaviorModal;
window.closeBehaviorModal = closeBehaviorModal;
window.saveBehavior = saveBehavior;
window.deleteBehavior = deleteBehavior;

// Auth functions for window exports
window.switchAuthTab = switchAuthTab;
window.togglePasswordVisibility = togglePasswordVisibility;
window.handleTeacherLogin = handleTeacherLogin;
window.handleTeacherRegister = handleTeacherRegister;
window.handleTeacherLogout = handleTeacherLogout;
window.loadLoginHistory = loadLoginHistory;
window.openAddIpModal = openAddIpModal;
window.closeAddIpModal = closeAddIpModal;
window.addAuthorizedIp = addAuthorizedIp;
window.revokeAuthorizedIp = revokeAuthorizedIp;
window.openAddEmailModal = openAddEmailModal;
window.closeAddEmailModal = closeAddEmailModal;
window.addAuthorizedEmail = addAuthorizedEmail;
window.revokeAuthorizedEmail = revokeAuthorizedEmail;
window.loadTeacherClassBreakdown = loadTeacherClassBreakdown;
window.renderTeacherClassBreakdownCard = renderTeacherClassBreakdownCard;
window.exportTeacherClassData = exportTeacherClassData;
window.leaveTeacherClass = leaveTeacherClass;
window.toggleTeacherStudentView = toggleTeacherStudentView;
window.loadTeacherStudentsBreakdown = loadTeacherStudentsBreakdown;
window.loadTeacherClassCourses = loadTeacherClassCourses;
window.viewCourseDetails = viewCourseDetails;
window.closeCourseDetailsModal = closeCourseDetailsModal;
window.loadTeacherContent = loadTeacherContent;
window.openContentUploadModal = openContentUploadModal;
window.closeContentUploadModal = closeContentUploadModal;
window.saveContentUpload = saveContentUpload;
window.viewContent = viewContent;
window.closeContentDetailsModal = closeContentDetailsModal;
window.deleteContent = deleteContent;
window.loadTeacherInbox = loadTeacherInbox;
window.loadTeacherOutbox = loadTeacherOutbox;
window.replyToMessage = replyToMessage;
window.deleteMessage = deleteMessage;

// Report functions for window exports
window.viewPrintReport = viewPrintReport;
window.downloadReportPDF = downloadReportPDF;
window.deleteReport = deleteReport;
window.editReport = editReport;
window.openSignatureModal = openSignatureModal;
window.openReportModal = openReportModal;
window.closeReportModal = closeReportModal;
window.openSendReportModal = openSendReportModal;
window.closeSendReportModal = closeSendReportModal;
window.handleSendReportSubmit = handleSendReportSubmit;
window.sendReportToAdmin = sendReportToAdmin;
window.sendReportToTeacher = sendReportToTeacher;
window.sendReportToParent = sendReportToParent;
window.loadParentsForStudent = loadParentsForStudent;
window.loadClassColleaguesForSharing = loadClassColleaguesForSharing;
window.generateSimpleBarcode = generateSimpleBarcode;
window.viewLessonPlan = viewLessonPlan;
window.closeLessonPlanViewModal = closeLessonPlanViewModal;

// Behavior log functions for window exports
window.openBehaviorModal = openBehaviorModal;
window.closeBehaviorModal = closeBehaviorModal;
window.saveBehavior = saveBehavior;
window.deleteBehavior = deleteBehavior;

// ===== LESSON PLANS =====
let currentLessonPlanId = null;

function openLessonPlanModal() {
    document.getElementById('lessonPlanForm').reset();
    currentLessonPlanId = null;
    document.getElementById('lessonPlanModalOverlay').classList.add('show');
    document.getElementById('lessonPlanModal').classList.add('show');
}

function closeLessonPlanModal() {
    document.getElementById('lessonPlanModalOverlay').classList.remove('show');
    document.getElementById('lessonPlanModal').classList.remove('show');
}

function saveLessonPlan(event) {
    event.preventDefault();

    const lessonPlanData = {
        teacher_id: currentTeacher.id,
        class: document.getElementById('lessonPlanClass').value,
        date: document.getElementById('lessonPlanDate').value,
        time: document.getElementById('lessonPlanTime').value,
        subject: document.getElementById('lessonPlanSubject').value,
        success_criteria: document.getElementById('lessonPlanSuccessCriteria').value,
        materials: document.getElementById('lessonPlanMaterials').value,
        intro_teacher: document.getElementById('lessonPlanIntroTeacher').value,
        intro_learner: document.getElementById('lessonPlanIntroLearner').value,
        step1_teacher: document.getElementById('lessonPlanStep1Teacher').value,
        step1_learner: document.getElementById('lessonPlanStep1Learner').value,
        step2_teacher: document.getElementById('lessonPlanStep2Teacher').value,
        step2_learner: document.getElementById('lessonPlanStep2Learner').value,
        step3_teacher: document.getElementById('lessonPlanStep3Teacher').value,
        step3_learner: document.getElementById('lessonPlanStep3Learner').value,
        conclusion_teacher: document.getElementById('lessonPlanConclusionTeacher').value,
        conclusion_learner: document.getElementById('lessonPlanConclusionLearner').value
    };

    if (currentLessonPlanId) {
        lessonPlanData.id = currentLessonPlanId;
    }

    fetch(`${API_BASE}?type=teacher&action=lesson_plan&subaction=save`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(lessonPlanData)
    })
    .then(r => r.json())
    .then(response => {
        if (response.success) {
            alert('Lesson plan saved successfully');
            closeLessonPlanModal();
            loadLessonPlans();
        } else {
            alert('Error saving lesson plan: ' + response.message);
        }
    })
    .catch(err => {
        console.error('Error saving lesson plan:', err);
        alert('Error saving lesson plan');
    });
}

function loadLessonPlans() {
    if (!currentTeacher || !currentTeacher.id) return;

    fetch(`${API_BASE}?type=teacher&action=lesson_plan&subaction=list&teacher_id=${currentTeacher.id}`)
        .then(r => r.json())
        .then(response => {
            if (response.success) {
                renderLessonPlans(response.data);
            }
        })
        .catch(err => console.error('Error loading lesson plans:', err));
}

function renderLessonPlans(plans) {
    const tbody = document.getElementById('lessonPlanBody');
    if (!plans || plans.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No lesson plans created yet.</td></tr>';
        return;
    }

    tbody.innerHTML = plans.map(plan => `
        <tr>
            <td>${plan.class || '-'}</td>
            <td>${plan.date || '-'}</td>
            <td>${plan.time || '-'}</td>
            <td>${plan.subject || '-'}</td>
            <td>${new Date(plan.created_at).toLocaleDateString()}</td>
            <td>
                <button class="teacher-btn teacher-btn-sm teacher-btn-primary" onclick="editLessonPlan(${plan.id})"><i class="fas fa-edit"></i></button>
                <button class="teacher-btn teacher-btn-sm teacher-btn-warning" onclick="printLessonPlanById(${plan.id})"><i class="fas fa-print"></i></button>
                <button class="teacher-btn teacher-btn-sm teacher-btn-danger" onclick="deleteLessonPlan(${plan.id})"><i class="fas fa-trash"></i></button>
            </td>
        </tr>
    `).join('');
}

function editLessonPlan(id) {
    fetch(`${API_BASE}?type=teacher&action=lesson_plan&subaction=get&id=${id}`)
        .then(r => r.json())
        .then(response => {
            if (response.success) {
                const plan = response.data;
                currentLessonPlanId = plan.id;

                document.getElementById('lessonPlanClass').value = plan.class || '';
                document.getElementById('lessonPlanDate').value = plan.date || '';
                document.getElementById('lessonPlanTime').value = plan.time || '';
                document.getElementById('lessonPlanSubject').value = plan.subject || '';
                document.getElementById('lessonPlanSuccessCriteria').value = plan.success_criteria || '';
                document.getElementById('lessonPlanMaterials').value = plan.materials || '';
                document.getElementById('lessonPlanIntroTeacher').value = plan.intro_teacher || '';
                document.getElementById('lessonPlanIntroLearner').value = plan.intro_learner || '';
                document.getElementById('lessonPlanStep1Teacher').value = plan.step1_teacher || '';
                document.getElementById('lessonPlanStep1Learner').value = plan.step1_learner || '';
                document.getElementById('lessonPlanStep2Teacher').value = plan.step2_teacher || '';
                document.getElementById('lessonPlanStep2Learner').value = plan.step2_learner || '';
                document.getElementById('lessonPlanStep3Teacher').value = plan.step3_teacher || '';
                document.getElementById('lessonPlanStep3Learner').value = plan.step3_learner || '';
                document.getElementById('lessonPlanConclusionTeacher').value = plan.conclusion_teacher || '';
                document.getElementById('lessonPlanConclusionLearner').value = plan.conclusion_learner || '';

                document.getElementById('lessonPlanModalOverlay').classList.add('show');
                document.getElementById('lessonPlanModal').classList.add('show');
            }
        })
        .catch(err => console.error('Error loading lesson plan:', err));
}

function deleteLessonPlan(id) {
    if (!confirm('Are you sure you want to delete this lesson plan?')) return;

    fetch(`${API_BASE}?type=teacher&action=lesson_plan&subaction=delete&id=${id}`, {
        method: 'DELETE'
    })
    .then(r => r.json())
    .then(response => {
        if (response.success) {
            alert('Lesson plan deleted successfully');
            loadLessonPlans();
        } else {
            alert('Error deleting lesson plan: ' + response.message);
        }
    })
    .catch(err => {
        console.error('Error deleting lesson plan:', err);
        alert('Error deleting lesson plan');
    });
}

function printLessonPlan() {
    const printWindow = window.open('', '_blank');
    const lessonPlanContent = document.getElementById('lessonPlanModal').innerHTML;

    printWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>Lesson Plan</title>
            <link rel="stylesheet" href="../css/teacher.css">
            <style>
                body { padding: 20px; }
                .progress-modal-footer, .progress-modal-close { display: none !important; }
                .lesson-plan-input, .lesson-plan-textarea, .lesson-plan-table-textarea {
                    border: none;
                    padding: 0;
                    resize: none;
                    background: transparent;
                }
                .lesson-plan-textarea, .lesson-plan-table-textarea {
                    min-height: auto;
                }
            </style>
        </head>
        <body>
            ${lessonPlanContent}
        </body>
        </html>
    `);
    printWindow.document.close();
    printWindow.print();
}

function printLessonPlanById(id) {
    fetch(`${API_BASE}?type=teacher&action=lesson_plan&subaction=get&id=${id}`)
        .then(r => r.json())
        .then(response => {
            if (response.success) {
                const plan = response.data;
                const printWindow = window.open('', '_blank');

                printWindow.document.write(`
                    <!DOCTYPE html>
                    <html>
                    <head>
                        <title>Lesson Plan - ${plan.subject}</title>
                        <link rel="stylesheet" href="../css/teacher.css">
                        <style>
                            body { padding: 20px; }
                            .lesson-plan-input, .lesson-plan-textarea, .lesson-plan-table-textarea {
                                border: none;
                                padding: 0;
                                resize: none;
                                background: transparent;
                            }
                            .lesson-plan-textarea, .lesson-plan-table-textarea {
                                min-height: auto;
                            }
                        </style>
                    </head>
                    <body>
                        <div class="lesson-plan-header">
                            <div class="lesson-plan-row">
                                <div class="lesson-plan-field">
                                    <label>Class:</label>
                                    <div>${plan.class || '-'}</div>
                                </div>
                                <div class="lesson-plan-field">
                                    <label>Date:</label>
                                    <div>${plan.date || '-'}</div>
                                </div>
                                <div class="lesson-plan-field">
                                    <label>Time:</label>
                                    <div>${plan.time || '-'}</div>
                                </div>
                            </div>
                            <div class="lesson-plan-row">
                                <div class="lesson-plan-field">
                                    <label>Subject:</label>
                                    <div>${plan.subject || '-'}</div>
                                </div>
                            </div>
                        </div>
                        <div class="lesson-plan-section">
                            <label>Success Criteria</label>
                            <p class="lesson-plan-sublabel">-Learners must be able to:</p>
                            <div>${plan.success_criteria || '-'}</div>
                        </div>
                        <div class="lesson-plan-section">
                            <label>Materials</label>
                            <div>${plan.materials || '-'}</div>
                        </div>
                        <div class="lesson-plan-table-container">
                            <table class="lesson-plan-table">
                                <thead>
                                    <tr>
                                        <th class="lesson-plan-th-left">TEACHER'S ACTIVITIES</th>
                                        <th class="lesson-plan-th-right">LEARNERS ACTIVITIES</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="lesson-plan-section-header">
                                            <u>Introduction</u>
                                            <div>${plan.intro_teacher || '-'}</div>
                                        </td>
                                        <td class="lesson-plan-section-header">
                                            <u>Introduction</u>
                                            <div>${plan.intro_learner || '-'}</div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="2" class="lesson-plan-section-title">
                                            <u>Developmental steps</u>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="lesson-plan-step-header">
                                            <u>Step 1</u>
                                            <div>${plan.step1_teacher || '-'}</div>
                                        </td>
                                        <td class="lesson-plan-step-header">
                                            <u>Step 1</u>
                                            <div>${plan.step1_learner || '-'}</div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="lesson-plan-step-header">
                                            <u>Step 2</u>
                                            <div>${plan.step2_teacher || '-'}</div>
                                        </td>
                                        <td class="lesson-plan-step-header">
                                            <u>Step 2</u>
                                            <div>${plan.step2_learner || '-'}</div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="lesson-plan-step-header">
                                            <u>Step 3</u>
                                            <div>${plan.step3_teacher || '-'}</div>
                                        </td>
                                        <td class="lesson-plan-step-header">
                                            <u>Step 3</u>
                                            <div>${plan.step3_learner || '-'}</div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="lesson-plan-section-header">
                                            <u>Conclusion</u>
                                            <div>${plan.conclusion_teacher || '-'}</div>
                                        </td>
                                        <td class="lesson-plan-section-header">
                                            <u>Conclusion</u>
                                            <div>${plan.conclusion_learner || '-'}</div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </body>
                    </html>
                `);
                printWindow.document.close();
                printWindow.print();
            }
        })
        .catch(err => console.error('Error loading lesson plan for print:', err));
}

// ===== INIT =====
document.addEventListener('DOMContentLoaded', async function() {
    // Try auto-login first (now async to handle OAuth token)
    const loggedIn = await autoLogin();
    if (!loggedIn) {
        document.getElementById('authScreen').style.display = 'flex';
        document.getElementById('teacherDashboard').style.display = 'none';
    }

    // Setup note type change event listener
    const noteTypeSelect = document.getElementById('noteType');
    if (noteTypeSelect) {
        noteTypeSelect.addEventListener('change', function() {
            const noteStudentGroup = document.getElementById('noteStudentGroup');
            if (noteStudentGroup) {
                noteStudentGroup.style.display = this.value === 'student' ? 'block' : 'none';
            }
        });
    }

    // Handle radio button changes for send options
    const radioButtons = document.querySelectorAll('input[name="sendTo"]');
    const teacherSelectGroup = document.getElementById('teacherSelectGroup');
    const parentSelectGroup = document.getElementById('parentSelectGroup');
    const priorityGroup = document.getElementById('priorityGroup');

    radioButtons.forEach(radio => {
        radio.addEventListener('change', function() {
            if (this.value === 'admin') {
                teacherSelectGroup.style.display = 'none';
                parentSelectGroup.style.display = 'none';
                priorityGroup.style.display = 'block';
            } else if (this.value === 'teacher') {
                teacherSelectGroup.style.display = 'block';
                parentSelectGroup.style.display = 'none';
                priorityGroup.style.display = 'none';
            } else if (this.value === 'parent') {
                teacherSelectGroup.style.display = 'none';
                parentSelectGroup.style.display = 'block';
                priorityGroup.style.display = 'none';
            }
        });
    });
});

// Auth functions for window exports
window.switchAuthTab = switchAuthTab;
window.togglePasswordVisibility = togglePasswordVisibility;
window.handleTeacherLogin = handleTeacherLogin;
window.handleTeacherRegister = handleTeacherRegister;
window.handleTeacherLogout = handleTeacherLogout;
window.loadLoginHistory = loadLoginHistory;
window.openAddIpModal = openAddIpModal;
window.closeAddIpModal = closeAddIpModal;
window.addAuthorizedIp = addAuthorizedIp;
window.revokeAuthorizedIp = revokeAuthorizedIp;
window.openAddEmailModal = openAddEmailModal;
window.closeAddEmailModal = closeAddEmailModal;
window.addAuthorizedEmail = addAuthorizedEmail;
window.revokeAuthorizedEmail = revokeAuthorizedEmail;
window.loadTeacherClassBreakdown = loadTeacherClassBreakdown;
window.renderTeacherClassBreakdownCard = renderTeacherClassBreakdownCard;
window.exportTeacherClassData = exportTeacherClassData;
window.leaveTeacherClass = leaveTeacherClass;
window.toggleTeacherStudentView = toggleTeacherStudentView;
window.loadTeacherStudentsBreakdown = loadTeacherStudentsBreakdown;
window.loadTeacherClassCourses = loadTeacherClassCourses;
window.viewCourseDetails = viewCourseDetails;
window.closeCourseDetailsModal = closeCourseDetailsModal;
window.loadTeacherContent = loadTeacherContent;
window.openContentUploadModal = openContentUploadModal;
window.closeContentUploadModal = closeContentUploadModal;
window.saveContentUpload = saveContentUpload;
window.viewContent = viewContent;
window.closeContentDetailsModal = closeContentDetailsModal;
window.deleteContent = deleteContent;
window.loadTeacherInbox = loadTeacherInbox;
window.loadTeacherOutbox = loadTeacherOutbox;
window.replyToMessage = replyToMessage;
window.deleteMessage = deleteMessage;

// Report functions for window exports
window.viewPrintReport = viewPrintReport;
window.downloadReportPDF = downloadReportPDF;
window.deleteReport = deleteReport;
window.editReport = editReport;
window.openSignatureModal = openSignatureModal;
window.openReportModal = openReportModal;
window.closeReportModal = closeReportModal;
window.openSendReportModal = openSendReportModal;
window.closeSendReportModal = closeSendReportModal;
window.handleSendReportSubmit = handleSendReportSubmit;
window.sendReportToAdmin = sendReportToAdmin;
window.sendReportToTeacher = sendReportToTeacher;
window.sendReportToParent = sendReportToParent;
window.loadParentsForStudent = loadParentsForStudent;
window.loadClassColleaguesForSharing = loadClassColleaguesForSharing;
window.generateSimpleBarcode = generateSimpleBarcode;

// Auth functions for window exports
window.switchAuthTab = switchAuthTab;
window.showRegStep1 = showRegStep1;
window.showRegStep2 = showRegStep2;
window.showRegStep3 = showRegStep3;
window.verifyTeacherCode = verifyTeacherCode;
