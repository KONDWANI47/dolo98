/**
 * VISITOR TRACKER - Noah Christian Academy
 * Tracks visitors and sends data to the server database
 */
(function() {
  'use strict';

  const SESSION_KEY = 'nca_visitor_session_v2';
  // Determine correct API path based on current page location
  const path = window.location.pathname;
  let API_URL = 'api/index.php?type=visitors&action=track';
  if (path.includes('/html/')) API_URL = '../api/index.php?type=visitors&action=track';
  else if (path.includes('/dashboard/')) API_URL = '../api/index.php?type=visitors&action=track';
  else if (path.includes('/admin/')) API_URL = '../api/index.php?type=visitors&action=track';

  // Generate session ID
  function getSessionId() {
    let sid = localStorage.getItem(SESSION_KEY);
    if (!sid) {
      sid = 'sid_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
      localStorage.setItem(SESSION_KEY, sid);
    }
    return sid;
  }

  // Get browser info
  function getBrowserInfo() {
    const ua = navigator.userAgent;
    if (ua.indexOf('Chrome') > -1 && ua.indexOf('Edg') === -1) return 'Chrome';
    if (ua.indexOf('Firefox') > -1) return 'Firefox';
    if (ua.indexOf('Safari') > -1 && ua.indexOf('Chrome') === -1) return 'Safari';
    if (ua.indexOf('Edg') > -1) return 'Edge';
    if (ua.indexOf('MSIE') > -1 || ua.indexOf('Trident') > -1) return 'Internet Explorer';
    if (ua.indexOf('Opera') > -1 || ua.indexOf('OPR') > -1) return 'Opera';
    return 'Unknown';
  }

  // Get OS info
  function getOSInfo() {
    const ua = navigator.userAgent;
    if (ua.indexOf('Windows NT 10.0') > -1) return 'Windows 10/11';
    if (ua.indexOf('Windows NT 6.3') > -1) return 'Windows 8.1';
    if (ua.indexOf('Windows NT 6.2') > -1) return 'Windows 8';
    if (ua.indexOf('Windows NT 6.1') > -1) return 'Windows 7';
    if (ua.indexOf('Mac OS X') > -1) return 'macOS';
    if (ua.indexOf('Linux') > -1 && ua.indexOf('Android') === -1) return 'Linux';
    if (ua.indexOf('Android') > -1) return 'Android';
    if (ua.indexOf('iPhone') > -1 || ua.indexOf('iPad') > -1) return 'iOS';
    return 'Unknown';
  }

  // Get device type
  function getDeviceType() {
    const ua = navigator.userAgent;
    if (/Mobile|Android|iPhone|iPod|BlackBerry|IEMobile|Opera Mini/i.test(ua)) {
      if (/iPad|Tablet|PlayBook|Silk/i.test(ua)) return 'Tablet';
      return 'Mobile';
    }
    return 'Desktop';
  }

  // Get current page
  function getCurrentPage() {
    const path = window.location.pathname;
    return path.substring(path.lastIndexOf('/') + 1) || 'index.html';
  }

  // Get referrer
  function getReferrer() {
    return document.referrer || 'Direct';
  }

  // Send visit data to server
  function trackVisit() {
    // Throttle: only send once per page per 60 seconds
    const lastLog = localStorage.getItem('nca_last_track_' + getCurrentPage());
    const now = Date.now();
    if (lastLog && (now - parseInt(lastLog)) < 60000) return;
    localStorage.setItem('nca_last_track_' + getCurrentPage(), String(now));

    const data = {
      ip: '', // Server will capture REMOTE_ADDR
      location: '',
      browser: getBrowserInfo(),
      os: getOSInfo(),
      device: getDeviceType(),
      page: getCurrentPage(),
      referrer: getReferrer(),
      sessionId: getSessionId()
    };

    try {
      const xhr = new XMLHttpRequest();
      xhr.open('POST', API_URL, true);
      xhr.setRequestHeader('Content-Type', 'application/json');
      xhr.timeout = 5000;
      xhr.send(JSON.stringify(data));
    } catch (e) {
      // Silent fail
    }
  }

  // Initialize
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', trackVisit);
  } else {
    trackVisit();
  }

  // Expose API for admin panel
  window.NCATracker = {
    getLogs: function() {
      try {
        const stored = localStorage.getItem('nca_visitor_logs');
        return stored ? JSON.parse(stored) : [];
      } catch(e) { return []; }
    },
    clearLogs: function() {
      localStorage.removeItem('nca_visitor_logs');
    },
    getStats: function() {
      const logs = this.getLogs();
      const uniqueIPs = new Set(logs.map(l => l.ip));
      return {
        totalVisits: logs.length,
        uniqueVisitors: uniqueIPs.size,
        browsers: [...new Set(logs.map(l => l.browser))].reduce((acc, b) => { acc[b] = logs.filter(l => l.browser === b).length; return acc; }, {}),
        devices: [...new Set(logs.map(l => l.device))].reduce((acc, d) => { acc[d] = logs.filter(l => l.device === d).length; return acc; }, {})
      };
    }
  };
})();