// Cookie Consent Management
document.addEventListener('DOMContentLoaded', function() {
    const cookieConsent = document.getElementById('cookieConsent');
    const acceptButton = document.getElementById('acceptCookies');
    
    // Check if user has already made a cookie choice
    function getCookieChoice() {
        return localStorage.getItem('cookieChoice');
    }
    
    // Save user's cookie choice
    function setCookieChoice(choice) {
        localStorage.setItem('cookieChoice', choice);
        
        // Set expiration for 1 year
        const expirationDate = new Date();
        expirationDate.setFullYear(expirationDate.getFullYear() + 1);
        localStorage.setItem('cookieChoiceExpiration', expirationDate.toISOString());
    }
    
    // Check if cookie choice has expired
    function isCookieChoiceExpired() {
        const expiration = localStorage.getItem('cookieChoiceExpiration');
        if (!expiration) return true;
        
        const expirationDate = new Date(expiration);
        return new Date() > expirationDate;
    }
    
    // Show cookie consent banner
    function showCookieConsent() {
        cookieConsent.style.display = 'block';
    }
    
    // Hide cookie consent banner
    function hideCookieConsent() {
        cookieConsent.style.display = 'none';
    }
    
    // Apply cookie settings based on user choice
    function applyCookieSettings(choice) {
        switch(choice) {
            case 'allow':
                // Enable all cookies (analytics, marketing, etc.)
                console.log('All cookies allowed');
                // You can enable Google Analytics, other tracking scripts here
                break;
            case 'essential':
                // Only essential cookies
                console.log('Essential cookies only');
                // Disable non-essential tracking
                break;
            case 'deny':
                // Deny all cookies
                console.log('All cookies denied');
                // Disable all tracking
                break;
        }
    }
    
    // Initialize cookie consent
    function initCookieConsent() {
        const existingChoice = getCookieChoice();
        
        if (!existingChoice || isCookieChoiceExpired()) {
            // Show banner if no choice or choice expired
            showCookieConsent();
        } else {
            // Apply existing choice
            applyCookieSettings(existingChoice);
            hideCookieConsent();
        }
    }
    
    // Handle accept button click
    acceptButton.addEventListener('click', function() {
        const selectedChoice = document.querySelector('input[name="cookieChoice"]:checked').value;
        setCookieChoice(selectedChoice);
        applyCookieSettings(selectedChoice);
        hideCookieConsent();
    });
    
    // Initialize on page load
    initCookieConsent();
    
    // Optional: Add function to reset cookie choice (for testing)
    window.resetCookieChoice = function() {
        localStorage.removeItem('cookieChoice');
        localStorage.removeItem('cookieChoiceExpiration');
        location.reload();
    };
});
