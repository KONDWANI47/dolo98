/**
 * Error Handling Middleware - Noah Christian Academy
 */

window.onerror = function(msg, src, line, col, err) {
    console.log('Error caught:', msg);
    return true;
};

window.addEventListener('unhandledrejection', e => e.preventDefault());

const originalFetch = window.fetch;
window.fetch = function(...args) {
    return originalFetch.apply(this, args).catch(err => {
        console.log('Fetch error:', err);
        return new Response(JSON.stringify({success:false}), {status:200,headers:{'Content-Type':'application/json'}});
    });
};

document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('img').forEach(img => {
        img.addEventListener('error', () => img.style.display = 'none');
    });
});

console.log('Error handler loaded');
