# Noah Christian Academy — Engineering Audit & Repair

## Source reviewed

- Original archive: `noah.zip`
- Original database dump: `noh.sql` / `if0_42680773_noh.sql`
- Original archive contained 148 entries:
  - 34 PHP
  - 12 JavaScript
  - 6 CSS
  - HTML pages, uploads, fonts, SQL backups and API modules.

## Static validation

- PHP syntax: **PASS** — all original PHP files parsed successfully.
- JavaScript syntax: **PASS** — all original JavaScript files passed Node syntax checking.
- PHP include/require target scan: **PASS** — no missing literal include/require targets.
- Route/reference scan found several genuine broken references.

## Repairs made

### 1. Registration POST / 404 path
The public registration code in `script.js` used a relative API URL. The API resolver now derives the `/api/` directory from the loaded `script.js` URL, so it works from both the website root and nested HTML pages.

### 2. Broken job-application endpoints
The archive referenced API files that were missing:
- `api/get_applications.php`
- `api/get_application_details.php`
- `api/submit_application.php`
- `api/update_application_status.php`
- `api/delete_application.php`

Compatibility endpoints were added and connected to the existing `job_applications` and `application_documents` tables.

The existing database uses `created_at`, not `applied_at`, so application retrieval was corrected to expose `created_at AS applied_at` for the existing JavaScript.

### 3. Broken HTML paths
Incorrect nested links such as `html/html/about.html` were corrected to local `about.html`, `features.html`, and `contact.html` links.

Admin links to teacher/parent portals were corrected to the actual `dashboard/` location.

### 4. Local subdirectory 404 behavior
The root `.htaccess` custom 404 target was changed from an absolute `/index.html` path to a relative `index.html` target so the application also works when installed under a local XAMPP subdirectory such as `/noah/`.

### 5. Database compatibility issues found during code/schema comparison
The application referenced fields not present in the supplied database schema. `database/auth_upgrade.sql` adds compatibility fields for:
- teacher/parent/admin email verification
- teacher active status
- student email
- student gallery image
- calendar-event attachments
- account-deletion admin notes
- parent report-access messages

This migration is additive and is intended to preserve existing data.

## Authentication redesign

The previous teacher/parent flow depended on admin approval and registration codes.

The repaired design changes the account lifecycle to:

1. Teacher or parent registers with a valid real email address.
2. The account is created as active/approved in the application.
3. A secure email verification token is generated.
4. A verification email is sent.
5. The user verifies the email.
6. Login accepts either the registered email address or the legacy username.
7. Existing accounts are treated as verified during migration so existing users are not unexpectedly locked out.

The admin dashboard no longer displays teacher/parent approval or registration-code controls. It displays email-verification status instead.

Other approval features in the school system (such as testimonials and school reports) are preserved.

## Composer / real-email support

`composer.json` was added with:
- `phpmailer/phpmailer`
- `google/apiclient`

The archive also includes:
- `auth.php` — starts optional Google OAuth
- `callback.php` — handles Google OAuth callback
- `api/email_service.php` — PHPMailer SMTP delivery with local `mail()` fallback
- `verify-email.html` — email verification page
- `.env.example` — configuration template
- `COMPOSER_INSTALL.md` — installation instructions

### Important

A real `vendor/` dependency tree was **not fabricated**. This environment has no Composer package download access, so the archive contains the Composer definition and setup instructions. On a machine with Composer/network access, run:

```bash
composer install
```

This creates the real `vendor/autoload.php` and dependency files.

Do not upload real SMTP passwords, Google client secrets, or other credentials into the public website repository.

## Existing functionality preserved

The repair does not remove the existing major modules, including:
- Admin
- Teacher portal
- Parent portal
- Students
- Parents
- Teachers
- Classes
- Subjects/Courses
- Assessments/results
- Attendance
- Timetable
- Payments
- Announcements
- Events
- Gallery
- Blog
- Testimonials
- PTA
- Messaging
- Vacancies/job applications
- Reports
- Notifications
- Visitor tracking
- Account deletion
- API/payment configuration

## Deployment sequence

1. Back up the production database.
2. Upload the repaired website files.
3. Import `database/auth_upgrade.sql`.
4. Configure database credentials for the target environment.
5. Configure SMTP values from `.env.example`.
6. Run `composer install` in the website root.
7. Configure Google OAuth only if Google sign-in is required.
8. Test:
   - public registration
   - teacher registration and email verification
   - parent registration and email verification
   - teacher email login
   - parent email login
   - admin email/username login
   - job application submission
   - admin job application management
   - existing teacher/parent login
   - announcements in teacher/parent portals
   - payment and other existing API functions.

## Security note

The supplied source contains environment-specific database credentials. For production, move those credentials to server environment variables or a protected configuration outside the public web root. Do not commit them to Git or expose them in downloadable public archives.
