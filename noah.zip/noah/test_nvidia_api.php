<?php
/**
 * Test NVIDIA API connection and list available models
 */

$apiKey = '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';
$baseUrl = 'https://integrate.api.nvidia.com/v1';

echo "Testing NVIDIA API Connection...\n\n";

// Test 1: List available models
echo "1. Fetching available models...\n";
$ch = curl_init($baseUrl . '/models');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Authorization: Bearer ' . $apiKey
]);
curl_setopt($ch, CURLOPT_TIMEOUT, 30);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$error = curl_error($ch);
curl_close($ch);

if ($error) {
    echo "ERROR: " . $error . "\n";
} else {
    echo "HTTP Status: " . $httpCode . "\n";
    echo "Response: " . $response . "\n\n";
}

// Test 2: Try a simple chat completion
echo "2. Testing chat completion with meta/llama-3.1-70b-instruct...\n";
$ch = curl_init($baseUrl . '/chat/completions');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
    'model' => 'meta/llama-3.1-70b-instruct',
    'messages' => [
        ['role' => 'user', 'content' => 'Hello, say "API working"']
    ],
    'max_tokens' => 50
]));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Authorization: Bearer ' . $apiKey
]);
curl_setopt($ch, CURLOPT_TIMEOUT, 60);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$error = curl_error($ch);
curl_close($ch);

if ($error) {
    echo "ERROR: " . $error . "\n";
} else {
    echo "HTTP Status: " . $httpCode . "\n";
    echo "Response: " . $response . "\n\n";
}

echo "Test complete.\n";
?>
