-- Certificate Tables Setup for Noah Christian Academy
-- This schema supports a professional certificate designer and generator

-- Certificate Templates Table
CREATE TABLE IF NOT EXISTS certificate_templates (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    category VARCHAR(100) DEFAULT 'Academic',
    tags VARCHAR(500),
    canvas_width INT DEFAULT 1123,
    canvas_height INT DEFAULT 794,
    unit VARCHAR(10) DEFAULT 'px',
    orientation VARCHAR(20) DEFAULT 'landscape',
    background_type VARCHAR(20) DEFAULT 'solid',
    background_color VARCHAR(20) DEFAULT '#FFFFFF',
    background_image VARCHAR(500),
    design_json LONGTEXT,
    preview_image VARCHAR(500),
    created_by INT,
    created_by_name VARCHAR(255),
    is_system_template TINYINT(1) DEFAULT 0,
    is_public TINYINT(1) DEFAULT 1,
    status VARCHAR(20) DEFAULT 'active',
    usage_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_category (category),
    INDEX idx_created_by (created_by),
    INDEX idx_status (status),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Certificate Records Table (Generated Certificates)
CREATE TABLE IF NOT EXISTS certificate_records (
    id INT PRIMARY KEY AUTO_INCREMENT,
    template_id INT,
    certificate_number VARCHAR(100) UNIQUE,
    student_id INT,
    student_name VARCHAR(255),
    student_class VARCHAR(100),
    award_title VARCHAR(255),
    description TEXT,
    date_issued DATE,
    academic_year VARCHAR(20),
    generated_by INT,
    generated_by_name VARCHAR(255),
    qr_code_url VARCHAR(500),
    pdf_url VARCHAR(500),
    verification_url VARCHAR(500),
    status VARCHAR(20) DEFAULT 'active',
    data_json LONGTEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (template_id) REFERENCES certificate_templates(id) ON DELETE SET NULL,
    INDEX idx_template_id (template_id),
    INDEX idx_student_id (student_id),
    INDEX idx_certificate_number (certificate_number),
    INDEX idx_date_issued (date_issued),
    INDEX idx_academic_year (academic_year),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Certificate Assets Table (Logos, Signatures, Backgrounds, etc.)
CREATE TABLE IF NOT EXISTS certificate_assets (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    type VARCHAR(50) NOT NULL,
    category VARCHAR(50) DEFAULT 'general',
    file_url VARCHAR(500) NOT NULL,
    file_name VARCHAR(255),
    file_size INT,
    file_type VARCHAR(100),
    uploaded_by INT,
    uploaded_by_name VARCHAR(255),
    description TEXT,
    is_public TINYINT(1) DEFAULT 1,
    usage_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_type (type),
    INDEX idx_category (category),
    INDEX idx_uploaded_by (uploaded_by)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Certificate Categories Table
CREATE TABLE IF NOT EXISTS certificate_categories (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    icon VARCHAR(50),
    color VARCHAR(20),
    sort_order INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default categories
INSERT INTO certificate_categories (name, description, icon, color, sort_order) VALUES
('Academic', 'Academic achievement certificates', 'fa-graduation-cap', '#085636', 1),
('Achievement', 'General achievement awards', 'fa-trophy', '#f39c12', 2),
('Graduation', 'Graduation and completion certificates', 'fa-certificate', '#9b59b6', 3),
('Participation', 'Participation and attendance certificates', 'fa-users', '#3498db', 4),
('Appreciation', 'Appreciation and recognition certificates', 'fa-heart', '#e74c3c', 5),
('Sports', 'Sports and athletic achievements', 'fa-running', '#27ae60', 6),
('Leadership', 'Leadership and service awards', 'fa-crown', '#8e44ad', 7),
('Teacher', 'Teacher and staff recognition', 'fa-chalkboard-teacher', '#2980b9', 8);

-- Certificate Verification Log
CREATE TABLE IF NOT EXISTS certificate_verification_log (
    id INT PRIMARY KEY AUTO_INCREMENT,
    certificate_id INT,
    certificate_number VARCHAR(100),
    verification_result VARCHAR(20),
    ip_address VARCHAR(50),
    user_agent TEXT,
    verified_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_certificate_id (certificate_id),
    INDEX idx_certificate_number (certificate_number),
    INDEX idx_verified_at (verified_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
