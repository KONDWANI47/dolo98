-- Noah Christian Academy authentication upgrade
-- Run after importing the existing database.
-- Existing accounts remain usable; only newly registered accounts require email verification.

ALTER TABLE admins
  ADD COLUMN IF NOT EXISTS email_verified TINYINT(1) NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS email_verification_token VARCHAR(128) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS email_verification_expires DATETIME DEFAULT NULL;

ALTER TABLE teachers
  ADD COLUMN IF NOT EXISTS email_verified TINYINT(1) NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS email_verification_token VARCHAR(128) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS email_verification_expires DATETIME DEFAULT NULL;

ALTER TABLE parents
  ADD COLUMN IF NOT EXISTS email_verified TINYINT(1) NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS email_verification_token VARCHAR(128) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS email_verification_expires DATETIME DEFAULT NULL;

-- Existing records are trusted for backward compatibility.
UPDATE admins SET email_verified = 1 WHERE email_verified IS NULL;
UPDATE teachers SET email_verified = 1 WHERE email_verified IS NULL;
UPDATE parents SET email_verified = 1 WHERE email_verified IS NULL;

-- Compatibility columns used by existing application modules.
ALTER TABLE teachers
  ADD COLUMN IF NOT EXISTS is_active TINYINT(1) NOT NULL DEFAULT 1;

ALTER TABLE students
  ADD COLUMN IF NOT EXISTS email VARCHAR(200) DEFAULT '';

ALTER TABLE students
  ADD COLUMN IF NOT EXISTS gallery_image VARCHAR(500) DEFAULT NULL;

ALTER TABLE calendar_events
  ADD COLUMN IF NOT EXISTS attachment_path VARCHAR(500) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS attachment_name VARCHAR(255) DEFAULT NULL;

ALTER TABLE account_deletion_requests
  ADD COLUMN IF NOT EXISTS admin_notes TEXT DEFAULT NULL;

ALTER TABLE parent_report_access
  ADD COLUMN IF NOT EXISTS message TEXT DEFAULT NULL;
