-- Add admin_notes column to account_deletion_requests table
ALTER TABLE account_deletion_requests ADD COLUMN admin_notes TEXT AFTER processed_by;
