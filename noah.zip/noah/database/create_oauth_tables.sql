-- OAuth Login Tokens Table for Noah Christian Academy
-- This table stores temporary tokens for Google OAuth login flow
-- Run this in your MySQL database (e.g., via phpMyAdmin)

CREATE TABLE IF NOT EXISTS `oauth_login_tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token_hash` char(64) NOT NULL,
  `user_type` varchar(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `token_hash` (`token_hash`),
  KEY `idx_oauth_user` (`user_type`, `user_id`),
  KEY `idx_oauth_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
