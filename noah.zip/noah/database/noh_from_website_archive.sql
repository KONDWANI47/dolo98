-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql105.infinityfree.com
-- Generation Time: Sep 29, 2026 at 12:06 PM
-- Server version: 11.4.13-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `if0_42680773_noh`
--

-- --------------------------------------------------------

--
-- Table structure for table `account_deletion_requests`
--

CREATE TABLE `account_deletion_requests` (
  `id` int(11) NOT NULL,
  `user_type` varchar(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `requested_at` datetime NOT NULL,
  `scheduled_deletion_at` datetime NOT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `processed_at` datetime DEFAULT NULL,
  `processed_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `account_deletion_requests`
--

INSERT INTO `account_deletion_requests` (`id`, `user_type`, `user_id`, `user_name`, `email`, `requested_at`, `scheduled_deletion_at`, `status`, `processed_at`, `processed_by`, `created_at`) VALUES
(1, 'parent', 14, 'cupicsart@gmail.com ', 'cupicsart@gmail.com', '2026-09-04 10:00:04', '2026-09-05 10:00:04', 'cancelled', '2026-09-04 10:15:03', NULL, '2026-09-04 08:00:04'),
(2, 'parent', 14, 'cupicsart@gmail.com ', 'cupicsart@gmail.com', '2026-09-04 10:15:20', '2026-09-05 10:15:20', 'cancelled', '2026-09-04 10:15:36', NULL, '2026-09-04 08:15:20'),
(3, 'parent', 14, 'cupicsart@gmail.com ', 'cupicsart@gmail.com', '2026-09-04 10:15:48', '2026-09-05 10:15:48', 'cancelled', '2026-09-04 10:15:52', NULL, '2026-09-04 08:15:48'),
(4, 'teacher', 23, 'cupicsart@gmail.com Chilima', 'gumbo@gmail.com', '2026-09-04 10:16:32', '2026-09-05 10:16:32', 'cancelled', '2026-09-04 10:33:16', NULL, '2026-09-04 08:16:32'),
(5, 'parent', 14, 'cupicsart@gmail.com ', 'cupicsart@gmail.com', '2026-09-04 10:32:45', '2026-09-05 10:32:45', 'cancelled', '2026-09-04 10:32:52', NULL, '2026-09-04 08:32:45'),
(6, 'teacher', 23, 'cupicsart@gmail.com Chilima', 'gumbo@gmail.com', '2026-09-04 10:33:22', '2026-09-05 10:33:22', 'cancelled', '2026-09-04 10:33:38', NULL, '2026-09-04 08:33:22'),
(7, 'teacher', 23, 'cupicsart@gmail.com Chilima', 'gumbo@gmail.com', '2026-09-04 11:21:50', '2026-09-05 11:21:50', 'cancelled', '2026-09-04 11:21:56', NULL, '2026-09-04 09:21:50'),
(8, 'teacher', 24, 'chisomo chiko', 'ch@gmil.com', '2026-09-04 12:34:23', '2026-09-05 12:34:23', 'cancelled', '2026-09-04 13:07:46', NULL, '2026-09-04 10:34:23'),
(9, 'teacher', 24, 'chisomo chiko', 'ch@gmil.com', '2026-09-04 13:43:39', '2026-09-05 13:43:39', 'cancelled', '2026-09-04 13:43:46', NULL, '2026-09-04 11:43:39'),
(10, 'parent', 14, 'cupicsart@gmail.com ', 'cupicsart@gmail.com', '2026-09-05 00:19:48', '2026-09-06 00:19:48', 'cancelled', '2026-09-05 00:19:55', NULL, '2026-09-04 22:19:48'),
(11, 'teacher', 23, 'cupicsart@gmail.com Chilima', 'gumbo@gmail.com', '2026-09-05 02:52:39', '2026-09-06 02:52:39', 'cancelled', '2026-09-05 02:52:44', NULL, '2026-09-05 00:52:39'),
(12, 'teacher', 23, 'cupicsart@gmail.com Chilima', 'gumbo@gmail.com', '2026-09-05 22:41:17', '2026-09-06 22:41:17', 'cancelled', '2026-09-05 22:41:24', NULL, '2026-09-05 20:41:17'),
(13, 'teacher', 25, 'kondwni kpichi', 'kondwni@gmil.com', '2026-09-06 20:22:47', '2026-09-07 20:22:47', 'cancelled', '2026-09-06 20:22:52', NULL, '2026-09-06 18:22:47'),
(14, 'parent', 14, 'cupicsart keen', 'cupicsart@gmail.com', '2026-09-07 01:01:42', '2026-09-08 01:01:42', 'cancelled', '2026-09-07 01:01:47', NULL, '2026-09-06 23:01:42');

-- --------------------------------------------------------

--
-- Table structure for table `activity_log`
--

CREATE TABLE `activity_log` (
  `id` int(11) NOT NULL,
  `action` varchar(255) NOT NULL,
  `detail` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `activity_log`
--

INSERT INTO `activity_log` (`id`, `action`, `detail`, `created_at`) VALUES
(1, 'New Registration', 'Test Student registered for Standard 5', '2026-07-25 10:25:46'),
(2, 'New Payment', 'Test Payer - MK50,000.00', '2026-07-25 10:27:54'),
(3, 'Login', 'Admin logged in (password upgraded to hash)', '2026-07-25 10:27:56'),
(4, 'Student Created', 'Test Student auto-created from registration #6', '2026-07-25 10:35:51'),
(5, 'Registration Updated', 'Registration #6 status: Approved', '2026-07-25 10:35:51'),
(6, 'Login', 'Admin logged in', '2026-07-25 10:53:22'),
(7, 'New Registration', 'kape mape registered for Daycare', '2026-07-25 11:20:14'),
(8, 'New Registration', 'kape mape registered for Daycare', '2026-07-25 11:35:25'),
(9, 'Login', 'Admin logged in', '2026-07-25 11:48:07'),
(10, 'Teacher Login', 'Alice Kamanga logged in', '2026-07-25 11:48:07'),
(11, 'Parent Login', 'John Banda logged in', '2026-07-25 11:48:07'),
(12, 'New Registration', 'Test Student registered for Standard 1', '2026-07-25 11:48:07'),
(13, 'Teacher Registered', 'gumbo@gmail.com created an account (pending approval)', '2026-07-25 11:50:00'),
(14, 'Teacher Updated', 'Teacher #9 updated', '2026-07-25 11:50:31'),
(15, 'Teacher Login', 'gumbo@gmail.com  logged in', '2026-07-25 11:50:39'),
(16, 'Teacher Updated', 'Teacher #9 updated', '2026-07-25 11:51:37'),
(17, 'Registration Updated', 'Registration #9 status: Approved', '2026-07-25 11:53:15'),
(18, 'Teacher Updated', 'Teacher #9 updated', '2026-07-25 11:54:29'),
(19, 'Teacher Updated', 'Teacher #9 updated', '2026-07-25 11:54:42'),
(20, 'New Registration', 'Jane Banda registered for Standard 2', '2026-07-25 11:54:57'),
(21, 'New Registration', 'kape mape registered for Daycare', '2026-07-25 12:00:08'),
(22, 'Vacancie Created', 'New Vacancie added (#5)', '2026-07-25 12:01:34'),
(23, 'Vacancie Created', 'New Vacancie added (#6)', '2026-07-25 12:05:08'),
(24, 'Student Created', 'kape mape auto-created from registration #11', '2026-07-25 12:07:26'),
(25, 'Registration Updated', 'Registration #11 status: Approved', '2026-07-25 12:07:26'),
(26, 'Student Linked', 'kape mape linked to registration #8', '2026-07-25 12:07:42'),
(27, 'Registration Updated', 'Registration #8 status: Approved', '2026-07-25 12:07:42'),
(28, 'New Payment', 'kape mape - MK50000', '2026-07-25 12:08:03'),
(29, 'New Registration', 'dolo ktttgsh registered for Daycare', '2026-07-25 12:08:55'),
(30, 'Student Created', 'dolo ktttgsh auto-created from registration #12', '2026-07-25 12:09:05'),
(31, 'Registration Updated', 'Registration #12 status: Approved', '2026-07-25 12:09:05'),
(32, 'Payment Updated', 'Payment #10 status: Paid', '2026-07-25 12:10:25'),
(33, 'Payment Updated', 'Payment #9 status: Paid', '2026-07-25 12:10:27'),
(34, 'Payment Updated', 'Payment #8 status: Paid', '2026-07-25 12:10:28'),
(35, 'Payment Updated', 'Payment #8 updated', '2026-07-25 12:10:39'),
(36, 'Registration Deleted', 'Registration #12 deleted', '2026-07-25 19:11:11'),
(37, 'Vacancie Created', 'New Vacancie added (#7)', '2026-07-25 19:11:35'),
(38, 'Teacher Login', 'gumbo@gmail.com mape logged in', '2026-07-25 19:31:56'),
(39, 'Teacher Updated', 'Teacher #9 updated', '2026-07-25 19:32:26'),
(40, 'Course Created', 'New Course added (#9)', '2026-07-25 19:51:16'),
(41, 'Teacher Deleted', 'Teacher #8 deleted', '2026-07-25 19:53:42'),
(42, 'Teacher Updated', 'Teacher #9 updated', '2026-07-25 20:23:25'),
(43, 'Teacher Login', 'gumbo@gmail.com mape logged in', '2026-07-25 20:23:54'),
(44, 'Course Created', 'New Course added (#10)', '2026-07-25 20:24:58'),
(45, 'Course Created', 'New Course added (#11)', '2026-07-25 20:25:51'),
(46, 'Event Deleted', 'Event #5 deleted', '2026-07-25 20:27:41'),
(47, 'New Registration', 'dolo ktttgsh registered for Daycare', '2026-07-25 20:38:13'),
(48, 'Student Linked', 'dolo ktttgsh linked to registration #13', '2026-07-25 20:38:25'),
(49, 'Registration Updated', 'Registration #13 status: Approved', '2026-07-25 20:38:25'),
(50, 'Student Linked', 'kape mape linked to registration #7', '2026-07-25 20:38:41'),
(51, 'Registration Updated', 'Registration #7 status: Approved', '2026-07-25 20:38:41'),
(52, 'Student Created', 'Wezzie Mhango auto-created from registration #5', '2026-07-25 20:38:43'),
(53, 'Registration Updated', 'Registration #5 status: Approved', '2026-07-25 20:38:43'),
(54, 'Student Created', 'Chisomo Moyo auto-created from registration #3', '2026-07-25 20:38:45'),
(55, 'Registration Updated', 'Registration #3 status: Approved', '2026-07-25 20:38:45'),
(56, 'New Registration', 'maxwell banda registered for Daycare', '2026-07-25 20:40:04'),
(57, 'Student Created', 'maxwell banda auto-created from registration #14', '2026-07-25 20:40:23'),
(58, 'Registration Updated', 'Registration #14 status: Approved', '2026-07-25 20:40:23'),
(59, 'New Payment', 'maxwell banda - MK6000', '2026-07-25 20:40:41'),
(60, 'Payment Updated', 'Payment #11 status: Paid', '2026-07-25 20:40:56'),
(61, 'Vacancie Created', 'New Vacancie added (#8)', '2026-07-25 20:42:10'),
(62, 'Vacancie Created', 'New Vacancie added (#9)', '2026-07-25 21:02:15'),
(63, 'Teacher Updated', 'Teacher #9 updated', '2026-07-25 21:14:01'),
(64, 'Teacher Login', 'gumbo@gmail.com mape logged in', '2026-07-25 21:14:38'),
(65, 'Course Created', 'New Course added (#12)', '2026-07-25 21:15:49'),
(66, 'Payment Updated', 'Payment #2 status: Paid', '2026-07-25 21:19:19'),
(67, 'Payment Updated', 'Payment #7 status: Paid', '2026-07-25 21:19:23'),
(68, 'Event Created', 'New Event added (#6)', '2026-07-25 21:22:20'),
(69, 'Teacher Login', 'gumbo@gmail.com mape logged in', '2026-07-25 21:28:31'),
(70, 'Event Updated', 'Event #4 updated', '2026-07-25 21:45:40'),
(71, 'Announcement Updated', 'Announcement #2 updated', '2026-07-25 21:47:29'),
(72, 'Announcement Updated', 'Announcement #1 updated', '2026-07-25 21:49:41'),
(73, 'Gallery Updated', 'Gallery #8 updated', '2026-07-25 21:53:27'),
(74, 'Settings Updated', 'Admin settings were updated', '2026-07-25 21:55:24'),
(75, 'Gallery Updated', 'Gallery #8 updated', '2026-07-25 22:04:04'),
(76, 'Announcement Updated', 'Announcement #2 updated', '2026-07-25 22:12:07'),
(77, 'Announcement Updated', 'Announcement #1 updated', '2026-07-25 22:12:28'),
(78, 'Assessment Created', 'Assessment for Chisomo Moyo - english: 90%', '2026-07-25 22:17:31'),
(79, 'Assessment Created', 'Assessment for Chisomo Moyo - english: 30%', '2026-07-25 22:23:12'),
(80, 'Assessment Created', 'Assessment for dolo ktttgsh - english: 30%', '2026-07-25 22:23:20'),
(81, 'Teacher Updated', 'Teacher #3 updated', '2026-07-25 22:27:51'),
(82, 'Assessment Created', 'Assessment for maxwell banda - english: 89%', '2026-07-25 22:28:30'),
(83, 'Assessment Created', 'Assessment for kape mape - chichew: 100%', '2026-07-25 22:29:09'),
(84, 'Bulk Attendance', 'Marked attendance for 4 students on 2026-07-25', '2026-07-25 22:30:59'),
(85, 'Gallery Deleted', 'Gallery #8 deleted', '2026-07-25 22:31:31'),
(86, 'Gallery Deleted', 'Gallery #5 deleted', '2026-07-25 22:31:36'),
(87, 'Gallery Deleted', 'Gallery #4 deleted', '2026-07-25 22:31:40'),
(88, 'Gallery Deleted', 'Gallery #2 deleted', '2026-07-25 22:31:44'),
(89, 'Gallery Deleted', 'Gallery #1 deleted', '2026-07-25 22:31:47'),
(90, 'Gallery Deleted', 'Gallery #3 deleted', '2026-07-25 22:31:51'),
(91, 'Gallery Deleted', 'Gallery #6 deleted', '2026-07-25 22:31:54'),
(92, 'Gallery Deleted', 'Gallery #7 deleted', '2026-07-25 22:31:57'),
(93, 'Blog Deleted', 'Blog #4 deleted', '2026-07-25 22:32:06'),
(94, 'Teammember Deleted', 'Teammember #1 deleted', '2026-07-25 22:32:15'),
(95, 'Assessment Created', 'Assessment for kape mape - chichew: 100%', '2026-07-25 22:36:35'),
(96, 'Assessment Created', 'Assessment for dolo ktttgsh - chichew: 16%', '2026-07-25 22:36:46'),
(97, 'Assessment Created', 'Assessment for dolo ktttgsh - chichew: 16%', '2026-07-25 22:37:03'),
(98, 'Assessment Created', 'Assessment for dolo ktttgsh - chichew: 16%', '2026-07-25 22:37:11'),
(99, 'Event Updated', 'Event #4 updated', '2026-07-25 22:38:51'),
(100, 'Event Updated', 'Event #1 updated', '2026-07-25 22:39:57'),
(101, 'Event Updated', 'Event #2 updated', '2026-07-25 22:40:07'),
(102, 'Event Updated', 'Event #6 updated', '2026-07-25 22:40:18'),
(103, 'Event Updated', 'Event #6 updated', '2026-07-25 22:40:28'),
(104, 'Event Updated', 'Event #1 updated', '2026-07-25 22:41:10'),
(105, 'Course Created', 'New Course added (#13)', '2026-07-25 22:49:49'),
(106, 'Parent Password Reset', 'Password reset for parent #3', '2026-07-25 23:03:40'),
(107, 'Parent Password Reset', 'Password reset for parent #3', '2026-07-25 23:03:53'),
(108, 'Parent Password Reset', 'Password reset for parent #3', '2026-07-25 23:05:45'),
(109, 'Parent Registered', 'gumbo@gmail.com created an account (pending approval)', '2026-07-25 23:07:30'),
(110, 'Registration Code Generated', 'Code NCA-6XET-ZEX7 sent to gumbo@gmail.com  (gumbo@gmail.com) for parent account #7', '2026-07-25 23:08:37'),
(111, 'Parent Updated', 'Parent #7 updated', '2026-07-25 23:08:41'),
(112, 'Parent Login', 'gumbo@gmail.com  logged in', '2026-07-25 23:09:16'),
(113, 'Event Updated', 'Event #4 updated', '2026-07-25 23:16:03'),
(114, 'Event Updated', 'Event #6 updated', '2026-07-25 23:17:36'),
(115, 'Content Updated', 'Team page content updated', '2026-07-25 23:22:30'),
(116, 'Message Deleted', 'Message #6 deleted', '2026-07-25 23:37:36'),
(117, 'Content Updated', 'Footer page content updated', '2026-07-25 23:39:51'),
(118, 'Payment Deleted', 'Payment #1 deleted', '2026-07-26 03:57:50'),
(119, 'Payment Deleted', 'Payment #2 deleted', '2026-07-26 03:57:55'),
(120, 'Payment Deleted', 'Payment #3 deleted', '2026-07-26 03:58:01'),
(121, 'Payment Deleted', 'Payment #9 deleted', '2026-07-26 03:58:07'),
(122, 'Payment Deleted', 'Payment #11 deleted', '2026-07-26 03:58:12'),
(123, 'Payment Deleted', 'Payment #10 deleted', '2026-07-26 03:58:17'),
(124, 'Payment Deleted', 'Payment #7 deleted', '2026-07-26 03:58:21'),
(125, 'Payment Deleted', 'Payment #8 deleted', '2026-07-26 03:58:26'),
(126, 'Payment Deleted', 'Payment #6 deleted', '2026-07-26 03:58:30'),
(127, 'Payment Deleted', 'Payment #5 deleted', '2026-07-26 03:58:36'),
(128, 'Payment Deleted', 'Payment #4 deleted', '2026-07-26 03:58:44'),
(129, 'Course Created', 'New Course added (#14)', '2026-07-26 03:59:42'),
(130, 'Registration Deleted', 'Registration #13 deleted', '2026-07-26 04:00:24'),
(131, 'Registration Deleted', 'Registration #14 deleted', '2026-07-26 04:00:30'),
(132, 'Registration Deleted', 'Registration #9 deleted', '2026-07-26 04:00:37'),
(133, 'Registration Deleted', 'Registration #11 deleted', '2026-07-26 04:00:44'),
(134, 'Registration Deleted', 'Registration #8 deleted', '2026-07-26 04:00:49'),
(135, 'Settings Updated', 'Admin settings were updated', '2026-07-26 04:01:25'),
(136, 'Event Updated', 'Event #4 updated', '2026-07-26 04:14:17'),
(137, 'Event Updated', 'Event #2 updated', '2026-07-26 04:14:38'),
(138, 'Event Updated', 'Event #1 updated', '2026-07-26 04:14:52'),
(139, 'Event Updated', 'Event #1 updated', '2026-07-26 04:15:09'),
(140, 'Event Updated', 'Event #6 updated', '2026-07-26 04:15:20'),
(141, 'Content Updated', 'Footer page content updated', '2026-07-26 04:16:07'),
(142, 'Content Updated', 'Footer page content updated', '2026-07-26 04:27:48'),
(143, 'Content Updated', 'Footer page content updated', '2026-07-26 04:33:41'),
(144, 'Content Updated', 'Org_chart page content updated', '2026-07-26 04:48:12'),
(145, 'Content Updated', 'Org_chart page content updated', '2026-07-26 04:48:23'),
(146, 'Content Updated', 'Org_chart page content updated', '2026-07-26 04:48:46'),
(147, 'Content Updated', 'Org_chart page content updated', '2026-07-26 05:00:53'),
(148, 'Content Updated', 'Org_chart page content updated', '2026-07-26 05:03:24'),
(149, 'Teammember Updated', 'Teammember #2 updated', '2026-07-26 05:04:02'),
(150, 'Content Updated', 'Org_chart page content updated', '2026-07-26 05:12:01'),
(151, 'Teammember Updated', 'Teammember #3 updated', '2026-07-26 05:18:10'),
(152, 'Teammember Updated', 'Teammember #3 updated', '2026-07-26 05:50:43'),
(153, 'Content Updated', 'Org_chart page content updated', '2026-07-26 05:56:13'),
(154, 'Settings Updated', 'Admin settings were updated', '2026-07-26 05:57:55'),
(155, 'Event Updated', 'Event #1 updated', '2026-07-26 06:00:33'),
(156, 'Content Updated', 'Org_chart page content updated', '2026-07-26 06:02:35'),
(157, 'Student Deleted', 'Student #15 deleted', '2026-07-26 06:11:51'),
(158, 'Student Deleted', 'Student #14 deleted', '2026-07-26 06:11:55'),
(159, 'Student Deleted', 'Student #13 deleted', '2026-07-26 06:11:59'),
(160, 'Student Deleted', 'Student #12 deleted', '2026-07-26 06:12:03'),
(161, 'Student Deleted', 'Student #11 deleted', '2026-07-26 06:12:07'),
(162, 'Student Deleted', 'Student #10 deleted', '2026-07-26 06:12:10'),
(163, 'Student Deleted', 'Student #9 deleted', '2026-07-26 06:12:13'),
(164, 'Student Deleted', 'Student #8 deleted', '2026-07-26 06:12:17'),
(165, 'Student Deleted', 'Student #4 deleted', '2026-07-26 06:12:22'),
(166, 'Student Deleted', 'Student #3 deleted', '2026-07-26 06:12:26'),
(167, 'Student Deleted', 'Student #2 deleted', '2026-07-26 06:12:29'),
(168, 'Student Deleted', 'Student #6 deleted', '2026-07-26 06:12:32'),
(169, 'Student Deleted', 'Student #5 deleted', '2026-07-26 06:12:35'),
(170, 'Student Deleted', 'Student #7 deleted', '2026-07-26 06:12:39'),
(171, 'Student Deleted', 'Student #1 deleted', '2026-07-26 06:12:43'),
(172, 'Registration Deleted', 'Registration #10 deleted', '2026-07-26 06:12:49'),
(173, 'Registration Deleted', 'Registration #6 deleted', '2026-07-26 06:12:52'),
(174, 'Student Created', 'Brian Msiska auto-created from registration #2', '2026-07-26 06:12:58'),
(175, 'Registration Updated', 'Registration #2 status: Approved', '2026-07-26 06:12:58'),
(176, 'Teammember Deleted', 'Teammember #6 deleted', '2026-07-26 06:27:12'),
(177, 'Content Updated', 'Org_chart page content updated', '2026-07-26 06:28:13'),
(178, 'Settings Updated', 'Admin settings were updated', '2026-07-26 06:30:10'),
(179, 'Settings Updated', 'Admin settings were updated', '2026-07-26 06:30:11'),
(180, 'Teammember Updated', 'Teammember #2 updated', '2026-07-26 06:41:43'),
(181, 'Teammember Updated', 'Teammember #3 updated', '2026-07-26 06:49:15'),
(182, 'Content Updated', 'Home page content updated', '2026-07-26 06:49:30'),
(183, 'Content Updated', 'Home page content updated', '2026-07-26 06:55:33'),
(184, 'Gallery Created', 'New Gallery added (#9)', '2026-07-26 06:56:19'),
(185, 'Announcement Updated', 'Announcement #2 updated', '2026-07-26 07:13:54'),
(186, 'Announcement Updated', 'Announcement #3 updated', '2026-07-26 07:14:08'),
(187, 'Announcement Updated', 'Announcement #4 updated', '2026-07-26 07:14:12'),
(188, 'Announcement Updated', 'Announcement #5 updated', '2026-07-26 07:14:26'),
(189, 'Announcement Updated', 'Announcement #4 updated', '2026-07-26 07:14:35'),
(190, 'Event Updated', 'Event #6 updated', '2026-07-26 07:21:38'),
(191, 'Parent Updated', 'Parent #7 updated', '2026-07-26 07:46:40'),
(192, 'Parent Password Reset', 'Password reset for parent #7', '2026-07-26 07:46:59'),
(193, 'Parent Deleted', 'Parent #7 deleted', '2026-07-26 07:48:15'),
(194, 'Teacher Updated', 'Teacher #9 updated', '2026-07-26 07:50:19'),
(195, 'Teacher Login', 'gumbo@gmail.com mape logged in', '2026-07-26 07:50:34'),
(196, 'Course Created', 'New Course added (#15)', '2026-07-26 07:54:06'),
(197, 'Teacher Login', 'gumbo@gmail.com mape logged in', '2026-07-26 08:06:53'),
(198, 'Teammember Updated', 'Teammember #4 updated', '2026-07-26 08:08:36'),
(199, 'Parent Updated', 'Parent #6 updated', '2026-07-26 08:10:26'),
(200, 'Parent Updated', 'Parent #6 updated', '2026-07-26 08:10:29'),
(201, 'Parent Password Reset', 'Password reset for parent #6', '2026-07-26 08:10:51'),
(202, 'Parent Login', 'Samuel Kachingwe logged in', '2026-07-26 08:11:04'),
(203, 'Assessment Deleted', 'Assessment #9 deleted', '2026-07-26 08:27:15'),
(204, 'Assessment Deleted', 'Assessment #12 deleted', '2026-07-26 08:27:20'),
(205, 'Assessment Deleted', 'Assessment #13 deleted', '2026-07-26 08:27:23'),
(206, 'Assessment Deleted', 'Assessment #11 deleted', '2026-07-26 08:27:27'),
(207, 'Assessment Deleted', 'Assessment #10 deleted', '2026-07-26 08:27:30'),
(208, 'Assessment Deleted', 'Assessment #17 deleted', '2026-07-26 08:27:41'),
(209, 'Assessment Deleted', 'Assessment #16 deleted', '2026-07-26 08:27:45'),
(210, 'Assessment Deleted', 'Assessment #15 deleted', '2026-07-26 08:27:48'),
(211, 'Assessment Deleted', 'Assessment #14 deleted', '2026-07-26 08:27:51'),
(212, 'Announcement Updated', 'Announcement #5 updated', '2026-07-26 08:46:13'),
(213, 'Vacancie Created', 'New Vacancie added (#10)', '2026-07-26 08:48:05'),
(214, 'Exam Uploaded', 'Exam \'dolo exm\' uploaded by gumbo@gmail.com mape', '2026-07-26 08:49:02'),
(215, 'Exam Updated', 'Exam #1 updated', '2026-07-26 08:49:21'),
(216, 'Exam Deleted', 'Exam #1 deleted', '2026-07-26 08:49:59'),
(217, 'New Payment', 'chumunthu banda - MK60,000.00', '2026-07-26 09:18:29'),
(218, 'Payment Updated', 'Payment #12 status: Paid', '2026-07-26 09:19:04'),
(219, 'Course Created', 'New Course added (#16)', '2026-07-26 09:28:48'),
(220, 'Teacher Login', 'gumbo@gmail.com mape logged in', '2026-07-26 10:03:14'),
(221, 'Gallery Deleted', 'Gallery #9 deleted', '2026-07-26 10:32:04'),
(222, 'Vacancie Created', 'New Vacancie added (#11)', '2026-07-26 10:45:51'),
(223, 'Login', 'Admin logged in', '2026-07-26 11:57:54'),
(224, 'Student Deleted', 'Student #16 deleted', '2026-07-26 11:58:14'),
(225, 'Payment Deleted', 'Payment #12 deleted', '2026-07-26 11:58:19'),
(226, 'Attendance Deleted', 'Attendance #18 deleted', '2026-07-26 11:58:24'),
(227, 'Attendance Deleted', 'Attendance #16 deleted', '2026-07-26 11:58:27'),
(228, 'Attendance Deleted', 'Attendance #17 deleted', '2026-07-26 11:58:29'),
(229, 'Attendance Deleted', 'Attendance #9 deleted', '2026-07-26 11:58:35'),
(230, 'Attendance Deleted', 'Attendance #15 deleted', '2026-07-26 11:58:39'),
(231, 'Attendance Deleted', 'Attendance #1 deleted', '2026-07-26 11:58:45'),
(232, 'Attendance Deleted', 'Attendance #2 deleted', '2026-07-26 11:58:47'),
(233, 'Attendance Deleted', 'Attendance #3 deleted', '2026-07-26 11:58:53'),
(234, 'Attendance Deleted', 'Attendance #4 deleted', '2026-07-26 11:58:59'),
(235, 'Attendance Deleted', 'Attendance #5 deleted', '2026-07-26 11:59:05'),
(236, 'Attendance Deleted', 'Attendance #7 deleted', '2026-07-26 11:59:09'),
(237, 'Attendance Deleted', 'Attendance #8 deleted', '2026-07-26 11:59:12'),
(238, 'Attendance Deleted', 'Attendance #6 deleted', '2026-07-26 11:59:16'),
(239, 'Teacher Deleted', 'Teacher #7 deleted', '2026-07-26 11:59:26'),
(240, 'Teacher Deleted', 'Teacher #9 deleted', '2026-07-26 11:59:28'),
(241, 'Teacher Deleted', 'Teacher #6 deleted', '2026-07-26 11:59:30'),
(242, 'Teacher Deleted', 'Teacher #4 deleted', '2026-07-26 11:59:33'),
(243, 'Teacher Deleted', 'Teacher #1 deleted', '2026-07-26 11:59:36'),
(244, 'Teacher Deleted', 'Teacher #2 deleted', '2026-07-26 11:59:39'),
(245, 'Teacher Deleted', 'Teacher #3 deleted', '2026-07-26 11:59:41'),
(246, 'Teacher Deleted', 'Teacher #5 deleted', '2026-07-26 11:59:44'),
(247, 'Parent Deleted', 'Parent #6 deleted', '2026-07-26 11:59:51'),
(248, 'Parent Deleted', 'Parent #4 deleted', '2026-07-26 11:59:54'),
(249, 'Parent Deleted', 'Parent #1 deleted', '2026-07-26 11:59:57'),
(250, 'Parent Deleted', 'Parent #2 deleted', '2026-07-26 12:00:03'),
(251, 'Parent Deleted', 'Parent #3 deleted', '2026-07-26 12:00:06'),
(252, 'Parent Deleted', 'Parent #5 deleted', '2026-07-26 12:00:12'),
(253, 'Parent Registered', 'gumbo@gmail.com created an account (pending approval)', '2026-07-26 12:26:51'),
(254, 'Teacher Created', 'New Teacher added (#12)', '2026-07-26 12:27:53'),
(255, 'Parent Updated', 'Parent #8 updated', '2026-07-26 12:28:48'),
(256, 'Parent Deleted', 'Parent #8 deleted', '2026-07-26 12:29:05'),
(257, 'Parent Registered', 'Simon created an account (pending approval)', '2026-07-26 12:29:57'),
(258, 'Parent Updated', 'Parent #9 updated', '2026-07-26 12:30:37'),
(259, 'Parent Login', 'Simon  logged in', '2026-07-26 12:31:18'),
(260, 'Parent Login', 'Simon  logged in', '2026-07-26 12:31:37'),
(261, 'Login', 'Admin logged in', '2026-07-26 12:37:26'),
(262, 'Teacher Updated', 'Teacher #12 updated', '2026-07-26 12:44:01'),
(263, 'Teacher Login', 'vdfuodio bdiofdjfs logged in', '2026-07-26 12:45:27');
INSERT INTO `activity_log` (`id`, `action`, `detail`, `created_at`) VALUES
(264, 'Teacher Updated', 'Teacher #12 updated', '2026-07-26 12:47:12'),
(265, 'Teacher Updated', 'Teacher #12 updated', '2026-07-26 12:47:51'),
(266, 'Login', 'Admin logged in', '2026-07-26 12:51:22'),
(267, 'Login', 'Admin logged in', '2026-07-26 12:51:46'),
(268, 'Event Created', 'New Event added (#7)', '2026-07-26 12:53:57'),
(269, 'Event Created', 'New Event added (#8)', '2026-07-26 12:55:38'),
(270, 'Event Created', 'New Event added (#9)', '2026-07-26 12:55:39'),
(271, 'Content Updated', 'Org_chart page content updated', '2026-07-26 12:57:56'),
(272, 'Teacher Deleted', 'Teacher #12 deleted', '2026-07-26 13:06:42'),
(273, 'Login', 'Admin logged in', '2026-07-26 13:19:23'),
(274, 'New Registration', 'KONDWANI KAPICHI registered for Daycare', '2026-07-26 13:27:00'),
(275, 'Registration Deleted', 'Registration #15 deleted', '2026-07-26 19:55:17'),
(276, 'Teacher Created', 'New Teacher added (#13)', '2026-07-26 19:56:22'),
(277, 'Teacher Updated', 'Teacher #13 updated', '2026-07-26 19:57:07'),
(278, 'Teacher Login', 'chumunthu banda logged in', '2026-07-26 19:58:28'),
(279, 'Teacher Updated', 'Teacher #13 updated', '2026-07-26 19:59:54'),
(280, 'Course Created', 'New Course added (#17)', '2026-07-26 20:00:22'),
(281, 'Parent Deleted', 'Parent #9 deleted', '2026-07-26 20:00:57'),
(282, 'New Registration', 'chumunthu banda registered for Standard 8', '2026-07-26 20:03:55'),
(283, 'New Payment', 'chumunthu banda - MK40,000.00', '2026-07-26 20:05:04'),
(284, 'Student Created', 'chumunthu banda auto-created from registration #16', '2026-07-26 20:05:38'),
(285, 'Registration Updated', 'Registration #16 status: Approved', '2026-07-26 20:05:38'),
(286, 'Payment Updated', 'Payment #13 status: Paid', '2026-07-26 20:06:05'),
(287, 'Assessment Created', 'Assessment for chumunthu banda - english: 99%', '2026-07-26 20:07:40'),
(288, 'Course Created', 'New Course added (#18)', '2026-07-26 20:08:02'),
(289, 'Registration Deleted', 'Registration #16 deleted', '2026-07-26 20:08:26'),
(290, 'Payment Deleted', 'Payment #13 deleted', '2026-07-26 20:08:50'),
(291, 'Student Deleted', 'Student #17 deleted', '2026-07-26 20:08:58'),
(292, 'Login', 'Admin logged in', '2026-07-27 04:51:49'),
(293, 'Service Updated', 'Service #7 updated', '2026-07-27 04:56:38'),
(294, 'Parent Registered', 'Precious Chimwemwe created an account (pending approval)', '2026-07-27 05:01:11'),
(295, 'New Registration', 'Monica Mandevu registered for Daycare', '2026-07-27 05:01:14'),
(296, 'Login', 'Admin logged in', '2026-07-27 05:03:17'),
(297, 'Student Created', 'Monica Mandevu auto-created from registration #17', '2026-07-27 05:03:56'),
(298, 'Registration Updated', 'Registration #17 status: Approved', '2026-07-27 05:03:56'),
(299, 'New Payment', 'Kondwan Kapichi - MK30000', '2026-07-27 05:06:16'),
(300, 'Payment Updated', 'Payment #14 status: Paid', '2026-07-27 05:06:43'),
(301, 'Registration Deleted', 'Registration #17 deleted', '2026-07-27 05:07:44'),
(302, 'Student Deleted', 'Student #18 deleted', '2026-07-27 05:08:30'),
(303, 'Payment Deleted', 'Payment #14 deleted', '2026-07-27 05:08:43'),
(304, 'Teammember Updated', 'Teammember #8 updated', '2026-07-27 06:12:16'),
(305, 'Service Updated', 'Service #7 updated', '2026-07-27 06:13:09'),
(306, 'Event Deleted', 'Event #7 deleted', '2026-07-27 06:59:54'),
(307, 'Content Updated', 'Footer page content updated', '2026-07-27 07:30:24'),
(308, 'Content Updated', 'Footer page content updated', '2026-07-27 07:32:05'),
(309, 'Teacher Updated', 'Teacher #13 updated', '2026-07-27 07:34:14'),
(310, 'Teacher Login', 'chumunthu banda logged in', '2026-07-27 07:34:31'),
(311, 'Assessment Deleted', 'Assessment #18 deleted', '2026-07-27 07:34:52'),
(312, 'Exam Uploaded', 'Exam \'dolo exm\' uploaded by chumunthu banda', '2026-07-27 07:41:36'),
(313, 'Exam Updated', 'Exam #2 updated', '2026-07-27 07:42:01'),
(314, 'Teacher Registered', 'Test Teacher created an account (pending approval)', '2026-07-27 10:19:35'),
(315, 'Teacher Registered', 'Test Teacher2 created an account (pending approval)', '2026-07-27 10:19:50'),
(316, 'Teacher Registered', 'dolo@gmail.com created an account (pending approval)', '2026-07-27 10:22:48'),
(317, 'Parent Registered', 'cupicsart@gmail.com created an account (pending approval)', '2026-07-27 10:23:25'),
(318, 'Parent Updated', 'Parent #11 updated', '2026-07-27 10:23:57'),
(319, 'Teacher Updated', 'Teacher #16 updated', '2026-07-27 10:24:31'),
(320, 'Parent Login', 'cupicsart@gmail.com  logged in', '2026-07-27 10:25:08'),
(321, 'Vacancie Created', 'New Vacancie added (#12)', '2026-07-27 10:26:08'),
(322, 'Teacher Login', 'dolo@gmail.com  logged in', '2026-07-27 10:27:08'),
(323, 'Parent Updated', 'Parent #10 updated', '2026-07-27 10:27:43'),
(324, 'Child Registration Submitted', 'kape mape registered by parent #11 (pending approval)', '2026-07-27 10:31:54'),
(325, 'Student Created', 'kape mape auto-created from registration #18', '2026-07-27 10:32:11'),
(326, 'Student Linked', 'kape mape linked to parent #11', '2026-07-27 10:32:11'),
(327, 'Registration Updated', 'Registration #18 status: Approved', '2026-07-27 10:32:11'),
(328, 'Content Updated', 'Home page content updated', '2026-07-28 05:48:26'),
(329, 'Exam Deleted', 'Exam #2 deleted', '2026-07-28 05:49:54'),
(330, 'Admin Created', 'New admin: gumbo@gmail.com', '2026-07-28 05:55:42'),
(331, 'Login', 'Admin logged in', '2026-07-28 05:57:49'),
(332, 'Course Created', 'New Course added (#19)', '2026-07-28 05:59:10'),
(333, 'Course Updated', 'Course #1 updated', '2026-07-28 06:06:50'),
(334, 'Settings Updated', 'Admin settings were updated', '2026-07-28 06:15:51'),
(335, 'Settings Updated', 'Admin settings were updated', '2026-07-28 06:21:03'),
(336, 'Vacancie Deleted', 'Vacancie #12 deleted', '2026-07-28 06:21:56'),
(337, 'Vacancy Posted', 'New vacancy: ICT Officer', '2026-07-28 06:27:55'),
(338, 'Course Updated', 'Course #19 updated', '2026-07-28 06:29:04'),
(339, 'Course Updated', 'Course #16 updated', '2026-07-28 06:29:23'),
(340, 'Login', 'Admin logged in', '2026-07-29 12:19:59'),
(341, 'Student Deleted', 'Student #19 deleted', '2026-07-29 12:21:28'),
(342, 'Teacher Deleted', 'Teacher #16 deleted', '2026-07-29 12:21:41'),
(343, 'Course Updated', 'Course #5 updated', '2026-07-29 12:26:06'),
(344, 'New Registration', 'kondwni registered for Standard 8', '2026-07-29 12:27:13'),
(345, 'Registration Deleted', 'Registration #18 deleted', '2026-07-29 12:27:40'),
(346, 'Student Created', 'kondwni  auto-created from registration #19', '2026-07-29 12:27:41'),
(347, 'Registration Updated', 'Registration #19 status: Approved', '2026-07-29 12:27:41'),
(348, 'Student Created', 'New Student added (#21)', '2026-07-29 12:30:37'),
(349, 'Student Deleted', 'Student #21 deleted', '2026-07-29 12:30:56'),
(350, 'Job Application Submitted', 'Application for ICT Officer by kondwni', '2026-07-29 13:47:33'),
(351, 'Job Application Submitted', 'Application for ICT Officer by kondwni', '2026-07-29 13:57:44'),
(352, 'Content Updated', 'Org_chart page content updated', '2026-07-29 13:59:05'),
(353, 'Content Updated', 'Org_chart page content updated', '2026-07-29 13:59:13'),
(354, 'Content Updated', 'Org_chart page content updated', '2026-07-29 13:59:39'),
(355, 'Content Updated', 'Org_chart page content updated', '2026-07-29 14:00:18'),
(356, 'Content Updated', 'Org_chart page content updated', '2026-07-29 14:00:18'),
(357, 'Content Updated', 'Org_chart page content updated', '2026-07-29 14:00:18'),
(358, 'Content Updated', 'Org_chart page content updated', '2026-07-29 14:00:47'),
(359, 'Settings Updated', 'Admin settings were updated', '2026-07-29 14:01:58'),
(360, 'New Message', 'From: kondwni', '2026-07-29 16:16:16'),
(361, 'Message Deleted', 'Message #7 deleted', '2026-07-29 16:17:19'),
(362, 'Teacher Updated', 'Teacher #13 updated', '2026-07-29 17:05:20'),
(363, 'Teacher Login', 'chumunthu banda logged in', '2026-07-29 17:05:55'),
(364, 'Teacher Login', 'chumunthu banda logged in', '2026-07-29 17:12:59'),
(365, 'Teacher Login', 'chumunthu banda logged in', '2026-07-29 17:12:59'),
(366, 'New Registration', 'kondwani banda registered for Standard 1', '2026-07-29 17:31:15'),
(367, 'Student Created', 'kondwani banda auto-created from registration #20', '2026-07-29 17:31:19'),
(368, 'Registration Updated', 'Registration #20 status: Approved', '2026-07-29 17:31:19'),
(369, 'Teacher Login', 'chumunthu banda logged in', '2026-07-30 08:17:05'),
(370, 'Vacancie Updated', 'Vacancie #13 updated', '2026-07-30 08:21:13'),
(371, 'Vacancie Updated', 'Vacancie #13 updated', '2026-07-30 08:21:37'),
(372, 'Job Application Submitted', 'Application for ICT Officer by bckjxnl', '2026-07-30 08:23:13'),
(373, 'Teacher Created', 'New Teacher added (#17)', '2026-07-30 08:26:18'),
(374, 'Teacher Updated', 'Teacher #17 updated', '2026-07-30 08:28:05'),
(375, 'Teacher Login', 'dol kaya logged in', '2026-07-30 08:28:40'),
(376, 'Application Status Updated', 'Application #3 marked as Reviewed', '2026-07-30 08:45:47'),
(377, 'Application Status Updated', 'Application #3 marked as Accepted', '2026-07-30 08:45:51'),
(378, 'Job Application Submitted', 'Application for ICT Officer by bvduojdshiosdiohu', '2026-07-30 08:49:01'),
(379, 'Application Status Updated', 'Application #4 marked as Accepted', '2026-07-30 08:50:20'),
(380, 'Event Created', 'New Event added (#10)', '2026-07-30 08:52:12'),
(381, 'Admin Updated', 'Admin #2 updated', '2026-07-31 06:57:21'),
(382, 'Admin Created', 'New admin: chifuniro@gmail.com', '2026-07-31 10:33:06'),
(383, 'Teacher Updated', 'Teacher #17 updated', '2026-07-31 10:34:25'),
(384, 'Teacher Updated', 'Teacher #17 updated', '2026-07-31 10:35:05'),
(385, 'Teacher Login', 'dol kaya logged in', '2026-07-31 10:35:09'),
(386, 'Admin Created', 'New admin: c@gmail.com', '2026-07-31 11:01:39'),
(387, 'Report Created', 'Report for \'kondwni\' created by dol kaya', '2026-07-31 11:03:50'),
(388, 'Assessment Created', 'Assessment for kondwni  - english: 90%', '2026-07-31 11:04:41'),
(389, 'Report Signed', 'Report #1 signed', '2026-07-31 11:13:48'),
(390, 'Vacancy Posted', 'New vacancy: ICT Officer', '2026-07-31 11:51:11'),
(391, 'Vacancie Deleted', 'Vacancie #14 deleted', '2026-07-31 12:22:05'),
(392, 'Application Status Updated', 'Application #4 marked as Rejected', '2026-07-31 12:22:14'),
(393, 'Application Status Updated', 'Application #3 marked as Rejected', '2026-07-31 12:22:27'),
(394, 'Job Application Submitted', 'Application for ICT Officer by bvduojdshiosdiohu', '2026-07-31 12:26:18'),
(395, 'Application Status Updated', 'Application #5 marked as Rejected', '2026-07-31 12:26:35'),
(396, 'Application Status Updated', 'Application #5 marked as Reviewed', '2026-07-31 12:27:05'),
(397, 'Application Status Updated', 'Application #5 marked as Accepted', '2026-07-31 12:27:08'),
(398, 'Application Status Updated', 'Application #5 marked as Rejected', '2026-07-31 12:27:27'),
(399, 'Course Deleted', 'Course #19 deleted', '2026-07-31 12:28:10'),
(400, 'Course Deleted', 'Course #18 deleted', '2026-07-31 12:28:13'),
(401, 'Course Deleted', 'Course #16 deleted', '2026-07-31 12:28:16'),
(402, 'Course Deleted', 'Course #15 deleted', '2026-07-31 12:28:22'),
(403, 'Course Deleted', 'Course #14 deleted', '2026-07-31 12:28:22'),
(404, 'Course Deleted', 'Course #11 deleted', '2026-07-31 12:28:24'),
(405, 'Course Deleted', 'Course #9 deleted', '2026-07-31 12:28:27'),
(406, 'Course Deleted', 'Course #10 deleted', '2026-07-31 12:28:30'),
(407, 'Course Deleted', 'Course #8 deleted', '2026-07-31 12:28:33'),
(408, 'Course Deleted', 'Course #17 deleted', '2026-07-31 12:28:36'),
(409, 'Course Deleted', 'Course #12 deleted', '2026-07-31 12:28:39'),
(410, 'Course Deleted', 'Course #7 deleted', '2026-07-31 12:28:42'),
(411, 'Course Deleted', 'Course #1 deleted', '2026-07-31 12:28:47'),
(412, 'Gallery Created', 'New Gallery added (#10)', '2026-07-31 12:29:18'),
(413, 'Gallery Deleted', 'Gallery #10 deleted', '2026-07-31 12:29:37'),
(414, 'Teacher Updated', 'Teacher #17 updated', '2026-07-31 12:31:45'),
(415, 'Teacher Login', 'dol kaya logged in', '2026-07-31 12:31:59'),
(416, 'Admin Deleted', 'Admin #11 deleted', '2026-07-31 13:20:31'),
(417, 'Admin Deleted', 'Admin #10 deleted', '2026-07-31 13:20:34'),
(418, 'Admin Deleted', 'Admin #2 deleted', '2026-07-31 13:20:37'),
(419, 'Admin Deleted', 'Admin #1 deleted', '2026-07-31 13:20:39'),
(420, 'Admin Created', 'New admin: c@gmail.com', '2026-07-31 13:20:50'),
(421, 'Admin Deleted', 'Admin #12 deleted', '2026-07-31 13:21:02'),
(422, 'Parent Deleted', 'Parent #11 deleted', '2026-07-31 13:22:08'),
(423, 'Parent Created', 'New Parent added (#12)', '2026-07-31 13:30:11'),
(424, 'Admin Created', 'New admin: c@gmail.com', '2026-07-31 14:18:09'),
(425, 'Attendance Created', 'New Attendance added (#19)', '2026-07-31 14:25:01'),
(426, 'Settings Updated', 'Admin settings were updated', '2026-07-31 14:48:46'),
(427, 'Profile Updated', 'Admin profile photo and settings updated', '2026-07-31 15:04:23'),
(428, 'Profile Updated', 'Admin profile photo and settings updated', '2026-07-31 15:04:30'),
(429, 'Admin Updated', 'Admin #13 updated', '2026-07-31 15:33:29'),
(430, 'Teacher Created', 'New Teacher added (#19)', '2026-07-31 15:54:50'),
(431, 'Teacher Updated', 'Teacher #19 updated', '2026-07-31 15:55:01'),
(432, 'Teacher Updated', 'Teacher #19 updated', '2026-07-31 15:55:07'),
(433, 'Teacher Deleted', 'Teacher #17 deleted', '2026-07-31 15:55:13'),
(434, 'Teacher Deleted', 'Teacher #13 deleted', '2026-07-31 15:55:15'),
(435, 'Teacher Created', 'New Teacher added (#20)', '2026-07-31 15:56:04'),
(436, 'Login', 'Admin logged in', '2026-07-31 16:51:54'),
(437, 'Login', 'Admin logged in', '2026-07-31 16:51:54'),
(438, 'New Registration', 'Test Student registered for Standard 1', '2026-07-31 17:08:12'),
(439, 'New Registration', 'Test Student registered for Standard 1', '2026-07-31 17:08:58'),
(440, 'Student Created', 'Test Student auto-created from registration #22', '2026-07-31 17:11:34'),
(441, 'Registration Updated', 'Registration #22 status: Approved', '2026-07-31 17:11:34'),
(442, 'Student Linked', 'Test Student linked to registration #21', '2026-07-31 17:11:36'),
(443, 'Registration Updated', 'Registration #21 status: Approved', '2026-07-31 17:11:36'),
(444, 'New Registration', 'kondw dolo registered for Daycare', '2026-07-31 17:24:06'),
(445, 'Student Created', 'kondw dolo auto-created from registration #23', '2026-07-31 17:24:38'),
(446, 'Registration Updated', 'Registration #23 status: Approved', '2026-07-31 17:24:38'),
(447, 'Registration Deleted', 'Registration #23 deleted', '2026-07-31 17:24:43'),
(448, 'Student Deleted', 'Student #24 deleted', '2026-07-31 17:24:52'),
(449, 'New Payment', 'kape mape - MK60,000.00', '2026-07-31 17:29:47'),
(450, 'Payment Updated', 'Payment #15 status: Paid', '2026-07-31 18:24:35'),
(451, 'Admin Created', 'New admin: gumbo@gmail.com', '2026-07-31 18:45:13'),
(452, 'Login', 'Admin logged in', '2026-07-31 18:46:00'),
(453, 'Content Updated', 'Home page content updated', '2026-07-31 19:01:12'),
(454, 'Login', 'Admin logged in', '2026-07-31 19:03:03'),
(455, 'Teacher Updated', 'Teacher #20 updated', '2026-07-31 19:05:41'),
(456, 'Teacher Updated', 'Teacher #20 updated', '2026-07-31 19:05:49'),
(457, 'Teacher Login', 'gumbo@gmail.com banda logged in', '2026-07-31 19:06:40'),
(458, 'Content Updated', 'Org_chart page content updated', '2026-07-31 20:25:03'),
(459, 'Teammember Created', 'New Teammember added (#9)', '2026-07-31 20:25:32'),
(460, 'Content Updated', 'Home page content updated', '2026-07-31 20:25:58'),
(461, 'Course Updated', 'Course #13 updated', '2026-07-31 20:26:51'),
(462, 'Teacher Updated', 'Teacher #20 updated', '2026-07-31 20:27:46'),
(463, 'Teacher Updated', 'Teacher #20 updated', '2026-07-31 20:28:40'),
(464, 'Teacher Updated', 'Teacher #20 updated', '2026-07-31 20:29:10'),
(465, 'Vacancy Posted', 'New vacancy: scxlinxkl', '2026-07-31 20:47:47'),
(466, 'Job Application Submitted', 'Application for scxlinxkl by xcx', '2026-07-31 20:48:36'),
(467, 'Application Status Updated', 'Application #6 marked as Rejected', '2026-07-31 20:48:56'),
(468, 'Vacancie Updated', 'Vacancie #13 updated', '2026-07-31 21:13:10'),
(469, 'Course Updated', 'Course #5 updated', '2026-07-31 21:59:08'),
(470, 'Vacancie Deleted', 'Vacancie #15 deleted', '2026-07-31 22:34:08'),
(471, 'Login', 'Admin logged in', '2026-08-01 06:17:49'),
(472, 'Login', 'Admin logged in', '2026-08-01 12:17:41'),
(473, 'Login', 'Admin logged in', '2026-08-01 12:47:42'),
(474, 'Notification Created', 'New Notification added (#1)', '2026-08-01 12:53:23'),
(475, 'Login', 'Admin logged in', '2026-08-01 12:55:25'),
(476, 'Student Created', 'New Student added (#25)', '2026-08-01 12:57:43'),
(477, 'Student Created', 'New Student added (#26)', '2026-08-01 12:57:45'),
(478, 'Login', 'Admin logged in', '2026-08-01 12:58:35'),
(479, 'Notification Created', 'New Notification added (#2)', '2026-08-01 12:59:15'),
(480, 'New Registration', 'kondw dolo registered for Standard 7', '2026-08-01 13:13:46'),
(481, 'New Payment', 'kape mape - MK60,000.00', '2026-08-01 13:14:21'),
(482, 'Login', 'Admin logged in', '2026-08-01 13:28:24'),
(483, 'Student Deleted', 'Student #26 deleted', '2026-08-01 13:30:58'),
(484, 'Student Deleted', 'Student #25 deleted', '2026-08-01 13:31:02'),
(485, 'Student Deleted', 'Student #23 deleted', '2026-08-01 13:31:05'),
(486, 'Student Deleted', 'Student #22 deleted', '2026-08-01 13:31:08'),
(487, 'Student Deleted', 'Student #20 deleted', '2026-08-01 13:31:10'),
(488, 'Payment Deleted', 'Payment #16 deleted', '2026-08-01 13:31:18'),
(489, 'Payment Deleted', 'Payment #15 deleted', '2026-08-01 13:31:58'),
(490, 'Attendance Deleted', 'Attendance #19 deleted', '2026-08-01 13:32:09'),
(491, 'Teacher Deleted', 'Teacher #20 deleted', '2026-08-01 13:32:22'),
(492, 'Course Deleted', 'Course #13 deleted', '2026-08-01 13:32:35'),
(493, 'Course Deleted', 'Course #5 deleted', '2026-08-01 13:32:37'),
(494, 'Course Deleted', 'Course #4 deleted', '2026-08-01 13:32:40'),
(495, 'Course Deleted', 'Course #2 deleted', '2026-08-01 13:32:43'),
(496, 'Gallery Created', 'New Gallery added (#11)', '2026-08-01 13:33:56'),
(497, 'Gallery Created', 'New Gallery added (#12)', '2026-08-01 13:35:14'),
(498, 'Gallery Deleted', 'Gallery #12 deleted', '2026-08-01 13:37:06'),
(499, 'Gallery Created', 'New Gallery added (#13)', '2026-08-01 13:37:19'),
(500, 'Gallery Created', 'New Gallery added (#14)', '2026-08-01 13:37:59'),
(501, 'Gallery Deleted', 'Gallery #13 deleted', '2026-08-01 13:39:10'),
(502, 'Gallery Created', 'New Gallery added (#15)', '2026-08-01 13:39:26'),
(503, 'Teacher Registered', 'Dziwani David Kapyola created an account (pending approval)', '2026-08-02 07:35:25'),
(504, 'Teacher Updated', 'Teacher #21 updated', '2026-08-03 10:51:01'),
(505, 'Teacher Login', 'Dziwani David Kapyola logged in', '2026-08-03 10:53:19'),
(506, 'Teacher Updated', 'Teacher #21 updated', '2026-08-03 10:58:31'),
(507, 'Login', 'Admin logged in', '2026-08-03 13:38:18'),
(508, 'Registration Deleted', 'Registration #24 deleted', '2026-08-03 13:38:32'),
(509, 'Registration Deleted', 'Registration #22 deleted', '2026-08-03 13:38:36'),
(510, 'Registration Deleted', 'Registration #21 deleted', '2026-08-03 13:38:39'),
(511, 'Registration Deleted', 'Registration #20 deleted', '2026-08-03 13:38:42'),
(512, 'Registration Deleted', 'Registration #19 deleted', '2026-08-03 13:38:45'),
(513, 'Admin Deleted', 'Admin #13 deleted', '2026-08-03 18:41:59'),
(514, 'Admin Deleted', 'Admin #14 deleted', '2026-08-03 18:42:08'),
(515, 'Login', 'Admin logged in', '2026-08-03 23:17:53'),
(516, 'Teacher Login', 'Dziwani David Kapyola logged in', '2026-08-04 08:20:31'),
(517, 'Teacher Updated', 'Teacher #21 updated', '2026-08-04 08:22:16'),
(518, 'Login', 'Admin logged in', '2026-08-04 11:39:03'),
(519, 'Student Created', 'New Student added (#27)', '2026-08-04 16:21:31'),
(520, 'New Payment', 'Mrs Nkhata - MK100000', '2026-08-04 16:29:48'),
(521, 'New Payment', 'Mrs Nkhata  - MK95000', '2026-08-04 16:32:20'),
(522, 'New Payment', 'Mrs Nkhata  - MK30000', '2026-08-04 16:35:06'),
(523, 'New Payment', 'Mrs Nkhata - MK15000', '2026-08-04 16:36:21'),
(524, 'New Payment', 'Mrs Nkhata  - MK15000', '2026-08-04 16:37:45'),
(525, 'Teacher Registered', 'Precious Chimwemwe Msukuma created an account (pending approval)', '2026-08-04 16:42:08');
INSERT INTO `activity_log` (`id`, `action`, `detail`, `created_at`) VALUES
(526, 'Teacher Updated', 'Teacher #22 updated', '2026-08-04 16:44:11'),
(527, 'Teacher Login', 'Precious Chimwemwe Msukuma logged in', '2026-08-04 16:46:59'),
(528, 'Teacher Updated', 'Teacher #22 updated', '2026-08-04 16:51:46'),
(529, 'Teacher Updated', 'Teacher #22 updated', '2026-08-04 16:52:57'),
(530, 'Content Updated', 'Home page content updated', '2026-08-04 16:55:53'),
(531, 'Parent Registered', 'Precious Chimwemwe Msukuma created an account (pending approval)', '2026-08-04 17:00:34'),
(532, 'Parent Updated', 'Parent #13 updated', '2026-08-04 17:03:49'),
(533, 'Parent Login', 'Precious Chimwemwe Msukuma logged in', '2026-08-04 17:07:32'),
(534, 'Child Registration Submitted', 'Shiloh Uchindami Msukuma registered by parent #13 (pending approval)', '2026-08-04 17:13:03'),
(535, 'Student Created', 'Shiloh Uchindami Msukuma auto-created from registration #25', '2026-08-04 17:16:32'),
(536, 'Student Linked', 'Shiloh Uchindami Msukuma linked to parent #13', '2026-08-04 17:16:34'),
(537, 'Registration Updated', 'Registration #25 status: Approved', '2026-08-04 17:16:34'),
(538, 'Student Linked', 'Shiloh Uchindami Msukuma linked to registration #25', '2026-08-04 17:16:34'),
(539, 'Registration Updated', 'Registration #25 status: Approved', '2026-08-04 17:16:34'),
(540, 'Login', 'Admin logged in', '2026-08-04 17:25:54'),
(541, 'Login', 'Admin logged in', '2026-08-05 07:44:27'),
(542, 'Student Updated', 'Student #27 updated', '2026-08-05 07:59:38'),
(543, 'Parent Updated', 'Parent #13 updated', '2026-08-05 08:15:06'),
(544, 'Course Created', 'New course: bxioxn', '2026-08-05 08:15:46'),
(545, 'Course Deleted', 'Course #20 deleted', '2026-08-05 08:15:58'),
(546, 'Login', 'Admin logged in', '2026-08-05 08:40:29'),
(547, 'Admin Created', 'New admin: cpucsrt@gmil.com', '2026-08-05 10:55:27'),
(548, 'Admin Updated', 'Admin #15 updated', '2026-08-05 11:10:56'),
(549, 'Login', 'Admin logged in', '2026-08-05 17:03:37'),
(550, 'Login', 'Admin logged in', '2026-08-06 06:17:50'),
(551, 'testimonial_submitted', 'New testimonial submitted by gcvjlbk/l', '2026-08-06 06:23:16'),
(552, 'testimonial_submitted', 'New testimonial submitted by gcvjlbk/l', '2026-08-06 06:27:44'),
(553, 'Login', 'Admin logged in', '2026-08-07 14:03:14'),
(554, 'Login', 'Admin logged in', '2026-08-08 06:28:41'),
(555, 'Gallery Deleted', 'Gallery #14 deleted', '2026-08-08 07:07:01'),
(556, 'Admin Deleted', 'Admin #15 deleted', '2026-08-08 09:11:41'),
(557, 'Login', 'Admin logged in', '2026-08-10 17:11:01'),
(558, 'testimonial_submitted', 'New testimonial submitted by mayamiko', '2026-08-10 17:24:06'),
(559, 'Login', 'Admin logged in', '2026-08-10 18:27:29'),
(560, 'Notification Created', 'New Notification added (#3)', '2026-08-10 19:36:40'),
(561, 'Notification Created', 'New Notification added (#4)', '2026-08-10 20:45:23'),
(562, 'Notification Created', 'New Notification added (#5)', '2026-08-10 20:45:31'),
(563, 'Vacancie Updated', 'Vacancie #13 updated', '2026-08-10 20:46:13'),
(564, 'Vacancie Updated', 'Vacancie #13 updated', '2026-08-10 20:47:23'),
(565, 'Vacancy Posted', 'New vacancy: ICT Officer (Copy)', '2026-08-10 20:47:45'),
(566, 'Vacancie Deleted', 'Vacancie #16 deleted', '2026-08-10 20:48:25'),
(567, 'testimonial_submitted', 'New testimonial submitted by bvux iofdjo;fs', '2026-08-11 07:21:26'),
(568, 'Login', 'Admin logged in', '2026-08-11 07:22:44'),
(569, 'Login', 'Admin logged in', '2026-08-11 12:47:21'),
(570, 'Gallery Created', 'New Gallery added (#16)', '2026-08-12 06:40:54'),
(571, 'New Registration', 'chumunthu banda registered for Daycare', '2026-08-12 06:52:49'),
(572, 'Login', 'Admin logged in', '2026-08-12 06:53:22'),
(573, 'Registration Updated', 'Registration #26 status: Rejected', '2026-08-12 06:53:39'),
(574, 'Gallery Deleted', 'Gallery #16 deleted', '2026-08-12 13:16:55'),
(575, 'Login', 'Admin logged in', '2026-08-12 13:34:21'),
(576, 'Book Added', 'New book: vyf7gouihl', '2026-08-12 13:38:25'),
(577, 'Library Deleted', 'Library #1 deleted', '2026-08-12 13:38:41'),
(578, 'Activity Added', 'New activity: jk', '2026-08-12 13:44:23'),
(579, 'Book Added', 'New book: vyf7gouihl', '2026-08-12 15:26:48'),
(580, 'Library Deleted', 'Library #2 deleted', '2026-08-12 15:32:39'),
(581, 'Schedule Added', 'New schedule: Daycare -  gctyfiguoihlk', '2026-08-12 15:34:05'),
(582, 'Timetable Deleted', 'Timetable #1 deleted', '2026-08-12 15:42:24'),
(583, 'Sport Updated', 'Sport #1 updated', '2026-08-12 15:44:52'),
(584, 'Sport Updated', 'Sport #1 updated', '2026-08-12 15:45:05'),
(585, 'Sport Deleted', 'Sport #1 deleted', '2026-08-12 15:45:09'),
(586, 'Vehicle Added', 'New vehicle: cd 3468', '2026-08-12 15:53:40'),
(587, 'Notification Created', 'New Job Vacancy: ICT Officer', '2026-08-12 15:58:00'),
(588, 'Teacher Registered', 'cupicsart@gmail.com created an account (pending approval)', '2026-08-12 16:11:39'),
(589, 'Teacher Updated', 'Teacher #23 updated', '2026-08-12 16:12:23'),
(590, 'Teacher Login', 'cupicsart@gmail.com  logged in', '2026-08-12 16:12:54'),
(591, 'Login', 'Admin logged in', '2026-09-01 14:46:18'),
(592, 'Teacher Updated', 'Teacher #23 updated', '2026-09-01 15:16:06'),
(593, 'Teacher Login', 'cupicsart@gmail.com  logged in', '2026-09-01 15:16:25'),
(594, 'Announcement Created', 'New Announcement added (#6)', '2026-09-01 15:34:33'),
(595, 'New Payment', 'Precious Chimwemwe Msukuma - MK6888899900', '2026-09-01 15:35:59'),
(596, 'Payment Updated', 'Payment #22 status: Paid', '2026-09-01 15:36:27'),
(597, 'Payment Deleted', 'Payment #22 deleted', '2026-09-01 15:37:15'),
(598, 'Gallery Deleted', 'Gallery #11 deleted', '2026-09-01 15:48:23'),
(599, 'Gallery Deleted', 'Gallery #15 deleted', '2026-09-01 15:48:31'),
(600, 'Gallery Created', 'New Gallery added (#17)', '2026-09-01 15:49:20'),
(601, 'Gallery Created', 'New Gallery added (#18)', '2026-09-01 15:49:53'),
(602, 'Gallery Created', 'New Gallery added (#19)', '2026-09-01 15:50:58'),
(603, 'New Registration', 'kondwni registered for Daycare', '2026-09-01 17:32:37'),
(604, 'Student Created', 'kondwni  auto-created from registration #27', '2026-09-01 17:33:06'),
(605, 'Registration Updated', 'Registration #27 status: Approved', '2026-09-01 17:33:06'),
(606, 'New Payment', 'mr gunbo - MK1100000', '2026-09-01 17:33:59'),
(607, 'Payment Updated', 'Payment #23 status: Paid', '2026-09-01 17:34:17'),
(608, 'Event Created', 'New Event added (#11)', '2026-09-01 17:35:50'),
(609, 'Event Updated', 'Event #11 updated', '2026-09-01 17:38:26'),
(610, 'Event Updated', 'Event #11 updated', '2026-09-01 17:39:22'),
(611, 'Login', 'Admin logged in', '2026-09-01 18:24:44'),
(612, 'Login', 'Admin logged in', '2026-09-01 21:58:53'),
(613, 'Testimonial Deleted', 'Testimonial #4 deleted', '2026-09-01 22:01:48'),
(614, 'Teammember Updated', 'Teammember #8 updated', '2026-09-01 22:02:37'),
(615, 'Announcement Deleted', 'Announcement #6 deleted', '2026-09-01 22:33:11'),
(616, 'Payment Deleted', 'Payment #23 deleted', '2026-09-01 22:51:40'),
(617, 'Student Deleted', 'Student #29 deleted', '2026-09-01 22:52:03'),
(618, 'Announcement Created', 'New Announcement added (#7)', '2026-09-02 00:23:56'),
(619, 'Announcement Updated', 'Announcement #7 updated', '2026-09-02 00:24:13'),
(620, 'Announcement Deleted', 'Announcement #7 deleted', '2026-09-02 01:50:05'),
(621, 'Attendance Created', 'New Attendance added (#20)', '2026-09-02 07:40:58'),
(622, 'Attendance Created', 'New Attendance added (#21)', '2026-09-02 07:41:11'),
(623, 'Content Updated', 'Footer page content updated', '2026-09-02 07:42:34'),
(624, 'Content Updated', 'Footer page content updated', '2026-09-02 07:43:39'),
(625, 'Announcement Updated', 'Announcement #2 updated', '2026-09-02 07:44:10'),
(626, 'testimonial_submitted', 'New testimonial submitted by vulil', '2026-09-02 08:13:50'),
(627, 'Testimonial Deleted', 'Testimonial #5 deleted', '2026-09-02 08:15:11'),
(628, 'Notification Created', 'bdvildvoi', '2026-09-02 10:48:22'),
(629, 'Attendance Deleted', 'Attendance #20 deleted', '2026-09-02 10:52:58'),
(630, 'Attendance Deleted', 'Attendance #21 deleted', '2026-09-02 10:53:01'),
(631, 'Attendance Created', 'New Attendance added (#22)', '2026-09-02 11:21:41'),
(632, 'Attendance Deleted', 'Attendance #22 deleted', '2026-09-02 11:21:59'),
(633, 'User Created', 'New User added (#1)', '2026-09-02 17:24:34'),
(634, 'Teacher Updated', 'Teacher #23 updated', '2026-09-02 20:28:26'),
(635, 'Teacher Login', 'cupicsart@gmail.com  logged in', '2026-09-02 20:28:49'),
(636, 'Teacher Updated', 'Teacher #23 updated', '2026-09-02 20:29:34'),
(637, 'Schedule Added', 'New schedule: Daycare - english', '2026-09-03 06:53:10'),
(638, 'Teacher Login', 'cupicsart@gmail.com Chilima logged in', '2026-09-03 06:55:55'),
(639, 'New Payment', 'kondwni - MK110,000.00', '2026-09-03 11:40:40'),
(640, 'Payment Updated', 'Payment #24 status: Paid', '2026-09-03 11:41:10'),
(641, 'Payment Deleted', 'Payment #24 deleted', '2026-09-03 11:41:31'),
(642, 'Course Created', 'New course: english', '2026-09-03 14:18:48'),
(643, 'Registration Code Generated', 'Code NCA-QBSP-HMLS sent to Precious Chimwemwe Msukuma (preciousmsukuma09@gmail.com) for parent account #13', '2026-09-03 14:55:12'),
(644, 'Teacher Updated', 'Teacher #23 updated', '2026-09-03 15:32:33'),
(645, 'Teacher Login', 'cupicsart@gmail.com Chilima logged in', '2026-09-03 15:32:47'),
(646, 'Parent Registered', 'cupicsart@gmail.com created an account (pending approval)', '2026-09-03 15:36:28'),
(647, 'Parent Updated', 'Parent #14 updated', '2026-09-03 15:36:43'),
(648, 'Parent Login', 'cupicsart@gmail.com  logged in', '2026-09-03 15:37:07'),
(649, 'Child Registration Submitted', 'dolo keen registered by parent #14 (pending approval)', '2026-09-03 16:51:15'),
(650, 'Student Created', 'dolo keen auto-created from registration #28', '2026-09-03 16:52:09'),
(651, 'Student Linked', 'dolo keen linked to parent #14', '2026-09-03 16:52:09'),
(652, 'Registration Updated', 'Registration #28 status: Approved', '2026-09-03 16:52:09'),
(653, 'Account Deletion Requested', 'parent #14 (cupicsart@gmail.com ) requested account deletion. Scheduled for: 2026-09-05 10:00:04', '2026-09-04 08:00:04'),
(654, 'Account Deletion Cancelled', 'parent #14 cancelled their account deletion request', '2026-09-04 08:15:03'),
(655, 'Account Deletion Requested', 'parent #14 (cupicsart@gmail.com ) requested account deletion. Scheduled for: 2026-09-05 10:15:20', '2026-09-04 08:15:20'),
(656, 'Account Deletion Cancelled', 'parent #14 cancelled their account deletion request', '2026-09-04 08:15:36'),
(657, 'Account Deletion Requested', 'parent #14 (cupicsart@gmail.com ) requested account deletion. Scheduled for: 2026-09-05 10:15:48', '2026-09-04 08:15:48'),
(658, 'Account Deletion Cancelled', 'parent #14 cancelled their account deletion request', '2026-09-04 08:15:52'),
(659, 'Account Deletion Requested', 'teacher #23 (cupicsart@gmail.com Chilima) requested account deletion. Scheduled for: 2026-09-05 10:16:32', '2026-09-04 08:16:32'),
(660, 'Teacher Login', 'cupicsart@gmail.com Chilima logged in', '2026-09-04 08:31:50'),
(661, 'Account Deletion Requested', 'parent #14 (cupicsart@gmail.com ) requested account deletion. Scheduled for: 2026-09-05 10:32:45', '2026-09-04 08:32:45'),
(662, 'Account Deletion Cancelled', 'parent #14 cancelled their account deletion request', '2026-09-04 08:32:52'),
(663, 'Account Deletion Cancelled', 'teacher #23 cancelled their account deletion request', '2026-09-04 08:33:16'),
(664, 'Account Deletion Requested', 'teacher #23 (cupicsart@gmail.com Chilima) requested account deletion. Scheduled for: 2026-09-05 10:33:22', '2026-09-04 08:33:22'),
(665, 'Account Deletion Cancelled', 'teacher #23 cancelled their account deletion request', '2026-09-04 08:33:38'),
(666, 'Account Deletion Requested', 'teacher #23 (cupicsart@gmail.com Chilima) requested account deletion. Scheduled for: 2026-09-05 11:21:50', '2026-09-04 09:21:51'),
(667, 'Account Deletion Cancelled', 'teacher #23 cancelled their account deletion request', '2026-09-04 09:21:56'),
(668, 'Assessment Created', 'Assessment for Daniel Nkhata - endlish: 90%', '2026-09-04 10:17:37'),
(669, 'Assessment Created', 'Assessment for Shiloh Uchindami Msukuma - endlish: 90%', '2026-09-04 10:18:03'),
(670, 'Bulk Attendance', 'Marked attendance for 2 students on 2026-09-04', '2026-09-04 10:19:01'),
(671, 'Bulk Attendance', 'Marked attendance for 2 students on 2026-09-04', '2026-09-04 10:19:26'),
(672, 'Teacher Registered', 'chisomo chiko created an account (pending approval)', '2026-09-04 10:28:04'),
(673, 'Teacher Updated', 'Teacher #24 updated', '2026-09-04 10:28:44'),
(674, 'Teacher Updated', 'Teacher #24 updated', '2026-09-04 10:31:40'),
(675, 'Teacher Login', 'chisomo chiko logged in', '2026-09-04 10:32:22'),
(676, 'Account Deletion Requested', 'teacher #24 (chisomo chiko) requested account deletion. Scheduled for: 2026-09-05 12:34:23', '2026-09-04 10:34:23'),
(677, 'Teacher Login', 'chisomo chiko logged in', '2026-09-04 10:56:49'),
(678, 'Account Deletion Cancelled', 'teacher #24 cancelled their account deletion request', '2026-09-04 11:07:46'),
(679, 'Timetable Updated', 'Timetable #2 updated', '2026-09-04 11:25:02'),
(680, 'Account Deletion Requested', 'teacher #24 (chisomo chiko) requested account deletion. Scheduled for: 2026-09-05 13:43:39', '2026-09-04 11:43:39'),
(681, 'Account Deletion Cancelled', 'teacher #24 cancelled their account deletion request', '2026-09-04 11:43:46'),
(682, 'Student Updated', 'Student #30 updated', '2026-09-04 15:50:54'),
(683, 'Attendance Created', 'New Attendance added (#27)', '2026-09-04 18:19:35'),
(684, 'Registration Phone Updated', 'Phone updated for registration #28', '2026-09-04 18:20:13'),
(685, 'Announcement Created', 'New Announcement added (#8)', '2026-09-04 21:56:19'),
(686, 'Announcement Deleted', 'Announcement #8 deleted', '2026-09-04 21:56:26'),
(687, 'Account Deletion Requested', 'parent #14 (cupicsart@gmail.com ) requested account deletion. Scheduled for: 2026-09-06 00:19:48', '2026-09-04 22:19:48'),
(688, 'Account Deletion Cancelled', 'parent #14 cancelled their account deletion request', '2026-09-04 22:19:55'),
(689, 'Timetable Document Uploaded', 'Timetable document \'term one time tb;e\' uploaded for Term 1', '2026-09-04 23:04:14'),
(690, 'Timetable Sent to Teachers', 'Timetable document \'term one time tb;e\' sent to 5 teachers', '2026-09-04 23:04:27'),
(691, 'Timetable Document Uploaded', 'Timetable document \'dolo\' uploaded for Term 2', '2026-09-04 23:06:09'),
(692, 'Timetable Sent to Teachers', 'Timetable document \'dolo\' sent to 5 teachers', '2026-09-04 23:06:17'),
(693, 'Timetable Sent to Teachers', 'Timetable document \'dolo\' sent to 5 teachers', '2026-09-04 23:12:08'),
(694, 'Teacher File Uploaded', 'Teacher chisomo chiko uploaded 1 file(s) to admin: \'time tble\'', '2026-09-04 23:48:32'),
(695, 'Teacher File Status Updated', 'File #1 status updated to approved', '2026-09-05 00:22:06'),
(696, 'Teacher File Status Updated', 'File #1 status updated to approved', '2026-09-05 00:22:08'),
(697, 'Course Created', 'New course: nbfbp', '2026-09-05 00:34:54'),
(698, 'Login', 'Admin logged in', '2026-09-05 00:45:20'),
(699, 'Vacancy Posted', 'New vacancy: undefined (Copy)', '2026-09-05 00:46:49'),
(700, 'Vacancie Updated', 'Vacancie #17 updated', '2026-09-05 00:46:55'),
(701, 'Notification Created', 'New Job Vacancy: undefined (Copy)', '2026-09-05 00:47:33'),
(702, 'Notification Created', 'New Job Vacancy: undefined (Copy)', '2026-09-05 00:47:51'),
(703, 'Teacher Login', 'cupicsart@gmail.com Chilima logged in', '2026-09-05 00:49:58'),
(704, 'Account Deletion Requested', 'teacher #23 (cupicsart@gmail.com Chilima) requested account deletion. Scheduled for: 2026-09-06 02:52:39', '2026-09-05 00:52:39'),
(705, 'Account Deletion Cancelled', 'teacher #23 cancelled their account deletion request', '2026-09-05 00:52:44'),
(706, 'Teacher Login', 'cupicsart@gmail.com Chilima logged in', '2026-09-05 00:59:29'),
(707, 'Complaint Submitted', 'Complaint from parent #14 for class Standard 4', '2026-09-05 01:21:16'),
(708, 'Complaint Response Submitted', 'Teacher #23 responded to complaint #1', '2026-09-05 01:22:13'),
(709, 'Timetable_document Deleted', 'Timetable_document #2 deleted', '2026-09-05 01:25:58'),
(710, 'Teacher File Status Updated', 'File #1 status updated to approved', '2026-09-05 01:26:19'),
(711, 'Complaint Deleted', 'Teacher #23 deleted complaint #1', '2026-09-05 07:27:53'),
(712, 'Parent Login', 'cupicsart@gmail.com  logged in', '2026-09-05 07:28:17'),
(713, 'Attendance Deleted', 'Attendance #27 deleted', '2026-09-05 14:28:41'),
(714, 'Attendance Deleted', 'Attendance #26 deleted', '2026-09-05 14:28:44'),
(715, 'Attendance Deleted', 'Attendance #25 deleted', '2026-09-05 14:28:48'),
(716, 'Attendance Deleted', 'Attendance #24 deleted', '2026-09-05 14:28:52'),
(717, 'Attendance Deleted', 'Attendance #23 deleted', '2026-09-05 14:28:56'),
(718, 'Parent Login', 'cupicsart@gmail.com  logged in', '2026-09-05 17:03:55'),
(719, 'Payment Updated', 'Payment #21 status: Paid', '2026-09-05 18:40:04'),
(720, 'Login', 'Admin logged in', '2026-09-05 19:43:54'),
(721, 'Account Deletion Requested', 'teacher #23 (cupicsart@gmail.com Chilima) requested account deletion. Scheduled for: 2026-09-06 22:41:17', '2026-09-05 20:41:18'),
(722, 'Account Deletion Cancelled', 'teacher #23 cancelled their account deletion request', '2026-09-05 20:41:24'),
(723, 'Login', 'Admin logged in', '2026-09-06 09:05:41'),
(724, 'Login', 'Admin logged in', '2026-09-06 09:08:32'),
(725, 'Login', 'Admin logged in', '2026-09-06 13:36:19'),
(726, 'Login', 'Admin logged in', '2026-09-06 14:02:34'),
(727, 'Teacher Login', 'cupicsart@gmail.com Chilima logged in', '2026-09-06 16:37:37'),
(728, 'Teacher Registered', 'kondwni kpichi created an account (pending approval)', '2026-09-06 18:14:19'),
(729, 'Teacher Updated', 'Teacher #25 updated', '2026-09-06 18:14:50'),
(730, 'Teacher Login', 'kondwni kpichi logged in', '2026-09-06 18:15:15'),
(731, 'Teacher Updated', 'Teacher #25 updated', '2026-09-06 18:18:48'),
(732, 'Teacher Login', 'kondwni kpichi logged in', '2026-09-06 18:19:03'),
(733, 'Teacher Login', 'kondwni kpichi logged in', '2026-09-06 18:20:57'),
(734, 'Teacher Updated', 'Teacher #25 updated', '2026-09-06 18:21:38'),
(735, 'Teacher Login', 'kondwni kpichi logged in', '2026-09-06 18:21:58'),
(736, 'Teacher Login', 'kondwni kpichi logged in', '2026-09-06 18:22:00'),
(737, 'Teacher Login', 'kondwni kpichi logged in', '2026-09-06 18:22:00'),
(738, 'Account Deletion Requested', 'teacher #25 (kondwni kpichi) requested account deletion. Scheduled for: 2026-09-07 20:22:47', '2026-09-06 18:22:47'),
(739, 'Account Deletion Cancelled', 'teacher #25 cancelled their account deletion request', '2026-09-06 18:22:52'),
(740, 'Teacher Login', 'kondwni kpichi logged in', '2026-09-06 18:27:54'),
(741, 'Teacher Login', 'kondwni kpichi logged in', '2026-09-06 19:14:20'),
(742, 'Teacher Login', 'kondwni kpichi logged in', '2026-09-06 20:55:53'),
(743, 'Teacher Login', 'kondwni kpichi logged in', '2026-09-06 20:57:03'),
(744, 'Teacher Login', 'kondwni kpichi logged in', '2026-09-06 20:58:28'),
(745, 'Course Created', 'New course: english', '2026-09-06 21:01:13'),
(746, 'Course Created', 'New course: english', '2026-09-06 21:01:13'),
(747, 'Teacher Login', 'kondwni kpichi logged in', '2026-09-06 21:01:58'),
(748, 'Teacher Updated', 'Teacher #25 updated', '2026-09-06 21:11:24'),
(749, 'Teacher Login', 'kondwni kpichi logged in', '2026-09-06 21:22:15'),
(750, 'Teacher Login', 'kondwni kpichi logged in', '2026-09-06 21:26:28'),
(751, 'Teacher Login', 'kondwni kpichi logged in', '2026-09-06 21:27:17'),
(752, 'Teacher Login', 'kondwni kpichi logged in', '2026-09-06 21:38:54'),
(753, 'Teacher Login', 'kondwni kpichi logged in', '2026-09-06 21:39:31'),
(754, 'Teacher Login', 'kondwni kpichi logged in', '2026-09-06 21:48:11'),
(755, 'Teacher Login', 'kondwni kpichi logged in', '2026-09-06 21:48:25'),
(756, 'Teacher Login', 'kondwni kpichi logged in', '2026-09-06 21:49:18'),
(757, 'Teacher Login', 'kondwni kpichi logged in', '2026-09-06 22:01:34'),
(758, 'Teacher Login', 'kondwni kpichi logged in', '2026-09-06 22:06:26'),
(759, 'Teacher Login', 'kondwni kpichi logged in', '2026-09-06 22:16:17'),
(760, 'Teacher Login', 'kondwni kpichi logged in', '2026-09-06 22:39:21');
INSERT INTO `activity_log` (`id`, `action`, `detail`, `created_at`) VALUES
(761, 'Teacher Login', 'kondwni kpichi logged in', '2026-09-06 22:40:35'),
(762, 'Teacher Login', 'kondwni kpichi logged in', '2026-09-06 22:56:22'),
(763, 'Parent Login', 'cupicsart keen logged in', '2026-09-06 22:59:32'),
(764, 'Account Deletion Requested', 'parent #14 (cupicsart keen) requested account deletion. Scheduled for: 2026-09-08 01:01:42', '2026-09-06 23:01:42'),
(765, 'Account Deletion Cancelled', 'parent #14 cancelled their account deletion request', '2026-09-06 23:01:47'),
(766, 'Teacher Login', 'kondwni kpichi logged in', '2026-09-06 23:21:01');

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(200) DEFAULT '',
  `phone` varchar(50) DEFAULT '',
  `profile_photo` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(50) DEFAULT 'Admin',
  `status` varchar(20) DEFAULT 'Active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `admin_notifications`
--

CREATE TABLE `admin_notifications` (
  `id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text DEFAULT NULL,
  `related_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `read_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_notifications`
--

INSERT INTO `admin_notifications` (`id`, `type`, `title`, `message`, `related_id`, `created_at`, `is_read`, `read_at`) VALUES
(1, 'account_deletion', 'Account Deletion Request: cupicsart@gmail.com ', 'A parent has requested account deletion. Scheduled for 2026-09-05 10:00:04.', 1, '2026-09-04 10:00:04', 0, NULL),
(2, 'account_deletion', 'Account Deletion Request: cupicsart@gmail.com ', 'A parent has requested account deletion. Scheduled for 2026-09-05 10:15:20.', 2, '2026-09-04 10:15:20', 0, NULL),
(3, 'account_deletion', 'Account Deletion Request: cupicsart@gmail.com ', 'A parent has requested account deletion. Scheduled for 2026-09-05 10:15:48.', 3, '2026-09-04 10:15:48', 0, NULL),
(4, 'account_deletion', 'Account Deletion Request: cupicsart@gmail.com Chilima', 'A teacher has requested account deletion. Scheduled for 2026-09-05 10:16:32.', 4, '2026-09-04 10:16:32', 0, NULL),
(5, 'account_deletion', 'Account Deletion Request: cupicsart@gmail.com ', 'A parent has requested account deletion. Scheduled for 2026-09-05 10:32:45.', 5, '2026-09-04 10:32:45', 0, NULL),
(6, 'account_deletion', 'Account Deletion Request: cupicsart@gmail.com Chilima', 'A teacher has requested account deletion. Scheduled for 2026-09-05 10:33:22.', 6, '2026-09-04 10:33:22', 0, NULL),
(7, 'account_deletion', 'Account Deletion Request: cupicsart@gmail.com Chilima', 'A teacher has requested account deletion. Scheduled for 2026-09-05 11:21:50.', 7, '2026-09-04 11:21:51', 0, NULL),
(8, 'account_deletion', 'Account Deletion Request: chisomo chiko', 'A teacher has requested account deletion. Scheduled for 2026-09-05 12:34:23.', 8, '2026-09-04 12:34:24', 0, NULL),
(9, 'account_deletion', 'Account Deletion Request: chisomo chiko', 'A teacher has requested account deletion. Scheduled for 2026-09-05 13:43:39.', 9, '2026-09-04 13:43:39', 0, NULL),
(10, 'account_deletion', 'Account Deletion Request: cupicsart@gmail.com ', 'A parent has requested account deletion. Scheduled for 2026-09-06 00:19:48.', 10, '2026-09-05 00:19:48', 0, NULL),
(11, 'account_deletion', 'Account Deletion Request: cupicsart@gmail.com Chilima', 'A teacher has requested account deletion. Scheduled for 2026-09-06 02:52:39.', 11, '2026-09-05 02:52:39', 0, NULL),
(12, 'complaint_response', 'Complaint Response Received', 'Your complaint for Standard 4 has been viewed and responded to by the teacher.', 14, '2026-09-05 03:22:13', 1, '2026-09-05 03:28:22'),
(13, 'account_deletion', 'Account Deletion Request: cupicsart@gmail.com Chilima', 'A teacher has requested account deletion. Scheduled for 2026-09-06 22:41:17.', 12, '2026-09-05 22:41:18', 0, NULL),
(14, 'account_deletion', 'Account Deletion Request: kondwni kpichi', 'A teacher has requested account deletion. Scheduled for 2026-09-07 20:22:47.', 13, '2026-09-06 20:22:47', 0, NULL),
(15, 'account_deletion', 'Account Deletion Request: cupicsart keen', 'A parent has requested account deletion. Scheduled for 2026-09-08 01:01:42.', 14, '2026-09-07 01:01:42', 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `admin_report_review`
--

CREATE TABLE `admin_report_review` (
  `id` int(11) NOT NULL,
  `report_id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `review_type` varchar(20) DEFAULT 'approval' COMMENT 'approval, quality, compliance',
  `decision` varchar(20) DEFAULT 'Pending' COMMENT 'Pending, Approved, Rejected, Needs Revision',
  `feedback` text DEFAULT NULL,
  `priority` varchar(20) DEFAULT 'normal' COMMENT 'low, normal, high, urgent',
  `review_deadline` datetime DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `admin_sessions`
--

CREATE TABLE `admin_sessions` (
  `id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `display_name` varchar(200) DEFAULT '',
  `session_token` varchar(255) NOT NULL,
  `ip_address` varchar(50) DEFAULT '',
  `user_agent` text DEFAULT '',
  `login_time` datetime DEFAULT current_timestamp(),
  `last_activity` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_active` tinyint(1) DEFAULT 1,
  `logout_time` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE `announcements` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `priority` varchar(20) DEFAULT 'normal',
  `target_audience` varchar(50) DEFAULT 'all',
  `status` varchar(20) DEFAULT 'Published',
  `created_by` varchar(100) DEFAULT 'Admin',
  `pinned` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `announcements`
--

INSERT INTO `announcements` (`id`, `title`, `content`, `priority`, `target_audience`, `status`, `created_by`, `pinned`, `created_at`, `updated_at`) VALUES
(1, 'Welcome to Noah Christian Academy!', 'We are excited to start the new academic year. Please register your child today!', 'urgent', 'all', 'Published', 'Admin', 1, '2026-07-25 10:16:56', '2026-07-25 22:12:28'),
(2, 'Term 1 Exams Schedule', 'Term 1 examinations will begin on March 25th. Students are advised to prepare adequately. Exam timetable will be shared next week.', 'urgent', 'all', 'Published', 'Admin', 1, '2026-07-25 10:17:12', '2026-09-02 07:44:10'),
(3, 'School Holiday Notice', 'The school will be closed for Easter holidays from March 29th to April 1st. Classes resume on April 2nd.', 'normal', 'all', 'Published', 'Admin', 1, '2026-07-25 10:17:12', '2026-07-26 07:14:08'),
(4, 'Parent Meeting Reminder', 'Reminder: Parent-Teacher meeting scheduled for March 15th at 2 PM in the School Hall. All parents are encouraged to attend.', 'normal', 'all', 'Published', 'Admin', 1, '2026-07-25 10:17:12', '2026-07-26 07:14:35'),
(5, 'New Library Books', 'We have added new books to the school library. Students are encouraged to visit and explore the new collection.', 'urgent', 'all', 'Published', 'Admin', 1, '2026-07-25 10:17:12', '2026-07-26 08:46:13');

-- --------------------------------------------------------

--
-- Table structure for table `apis`
--

CREATE TABLE `apis` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` enum('payment','sms','email','other') NOT NULL DEFAULT 'other',
  `provider` varchar(100) NOT NULL,
  `endpoint` varchar(500) NOT NULL,
  `api_key` varchar(255) NOT NULL,
  `api_secret` varchar(255) DEFAULT NULL,
  `headers` text DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `priority` int(11) DEFAULT 1,
  `description` text DEFAULT NULL,
  `last_used` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `application_documents`
--

CREATE TABLE `application_documents` (
  `id` int(11) NOT NULL,
  `application_id` int(11) NOT NULL,
  `document_type` varchar(50) DEFAULT 'other',
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_size` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `assessments`
--

CREATE TABLE `assessments` (
  `id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `registration_id` int(11) DEFAULT NULL,
  `student_name` varchar(200) DEFAULT '',
  `class_name` varchar(50) DEFAULT '',
  `subject` varchar(100) NOT NULL,
  `type` varchar(50) DEFAULT 'Quiz',
  `score` int(11) DEFAULT 0,
  `date` date DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `assessments`
--

INSERT INTO `assessments` (`id`, `teacher_id`, `student_id`, `registration_id`, `student_name`, `class_name`, `subject`, `type`, `score`, `date`, `remarks`, `created_at`, `updated_at`) VALUES
(20, 23, 27, NULL, 'Daniel Nkhata', 'Standard 4', 'endlish', '0', 90, '2026-09-04', '', '2026-09-04 10:17:37', '2026-09-04 10:17:37'),
(21, 23, 28, 25, 'Shiloh Uchindami Msukuma', 'Standard 4', 'endlish', '0', 90, '2026-09-04', '', '2026-09-04 10:18:03', '2026-09-04 10:18:03');

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `registration_id` int(11) DEFAULT NULL,
  `student_name` varchar(200) DEFAULT '',
  `class_name` varchar(50) DEFAULT '',
  `date` date NOT NULL,
  `status` varchar(20) DEFAULT 'Present',
  `remarks` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `author` varchar(100) DEFAULT '',
  `category` varchar(100) DEFAULT 'General',
  `content` text DEFAULT NULL,
  `image` varchar(500) DEFAULT '',
  `status` varchar(20) DEFAULT 'Draft',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`id`, `title`, `author`, `category`, `content`, `image`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Why Christian Education Matters', 'Admin', 'Education', 'Christian education provides a foundation for moral and spiritual development alongside academic excellence. At Noah Christian Academy, we integrate biblical values into every aspect of learning...', '', 'Published', '2026-07-25 10:17:12', '2026-07-25 10:17:12'),
(2, 'Tips for Supporting Your Child\'s Learning', 'Mary Mwale', 'Parenting', 'Parents play a crucial role in their children\'s education. Here are some practical tips for supporting your child\'s learning journey at home...', '', 'Published', '2026-07-25 10:17:12', '2026-07-25 10:17:12'),
(3, 'Our Approach to Mathematics Teaching', 'Alice Kamanga', 'Academic', 'Mathematics can be challenging for many students. Our approach focuses on building strong foundational skills through hands-on activities and real-world applications...', '', 'Published', '2026-07-25 10:17:12', '2026-07-25 10:17:12');

-- --------------------------------------------------------

--
-- Table structure for table `calendar_events`
--

CREATE TABLE `calendar_events` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `event_type` varchar(50) DEFAULT 'general',
  `event_date` date NOT NULL,
  `event_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `location` varchar(255) DEFAULT '',
  `created_by` varchar(100) DEFAULT '',
  `created_by_id` int(11) DEFAULT NULL,
  `target_audience` varchar(50) DEFAULT 'all',
  `class_name` varchar(50) DEFAULT '',
  `reminder_sent` tinyint(1) DEFAULT 0,
  `status` varchar(20) DEFAULT 'Active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `class_teachers`
--

CREATE TABLE `class_teachers` (
  `id` int(11) NOT NULL,
  `class_name` varchar(50) NOT NULL,
  `teacher_name` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `class_teachers`
--

INSERT INTO `class_teachers` (`id`, `class_name`, `teacher_name`, `created_at`) VALUES
(1, 'Standard 1', 'John Banda', '2026-07-25 10:17:12'),
(2, 'Standard 2', 'Alice Kamanga', '2026-07-25 10:17:12'),
(3, 'Standard 3', 'Peter Mkandawire', '2026-07-25 10:17:12'),
(4, 'Standard 4', 'John Banda', '2026-07-25 10:17:12'),
(5, 'Standard 5', 'Alice Kamanga', '2026-07-25 10:17:12'),
(6, 'Standard 6', 'Grace Chilima', '2026-07-25 10:17:12'),
(7, 'Standard 7', 'David Phiri', '2026-07-25 10:17:12'),
(8, 'Standard 8', 'Esther Kamanga', '2026-07-25 10:17:12'),
(9, 'Form 1', 'Mary Mwale', '2026-07-25 10:17:12'),
(10, 'Form 2', 'David Phiri', '2026-07-25 10:17:12');

-- --------------------------------------------------------

--
-- Table structure for table `collaboration_logs`
--

CREATE TABLE `collaboration_logs` (
  `id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `collaborator_id` int(11) NOT NULL,
  `class_name` varchar(50) DEFAULT '',
  `activity_type` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `related_report_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `collaboration_sessions`
--

CREATE TABLE `collaboration_sessions` (
  `id` int(11) NOT NULL,
  `session_name` varchar(255) NOT NULL,
  `class_name` varchar(50) DEFAULT '',
  `participants` text NOT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `status` varchar(20) DEFAULT 'Scheduled',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `complaints`
--

CREATE TABLE `complaints` (
  `id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `parent_name` varchar(255) NOT NULL,
  `class_name` varchar(100) NOT NULL,
  `complaint_text` text NOT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `teacher_response` text DEFAULT NULL,
  `responded_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `code` varchar(50) DEFAULT '',
  `description` text DEFAULT NULL,
  `grade_level` varchar(50) DEFAULT '',
  `credits` int(11) DEFAULT 0,
  `teacher_id` int(11) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'Active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `title`, `code`, `description`, `grade_level`, `credits`, `teacher_id`, `status`, `created_at`, `updated_at`) VALUES
(21, 'english', 'end67', 'ctvujkhgvcythj', 'Standard 4', 4, 23, 'Active', '2026-09-03 14:18:48', '2026-09-03 14:18:48'),
(22, 'nbfbp', 'b lov xmv;', 'cdvfbgv', 'Standard 4', 0, 24, 'Active', '2026-09-05 00:34:54', '2026-09-05 00:34:54'),
(23, 'english', 'end67', 'hxcncdiucvk', 'Standard 4', 3, 25, 'Active', '2026-09-06 21:01:13', '2026-09-06 21:01:13'),
(24, 'english', 'end67', 'hxcncdiucvk', 'Standard 4', 3, 25, 'Active', '2026-09-06 21:01:13', '2026-09-06 21:01:13');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `date` date DEFAULT NULL,
  `time` time DEFAULT NULL,
  `location` varchar(255) DEFAULT '',
  `description` text DEFAULT NULL,
  `image_url` varchar(500) DEFAULT '',
  `video_url` varchar(500) DEFAULT '',
  `link` varchar(500) DEFAULT '',
  `status` varchar(20) DEFAULT 'Upcoming',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `title`, `date`, `time`, `location`, `description`, `image_url`, `video_url`, `link`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Parent-Teacher Meeting', '2024-03-15', '14:00:00', 'School Hall', 'Quarterly meeting to discuss student progress and school activities', NULL, '', '', 'Ongoing', '2026-07-25 10:17:12', '2026-09-06 05:08:32'),
(2, 'Sports Day', '2024-04-20', '08:00:00', 'School Grounds', 'Annual sports competition featuring various athletic events', NULL, '', '', 'Upcoming', '2026-07-25 10:17:12', '2026-09-06 05:08:32'),
(3, 'Graduation Ceremony', '2024-07-30', '10:00:00', 'School Hall', 'Graduation ceremony for Standard 8 and Form 4 students', '', '', '', 'Upcoming', '2026-07-25 10:17:12', '2026-07-25 10:17:12'),
(4, 'Open Day', '2024-02-10', '09:00:00', 'Campus', 'Open day for prospective parents and students to tour the school', NULL, '', '', 'Completed', '2026-07-25 10:17:12', '2026-09-06 05:08:32'),
(6, 'SCHOOL PROGRAMS & PROGRAMS', '2026-07-02', '14:23:00', 'MIRACLE ECD Campus', 'cerebrtion', NULL, '', '', 'Upcoming', '2026-07-25 21:22:20', '2026-09-06 05:08:32'),
(8, 'Summer Camp', '2026-07-29', '20:00:00', 'Sports ground', 'Students in their usual uniform', '', '', '', 'Upcoming', '2026-07-26 12:55:38', '2026-07-26 12:55:38'),
(9, 'Summer Camp', '2026-07-29', '20:00:00', 'Sports ground', 'Students in their usual uniform', '', '', '', 'Upcoming', '2026-07-26 12:55:39', '2026-07-26 12:55:39'),
(10, 'Graduation Ceremony', '2026-07-02', '01:52:00', 'School Hall', 'v wduoijsdhubxyugXvyiX', NULL, '', '', 'Upcoming', '2026-07-30 08:52:12', '2026-09-06 05:08:32'),
(11, 'bvfujdvndvbnjuv', '2026-09-02', '10:35:00', 'gdeiudcnuidfk', 'gdwiudcniodck', NULL, '', '', 'Completed', '2026-09-01 17:35:50', '2026-09-06 05:08:32');

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `id` int(11) NOT NULL,
  `image_url` varchar(500) NOT NULL,
  `video_url` varchar(500) DEFAULT '',
  `media_type` varchar(20) DEFAULT 'image',
  `title` varchar(255) NOT NULL,
  `category` varchar(100) DEFAULT 'Academic',
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`id`, `image_url`, `video_url`, `media_type`, `title`, `category`, `description`, `created_at`) VALUES
(17, 'uploads/gallery_6a96f3ffeeea22.60513852.jpg', '', 'image', 'school', 'Academic', '', '2026-09-01 15:49:20'),
(18, 'uploads/gallery_6a96f421bb0065.18524444.jpg', '', 'image', 'Logo', 'Academic', '', '2026-09-01 15:49:53'),
(19, 'uploads/gallery_6a96f4620f2051.55277767.jpg', '', 'image', 'meeting', 'Events', '', '2026-09-01 15:50:58');

-- --------------------------------------------------------

--
-- Table structure for table `job_applications`
--

CREATE TABLE `job_applications` (
  `id` int(11) NOT NULL,
  `vacancy_id` int(11) NOT NULL,
  `applicant_name` varchar(255) NOT NULL,
  `applicant_email` varchar(255) NOT NULL,
  `applicant_phone` varchar(50) DEFAULT NULL,
  `cover_letter` text DEFAULT NULL,
  `status` varchar(50) DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `library`
--

CREATE TABLE `library` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `isbn` varchar(50) DEFAULT '',
  `publisher` varchar(255) DEFAULT '',
  `year` int(11) DEFAULT NULL,
  `pages` int(11) DEFAULT NULL,
  `category` varchar(100) NOT NULL,
  `language` varchar(50) DEFAULT 'English',
  `tags` text DEFAULT '',
  `copies` int(11) DEFAULT 1,
  `available` int(11) DEFAULT 1,
  `location` varchar(255) DEFAULT '',
  `status` varchar(20) DEFAULT 'Available',
  `borrower` varchar(255) DEFAULT '',
  `borrower_type` varchar(50) DEFAULT '',
  `borrowed_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `description` text DEFAULT '',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) DEFAULT '',
  `subject` varchar(255) DEFAULT '',
  `message` text DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `name`, `email`, `subject`, `message`, `is_read`, `created_at`) VALUES
(1, 'Thomas Kanyama', 'thomas.kanyama@gmail.com', 'Inquiry about admission', 'Hello, I would like to inquire about admission procedures for my daughter Emily for Standard 1. Please provide information on requirements and fees.', 1, '2026-07-25 10:17:12'),
(2, 'Martha Nkhoma', 'martha.nkhoma@yahoo.com', 'School fees inquiry', 'Hi, I would like to know the current school fees for Standard 4 students and if there are any payment plans available.', 1, '2026-07-25 10:17:12'),
(3, 'George Banda', 'george.banda@gmail.com', 'Transport services', 'Does the school provide transport services? If yes, what are the routes and fees?', 1, '2026-07-25 10:17:12'),
(4, 'Sarah Phiri', 'sarah.phiri@hotmail.com', 'Curriculum question', 'What curriculum does the school follow? Is it the Malawi government curriculum or international?', 1, '2026-07-25 10:17:12'),
(5, 'John Mwale', 'john.mwale@company.com', 'Partnership inquiry', 'Our company would like to discuss potential partnership opportunities with the school for student internship programs.', 1, '2026-07-25 10:17:12');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL DEFAULT 'system',
  `title` varchar(255) NOT NULL,
  `message` text DEFAULT NULL,
  `icon` varchar(100) DEFAULT 'fa-bell',
  `icon_bg` varchar(20) DEFAULT '#085636',
  `link` varchar(255) DEFAULT NULL,
  `link_label` varchar(100) DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `priority` varchar(20) DEFAULT 'normal',
  `target_audience` varchar(50) DEFAULT 'admin',
  `source_type` varchar(50) DEFAULT NULL,
  `source_id` int(11) DEFAULT NULL,
  `delivery_teacher_portal` tinyint(1) DEFAULT 0,
  `delivery_parent_portal` tinyint(1) DEFAULT 0,
  `delivery_email` tinyint(1) DEFAULT 0,
  `delivery_sms` tinyint(1) DEFAULT 0,
  `email_recipients` text DEFAULT NULL,
  `sms_recipients` text DEFAULT NULL,
  `sms_api_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `type`, `title`, `message`, `icon`, `icon_bg`, `link`, `link_label`, `is_read`, `priority`, `target_audience`, `source_type`, `source_id`, `delivery_teacher_portal`, `delivery_parent_portal`, `delivery_email`, `delivery_sms`, `email_recipients`, `sms_recipients`, `sms_api_id`, `created_at`, `updated_at`) VALUES
(1, 'system', 'Test Notification', 'This is a test notification', 'fa-bell', '#085636', NULL, NULL, 0, '0', 'all', NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2026-08-01 12:53:23', '2026-08-01 12:53:23'),
(2, 'system', 'vdiukdsk', 'vdiugdshusd', 'fa-bell', '#085636', '', NULL, 0, '0', 'admin', NULL, NULL, 1, 1, 1, 0, '', NULL, NULL, '2026-08-01 12:59:15', '2026-08-01 12:59:15'),
(3, 'system', 'bfdiodfjdfioj', 'cbfndtytuf,ighljbkn', 'fa-bell', '#085636', '', NULL, 0, '0', 'admin', NULL, NULL, 1, 1, 0, 0, '', NULL, NULL, '2026-08-10 19:36:40', '2026-08-10 19:36:40'),
(4, 'system', 'New Job Vacancy: ICT Officer', 'We have 1 new job vacancy/vacancies available: ICT Officer. Apply now!', 'fa-bell', '#085636', '', NULL, 0, '0', 'admin', NULL, NULL, 0, 1, 1, 0, '', NULL, NULL, '2026-08-10 20:45:23', '2026-08-10 20:45:23'),
(5, 'system', 'New Job Vacancy: ICT Officer', 'We have 1 new job vacancy/vacancies available: ICT Officer. Apply now!', 'fa-bell', '#085636', '', NULL, 0, '0', 'admin', NULL, NULL, 0, 1, 1, 0, '', NULL, NULL, '2026-08-10 20:45:31', '2026-08-10 20:45:31'),
(6, 'message', 'New Job Vacancy: ICT Officer', 'XVbikcdvmvlkx', 'fa-bell', '#085636', '', NULL, 0, '0', 'admin', NULL, NULL, 1, 1, 0, 0, '', NULL, NULL, '2026-08-12 15:58:00', '2026-08-12 15:58:00'),
(7, 'system', 'bdvildvoi', 'vdiuscbcsi', 'fa-bell', '#085636', '', NULL, 0, '0', 'admin', NULL, NULL, 1, 0, 0, 0, '', NULL, NULL, '2026-09-02 10:48:22', '2026-09-02 10:48:22'),
(8, 'system', 'New Job Vacancy: undefined (Copy)', 'We have 1 new job vacancy/vacancies available: undefined (Copy). Apply now!', 'fa-bell', '#085636', '', NULL, 0, '0', 'admin', NULL, NULL, 1, 0, 0, 0, '', '', NULL, '2026-09-05 00:47:33', '2026-09-05 00:47:33'),
(9, 'system', 'New Job Vacancy: undefined (Copy)', 'We have 1 new job vacancy/vacancies available: undefined (Copy). Apply now!', 'fa-bell', '#085636', '', NULL, 0, '0', 'admin', NULL, NULL, 1, 0, 0, 0, '', '', NULL, '2026-09-05 00:47:51', '2026-09-05 00:47:51');

-- --------------------------------------------------------

--
-- Table structure for table `parents`
--

CREATE TABLE `parents` (
  `id` int(11) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(200) DEFAULT '',
  `phone` varchar(50) DEFAULT '',
  `password` varchar(255) NOT NULL,
  `student_ids` text DEFAULT '',
  `approved` tinyint(1) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `registration_code` varchar(50) DEFAULT NULL,
  `code_expires_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `parents`
--

INSERT INTO `parents` (`id`, `first_name`, `last_name`, `username`, `email`, `phone`, `password`, `student_ids`, `approved`, `is_active`, `registration_code`, `code_expires_at`, `created_at`, `updated_at`) VALUES
(10, 'Precious', 'Chimwemwe', 'Precious', 'pchimwemwe@gmail.com', '', '$2y$10$haCBqud3iVV.UMcUFPbviuSmV/0kKDmxBHNU.OnArudtWqkpIsE6i', '', 1, 1, '', NULL, '2026-07-27 05:01:11', '2026-07-27 10:27:43'),
(12, 'thoko', 'masinga', 'thokoalfred@gmail.com', 'thokoalfred13@gmail.com', '', '$2y$10$cAvvgYoT8h6ugOAA1yC93uIJvWyBeDZuiMSoiye8DoZX6IcfANgvq', '', 0, 1, NULL, NULL, '2026-07-31 13:30:11', '2026-07-31 13:30:11'),
(13, 'Precious', 'Chimwemwe Msukuma', 'pcm', 'preciousmsukuma09@gmail.com', '0999635561/0884190000', '$2y$10$EjkZab5yL24yX34NTKwBI.bZtTir9Mry6ndQDN3R3jplfTx2M5CES', '1,28', 0, 1, 'NCA-QBSP-HMLS', '2026-09-04 16:55:11', '2026-08-04 17:00:34', '2026-09-03 14:55:12'),
(14, 'cupicsart', 'keen', 'cupicsart@gmail.com', 'cupicsart@gmail.com', '0992260985', '$2y$10$.HZbNxg70ADH31.WqI5/TOsCJMdn2agwtfurVMR01wsmwb9sO7lL.', '30', 1, 1, '', NULL, '2026-09-03 15:36:28', '2026-09-05 17:04:56');

-- --------------------------------------------------------

--
-- Table structure for table `parent_authorized_emails`
--

CREATE TABLE `parent_authorized_emails` (
  `id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `parent_authorized_ips`
--

CREATE TABLE `parent_authorized_ips` (
  `id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `parent_authorized_ips`
--

INSERT INTO `parent_authorized_ips` (`id`, `parent_id`, `ip_address`, `description`, `created_at`) VALUES
(2, 10, '192.168.1.1', 'Test IP', '2026-09-05 19:14:10');

-- --------------------------------------------------------

--
-- Table structure for table `parent_login_logs`
--

CREATE TABLE `parent_login_logs` (
  `id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `ip_address` varchar(50) DEFAULT '',
  `location` varchar(255) DEFAULT '',
  `browser` varchar(100) DEFAULT '',
  `os` varchar(100) DEFAULT '',
  `device` varchar(50) DEFAULT '',
  `user_agent` text DEFAULT '',
  `login_status` varchar(20) DEFAULT 'success',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `parent_login_logs`
--

INSERT INTO `parent_login_logs` (`id`, `parent_id`, `ip_address`, `location`, `browser`, `os`, `device`, `user_agent`, `login_status`, `created_at`) VALUES
(1, 7, '::1', '', 'Edge', 'Windows 10/11', 'Desktop', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0', 'success', '2026-07-25 23:09:16'),
(2, 6, '::1', '', 'Edge', 'Windows 10/11', 'Desktop', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0', 'success', '2026-07-26 08:11:04'),
(3, 8, '102.70.100.203', '', 'Edge', 'Windows 10/11', 'Desktop', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0', 'failed', '2026-07-26 12:28:17'),
(4, 9, '197.211.119.184', '', 'Edge', 'Windows 10/11', 'Desktop', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0', 'success', '2026-07-26 12:31:18'),
(5, 9, '102.70.100.203', '', 'Edge', 'Windows 10/11', 'Desktop', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0', 'success', '2026-07-26 12:31:37'),
(6, 11, '::1', '', 'Edge', 'Windows 10/11', 'Desktop', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0', 'success', '2026-07-27 10:25:08'),
(7, 13, '105.234.174.124', '', 'Chrome', 'Linux', 'Desktop', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', 'success', '2026-08-04 17:07:32'),
(8, 14, '::1', '', 'Edge', 'Windows 10/11', 'Desktop', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0', 'success', '2026-09-03 15:37:07'),
(9, 14, '::1', '', 'Edge', 'Windows 10/11', 'Desktop', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0', 'success', '2026-09-05 07:28:17'),
(10, 14, '::1', '', 'Edge', 'Windows 10/11', 'Desktop', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0', 'success', '2026-09-05 17:03:55'),
(11, 14, '::1', '', 'Edge', 'Windows 10/11', 'Desktop', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0', 'success', '2026-09-06 22:59:32');

-- --------------------------------------------------------

--
-- Table structure for table `parent_report_access`
--

CREATE TABLE `parent_report_access` (
  `id` int(11) NOT NULL,
  `report_id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `access_granted_by` varchar(20) NOT NULL COMMENT 'Teacher, Admin',
  `access_granted_by_id` int(11) NOT NULL,
  `access_level` varchar(20) DEFAULT 'view' COMMENT 'view, download',
  `status` varchar(20) DEFAULT 'Pending' COMMENT 'Pending, Viewed, Archived',
  `granted_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `viewed_at` datetime DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `payer_name` varchar(200) NOT NULL,
  `student_name` varchar(200) DEFAULT '',
  `student_id` int(11) DEFAULT NULL,
  `registration_id` int(11) DEFAULT NULL,
  `amount` decimal(12,2) DEFAULT 0.00,
  `payment_type` varchar(100) DEFAULT '',
  `phone` varchar(50) DEFAULT '',
  `payment_method` varchar(100) DEFAULT '',
  `api_provider` varchar(100) DEFAULT NULL,
  `api_name` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `payment_proof` varchar(255) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `payer_name`, `student_name`, `student_id`, `registration_id`, `amount`, `payment_type`, `phone`, `payment_method`, `api_provider`, `api_name`, `notes`, `payment_proof`, `status`, `created_at`, `updated_at`) VALUES
(17, 'Mrs Nkhata', 'Daniel Nkhata', NULL, NULL, '100000.00', 'Tuition', '0991943021', 'Bank Transfer', NULL, NULL, '', NULL, 'Pending', '2026-08-04 16:29:48', '2026-08-04 16:29:48'),
(18, 'Mrs Nkhata ', 'Daniel Nkhata ', NULL, NULL, '95000.00', 'Uniform', '', 'Bank Transfer', NULL, NULL, '', NULL, 'Pending', '2026-08-04 16:32:20', '2026-08-04 16:32:20'),
(19, 'Mrs Nkhata ', 'Daniel Nkhata ', NULL, NULL, '30000.00', 'Other', '0888383886', 'Bank Transfer', NULL, NULL, 'Summer fees ', NULL, 'Pending', '2026-08-04 16:35:06', '2026-08-04 16:35:06'),
(20, 'Mrs Nkhata', 'Daniel Nkhata', NULL, NULL, '15000.00', 'Registration Fee', '0991943021', 'Bank Transfer', NULL, NULL, '', NULL, 'Pending', '2026-08-04 16:36:21', '2026-08-04 16:36:21'),
(21, 'Mrs Nkhata ', 'Daniel Nkhata ', NULL, NULL, '15000.00', 'Other', '0888383886', 'Bank Transfer', NULL, NULL, 'Code number ', NULL, 'Paid', '2026-08-04 16:37:45', '2026-09-05 18:40:04');

-- --------------------------------------------------------

--
-- Table structure for table `registrations`
--

CREATE TABLE `registrations` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `student_name` varchar(200) NOT NULL,
  `grade` varchar(50) DEFAULT '',
  `parent_name` varchar(200) DEFAULT '',
  `phone` varchar(50) DEFAULT '',
  `email` varchar(200) DEFAULT '',
  `address` text DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `id_photo` varchar(255) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `registrations`
--

INSERT INTO `registrations` (`id`, `student_id`, `student_name`, `grade`, `parent_name`, `phone`, `email`, `address`, `dob`, `notes`, `id_photo`, `status`, `created_at`, `updated_at`) VALUES
(25, 28, 'Shiloh Uchindami Msukuma', 'Standard 4', 'Precious Chimwemwe Msukuma', '0999132773/0999635561', 'preciousmsukuma09@gmail.com', 'Area 38 New Site', '2017-08-05', 'Registered via parent portal. Emergency: Mrs Grace Msukuma (0999132773) Medical: ', NULL, 'Approved', '2026-08-04 17:13:03', '2026-08-04 17:16:32'),
(26, NULL, 'chumunthu banda', 'Daycare', 'Precious Chimwemwe Msukuma', '0992260987', 'cupicsart@gmail.com', 'lilongwe area 23, near dolo house', '2026-08-13', 'rxdtfuyiguoh', NULL, 'Rejected', '2026-08-12 06:52:49', '2026-08-12 06:53:39'),
(27, NULL, 'kondwni', 'Daycare', 'mr gunbo', '0992260985', 'kondwni@gmil.com', 'lilongwe', '2026-09-02', 'bdcilcmlc', NULL, 'Approved', '2026-09-01 17:32:37', '2026-09-01 17:33:06'),
(28, 30, 'dolo keen', 'Daycare', 'cupicsart@gmail.com ', '0992260985', 'cupicsart@gmail.com', 'lilongwe', '2026-09-04', 'Registered via parent portal. Emergency: 0992260985 (0998887776) Medical: no', NULL, 'Approved', '2026-09-03 16:51:15', '2026-09-04 18:20:13');

-- --------------------------------------------------------

--
-- Table structure for table `report_collaboration_comments`
--

CREATE TABLE `report_collaboration_comments` (
  `id` int(11) NOT NULL,
  `report_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `section_reference` varchar(100) DEFAULT '',
  `comment_text` text NOT NULL,
  `is_resolved` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `report_recipients`
--

CREATE TABLE `report_recipients` (
  `id` int(11) NOT NULL,
  `report_id` int(11) NOT NULL,
  `recipient_type` varchar(20) NOT NULL COMMENT 'Teacher, Admin, Parent',
  `recipient_id` int(11) NOT NULL,
  `access_level` varchar(20) DEFAULT 'view' COMMENT 'view, edit, approve',
  `status` varchar(20) DEFAULT 'Pending' COMMENT 'Pending, Viewed, Approved, Rejected',
  `assigned_by` varchar(20) NOT NULL COMMENT 'Teacher, Admin, Parent',
  `assigned_by_id` int(11) NOT NULL,
  `message` text DEFAULT NULL,
  `assigned_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `viewed_at` datetime DEFAULT NULL,
  `responded_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `report_sharing_log`
--

CREATE TABLE `report_sharing_log` (
  `id` int(11) NOT NULL,
  `report_id` int(11) NOT NULL,
  `sent_from_type` varchar(20) NOT NULL COMMENT 'Teacher, Admin, Parent',
  `sent_from_id` int(11) NOT NULL,
  `sent_to_type` varchar(20) NOT NULL COMMENT 'Teacher, Admin, Parent',
  `sent_to_id` int(11) NOT NULL,
  `action` varchar(50) NOT NULL COMMENT 'Submitted, Approved, Rejected, Returned, Published',
  `access_level` varchar(20) DEFAULT 'view' COMMENT 'view, edit, approve',
  `message` text DEFAULT NULL,
  `status` varchar(20) DEFAULT 'Pending' COMMENT 'Pending, Completed, Cancelled',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `completed_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `school_reports`
--

CREATE TABLE `school_reports` (
  `id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `teacher_name` varchar(200) DEFAULT '',
  `student_id` int(11) DEFAULT NULL,
  `student_name` varchar(200) NOT NULL,
  `class_name` varchar(50) DEFAULT '',
  `term` varchar(50) DEFAULT '',
  `academic_year` varchar(20) DEFAULT '',
  `report_data` longtext DEFAULT NULL,
  `overall_comment` text DEFAULT NULL,
  `overall_grade` varchar(10) DEFAULT '',
  `signature_img` longtext DEFAULT NULL,
  `status` varchar(20) DEFAULT 'Draft',
  `signed_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `workflow_status` varchar(20) DEFAULT 'Draft' COMMENT 'Draft, Pending, Approved, Rejected, Published',
  `current_location` varchar(50) DEFAULT 'Teacher' COMMENT 'Teacher, Admin, Parent',
  `sent_to_admin` tinyint(1) DEFAULT 0,
  `sent_to_parent` tinyint(1) DEFAULT 0,
  `admin_feedback` text DEFAULT NULL,
  `parent_feedback` text DEFAULT NULL,
  `admin_reviewed_at` datetime DEFAULT NULL,
  `parent_viewed_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `icon` varchar(100) DEFAULT 'fas fa-concierge-bell',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `title`, `description`, `icon`, `created_at`) VALUES
(1, 'Christian Education', 'Faith-centered teaching with Christian values embedded in daily learning.', 'fas fa-praying-hands', '2026-07-25 10:16:56'),
(2, 'Academic Excellence', 'Well-qualified teachers providing structured academic lessons and character development.', 'fas fa-book-open', '2026-07-25 10:16:56'),
(3, 'Safe Environment', 'Supportive staff, healthy campus routines, and positive discipline for every child.', 'fas fa-shield-alt', '2026-07-25 10:16:56'),
(4, 'School Transport', 'Safe and reliable transport services for students in selected areas.', 'fas fa-bus', '2026-07-25 10:17:12'),
(5, 'School Meals', 'Nutritious meals provided daily for students.', 'fas fa-utensils', '2026-07-25 10:17:12'),
(6, 'After-School Care', 'Supervised after-school program for working parents.', 'fas fa-clock', '2026-07-25 10:17:12'),
(7, 'Library Services', 'Well-stocked library with reading programs and research materials.dolo', 'fas fa-book-reader', '2026-07-25 10:17:12');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `setting_key`, `setting_value`, `updated_at`) VALUES
(1, 'username', 'admin', '2026-07-25 10:16:55'),
(2, 'displayName', 'NCA', '2026-07-29 14:01:58'),
(3, 'email', 'admin@nca.edu', '2026-07-25 10:16:55'),
(4, 'password', '$2y$10$TtYrI7Lm37LYYgPYI5X.j.43ChHYyWfHxz6LzbJf0bPr.QJ1BxRou', '2026-07-25 10:27:56'),
(5, 'schoolName', 'Noah Christian Academy', '2026-07-25 10:16:55');

-- --------------------------------------------------------

--
-- Table structure for table `shared_report_drafts`
--

CREATE TABLE `shared_report_drafts` (
  `id` int(11) NOT NULL,
  `report_id` int(11) NOT NULL,
  `owner_teacher_id` int(11) NOT NULL,
  `shared_with_teacher_id` int(11) NOT NULL,
  `access_level` varchar(50) DEFAULT 'view',
  `comments` text DEFAULT NULL,
  `status` varchar(20) DEFAULT 'Active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `shared_resources`
--

CREATE TABLE `shared_resources` (
  `id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `resource_type` varchar(50) DEFAULT 'document',
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `file_url` varchar(500) DEFAULT '',
  `file_name` varchar(255) DEFAULT '',
  `shared_with_class` varchar(50) DEFAULT '',
  `shared_with_all` tinyint(1) DEFAULT 0,
  `download_count` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `site_content`
--

CREATE TABLE `site_content` (
  `id` int(11) NOT NULL,
  `page_name` varchar(50) NOT NULL,
  `content_key` varchar(100) NOT NULL,
  `content_value` text DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `site_content`
--

INSERT INTO `site_content` (`id`, `page_name`, `content_key`, `content_value`, `updated_at`) VALUES
(1, 'home', 'heroTitle', 'WELCOME TO NOAH CHRISTIAN ACADEMY', '2026-07-31 20:25:58'),
(2, 'home', 'heroTag', 'A BETTER EDUCATION WITH A BRIGHTER FUTURE', '2026-07-28 05:48:26'),
(3, 'home', 'admissionsHeading', 'Admissions', '2026-07-25 10:16:56'),
(4, 'home', 'admissionsText', 'Join our community of learners rooted in faith, excellence, and character.', '2026-07-25 10:16:56'),
(5, 'home', 'ctaHeading', 'Ready to Get Started?', '2026-07-25 10:16:56'),
(6, 'home', 'ctaText', 'Choose registration or payment and take the next step with Noah Christian Academy.', '2026-07-25 10:16:56'),
(7, 'about', 'title', 'About Noah Christian Academy', '2026-07-25 10:16:56'),
(8, 'about', 'mission', 'To deliver holistic education rooted in Christian values, developing learners who are intellectually developed, spiritually grounded and morally upright.', '2026-07-25 10:16:56'),
(9, 'about', 'vision', 'To be a leading centre of academic excellence and holistic learners development in Malawi.', '2026-07-25 10:16:56'),
(10, 'about', 'values', 'Faith in God, Academic Excellence, Discipline and Integrity', '2026-07-25 10:16:56'),
(11, 'features', 'heading', 'Our Features', '2026-07-25 10:16:56'),
(12, 'features', 'subtitle', 'Discover what makes Noah Christian Academy a unique environment.', '2026-07-25 10:16:56'),
(13, 'team', 'heading', 'Our Team', '2026-07-25 10:16:56'),
(14, 'team', 'subtitle', 'Meet our dedicated team of educators and staff.', '2026-07-25 10:16:56'),
(15, 'footer', 'address', 'P.O.BOX 30458, Area 24 PHA (Behind chilungamo investment), Lilongwe, Malawi ', '2026-07-26 04:33:41'),
(16, 'footer', 'phone', '+265 999 635 561', '2026-07-25 10:16:56'),
(17, 'footer', 'email', 'noahchristianacademy2021@gmail.com', '2026-07-25 10:16:56'),
(18, 'footer', 'copyright', '┬® 2026 Noah Christian Academy. All rights reserved.', '2026-07-25 10:16:56'),
(21, 'footer', 'phone2', '+265 999 693 134', '2026-09-02 07:43:39'),
(22, 'footer', 'description', 'Faith-led education with academic excellence and holistic learner development.', '2026-07-26 04:16:07'),
(23, 'footer', 'schoolHours', 'Monday - Friday: 7:30 AM - 4:00 PM | Saturday: 8:00 AM - 12:00 PM (Office Only) ', '2026-07-26 04:33:41'),
(24, 'footer', 'facebookUrl', 'https://www.facebook.com', '2026-07-25 23:29:58'),
(25, 'footer', 'tiktokUrl', 'https://www.tiktok.com', '2026-07-25 23:29:58'),
(26, 'footer', 'whatsappUrl', 'https://wa.me/265999635561', '2026-07-25 23:29:58'),
(3607, 'org_chart', 'trustees', 'APOSTLE ADAMS LWESYA', '2026-07-29 13:59:13'),
(3614, 'org_chart', 'board', 'MRS FROLA GUBA CHIWALE', '2026-07-29 13:59:39'),
(3621, 'org_chart', 'accountant', 'PASTOR JOSIAH SIBALE', '2026-07-29 14:00:47'),
(5479, 'org_chart', 'title_trustees', 'TRUSTEES', '2026-07-26 06:02:35'),
(37019, 'org_chart', 'principal', 'PRECIOUS CHIMWEMWE MSUKUMA', '2026-07-29 14:00:18');

-- --------------------------------------------------------

--
-- Table structure for table `sports_activities`
--

CREATE TABLE `sports_activities` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` varchar(50) NOT NULL,
  `sub_category` varchar(100) DEFAULT '',
  `description` text DEFAULT '',
  `day` varchar(20) NOT NULL,
  `time` varchar(20) NOT NULL,
  `end_time` varchar(20) DEFAULT '',
  `duration` decimal(4,2) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `instructor` varchar(255) DEFAULT '',
  `instructor_phone` varchar(50) DEFAULT '',
  `instructor_email` varchar(255) DEFAULT '',
  `location` varchar(255) DEFAULT '',
  `min_participants` int(11) DEFAULT 0,
  `max_participants` int(11) DEFAULT 0,
  `target_group` varchar(50) DEFAULT '',
  `fee_required` varchar(10) DEFAULT 'No',
  `fee_amount` decimal(10,2) DEFAULT 0.00,
  `equipment` text DEFAULT '',
  `requirements` text DEFAULT '',
  `status` varchar(20) DEFAULT 'Active',
  `current_participants` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `gender` varchar(10) DEFAULT '',
  `grade` varchar(50) DEFAULT '',
  `dob` date DEFAULT NULL,
  `parent_name` varchar(200) DEFAULT '',
  `parent_id` int(11) DEFAULT NULL,
  `phone` varchar(50) DEFAULT '',
  `address` text DEFAULT NULL,
  `emergency_contact` varchar(100) DEFAULT '',
  `emergency_phone` varchar(50) DEFAULT '',
  `medical_info` text DEFAULT NULL,
  `enrollment_date` date DEFAULT NULL,
  `status` varchar(20) DEFAULT 'Active',
  `fees_status` varchar(20) DEFAULT 'Pending',
  `registration_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `first_name`, `last_name`, `gender`, `grade`, `dob`, `parent_name`, `parent_id`, `phone`, `address`, `emergency_contact`, `emergency_phone`, `medical_info`, `enrollment_date`, `status`, `fees_status`, `registration_id`, `created_at`, `updated_at`) VALUES
(27, 'Daniel', 'Nkhata', 'Male', 'Standard 4', '0000-00-00', 'Mrs Nkhata', NULL, '0991943021', '', '', '', '', NULL, 'Active', 'Pending', NULL, '2026-08-04 16:21:31', '2026-08-05 07:59:38'),
(28, 'Shiloh', 'Uchindami Msukuma', '', 'Standard 4', '2017-08-05', 'Precious Chimwemwe Msukuma', NULL, '0999132773/0999635561', 'Area 38 New Site', '', '', NULL, NULL, 'Active', 'Pending', 25, '2026-08-04 17:16:32', '2026-08-04 17:16:32'),
(30, 'dolo', 'keen', '', 'Daycare', '2026-09-04', 'cupicsart@gmail.com', NULL, '0992260985', 'lilongwe', '0992260985', '0992260985', 'none', NULL, 'Active', 'Pending', 28, '2026-09-03 16:52:09', '2026-09-04 15:50:49');

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `id` int(11) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(200) DEFAULT '',
  `phone` varchar(50) DEFAULT '',
  `subject` varchar(200) DEFAULT '',
  `qualification` varchar(200) DEFAULT '',
  `date_of_employment` date DEFAULT NULL,
  `national_id` varchar(50) DEFAULT '',
  `residential_address` text DEFAULT NULL,
  `next_of_kin` varchar(200) DEFAULT '',
  `next_of_kin_relationship` varchar(100) DEFAULT '',
  `next_of_kin_phone` varchar(50) DEFAULT '',
  `password` varchar(255) NOT NULL,
  `class_assigned` varchar(50) DEFAULT '',
  `approved` tinyint(1) DEFAULT 0,
  `registration_code` varchar(50) DEFAULT NULL,
  `code_expires_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_ip` varchar(45) DEFAULT NULL,
  `created_device` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`id`, `first_name`, `last_name`, `username`, `email`, `phone`, `subject`, `qualification`, `date_of_employment`, `national_id`, `residential_address`, `next_of_kin`, `next_of_kin_relationship`, `next_of_kin_phone`, `password`, `class_assigned`, `approved`, `registration_code`, `code_expires_at`, `created_at`, `updated_at`, `created_ip`, `created_device`) VALUES
(19, 'ALFRED', 'THOKOZANI MASINGA', 'THOKOZANI', 'thokoalfred13@gmail.com', '0997893100', 'PHYSICS, COMPUTER, MATHEMATICS', 'Bachelors Degree', '0000-00-00', '', '', '', '', '', 'teacher123', '', 1, NULL, NULL, '2026-07-31 15:54:50', '2026-07-31 15:55:01', NULL, NULL),
(21, 'Dziwani', 'David Kapyola', 'Kapyoladavid', 'kapyoladavid3@gmail.com', '0882334040', 'Mathematics', 'MSCE PT3', '2026-02-10', 'QA08Q1PN', 'Box 30458 Lilongwe3', 'Andrew Lipita', 'Brother', '0999666157', '$2y$10$e9StNUnlyKypECTpZ4kCIe.SKArnKD.k6wsgYPJfi.u2Nv0cA9urq', '', 1, '', NULL, '2026-08-02 07:35:25', '2026-08-04 08:22:16', '102.70.101.51', 'Linux Computer - Chrome'),
(22, 'Precious', 'Chimwemwe Msukuma', 'pcm', 'preciousmsukuma09@gmail.com', '0999635561', 'Languages', 'BAE Languages and Linguistics (Under Graduate)', '0000-00-00', '', '', '', '', '', '$2y$10$.b44eu9khvA65oRGXUOW/O0deQB2Uj6Rs4zj4CLj8rQX0TCrX9UTe', '', 1, '', NULL, '2026-08-04 16:42:08', '2026-08-04 16:52:57', '105.234.174.124', 'Linux Computer - Chrome'),
(23, 'cupicsart@gmail.com', 'Chilima', 'cupic@gmil.com', 'gumbo@gmail.com', '+265 999 693 134', 'English', '', '0000-00-00', '', '', '', 'Parent', '', '$2y$10$kR53a6YVa5vWKoNyB1xLt.nhb0rmT04/34xx1089tqCHftXrs4ylW', 'Standard 4', 1, '', NULL, '2026-08-12 16:11:39', '2026-09-03 15:32:33', '::1', 'Windows PC - Edge'),
(24, 'chisomo', 'chiko', 'ch@gmil.com', 'ch@gmil.com', '+265 999 693 134', 'English', 'msce', '2026-09-04', 'ID645784746', 're 23', 'kond', 'Parent', 'kon', '$2y$10$WUuhHFfYOWUMuD8KdY1Fn.yr.oXTHKeTwTF/l.yWMcXRqNJPc.QT6', 'Standard 4', 1, '', NULL, '2026-09-04 10:28:04', '2026-09-04 10:31:40', '::1', 'Windows PC - Edge'),
(25, 'kondwni', 'kpichi', 'kondwni@gmil.com', 'kondwni@gmil.com', '0992260985', 'dolo', 'bisscow', '2026-09-06', 'ID6u7yy', 'goolo987', 'vxjkb', 'bxoxnk', 'gvxxh', '$2y$10$y8yoevdOV/WPgaI.VlXoKexxdxYfGSKHYljrrOIT5q1yoGpVGXzS2', 'Standard 4', 1, '', NULL, '2026-09-06 18:14:19', '2026-09-06 18:21:38', '::1', 'Windows PC - Edge');

-- --------------------------------------------------------

--
-- Table structure for table `teacher_authorized_emails`
--

CREATE TABLE `teacher_authorized_emails` (
  `id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `teacher_authorized_ips`
--

CREATE TABLE `teacher_authorized_ips` (
  `id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `teacher_class_assignments`
--

CREATE TABLE `teacher_class_assignments` (
  `id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `class_name` varchar(50) NOT NULL,
  `role` varchar(50) DEFAULT 'Primary Teacher',
  `subject_focus` varchar(200) DEFAULT '',
  `assigned_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `teacher_exams`
--

CREATE TABLE `teacher_exams` (
  `id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `teacher_name` varchar(200) DEFAULT '',
  `title` varchar(255) NOT NULL,
  `subject` varchar(200) DEFAULT '',
  `class_name` varchar(50) DEFAULT '',
  `term` varchar(50) DEFAULT '',
  `description` text DEFAULT NULL,
  `file_url` varchar(500) NOT NULL,
  `file_name` varchar(255) DEFAULT '',
  `status` varchar(20) DEFAULT 'Pending',
  `approved_by` varchar(200) DEFAULT '',
  `approved_at` datetime DEFAULT NULL,
  `admin_notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `teacher_files`
--

CREATE TABLE `teacher_files` (
  `id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_type` varchar(50) NOT NULL,
  `file_size` bigint(20) NOT NULL,
  `uploaded_by` varchar(100) NOT NULL,
  `target_type` enum('all','specific') DEFAULT 'all',
  `target_teachers` text DEFAULT NULL,
  `priority` enum('normal','high','urgent') DEFAULT 'normal',
  `sent_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `teacher_name` varchar(255) NOT NULL,
  `category` varchar(50) DEFAULT 'general',
  `file_url` varchar(500) NOT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `admin_notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `teacher_files`
--

INSERT INTO `teacher_files` (`id`, `teacher_id`, `title`, `description`, `file_name`, `file_path`, `file_type`, `file_size`, `uploaded_by`, `target_type`, `target_teachers`, `priority`, `sent_at`, `created_at`, `updated_at`, `teacher_name`, `category`, `file_url`, `status`, `admin_notes`) VALUES
(1, 24, 'time tble', '', '0', '', 'application/pdf', 6993, '', 'all', NULL, 'normal', NULL, '2026-09-04 23:48:31', '2026-09-05 00:22:06', 'chisomo chiko', 'general', '../uploads/teacher_files/teacher_6a9b58ceb7255_0.pdf', 'approved', '');

-- --------------------------------------------------------

--
-- Table structure for table `teacher_login_logs`
--

CREATE TABLE `teacher_login_logs` (
  `id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `browser` varchar(100) DEFAULT NULL,
  `os` varchar(100) DEFAULT NULL,
  `device` varchar(50) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `login_status` enum('success','failed','blocked') DEFAULT 'success',
  `login_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `teacher_messages`
--

CREATE TABLE `teacher_messages` (
  `id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `subject` varchar(255) DEFAULT '',
  `message` text NOT NULL,
  `read_status` tinyint(1) DEFAULT 0,
  `reply_to_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `teacher_notes`
--

CREATE TABLE `teacher_notes` (
  `id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `class_name` varchar(50) DEFAULT '',
  `student_id` int(11) DEFAULT NULL,
  `note_content` text NOT NULL,
  `note_type` varchar(50) DEFAULT 'general',
  `is_private` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `teacher_resources`
--

CREATE TABLE `teacher_resources` (
  `id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `teacher_name` varchar(255) NOT NULL,
  `teacher_class` varchar(100) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `category` varchar(50) NOT NULL,
  `subject` varchar(100) DEFAULT NULL,
  `url` varchar(500) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `file_url` varchar(500) DEFAULT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `file_type` varchar(100) DEFAULT NULL,
  `share_with` varchar(20) DEFAULT 'private',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `team_members`
--

CREATE TABLE `team_members` (
  `id` int(11) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `role` varchar(200) DEFAULT '',
  `category` varchar(100) DEFAULT 'Teaching',
  `image_url` varchar(500) DEFAULT '',
  `description` text DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0,
  `status` varchar(20) DEFAULT 'Active',
  `show_on_website` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `team_members`
--

INSERT INTO `team_members` (`id`, `first_name`, `last_name`, `role`, `category`, `image_url`, `description`, `sort_order`, `status`, `show_on_website`, `created_at`, `updated_at`) VALUES
(2, 'Mary', 'Mwale', 'Headteacher', 'Leadership', NULL, 'Headteacher with over 10 years of educational leadership.', 2, 'Active', 1, '2026-07-25 10:16:56', '2026-09-06 05:08:33'),
(3, 'David', 'Phiri', 'Science Teacher', 'Staff', NULL, 'Specializes in science and computer lessons.', 3, 'Active', 1, '2026-07-25 10:16:56', '2026-09-06 05:08:33'),
(4, 'Jane', 'Kamwendo', 'Deputy Headteacher', 'Teachers', NULL, 'Deputy Headteacher with 8 years of educational leadership experience.', 4, 'Active', 1, '2026-07-25 10:17:12', '2026-09-06 05:08:33'),
(5, 'Esther', 'Banda', 'Guidance Counselor', 'Support Staff', 'images/stu.jpg', 'Provides guidance and counseling services to students.', 5, 'Active', 1, '2026-07-25 10:17:12', '2026-07-25 10:17:12'),
(7, 'Mary', 'Nyirenda', 'Librarian', 'Support Staff', 'images/stu.jpg', 'Manages the school library and reading programs.', 7, 'Active', 1, '2026-07-25 10:17:12', '2026-07-25 10:17:12'),
(8, 'kondwni', 'Chilima', 'ICT Coordinator', 'Leadership', NULL, 'Manages computer lab and ICT curriculum integration.', 8, 'Active', 1, '2026-07-25 10:17:12', '2026-09-06 05:08:33'),
(9, 'David', 'Mwale', 'Science Teacher', 'Administration', NULL, '', 0, '0', 1, '2026-07-31 20:25:32', '2026-09-06 05:08:33');

-- --------------------------------------------------------

--
-- Table structure for table `testimonials`
--

CREATE TABLE `testimonials` (
  `id` int(11) NOT NULL,
  `parent_name` varchar(200) NOT NULL,
  `student_name` varchar(200) NOT NULL,
  `grade` varchar(50) NOT NULL,
  `years_enrolled` int(11) NOT NULL,
  `testimonial` text NOT NULL,
  `rating` int(11) NOT NULL,
  `anonymous` tinyint(1) DEFAULT 0,
  `status` varchar(20) DEFAULT 'pending',
  `rejection_reason` text DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `rejected_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `timetable`
--

CREATE TABLE `timetable` (
  `id` int(11) NOT NULL,
  `day` varchar(20) NOT NULL,
  `time` varchar(20) NOT NULL,
  `end_time` varchar(20) DEFAULT '',
  `duration` int(11) DEFAULT NULL,
  `period` varchar(100) DEFAULT '',
  `class_name` varchar(100) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `subject_code` varchar(50) DEFAULT '',
  `teacher` varchar(255) DEFAULT '',
  `room` varchar(100) DEFAULT '',
  `building` varchar(100) DEFAULT '',
  `room_type` varchar(50) DEFAULT 'Classroom',
  `term` varchar(50) DEFAULT '',
  `academic_year` varchar(20) DEFAULT '',
  `notes` text DEFAULT '',
  `recurring` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `timetable`
--

INSERT INTO `timetable` (`id`, `day`, `time`, `end_time`, `duration`, `period`, `class_name`, `subject`, `subject_code`, `teacher`, `room`, `building`, `room_type`, `term`, `academic_year`, `notes`, `recurring`, `created_at`, `updated_at`) VALUES
(2, 'Monday', '07:30', '08:00', 30, 'period 1 english', 'Standard 4', 'english', 'eng303', 'cupicsart@gmail.com Chilima', 'room 1', 'floor 5', 'Classroom', 'Term 1', '2026', 'no', 1, '2026-09-03 06:53:10', '2026-09-04 11:25:02');

-- --------------------------------------------------------

--
-- Table structure for table `timetable_documents`
--

CREATE TABLE `timetable_documents` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `class` varchar(100) DEFAULT '',
  `term` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `file_url` varchar(500) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_size` int(11) DEFAULT 0,
  `file_type` varchar(100) DEFAULT '',
  `uploaded_by` varchar(255) DEFAULT 'Admin',
  `target` varchar(20) DEFAULT 'teachers',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `timetable_documents`
--

INSERT INTO `timetable_documents` (`id`, `title`, `class`, `term`, `description`, `file_url`, `file_name`, `file_size`, `file_type`, `uploaded_by`, `target`, `created_at`) VALUES
(1, 'term one time tb;e', '', 'Term 1', 'bhsndvjk', '../uploads/timetable/timetable_6a9b4e6ed2894.pdf', 'LINA.pdf', 6993, 'application/pdf', 'Admin', 'teachers', '2026-09-04 23:04:14');

-- --------------------------------------------------------

--
-- Table structure for table `transport`
--

CREATE TABLE `transport` (
  `id` int(11) NOT NULL,
  `vehicle_number` varchar(50) NOT NULL,
  `vehicle_type` varchar(50) DEFAULT 'Bus',
  `make_model` varchar(255) DEFAULT '',
  `year` int(11) DEFAULT NULL,
  `color` varchar(50) DEFAULT '',
  `driver_name` varchar(255) NOT NULL,
  `driver_phone` varchar(50) NOT NULL,
  `driver_license` varchar(100) DEFAULT '',
  `driver_address` text DEFAULT '',
  `route` varchar(255) NOT NULL,
  `route_details` text DEFAULT '',
  `morning_time` varchar(20) DEFAULT '',
  `afternoon_time` varchar(20) DEFAULT '',
  `capacity` int(11) NOT NULL,
  `assigned_students` int(11) DEFAULT 0,
  `assigned_classes` varchar(255) DEFAULT '',
  `status` varchar(20) DEFAULT 'Active',
  `last_service` date DEFAULT NULL,
  `next_service` date DEFAULT NULL,
  `insurance_expiry` date DEFAULT NULL,
  `maintenance_notes` text DEFAULT '',
  `fuel_type` varchar(50) DEFAULT 'Diesel',
  `emergency_contact` varchar(255) DEFAULT '',
  `notes` text DEFAULT '',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `transport`
--

INSERT INTO `transport` (`id`, `vehicle_number`, `vehicle_type`, `make_model`, `year`, `color`, `driver_name`, `driver_phone`, `driver_license`, `driver_address`, `route`, `route_details`, `morning_time`, `afternoon_time`, `capacity`, `assigned_students`, `assigned_classes`, `status`, `last_service`, `next_service`, `insurance_expiry`, `maintenance_notes`, `fuel_type`, `emergency_contact`, `notes`, `created_at`, `updated_at`) VALUES
(1, 'cd 3468', 'Minibus', 'dolo', 1990, 'red', 'dolo dolo', '0992260985', '8998', 'dolodolo', 'dolo', ' vvdnvdpkvd', '18', '19', 7, 0, 'stnd 3', 'Active', '2026-08-13', '0000-00-00', '2026-08-12', 'cxvbv', 'Petrol', 'xcvdfb', 'xcvfb', '2026-08-12 15:53:40', '2026-08-12 15:53:40');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','teacher','parent') NOT NULL DEFAULT 'parent',
  `phone` varchar(20) DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `notes` text DEFAULT NULL,
  `last_login` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `password`, `role`, `phone`, `status`, `notes`, `last_login`, `created_at`, `updated_at`) VALUES
(1, 'kondwni', 'kpichi', 'gumbo@gmail.com', '$2y$10$3MJGoThK7h6RP.TJk9MCc.0/4dQeXYwxrV4yXtMaat4hP2mXP.tDe', 'admin', '+265 999 693 134', 'active', '', NULL, '2026-09-02 17:24:34', '2026-09-02 17:24:34');

-- --------------------------------------------------------

--
-- Table structure for table `vacancies`
--

CREATE TABLE `vacancies` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `requirements` text DEFAULT NULL,
  `grade` varchar(100) DEFAULT '',
  `responsibilities` text DEFAULT NULL,
  `duties` text DEFAULT NULL,
  `contact_email` varchar(255) DEFAULT '',
  `location` varchar(200) DEFAULT '',
  `position_type` varchar(100) DEFAULT 'Full-time',
  `salary_range` varchar(200) DEFAULT '',
  `application_deadline` date DEFAULT NULL,
  `status` varchar(20) DEFAULT 'Active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `vacancies`
--

INSERT INTO `vacancies` (`id`, `title`, `description`, `requirements`, `grade`, `responsibilities`, `duties`, `contact_email`, `location`, `position_type`, `salary_range`, `application_deadline`, `status`, `created_at`, `updated_at`) VALUES
(13, 'ICT Officer', 'We are seeking a skilled and motivated ICT Officer to join our team. The successful candidate will be responsible for managing and supporting the organization\'s information and communication technology systems to ensure smooth and efficient operations.\n\n', 'Qualifications\n\nBachelor’s degree in Information Technology, Computer Science, or related field.\n\nProven experience in ICT support and administration.\n\nStrong knowledge of networking, hardware, and software systems.\n\nExcellent problem-solving and communication skills.\n\nAbility to work independently and as part of a team.', '', 'Key Responsibilities\n\nMaintain and troubleshoot hardware, software, and network systems.\n\nProvide technical support and training to staff and users.\n\nManage ICT infrastructure, including servers, databases, and security.\n\nDevelop and implement ICT policies and procedures.\n\nEnsure data backup, recovery, and cybersecurity measures are in place.\n\nCollaborate with other departments to integrate technology solutions.\n', '', '', 'LILONGWE', 'Temporary', '300000', '2026-08-23', 'Active', '2026-07-28 06:27:55', '2026-08-10 20:47:23'),
(17, 'undefined (Copy)', '', '', '', '', '', '', '', 'Full-time', '', NULL, 'Archived', '2026-09-05 00:46:49', '2026-09-05 00:46:55');

-- --------------------------------------------------------

--
-- Table structure for table `visitor_logs`
--

CREATE TABLE `visitor_logs` (
  `id` int(11) NOT NULL,
  `ip_address` varchar(50) DEFAULT '',
  `location` varchar(255) DEFAULT '',
  `browser` varchar(100) DEFAULT '',
  `os` varchar(100) DEFAULT '',
  `device` varchar(50) DEFAULT '',
  `page` varchar(255) DEFAULT '',
  `referrer` varchar(500) DEFAULT '',
  `session_id` varchar(100) DEFAULT '',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `visitor_logs`
--

INSERT INTO `visitor_logs` (`id`, `ip_address`, `location`, `browser`, `os`, `device`, `page`, `referrer`, `session_id`, `created_at`) VALUES
(1, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/team.html', 'sid_1770233905453_1xasjwe5s', '2026-07-25 10:42:38'),
(2, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/team.html', 'sid_1770233905453_1xasjwe5s', '2026-07-25 10:48:08'),
(3, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/admissions.html', 'sid_1770233905453_1xasjwe5s', '2026-07-25 10:52:01'),
(4, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/admissions.html', 'sid_1770233905453_1xasjwe5s', '2026-07-25 11:05:07'),
(5, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/admissions.html', 'sid_1770233905453_1xasjwe5s', '2026-07-25 11:10:07'),
(6, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/admissions.html', 'sid_1770233905453_1xasjwe5s', '2026-07-25 11:12:19'),
(7, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/admissions.html', 'sid_1770233905453_1xasjwe5s', '2026-07-25 11:14:10'),
(8, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/admissions.html', 'sid_1770233905453_1xasjwe5s', '2026-07-25 11:15:21'),
(9, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/admissions.html', 'sid_1770233905453_1xasjwe5s', '2026-07-25 11:17:10'),
(10, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/admissions.html', 'sid_1770233905453_1xasjwe5s', '2026-07-25 11:18:59'),
(11, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/about.html', 'sid_1770233905453_1xasjwe5s', '2026-07-25 11:35:11'),
(12, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/admissions.html', 'sid_1770233905453_1xasjwe5s', '2026-07-25 11:48:22'),
(13, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/vacancy.html', 'sid_1770233905453_1xasjwe5s', '2026-07-25 12:02:53'),
(14, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/service.html', 'sid_1770233905453_1xasjwe5s', '2026-07-25 12:08:24'),
(15, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1770233905453_1xasjwe5s', '2026-07-25 19:53:21'),
(16, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1770233905453_1xasjwe5s', '2026-07-25 20:23:29'),
(17, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-07-25 20:37:49'),
(18, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/events.html', 'sid_1770233905453_1xasjwe5s', '2026-07-25 20:56:48'),
(19, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/features.html', 'sid_1770233905453_1xasjwe5s', '2026-07-25 20:58:12'),
(20, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/features.html', 'sid_1770233905453_1xasjwe5s', '2026-07-25 20:59:15'),
(21, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/admissions.html', 'sid_1770233905453_1xasjwe5s', '2026-07-25 21:02:39'),
(22, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/vacancy.html', 'sid_1770233905453_1xasjwe5s', '2026-07-25 21:04:28'),
(23, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/about.html', 'sid_1770233905453_1xasjwe5s', '2026-07-25 21:11:18'),
(24, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/pta.html', 'sid_1770233905453_1xasjwe5s', '2026-07-25 21:14:14'),
(25, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1770233905453_1xasjwe5s', '2026-07-25 21:22:32'),
(26, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-07-25 22:04:16'),
(27, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/gallery.html', 'sid_1770233905453_1xasjwe5s', '2026-07-25 22:12:35'),
(28, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/vacancy.html', 'sid_1770233905453_1xasjwe5s', '2026-07-25 22:28:09'),
(29, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-07-25 22:39:04'),
(30, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/events.html', 'sid_1770233905453_1xasjwe5s', '2026-07-25 23:04:15'),
(31, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1770233905453_1xasjwe5s', '2026-07-25 23:16:19'),
(32, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/blog.html', 'sid_1770233905453_1xasjwe5s', '2026-07-25 23:19:13'),
(33, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1770233905453_1xasjwe5s', '2026-07-25 23:24:46'),
(34, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/team.html', 'sid_1770233905453_1xasjwe5s', '2026-07-25 23:32:42'),
(35, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/admissions.html', 'sid_1770233905453_1xasjwe5s', '2026-07-25 23:36:23'),
(36, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/blog.html', 'sid_1770233905453_1xasjwe5s', '2026-07-25 23:40:01'),
(37, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/blog.html', 'sid_1770233905453_1xasjwe5s', '2026-07-25 23:41:29'),
(38, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-07-26 03:52:14'),
(39, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-07-26 04:04:01'),
(40, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1770233905453_1xasjwe5s', '2026-07-26 04:16:12'),
(41, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1770233905453_1xasjwe5s', '2026-07-26 04:20:33'),
(42, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/features.html', 'sid_1770233905453_1xasjwe5s', '2026-07-26 04:22:43'),
(43, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-07-26 04:25:51'),
(44, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/features.html', 'sid_1770233905453_1xasjwe5s', '2026-07-26 04:28:00'),
(45, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-07-26 04:32:12'),
(46, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-07-26 04:33:51'),
(47, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/team.html', 'sid_1770233905453_1xasjwe5s', '2026-07-26 04:36:29'),
(48, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/team.html', 'sid_1770233905453_1xasjwe5s', '2026-07-26 04:39:46'),
(49, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/team.html', 'sid_1770233905453_1xasjwe5s', '2026-07-26 05:17:48'),
(50, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/team.html', 'sid_1770233905453_1xasjwe5s', '2026-07-26 05:36:20'),
(51, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/team.html', 'sid_1770233905453_1xasjwe5s', '2026-07-26 05:56:57'),
(52, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/team.html', 'sid_1770233905453_1xasjwe5s', '2026-07-26 06:00:38'),
(53, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/events.html', 'sid_1770233905453_1xasjwe5s', '2026-07-26 06:15:39'),
(54, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/team.html', 'sid_1770233905453_1xasjwe5s', '2026-07-26 06:21:46'),
(55, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/team.html', 'sid_1770233905453_1xasjwe5s', '2026-07-26 06:22:59'),
(56, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/team.html', 'sid_1770233905453_1xasjwe5s', '2026-07-26 06:28:43'),
(57, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/team.html', 'sid_1770233905453_1xasjwe5s', '2026-07-26 06:42:10'),
(58, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/team.html', 'sid_1770233905453_1xasjwe5s', '2026-07-26 06:45:26'),
(59, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/team.html', 'sid_1770233905453_1xasjwe5s', '2026-07-26 06:46:48'),
(60, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/team.html', 'sid_1770233905453_1xasjwe5s', '2026-07-26 06:48:22'),
(61, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/team.html', 'sid_1770233905453_1xasjwe5s', '2026-07-26 06:49:32'),
(62, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/team.html', 'sid_1770233905453_1xasjwe5s', '2026-07-26 06:51:50'),
(63, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/admissions.html', 'sid_1770233905453_1xasjwe5s', '2026-07-26 06:53:36'),
(64, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/admissions.html', 'sid_1770233905453_1xasjwe5s', '2026-07-26 06:54:37'),
(65, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/gallery.html', 'sid_1770233905453_1xasjwe5s', '2026-07-26 06:56:44'),
(66, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/events.html', 'sid_1770233905453_1xasjwe5s', '2026-07-26 07:00:56'),
(67, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/gallery.html', 'sid_1770233905453_1xasjwe5s', '2026-07-26 07:02:44'),
(68, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/events.html', 'sid_1770233905453_1xasjwe5s', '2026-07-26 07:11:03'),
(69, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/events.html', 'sid_1770233905453_1xasjwe5s', '2026-07-26 07:12:04'),
(70, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/events.html', 'sid_1770233905453_1xasjwe5s', '2026-07-26 07:14:44'),
(71, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/events.html', 'sid_1770233905453_1xasjwe5s', '2026-07-26 07:15:59'),
(72, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/team.html', 'sid_1770233905453_1xasjwe5s', '2026-07-26 07:16:59'),
(73, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/team.html', 'sid_1770233905453_1xasjwe5s', '2026-07-26 07:20:16'),
(74, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/pta.html', 'sid_1770233905453_1xasjwe5s', '2026-07-26 07:33:38'),
(75, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/admissions.html', 'sid_1770233905453_1xasjwe5s', '2026-07-26 07:39:50'),
(76, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/admissions.html', 'sid_1770233905453_1xasjwe5s', '2026-07-26 07:44:55'),
(77, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/vacancy.html', 'sid_1770233905453_1xasjwe5s', '2026-07-26 07:47:09'),
(78, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/vacancy.html', 'sid_1770233905453_1xasjwe5s', '2026-07-26 07:49:37'),
(79, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-07-26 08:09:26'),
(80, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-07-26 08:53:11'),
(81, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-07-26 09:13:00'),
(82, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-07-26 09:17:58'),
(83, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-07-26 09:22:52'),
(84, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/features.html', 'sid_1770233905453_1xasjwe5s', '2026-07-26 09:24:58'),
(85, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1770233905453_1xasjwe5s', '2026-07-26 09:31:09'),
(86, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/vacancy.html', 'sid_1770233905453_1xasjwe5s', '2026-07-26 10:01:56'),
(87, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1770233905453_1xasjwe5s', '2026-07-26 10:03:20'),
(88, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/team.html', 'sid_1770233905453_1xasjwe5s', '2026-07-26 10:46:32'),
(89, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'https://noah98.gt.tc/html/team.html', 'sid_1785063894342_8xux8mdss', '2026-07-26 11:10:36'),
(90, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'https://noah98.gt.tc/dashboard/index.html', 'sid_1785063894342_8xux8mdss', '2026-07-26 11:56:38'),
(91, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1785063894342_8xux8mdss', '2026-07-26 12:05:21'),
(92, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'https://noah98.gt.tc/', 'sid_1785067523089_ddkqyl3og', '2026-07-26 12:05:22'),
(93, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'https://noah98.gt.tc/html/about.html', 'sid_1785067523089_ddkqyl3og', '2026-07-26 12:06:47'),
(94, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'https://noah98.gt.tc/html/about.html', 'sid_1785063894342_8xux8mdss', '2026-07-26 12:07:50'),
(95, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'https://noah98.gt.tc/html/admissions.html', 'sid_1785067523089_ddkqyl3og', '2026-07-26 12:08:33'),
(96, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'https://noah98.gt.tc/html/gallery.html', 'sid_1785063894342_8xux8mdss', '2026-07-26 12:12:16'),
(97, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'https://noah98.gt.tc/', 'sid_1785068010716_j6p77pem0', '2026-07-26 12:13:31'),
(98, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'Direct', 'sid_1785068011083_ix9l5difv', '2026-07-26 12:13:32'),
(99, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1785067523089_ddkqyl3og', '2026-07-26 12:14:16'),
(100, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'https://noah98.gt.tc/html/features.html', 'sid_1785063894342_8xux8mdss', '2026-07-26 12:14:30'),
(101, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'https://noah98.gt.tc/html/features.html', 'sid_1785067523089_ddkqyl3og', '2026-07-26 12:16:12'),
(102, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'Direct', 'sid_1785068010716_j6p77pem0', '2026-07-26 12:17:47'),
(103, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'Direct', 'sid_1785068269512_asg2fgd6n', '2026-07-26 12:17:50'),
(104, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'https://noah98.gt.tc/html/faq.html', 'sid_1785063894342_8xux8mdss', '2026-07-26 12:23:00'),
(105, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'https://noah98.gt.tc/html/vacancy.html', 'sid_1785067523089_ddkqyl3og', '2026-07-26 12:23:00'),
(106, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'https://noah98.gt.tc/dashboard/teacher.html', 'sid_1785063894342_8xux8mdss', '2026-07-26 12:26:28'),
(107, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'https://noah98.gt.tc/dashboard/teacher.html', 'sid_1785067523089_ddkqyl3og', '2026-07-26 12:27:36'),
(108, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'https://noah98.gt.tc/dashboard/parent.html', 'sid_1785063894342_8xux8mdss', '2026-07-26 12:34:08'),
(109, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'https://noah98.gt.tc/', 'sid_1785071918541_x0metkecs', '2026-07-26 13:18:38'),
(110, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'Direct', 'sid_1785071918541_x0metkecs', '2026-07-26 13:21:14'),
(111, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'Direct', 'sid_1785071696698_udg31rrhe', '2026-07-26 13:23:43'),
(112, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'https://noah98.gt.tc/dashboard/parent.html', 'sid_1785063894342_8xux8mdss', '2026-07-26 13:25:00'),
(113, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'Direct', 'sid_1785071696698_udg31rrhe', '2026-07-26 13:26:14'),
(114, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'Direct', 'sid_1785071918541_x0metkecs', '2026-07-26 14:16:22'),
(115, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1785063894342_8xux8mdss', '2026-07-26 14:16:24'),
(116, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'Direct', 'sid_1785071918541_x0metkecs', '2026-07-26 14:17:56'),
(117, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'https://noah98.gt.tc/', 'sid_1785075817295_71ohadqts', '2026-07-26 14:23:36'),
(118, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'https://noah98.gt.tc/', 'sid_1785075820052_d2g6ico5d', '2026-07-26 14:23:39'),
(119, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1785063894342_8xux8mdss', '2026-07-26 14:50:18'),
(120, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'Direct', 'sid_1785068010716_j6p77pem0', '2026-07-26 14:51:04'),
(121, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'https://noah98.gt.tc/', 'sid_1785077686434_asxap18hp', '2026-07-26 14:54:45'),
(122, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'https://noah98.gt.tc/html/admissions.html', 'sid_1785063894342_8xux8mdss', '2026-07-26 14:59:12'),
(123, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'https://noah98.gt.tc/html/faq.html', 'sid_1785063894342_8xux8mdss', '2026-07-26 15:15:50'),
(124, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'https://noah98.gt.tc/html/team.html', 'sid_1785063894342_8xux8mdss', '2026-07-26 15:17:41'),
(125, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'https://noah98.gt.tc/', 'sid_1785079276580_bi15dgnuj', '2026-07-26 15:21:16'),
(126, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'https://noah98.gt.tc/', 'sid_1785079278236_nhoct6dny', '2026-07-26 15:21:17'),
(127, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'https://noah98.gt.tc/', 'sid_1785079776660_4y6sdjf60', '2026-07-26 15:29:36'),
(128, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'Direct', 'sid_1785071696698_udg31rrhe', '2026-07-26 15:31:15'),
(129, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'Direct', 'sid_1785079912115_ot7tn818j', '2026-07-26 15:31:52'),
(130, '', '', 'Chrome', 'Linux', 'Desktop', 'index.html', 'https://noah98.gt.tc/html/team.html', 'sid_1785071696698_udg31rrhe', '2026-07-26 15:34:26'),
(131, '', '', 'Chrome', 'Linux', 'Desktop', 'index.html', 'https://noah98.gt.tc/html/features.html', 'sid_1785071696698_udg31rrhe', '2026-07-26 15:35:34'),
(132, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'https://noah98.gt.tc/', 'sid_1785080639052_fke5jyxlt', '2026-07-26 15:43:58');
INSERT INTO `visitor_logs` (`id`, `ip_address`, `location`, `browser`, `os`, `device`, `page`, `referrer`, `session_id`, `created_at`) VALUES
(133, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'https://noah98.gt.tc/html/gallery.html', 'sid_1785063894342_8xux8mdss', '2026-07-26 15:53:32'),
(134, '', '', 'Chrome', 'Linux', 'Desktop', 'index.html', 'Direct', 'sid_1785071696698_udg31rrhe', '2026-07-26 16:56:36'),
(135, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'https://noah98.gt.tc/html/admissions.html', 'sid_1785071696698_udg31rrhe', '2026-07-26 16:57:45'),
(136, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'Direct', 'sid_1785085069342_3jrxauwua', '2026-07-26 16:57:48'),
(137, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'https://noah98.gt.tc/html/admissions.html', 'sid_1785071696698_udg31rrhe', '2026-07-26 17:00:01'),
(138, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'Direct', 'sid_1785079276580_bi15dgnuj', '2026-07-26 17:34:11'),
(139, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'Direct', 'sid_1785077686434_asxap18hp', '2026-07-26 19:44:42'),
(140, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'Direct', 'sid_1785077686434_asxap18hp', '2026-07-26 19:53:16'),
(141, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1785063894342_8xux8mdss', '2026-07-26 19:53:57'),
(142, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1785063894342_8xux8mdss', '2026-07-26 19:58:11'),
(143, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1785063894342_8xux8mdss', '2026-07-26 20:02:46'),
(144, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'https://noah98.gt.tc/', 'sid_1785126616393_bmzjc9ww3', '2026-07-27 04:30:16'),
(145, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'Direct', 'sid_1785126991006_8xre55awl', '2026-07-27 04:36:31'),
(146, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'https://noah98.gt.tc/', 'sid_1785126616393_bmzjc9ww3', '2026-07-27 04:37:26'),
(147, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'https://noah98.gt.tc/?i=1', 'sid_1785126616393_bmzjc9ww3', '2026-07-27 04:40:48'),
(148, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'Direct', 'sid_1785077686434_asxap18hp', '2026-07-27 04:45:21'),
(149, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'https://noah98.gt.tc/html/admissions.html?i=1', 'sid_1785071696698_udg31rrhe', '2026-07-27 04:47:13'),
(150, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'https://noah98.gt.tc/html/features.html', 'sid_1785071696698_udg31rrhe', '2026-07-27 04:48:29'),
(151, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'Direct', 'sid_1785077686434_asxap18hp', '2026-07-27 04:49:14'),
(152, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'https://noah98.gt.tc/dashboard/teacher.html', 'sid_1785071696698_udg31rrhe', '2026-07-27 04:50:53'),
(153, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'Direct', 'sid_1785077686434_asxap18hp', '2026-07-27 04:54:19'),
(154, '', '', 'Chrome', 'Linux', 'Desktop', 'index.html', 'https://noah98.gt.tc/dashboard/teacher.html', 'sid_1785071696698_udg31rrhe', '2026-07-27 04:56:55'),
(155, '', '', 'Chrome', 'Linux', 'Desktop', 'index.html', 'https://noah98.gt.tc/html/contact.html', 'sid_1785071696698_udg31rrhe', '2026-07-27 04:58:31'),
(156, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'Direct', 'sid_1785077686434_asxap18hp', '2026-07-27 05:03:13'),
(157, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-07-27 06:13:20'),
(158, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/vacancy.html', 'sid_1770233905453_1xasjwe5s', '2026-07-27 06:14:20'),
(159, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/service.html', 'sid_1770233905453_1xasjwe5s', '2026-07-27 06:25:59'),
(160, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/events.html', 'sid_1770233905453_1xasjwe5s', '2026-07-27 07:03:08'),
(161, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/events.html', 'sid_1770233905453_1xasjwe5s', '2026-07-27 07:05:18'),
(162, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/events.html', 'sid_1770233905453_1xasjwe5s', '2026-07-27 07:06:54'),
(163, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/events.html', 'sid_1770233905453_1xasjwe5s', '2026-07-27 07:09:01'),
(164, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/events.html', 'sid_1770233905453_1xasjwe5s', '2026-07-27 07:15:27'),
(165, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/index.html', 'sid_1770233905453_1xasjwe5s', '2026-07-27 07:17:53'),
(166, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/index.html', 'sid_1770233905453_1xasjwe5s', '2026-07-27 07:19:17'),
(167, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-07-27 07:20:51'),
(168, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-07-27 07:27:21'),
(169, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-07-27 07:29:03'),
(170, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-07-27 07:30:29'),
(171, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-07-27 07:32:10'),
(172, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/about.html', 'sid_1770233905453_1xasjwe5s', '2026-07-27 07:43:14'),
(173, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-07-27 10:21:24'),
(174, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1770233905453_1xasjwe5s', '2026-07-27 10:22:56'),
(175, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-07-27 10:24:53'),
(176, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1770233905453_1xasjwe5s', '2026-07-27 10:26:41'),
(177, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-07-28 05:42:33'),
(178, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-07-29 12:16:54'),
(179, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/vacancy.html', 'sid_1770233905453_1xasjwe5s', '2026-07-29 12:19:09'),
(180, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-07-29 12:26:13'),
(181, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/vacancy.html', 'sid_1770233905453_1xasjwe5s', '2026-07-29 13:03:40'),
(182, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/vacancy.html', 'sid_1770233905453_1xasjwe5s', '2026-07-29 13:05:12'),
(183, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/gallery.html', 'sid_1770233905453_1xasjwe5s', '2026-07-29 13:57:12'),
(184, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/vacancy.html', 'sid_1770233905453_1xasjwe5s', '2026-07-29 14:04:26'),
(185, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/vacancy.html', 'sid_1770233905453_1xasjwe5s', '2026-07-29 14:30:22'),
(186, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/team.html', 'sid_1770233905453_1xasjwe5s', '2026-07-29 14:36:12'),
(187, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/about.html', 'sid_1770233905453_1xasjwe5s', '2026-07-29 14:55:09'),
(188, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/about.html', 'sid_1770233905453_1xasjwe5s', '2026-07-29 14:56:47'),
(189, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/about.html', 'sid_1770233905453_1xasjwe5s', '2026-07-29 14:58:00'),
(190, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/admissions.html', 'sid_1770233905453_1xasjwe5s', '2026-07-29 14:59:38'),
(191, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/admissions.html', 'sid_1770233905453_1xasjwe5s', '2026-07-29 15:04:24'),
(192, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/gallery.html', 'sid_1770233905453_1xasjwe5s', '2026-07-29 15:11:52'),
(193, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/events.html', 'sid_1770233905453_1xasjwe5s', '2026-07-29 15:29:47'),
(194, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/dashboard/index.html', 'sid_1770233905453_1xasjwe5s', '2026-07-29 15:34:08'),
(195, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/gallery.html', 'sid_1770233905453_1xasjwe5s', '2026-07-29 15:35:43'),
(196, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/contact.html', 'sid_1770233905453_1xasjwe5s', '2026-07-29 16:24:58'),
(197, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/dashboard/index.html', 'sid_1770233905453_1xasjwe5s', '2026-07-29 16:41:50'),
(198, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/gallery.html', 'sid_1770233905453_1xasjwe5s', '2026-07-29 16:44:50'),
(199, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/gallery.html', 'sid_1770233905453_1xasjwe5s', '2026-07-29 16:48:11'),
(200, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/dashboard/index.html', 'sid_1770233905453_1xasjwe5s', '2026-07-29 16:49:13'),
(201, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/team.html', 'sid_1770233905453_1xasjwe5s', '2026-07-29 16:54:16'),
(202, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/vacancy.html', 'sid_1770233905453_1xasjwe5s', '2026-07-29 17:10:05'),
(203, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/about.html', 'sid_1770233905453_1xasjwe5s', '2026-07-29 17:12:19'),
(204, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/team.html', 'sid_1770233905453_1xasjwe5s', '2026-07-29 17:20:33'),
(205, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1770233905453_1xasjwe5s', '2026-07-29 17:36:50'),
(206, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/index.html', 'sid_1770233905453_1xasjwe5s', '2026-07-29 17:43:12'),
(207, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/about.html', 'sid_1770233905453_1xasjwe5s', '2026-07-29 18:15:32'),
(208, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/contact.html', 'sid_1770233905453_1xasjwe5s', '2026-07-29 18:27:53'),
(209, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/testimonial.html', 'sid_1770233905453_1xasjwe5s', '2026-07-29 19:06:05'),
(210, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/contact.html', 'sid_1770233905453_1xasjwe5s', '2026-07-29 19:24:26'),
(211, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/contact.html', 'sid_1770233905453_1xasjwe5s', '2026-07-29 19:31:16'),
(212, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/about.html', 'sid_1770233905453_1xasjwe5s', '2026-07-29 19:33:02'),
(213, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/vacancy.html', 'sid_1770233905453_1xasjwe5s', '2026-07-30 05:15:03'),
(214, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/dashboard/index.html', 'sid_1770233905453_1xasjwe5s', '2026-07-30 05:17:02'),
(215, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/dashboard/index.html', 'sid_1770233905453_1xasjwe5s', '2026-07-30 05:38:33'),
(216, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/dashboard/index.html', 'sid_1770233905453_1xasjwe5s', '2026-07-30 05:39:38'),
(217, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/dashboard/index.html', 'sid_1770233905453_1xasjwe5s', '2026-07-30 06:43:24'),
(218, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-07-30 08:16:48'),
(219, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-07-30 08:21:47'),
(220, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/vacancy.html', 'sid_1770233905453_1xasjwe5s', '2026-07-30 08:28:20'),
(221, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1770233905453_1xasjwe5s', '2026-07-30 08:29:54'),
(222, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/contact.html', 'sid_1770233905453_1xasjwe5s', '2026-07-30 08:36:30'),
(223, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/vacancy.html', 'sid_1770233905453_1xasjwe5s', '2026-07-30 08:37:33'),
(224, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/dashboard/index.html', 'sid_1770233905453_1xasjwe5s', '2026-07-30 08:48:20'),
(225, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/gallery.html', 'sid_1770233905453_1xasjwe5s', '2026-07-30 08:52:16'),
(226, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-07-30 09:45:26'),
(227, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-07-30 09:57:26'),
(228, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-07-30 09:59:13'),
(229, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-07-30 10:02:19'),
(230, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-07-30 10:03:43'),
(231, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-07-30 10:06:32'),
(232, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-07-30 10:13:20'),
(233, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-07-30 10:15:00'),
(234, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-07-30 11:19:38'),
(235, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-07-30 11:23:22'),
(236, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/features.html', 'sid_1770233905453_1xasjwe5s', '2026-07-30 11:44:56'),
(237, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/features.html', 'sid_1770233905453_1xasjwe5s', '2026-07-30 11:46:32'),
(238, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-07-30 17:42:53'),
(239, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-07-31 06:18:34'),
(240, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-07-31 06:31:15'),
(241, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-07-31 06:56:55'),
(242, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-07-31 10:33:56'),
(243, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-07-31 11:14:47'),
(244, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/contact.html', 'sid_1770233905453_1xasjwe5s', '2026-07-31 11:33:30'),
(245, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/testimonial.html', 'sid_1770233905453_1xasjwe5s', '2026-07-31 11:37:28'),
(246, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/contact.html', 'sid_1770233905453_1xasjwe5s', '2026-07-31 11:48:00'),
(247, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1770233905453_1xasjwe5s', '2026-07-31 12:21:38'),
(248, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/vacancy.html', 'sid_1770233905453_1xasjwe5s', '2026-07-31 12:23:27'),
(249, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/admissions.html', 'sid_1770233905453_1xasjwe5s', '2026-07-31 12:25:17'),
(250, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/testimonial.html', 'sid_1770233905453_1xasjwe5s', '2026-07-31 12:29:28'),
(251, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/vacancy.html', 'sid_1770233905453_1xasjwe5s', '2026-07-31 12:31:04'),
(252, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/gallery.html', 'sid_1770233905453_1xasjwe5s', '2026-07-31 12:44:45'),
(253, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-07-31 13:29:42'),
(254, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1770233905453_1xasjwe5s', '2026-07-31 13:31:08'),
(255, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1770233905453_1xasjwe5s', '2026-07-31 13:32:13'),
(256, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1770233905453_1xasjwe5s', '2026-07-31 13:33:34'),
(257, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1770233905453_1xasjwe5s', '2026-07-31 13:37:08'),
(258, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1770233905453_1xasjwe5s', '2026-07-31 13:43:48'),
(259, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1770233905453_1xasjwe5s', '2026-07-31 13:45:53'),
(260, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1770233905453_1xasjwe5s', '2026-07-31 13:48:24'),
(261, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1770233905453_1xasjwe5s', '2026-07-31 13:49:25'),
(262, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1770233905453_1xasjwe5s', '2026-07-31 13:56:41'),
(263, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/features.html', 'sid_1770233905453_1xasjwe5s', '2026-07-31 16:06:58'),
(264, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/admissions.html', 'sid_1770233905453_1xasjwe5s', '2026-07-31 16:19:04'),
(265, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/admissions.html', 'sid_1770233905453_1xasjwe5s', '2026-07-31 16:21:43'),
(266, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/admissions.html', 'sid_1770233905453_1xasjwe5s', '2026-07-31 16:22:55'),
(267, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/admissions.html', 'sid_1770233905453_1xasjwe5s', '2026-07-31 16:27:47'),
(268, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/admissions.html', 'sid_1770233905453_1xasjwe5s', '2026-07-31 16:29:56'),
(269, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/gallery.html', 'sid_1770233905453_1xasjwe5s', '2026-07-31 16:32:48');
INSERT INTO `visitor_logs` (`id`, `ip_address`, `location`, `browser`, `os`, `device`, `page`, `referrer`, `session_id`, `created_at`) VALUES
(270, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/gallery.html', 'sid_1770233905453_1xasjwe5s', '2026-07-31 16:33:53'),
(271, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/gallery.html', 'sid_1770233905453_1xasjwe5s', '2026-07-31 16:51:10'),
(272, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/gallery.html', 'sid_1770233905453_1xasjwe5s', '2026-07-31 16:56:39'),
(273, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/gallery.html', 'sid_1770233905453_1xasjwe5s', '2026-07-31 17:00:06'),
(274, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/gallery.html', 'sid_1770233905453_1xasjwe5s', '2026-07-31 17:03:46'),
(275, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/gallery.html', 'sid_1770233905453_1xasjwe5s', '2026-07-31 17:10:31'),
(276, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/gallery.html', 'sid_1770233905453_1xasjwe5s', '2026-07-31 17:15:24'),
(277, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/gallery.html', 'sid_1770233905453_1xasjwe5s', '2026-07-31 17:18:59'),
(278, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/gallery.html', 'sid_1770233905453_1xasjwe5s', '2026-07-31 17:22:38'),
(279, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/gallery.html', 'sid_1770233905453_1xasjwe5s', '2026-07-31 17:30:06'),
(280, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/gallery.html', 'sid_1770233905453_1xasjwe5s', '2026-07-31 18:45:24'),
(281, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-07-31 18:50:44'),
(282, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1770233905453_1xasjwe5s', '2026-07-31 20:48:11'),
(283, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'Direct', 'sid_1770233905453_1xasjwe5s', '2026-08-01 05:53:32'),
(284, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1770233905453_1xasjwe5s', '2026-08-01 05:55:25'),
(285, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1770233905453_1xasjwe5s', '2026-08-01 05:57:35'),
(286, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1770233905453_1xasjwe5s', '2026-08-01 05:59:41'),
(287, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1770233905453_1xasjwe5s', '2026-08-01 06:01:24'),
(288, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1770233905453_1xasjwe5s', '2026-08-01 06:03:06'),
(289, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/service.html', 'sid_1770233905453_1xasjwe5s', '2026-08-01 06:04:31'),
(290, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/index.html', 'sid_1770233905453_1xasjwe5s', '2026-08-01 06:05:43'),
(291, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/gallery.html', 'sid_1770233905453_1xasjwe5s', '2026-08-01 06:07:05'),
(292, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/gallery.html', 'sid_1770233905453_1xasjwe5s', '2026-08-01 06:09:14'),
(293, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/gallery.html', 'sid_1770233905453_1xasjwe5s', '2026-08-01 06:11:32'),
(294, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/gallery.html', 'sid_1770233905453_1xasjwe5s', '2026-08-01 06:12:50'),
(295, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/gallery.html', 'sid_1770233905453_1xasjwe5s', '2026-08-01 06:13:55'),
(296, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/gallery.html', 'sid_1770233905453_1xasjwe5s', '2026-08-01 06:15:09'),
(297, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/gallery.html', 'sid_1770233905453_1xasjwe5s', '2026-08-01 06:16:23'),
(298, '', '', 'Chrome', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1785586615313_imiiifx3o', '2026-08-01 12:16:56'),
(299, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/test.html', 'sid_1785588427643_blpcqxz4g', '2026-08-01 12:47:08'),
(300, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/test.html', 'sid_1785588427643_blpcqxz4g', '2026-08-01 13:12:12'),
(301, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/html/admissions.html', 'sid_1785588427643_blpcqxz4g', '2026-08-01 13:13:14'),
(302, '', '', 'Chrome', 'Windows 10/11', 'Desktop', 'index.html', 'https://noah98.gt.tc/dashboard/teacher.html?', 'sid_1785580489483_vxdrz3m4b', '2026-08-01 13:27:56'),
(303, '', '', 'Chrome', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1785580489483_vxdrz3m4b', '2026-08-01 13:38:29'),
(304, '', '', 'Chrome', 'Windows 10/11', 'Desktop', 'index.html', 'https://noah98.gt.tc/html/about.html', 'sid_1785580489483_vxdrz3m4b', '2026-08-01 13:39:42'),
(305, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'http://www.noah98.gt.tc/', 'sid_1785655188159_1lwn55hqm', '2026-08-02 07:19:53'),
(306, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'http://www.noah98.gt.tc/', 'sid_1785655188159_1lwn55hqm', '2026-08-02 07:23:51'),
(307, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'http://www.noah98.gt.tc/', 'sid_1785655188159_1lwn55hqm', '2026-08-02 07:26:49'),
(308, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'Direct', 'sid_1785655188159_1lwn55hqm', '2026-08-02 07:30:55'),
(309, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'https://noah98.gt.tc/', 'sid_1785160433400_avbltv5hb', '2026-08-03 08:07:04'),
(310, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'https://noah98.gt.tc/dashboard/teacher.html', 'sid_1785160433400_avbltv5hb', '2026-08-03 08:09:21'),
(311, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'https://noah98.gt.tc/dashboard/teacher.html', 'sid_1785160433400_avbltv5hb', '2026-08-03 08:10:45'),
(312, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'http://www.noah98.gt.tc/dashboard/index.html', 'sid_1785655188159_1lwn55hqm', '2026-08-03 08:32:57'),
(313, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'http://www.noah98.gt.tc/dashboard/index.html', 'sid_1785655188159_1lwn55hqm', '2026-08-03 08:34:31'),
(314, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'http://www.noah98.gt.tc/', 'sid_1785746202119_ap9w3vost', '2026-08-03 08:36:41'),
(315, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'http://www.noah98.gt.tc/', 'sid_1785746202119_ap9w3vost', '2026-08-03 08:43:05'),
(316, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'https://noah98.gt.tc/html/vacancy.html', 'sid_1785160433400_avbltv5hb', '2026-08-03 09:03:44'),
(317, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'https://noah98.gt.tc/dashboard/teacher.html', 'sid_1785160433400_avbltv5hb', '2026-08-03 09:05:46'),
(318, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'https://noah98.gt.tc/dashboard/teacher.html', 'sid_1785160433400_avbltv5hb', '2026-08-03 09:07:22'),
(319, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1785160433400_avbltv5hb', '2026-08-03 10:33:07'),
(320, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'https://noah98.gt.tc/dashboard/teacher.html', 'sid_1785160433400_avbltv5hb', '2026-08-03 10:35:16'),
(321, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1785160433400_avbltv5hb', '2026-08-03 11:18:01'),
(322, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'https://noah98.gt.tc/dashboard/teacher.html', 'sid_1785160433400_avbltv5hb', '2026-08-03 11:19:02'),
(323, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'http://www.noah98.gt.tc/', 'sid_1785655188159_1lwn55hqm', '2026-08-04 08:17:43'),
(324, '', '', 'Chrome', 'Android', 'Mobile', 'index.html', 'http://www.noah98.gt.tc/', 'sid_1785655188159_1lwn55hqm', '2026-08-04 08:19:47'),
(325, '', '', 'Chrome', 'Windows 10/11', 'Desktop', 'index.html', 'https://noah98.gt.tc/dashboard/admin.html?i=1', 'sid_1785580489483_vxdrz3m4b', '2026-08-04 11:42:07'),
(326, '', '', 'Chrome', 'Windows 10/11', 'Desktop', 'index.html', 'https://noah98.gt.tc/html/vacancy.html', 'sid_1785580489483_vxdrz3m4b', '2026-08-04 11:52:58'),
(327, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'https://noah98.gt.tc/?i=1', 'sid_1785160433400_avbltv5hb', '2026-08-04 12:54:55'),
(328, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1785160433400_avbltv5hb', '2026-08-04 12:59:59'),
(329, '', '', 'Chrome', 'Linux', 'Desktop', 'index.html', 'https://noah98.gt.tc/dashboard/admin.html', 'sid_1785161600697_cab6xwz6h', '2026-08-04 16:38:23'),
(330, '', '', 'Chrome', 'Linux', 'Desktop', 'index.html', 'Direct', 'sid_1785161600697_cab6xwz6h', '2026-08-04 16:59:26'),
(331, '', '', 'Chrome', 'Linux', 'Desktop', 'index.html', 'Direct', 'sid_1785161600697_cab6xwz6h', '2026-08-04 17:06:25'),
(332, '', '', 'Chrome', 'Linux', 'Desktop', 'index.html', 'https://noah98.gt.tc/dashboard/index.html', 'sid_1785161600697_cab6xwz6h', '2026-08-04 17:14:25'),
(333, '', '', 'Chrome', 'Windows 10/11', 'Desktop', 'index.html', 'https://noah98.gt.tc/dashboard/admin.html', 'sid_1785580489483_vxdrz3m4b', '2026-08-04 17:28:53'),
(334, '', '', 'Chrome', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1785586615313_imiiifx3o', '2026-08-05 07:41:26'),
(335, '', '', 'Chrome', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1785586615313_imiiifx3o', '2026-08-05 16:28:32'),
(336, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'Direct', 'sid_1785588427643_blpcqxz4g', '2026-08-05 22:39:45'),
(337, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'Direct', 'sid_1785588427643_blpcqxz4g', '2026-08-06 06:20:43'),
(338, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1785588427643_blpcqxz4g', '2026-08-06 08:40:52'),
(339, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'Direct', 'sid_1785588427643_blpcqxz4g', '2026-08-07 07:07:33'),
(340, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'Direct', 'sid_1785588427643_blpcqxz4g', '2026-08-07 09:28:57'),
(341, '', '', 'Safari', 'macOS', 'Mobile', 'index.html', 'Direct', 'sid_1785588427643_blpcqxz4g', '2026-08-08 06:49:03'),
(342, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1786371659190_506wj4dz3', '2026-08-10 17:10:14'),
(343, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1786371659190_506wj4dz3', '2026-08-10 17:23:04'),
(344, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/testimonial.html', 'sid_1786371659190_506wj4dz3', '2026-08-10 17:48:59'),
(345, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1786371659190_506wj4dz3', '2026-08-10 20:46:39'),
(346, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/vacancy.html', 'sid_1786371659190_506wj4dz3', '2026-08-10 20:48:06'),
(347, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/vacancy.html', 'sid_1786371659190_506wj4dz3', '2026-08-11 06:27:15'),
(348, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/contact.html', 'sid_1786371659190_506wj4dz3', '2026-08-11 06:43:59'),
(349, '', '', 'Chrome', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1786432834208_rfhgqiyr3', '2026-08-11 07:20:34'),
(350, '', '', 'Chrome', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1786432834208_rfhgqiyr3', '2026-08-11 07:21:46'),
(351, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1786451994355_67vu8bmwh', '2026-08-11 12:39:55'),
(352, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1786451994355_67vu8bmwh', '2026-08-12 06:51:11'),
(353, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1786451994355_67vu8bmwh', '2026-08-12 13:18:58'),
(354, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1786451994355_67vu8bmwh', '2026-08-12 16:10:58'),
(355, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-01 14:01:51'),
(356, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 14:02:00'),
(357, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-01 14:04:01'),
(358, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-01 14:24:19'),
(359, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-01 14:28:22'),
(360, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-01 14:28:24'),
(361, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-01 14:30:22'),
(362, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 14:37:06'),
(363, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 14:41:31'),
(364, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 14:44:36'),
(365, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 14:46:24'),
(366, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 14:50:40'),
(367, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 14:57:05'),
(368, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 15:02:26'),
(369, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html?', 'sid_1787125872443_gz92cnjkl', '2026-09-01 15:03:54'),
(370, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/dashboard/admin.html?', 'sid_1787125872443_gz92cnjkl', '2026-09-01 15:04:00'),
(371, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/dashboard/admin.html?', 'sid_1787125872443_gz92cnjkl', '2026-09-01 15:06:01'),
(372, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'vacancy.html', 'http://localhost/noah/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 15:06:03'),
(373, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 15:08:32'),
(374, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 15:12:13'),
(375, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 15:14:30'),
(376, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'about.html', 'http://localhost/noah/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 15:14:45'),
(377, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/about.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 15:15:02'),
(378, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'testimonial.html', 'http://localhost/noah/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 15:15:17'),
(379, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 15:15:29'),
(380, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 15:17:22'),
(381, '', '', 'Safari', 'Android', 'Mobile', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 15:19:11'),
(382, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 15:33:44'),
(383, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 15:35:36'),
(384, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 15:37:21'),
(385, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 15:42:45'),
(386, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 15:45:11'),
(387, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 15:45:23'),
(388, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-01 15:46:02'),
(389, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'service.html', 'http://localhost/noah/', 'sid_1787125872443_gz92cnjkl', '2026-09-01 15:46:13'),
(390, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'service.html', 'http://localhost/noah/', 'sid_1787125872443_gz92cnjkl', '2026-09-01 15:51:02'),
(391, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/service.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 15:51:05'),
(392, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'gallery.html', 'http://localhost/noah/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 15:51:07'),
(393, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/gallery.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 17:24:40'),
(394, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/gallery.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 17:26:32'),
(395, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 17:27:29'),
(396, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 17:27:34'),
(397, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/gallery.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 17:27:38'),
(398, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/gallery.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 17:28:59'),
(399, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-01 17:30:51'),
(400, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 17:32:47'),
(401, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 17:34:02');
INSERT INTO `visitor_logs` (`id`, `ip_address`, `location`, `browser`, `os`, `device`, `page`, `referrer`, `session_id`, `created_at`) VALUES
(402, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-01 17:36:05'),
(403, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'features.html', 'http://localhost/noah/', 'sid_1787125872443_gz92cnjkl', '2026-09-01 17:36:09'),
(404, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'events.html', 'http://localhost/noah/html/features.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 17:36:12'),
(405, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 17:36:45'),
(406, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'events.html', 'http://localhost/noah/html/features.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 17:38:30'),
(407, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-01 18:24:16'),
(408, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-01 18:24:18'),
(409, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-01 18:35:38'),
(410, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 18:35:42'),
(411, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 18:46:08'),
(412, '', '', 'Safari', 'Android', 'Mobile', 'index.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 18:47:19'),
(413, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 18:49:03'),
(414, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 18:57:57'),
(415, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 18:59:00'),
(416, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 19:01:52'),
(417, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 19:28:45'),
(418, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 19:29:08'),
(419, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 19:29:24'),
(420, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 19:51:43'),
(421, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 19:57:06'),
(422, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-01 21:55:07'),
(423, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'about.html', 'http://localhost/noah/', 'sid_1787125872443_gz92cnjkl', '2026-09-01 21:56:10'),
(424, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'team.html', 'http://localhost/noah/html/about.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 21:56:13'),
(425, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'gallery.html', 'http://localhost/noah/html/team.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 21:56:30'),
(426, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/gallery.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 21:56:40'),
(427, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'vacancy.html', 'http://localhost/noah/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 21:57:48'),
(428, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-01 21:58:10'),
(429, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-01 21:58:14'),
(430, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-01 21:59:33'),
(431, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'about.html', 'http://localhost/noah/', 'sid_1787125872443_gz92cnjkl', '2026-09-01 22:00:25'),
(432, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'team.html', 'http://localhost/noah/html/about.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 22:00:44'),
(433, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'team.html', 'http://localhost/noah/html/team.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 22:02:43'),
(434, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-01 22:03:05'),
(435, '', '', 'Safari', 'Android', 'Mobile', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-01 22:09:31'),
(436, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-01 22:10:54'),
(437, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-01 22:14:31'),
(438, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'team.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-01 22:16:20'),
(439, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/team.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 22:16:39'),
(440, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-01 22:19:54'),
(441, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/team.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 22:20:03'),
(442, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/team.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 22:21:42'),
(443, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/team.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 22:28:40'),
(444, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/team.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 22:30:51'),
(445, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-01 22:31:58'),
(446, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-01 22:33:15'),
(447, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-01 22:42:10'),
(448, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/team.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 22:42:24'),
(449, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/team.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 22:49:30'),
(450, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'about.html', 'http://localhost/noah/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 22:49:36'),
(451, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-01 22:50:06'),
(452, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-01 22:51:23'),
(453, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/about.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 22:52:25'),
(454, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-01 23:14:50'),
(455, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/about.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 23:14:52'),
(456, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-01 23:16:06'),
(457, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-01 23:17:43'),
(458, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-01 23:18:07'),
(459, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-01 23:39:08'),
(460, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-01 23:40:17'),
(461, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-01 23:46:14'),
(462, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-01 23:53:13'),
(463, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-01 23:56:12'),
(464, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-01 23:58:25'),
(465, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 00:02:44'),
(466, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 00:07:01'),
(467, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 00:11:33'),
(468, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 00:15:50'),
(469, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 00:17:31'),
(470, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 00:19:03'),
(471, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 00:20:55'),
(472, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-02 00:22:00'),
(473, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 00:23:23'),
(474, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-02 00:24:23'),
(475, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 00:26:01'),
(476, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 00:27:29'),
(477, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 00:29:06'),
(478, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 00:33:55'),
(479, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 00:39:02'),
(480, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1788310182291_pdzxfrv82', '2026-09-02 00:49:42'),
(481, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'about.html', 'http://localhost/noah/', 'sid_1788310182291_pdzxfrv82', '2026-09-02 00:55:10'),
(482, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'team.html', 'http://localhost/noah/html/about.html', 'sid_1788310182291_pdzxfrv82', '2026-09-02 00:55:14'),
(483, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'gallery.html', 'http://localhost/noah/html/team.html', 'sid_1788310182291_pdzxfrv82', '2026-09-02 00:55:19'),
(484, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/gallery.html', 'sid_1788310182291_pdzxfrv82', '2026-09-02 00:55:26'),
(485, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1788310182291_pdzxfrv82', '2026-09-02 00:55:30'),
(486, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1788310182291_pdzxfrv82', '2026-09-02 00:57:05'),
(487, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/index.html', 'sid_1788310182291_pdzxfrv82', '2026-09-02 00:57:09'),
(488, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1788310182291_pdzxfrv82', '2026-09-02 00:58:14'),
(489, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1788310182291_pdzxfrv82', '2026-09-02 01:21:51'),
(490, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1788310182291_pdzxfrv82', '2026-09-02 01:21:58'),
(491, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 01:28:50'),
(492, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 01:34:18'),
(493, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 01:37:02'),
(494, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 01:38:36'),
(495, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 01:40:31'),
(496, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-02 01:41:41'),
(497, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admissions.html', 'http://localhost/noah/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-02 01:42:09'),
(498, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/admissions.html', 'sid_1787125872443_gz92cnjkl', '2026-09-02 01:43:19'),
(499, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 01:45:35'),
(500, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 01:47:38'),
(501, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 01:48:00'),
(502, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'service.html', 'http://localhost/noah/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-02 01:48:13'),
(503, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'team.html', 'http://localhost/noah/html/service.html', 'sid_1787125872443_gz92cnjkl', '2026-09-02 01:48:16'),
(504, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'features.html', 'http://localhost/noah/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-02 01:48:40'),
(505, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 01:57:24'),
(506, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'features.html', 'http://localhost/noah/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-02 01:58:18'),
(507, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/features.html', 'sid_1787125872443_gz92cnjkl', '2026-09-02 01:58:25'),
(508, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 07:39:03'),
(509, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 07:39:31'),
(510, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 07:42:39'),
(511, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'about.html', 'http://localhost/noah/', 'sid_1787125872443_gz92cnjkl', '2026-09-02 07:42:49'),
(512, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'gallery.html', 'http://localhost/noah/html/about.html', 'sid_1787125872443_gz92cnjkl', '2026-09-02 07:42:57'),
(513, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/gallery.html', 'sid_1787125872443_gz92cnjkl', '2026-09-02 07:44:21'),
(514, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/gallery.html', 'sid_1787125872443_gz92cnjkl', '2026-09-02 08:07:55'),
(515, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'testimonial.html', 'http://localhost/noah/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-02 08:12:52'),
(516, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 08:14:11'),
(517, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'testimonial.html', 'http://localhost/noah/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-02 08:15:18'),
(518, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 08:49:08'),
(519, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 08:53:42'),
(520, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 08:56:17'),
(521, '', '', 'Safari', 'Android', 'Mobile', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 09:15:16'),
(522, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 09:20:52'),
(523, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'testimonial.html', 'http://localhost/noah/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-02 09:21:23'),
(524, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/testimonial.html', 'sid_1787125872443_gz92cnjkl', '2026-09-02 09:21:32'),
(525, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 09:30:25'),
(526, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 09:31:27'),
(527, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 09:34:48'),
(528, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 09:36:51'),
(529, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 09:38:22'),
(530, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 09:39:21'),
(531, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 09:44:55'),
(532, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 09:49:34'),
(533, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 09:59:20'),
(534, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/testimonial.html', 'sid_1787125872443_gz92cnjkl', '2026-09-02 10:08:13'),
(535, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 10:08:18'),
(536, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 10:12:13'),
(537, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 10:16:10'),
(538, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 10:20:15'),
(539, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 10:24:53'),
(540, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 10:27:25'),
(541, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 10:30:57'),
(542, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 10:33:21');
INSERT INTO `visitor_logs` (`id`, `ip_address`, `location`, `browser`, `os`, `device`, `page`, `referrer`, `session_id`, `created_at`) VALUES
(543, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 10:34:32'),
(544, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 10:36:39'),
(545, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 10:38:23'),
(546, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 10:44:21'),
(547, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 10:47:13'),
(548, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 11:02:18'),
(549, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/testimonial.html', 'sid_1787125872443_gz92cnjkl', '2026-09-02 11:20:34'),
(550, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 11:20:55'),
(551, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 17:22:07'),
(552, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 17:23:25'),
(553, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 17:28:56'),
(554, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 17:50:26'),
(555, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 17:51:42'),
(556, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 18:07:10'),
(557, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 18:26:15'),
(558, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 18:32:05'),
(559, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 18:47:36'),
(560, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 18:50:08'),
(561, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 18:52:38'),
(562, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 18:55:16'),
(563, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 18:57:15'),
(564, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 19:15:18'),
(565, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 20:24:29'),
(566, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/testimonial.html', 'sid_1787125872443_gz92cnjkl', '2026-09-02 20:26:25'),
(567, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-02 20:28:34'),
(568, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-02 20:28:39'),
(569, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-02 20:29:39'),
(570, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 20:29:48'),
(571, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 20:31:27'),
(572, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 20:32:48'),
(573, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 20:38:29'),
(574, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-02 20:40:14'),
(575, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 05:26:18'),
(576, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-03 05:26:40'),
(577, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-03 05:33:51'),
(578, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-03 05:37:33'),
(579, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-03 05:39:13'),
(580, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-03 05:42:11'),
(581, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-03 05:43:42'),
(582, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 06:02:07'),
(583, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 06:03:20'),
(584, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-03 06:12:26'),
(585, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 06:12:38'),
(586, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 06:15:09'),
(587, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 06:22:30'),
(588, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-03 06:29:33'),
(589, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 06:32:59'),
(590, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 06:33:23'),
(591, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 06:48:40'),
(592, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 06:53:42'),
(593, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 06:54:33'),
(594, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-03 06:54:41'),
(595, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-03 06:59:07'),
(596, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-03 07:26:34'),
(597, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-03 07:38:44'),
(598, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 07:39:42'),
(599, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-03 08:09:18'),
(600, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 08:13:16'),
(601, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 08:18:06'),
(602, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 08:20:41'),
(603, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 08:24:50'),
(604, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-03 08:37:02'),
(605, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 09:43:03'),
(606, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 09:46:09'),
(607, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 10:08:23'),
(608, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 10:11:37'),
(609, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 10:13:34'),
(610, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 10:18:31'),
(611, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 10:20:21'),
(612, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 10:24:25'),
(613, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 10:28:36'),
(614, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 10:30:25'),
(615, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 10:33:55'),
(616, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 10:44:50'),
(617, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 10:50:27'),
(618, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 10:51:51'),
(619, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 11:00:16'),
(620, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 11:08:08'),
(621, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 11:13:18'),
(622, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 11:15:16'),
(623, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 11:23:22'),
(624, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 11:33:21'),
(625, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 11:39:12'),
(626, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 11:40:49'),
(627, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 11:47:44'),
(628, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 12:02:01'),
(629, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 12:05:15'),
(630, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 12:28:51'),
(631, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 12:38:02'),
(632, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 12:44:22'),
(633, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 12:54:25'),
(634, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 12:58:41'),
(635, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 13:08:06'),
(636, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 13:09:12'),
(637, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 13:11:15'),
(638, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 13:14:15'),
(639, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 13:15:19'),
(640, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 13:17:28'),
(641, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 13:19:01'),
(642, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 13:20:54'),
(643, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 13:22:14'),
(644, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 13:24:06'),
(645, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 13:35:57'),
(646, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 13:43:43'),
(647, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 13:56:58'),
(648, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 14:06:50'),
(649, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 14:08:10'),
(650, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 14:16:44'),
(651, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/', 'sid_1787125872443_gz92cnjkl', '2026-09-03 14:19:20'),
(652, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-03 14:19:24'),
(653, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 14:43:51'),
(654, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-03 14:51:20'),
(655, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-03 15:06:54'),
(656, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-03 15:12:47'),
(657, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 15:34:02'),
(658, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/', 'sid_1787125872443_gz92cnjkl', '2026-09-03 15:35:33'),
(659, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-03 15:35:36'),
(660, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-03 15:36:33'),
(661, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-03 15:36:52'),
(662, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 16:51:26'),
(663, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-03 16:51:53'),
(664, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-03 16:52:20'),
(665, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-03 16:55:04'),
(666, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 18:21:23'),
(667, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 19:18:15'),
(668, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 19:44:25'),
(669, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 20:12:10'),
(670, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 20:56:14'),
(671, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 21:25:52'),
(672, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 21:41:53'),
(673, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 21:44:18'),
(674, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-03 21:46:31'),
(675, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-03 21:46:40'),
(676, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 21:52:54'),
(677, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-03 22:08:50'),
(678, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 22:09:04'),
(679, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 22:17:42'),
(680, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-03 22:20:42'),
(681, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-03 22:29:07'),
(682, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-03 22:47:27'),
(683, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-03 23:14:12'),
(684, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-03 23:14:25'),
(685, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-03 23:15:01'),
(686, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 06:52:42');
INSERT INTO `visitor_logs` (`id`, `ip_address`, `location`, `browser`, `os`, `device`, `page`, `referrer`, `session_id`, `created_at`) VALUES
(687, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 06:56:44'),
(688, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 06:58:13'),
(689, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 07:14:47'),
(690, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 07:15:59'),
(691, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 07:19:00'),
(692, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 07:24:11'),
(693, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 07:26:29'),
(694, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 07:28:27'),
(695, '', '', 'Safari', 'Android', 'Mobile', 'teacher.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 07:30:12'),
(696, '', '', 'Safari', 'Android', 'Mobile', 'teacher.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 07:34:02'),
(697, '', '', 'Safari', 'Android', 'Mobile', 'teacher.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 07:39:25'),
(698, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 07:50:48'),
(699, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 07:52:57'),
(700, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 07:53:15'),
(701, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 07:55:27'),
(702, '', '', 'Safari', 'Android', 'Mobile', 'parent.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 07:57:13'),
(703, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 07:59:55'),
(704, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 08:03:40'),
(705, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 08:07:37'),
(706, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 08:10:43'),
(707, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 08:13:28'),
(708, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 08:14:46'),
(709, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 08:16:15'),
(710, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 08:19:56'),
(711, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 08:20:01'),
(712, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 08:21:28'),
(713, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 08:27:02'),
(714, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 08:32:13'),
(715, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 08:32:24'),
(716, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 08:38:57'),
(717, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 08:39:25'),
(718, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 09:17:13'),
(719, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 09:20:54'),
(720, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 09:22:15'),
(721, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 09:23:49'),
(722, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 09:38:09'),
(723, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 09:38:11'),
(724, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 09:48:16'),
(725, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 09:50:04'),
(726, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 09:50:08'),
(727, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 09:51:31'),
(728, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 09:55:05'),
(729, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 10:14:05'),
(730, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 10:16:51'),
(731, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 10:20:53'),
(732, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 10:22:05'),
(733, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 10:23:55'),
(734, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 10:24:51'),
(735, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'about.html', 'http://localhost/noah/', 'sid_1787125872443_gz92cnjkl', '2026-09-04 10:25:39'),
(736, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'team.html', 'http://localhost/noah/html/about.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 10:25:46'),
(737, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/team.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 10:26:14'),
(738, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 10:26:57'),
(739, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 10:28:19'),
(740, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 10:31:47'),
(741, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 10:33:49'),
(742, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 10:57:23'),
(743, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 11:07:21'),
(744, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 11:07:49'),
(745, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 11:13:07'),
(746, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 11:13:10'),
(747, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 11:15:19'),
(748, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 11:19:08'),
(749, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 11:22:09'),
(750, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 11:23:27'),
(751, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 11:25:08'),
(752, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 11:25:34'),
(753, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 11:28:00'),
(754, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 11:28:06'),
(755, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 11:41:53'),
(756, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 11:44:17'),
(757, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 11:45:39'),
(758, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 11:47:32'),
(759, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'about.html', 'http://localhost/noah/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 11:49:22'),
(760, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/about.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 11:49:26'),
(761, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'features.html', 'http://localhost/noah/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 11:49:45'),
(762, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'service.html', 'http://localhost/noah/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 11:49:53'),
(763, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'contact.html', 'http://localhost/noah/html/service.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 11:50:16'),
(764, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 11:51:34'),
(765, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 11:53:33'),
(766, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 11:57:27'),
(767, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'contact.html', 'http://localhost/noah/html/service.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 12:05:23'),
(768, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 12:05:29'),
(769, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'contact.html', 'http://localhost/noah/html/service.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 12:18:10'),
(770, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 12:24:52'),
(771, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 12:25:37'),
(772, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 12:28:51'),
(773, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 12:31:29'),
(774, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 12:31:59'),
(775, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 12:34:34'),
(776, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 12:39:41'),
(777, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 13:07:30'),
(778, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 13:12:52'),
(779, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 13:16:41'),
(780, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 13:17:01'),
(781, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 13:21:18'),
(782, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'contact.html', 'http://localhost/noah/html/service.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 13:21:25'),
(783, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'pta.html', 'http://localhost/noah/html/contact.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 13:21:37'),
(784, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'pta.html', 'http://localhost/noah/html/contact.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 13:25:20'),
(785, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'pta.html', 'http://localhost/noah/html/contact.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 13:27:27'),
(786, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 14:53:55'),
(787, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 14:53:58'),
(788, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 15:19:00'),
(789, '', '', 'Safari', 'Android', 'Mobile', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 15:20:32'),
(790, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 15:32:40'),
(791, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 15:40:35'),
(792, '', '', 'Safari', 'Android', 'Mobile', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 15:42:02'),
(793, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 15:43:45'),
(794, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 15:49:16'),
(795, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 15:51:02'),
(796, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 15:54:10'),
(797, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 15:54:53'),
(798, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'pta.html', 'http://localhost/noah/html/contact.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 15:54:59'),
(799, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'blog.html', 'http://localhost/noah/html/pta.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 15:55:19'),
(800, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'blog.html', 'http://localhost/noah/html/pta.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 16:02:55'),
(801, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 16:03:01'),
(802, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 17:59:52'),
(803, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'blog.html', 'http://localhost/noah/html/pta.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 18:00:05'),
(804, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 18:27:01'),
(805, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 18:42:47'),
(806, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 19:05:08'),
(807, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 19:05:34'),
(808, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 19:14:21'),
(809, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 19:14:27'),
(810, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 19:21:51'),
(811, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 19:22:50'),
(812, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 21:24:55'),
(813, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'team.html', 'http://localhost/noah/', 'sid_1787125872443_gz92cnjkl', '2026-09-04 21:48:54'),
(814, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 21:48:59'),
(815, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 21:49:03'),
(816, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 22:01:27'),
(817, '', '', 'Safari', 'Android', 'Mobile', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 22:11:58'),
(818, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 22:18:34');
INSERT INTO `visitor_logs` (`id`, `ip_address`, `location`, `browser`, `os`, `device`, `page`, `referrer`, `session_id`, `created_at`) VALUES
(819, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'team.html', 'http://localhost/noah/', 'sid_1787125872443_gz92cnjkl', '2026-09-04 22:19:28'),
(820, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/team.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 22:19:32'),
(821, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 22:19:34'),
(822, '', '', 'Safari', 'Android', 'Mobile', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 22:21:23'),
(823, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 22:27:04'),
(824, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-04 22:40:34'),
(825, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 22:42:18'),
(826, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 22:42:23'),
(827, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 22:51:53'),
(828, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 22:52:09'),
(829, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 23:00:00'),
(830, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 23:04:31'),
(831, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 23:06:26'),
(832, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 23:06:33'),
(833, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 23:11:38'),
(834, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 23:17:48'),
(835, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 23:29:42'),
(836, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 23:29:44'),
(837, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 23:33:34'),
(838, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 23:36:44'),
(839, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 23:41:42'),
(840, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 23:45:13'),
(841, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 23:54:45'),
(842, '', '', 'Safari', 'Android', 'Mobile', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-04 23:56:54'),
(843, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 00:01:24'),
(844, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 00:02:22'),
(845, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 00:02:42'),
(846, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 00:20:52'),
(847, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 00:31:26'),
(848, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 00:33:20'),
(849, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 00:33:25'),
(850, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-05 00:41:29'),
(851, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1788569086973_l0ap9bcbk', '2026-09-05 00:44:46'),
(852, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1788569086973_l0ap9bcbk', '2026-09-05 00:45:00'),
(853, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1788569086973_l0ap9bcbk', '2026-09-05 00:48:59'),
(854, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/admin.html?i=1', 'sid_1788569086973_l0ap9bcbk', '2026-09-05 00:49:43'),
(855, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1788569086973_l0ap9bcbk', '2026-09-05 00:49:46'),
(856, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1788569086973_l0ap9bcbk', '2026-09-05 00:49:50'),
(857, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-05 01:12:10'),
(858, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/admin.html?', 'sid_1787125872443_gz92cnjkl', '2026-09-05 01:12:50'),
(859, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 01:16:49'),
(860, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 01:17:17'),
(861, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 01:20:49'),
(862, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 01:20:59'),
(863, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 01:22:19'),
(864, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 01:26:38'),
(865, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 01:26:44'),
(866, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 01:28:03'),
(867, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 01:28:51'),
(868, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 01:29:03'),
(869, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 01:31:18'),
(870, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 01:31:32'),
(871, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 01:35:19'),
(872, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 01:36:49'),
(873, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 01:37:59'),
(874, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1788569086973_l0ap9bcbk', '2026-09-05 07:26:43'),
(875, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/admin.html?i=1', 'sid_1788569086973_l0ap9bcbk', '2026-09-05 07:27:59'),
(876, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1788569086973_l0ap9bcbk', '2026-09-05 07:32:33'),
(877, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'features.html', 'http://localhost/noah/', 'sid_1788569086973_l0ap9bcbk', '2026-09-05 07:32:57'),
(878, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'events.html', 'http://localhost/noah/html/features.html', 'sid_1788569086973_l0ap9bcbk', '2026-09-05 07:32:59'),
(879, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1788569086973_l0ap9bcbk', '2026-09-05 07:35:21'),
(880, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 07:40:54'),
(881, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 07:44:54'),
(882, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-05 07:44:56'),
(883, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/parent.html?', 'sid_1787125872443_gz92cnjkl', '2026-09-05 07:45:15'),
(884, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-05 07:46:11'),
(885, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 07:48:16'),
(886, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 07:49:27'),
(887, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 07:50:49'),
(888, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 07:56:40'),
(889, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-05 07:57:10'),
(890, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 08:09:37'),
(891, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-05 08:09:41'),
(892, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 08:12:05'),
(893, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 08:13:46'),
(894, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 08:14:33'),
(895, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 08:15:50'),
(896, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 08:26:14'),
(897, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 08:29:18'),
(898, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 08:34:27'),
(899, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 08:38:52'),
(900, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 08:42:44'),
(901, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-05 08:53:03'),
(902, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 08:53:13'),
(903, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 08:59:05'),
(904, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 09:10:07'),
(905, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 09:16:40'),
(906, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 09:24:15'),
(907, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 09:30:33'),
(908, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 09:31:35'),
(909, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 09:36:51'),
(910, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 09:46:52'),
(911, '', '', 'Safari', 'Android', 'Mobile', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 09:48:08'),
(912, '', '', 'Safari', 'Android', 'Mobile', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 09:49:14'),
(913, '', '', 'Safari', 'macOS', 'Mobile', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 09:53:27'),
(914, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 10:10:32'),
(915, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 10:11:15'),
(916, '', '', 'Safari', 'macOS', 'Mobile', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 10:12:28'),
(917, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 10:34:29'),
(918, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 10:41:36'),
(919, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 10:48:32'),
(920, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 11:30:18'),
(921, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 11:35:38'),
(922, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 11:36:43'),
(923, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 11:37:56'),
(924, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 11:39:56'),
(925, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 11:42:27'),
(926, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 11:52:27'),
(927, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-05 11:52:30'),
(928, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 11:52:35'),
(929, '', '', 'Safari', 'macOS', 'Mobile', 'parent.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 12:12:19'),
(930, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 12:12:33'),
(931, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 12:32:45'),
(932, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-05 12:41:53'),
(933, '', '', 'Safari', 'macOS', 'Mobile', 'parent.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 12:41:59'),
(934, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 12:42:11'),
(935, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 12:51:10'),
(936, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 12:53:04'),
(937, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 12:54:42'),
(938, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 12:58:20'),
(939, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 13:03:03'),
(940, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 13:28:51'),
(941, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 13:30:38'),
(942, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-05 13:30:56');
INSERT INTO `visitor_logs` (`id`, `ip_address`, `location`, `browser`, `os`, `device`, `page`, `referrer`, `session_id`, `created_at`) VALUES
(943, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 13:35:28'),
(944, '', '', 'Safari', 'macOS', 'Mobile', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 13:42:35'),
(945, '', '', 'Safari', 'macOS', 'Mobile', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 13:49:32'),
(946, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-05 13:56:06'),
(947, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 14:15:52'),
(948, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 14:15:55'),
(949, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-05 14:26:56'),
(950, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 14:26:59'),
(951, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 14:29:22'),
(952, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 14:55:24'),
(953, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-05 14:55:56'),
(954, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-05 15:25:01'),
(955, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-05 15:32:34'),
(956, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-05 15:35:11'),
(957, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-05 15:42:55'),
(958, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-05 15:45:58'),
(959, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-05 15:47:13'),
(960, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 16:04:47'),
(961, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-05 16:04:48'),
(962, '', '', 'Safari', 'macOS', 'Mobile', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-05 16:16:40'),
(963, '', '', 'Safari', 'macOS', 'Mobile', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-05 16:21:42'),
(964, '', '', 'Safari', 'macOS', 'Mobile', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-05 16:44:37'),
(965, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 16:56:02'),
(966, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 16:57:02'),
(967, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 17:02:58'),
(968, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 17:12:19'),
(969, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 17:13:28'),
(970, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-05 17:15:10'),
(971, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 17:17:02'),
(972, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 17:19:03'),
(973, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 17:36:38'),
(974, '', '', 'Safari', 'macOS', 'Mobile', 'parent.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 17:37:40'),
(975, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 17:44:28'),
(976, '', '', 'Safari', 'macOS', 'Mobile', 'parent.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 17:44:33'),
(977, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 18:03:23'),
(978, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 18:10:27'),
(979, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-05 18:12:16'),
(980, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 18:38:48'),
(981, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 18:38:57'),
(982, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-05 18:39:13'),
(983, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-05 18:40:14'),
(984, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-05 18:44:32'),
(985, '', '', 'Safari', 'macOS', 'Mobile', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-05 18:50:55'),
(986, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html?', 'sid_1787125872443_gz92cnjkl', '2026-09-05 18:51:57'),
(987, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-05 18:53:06'),
(988, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 18:54:31'),
(989, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 18:54:40'),
(990, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 19:08:11'),
(991, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 19:08:35'),
(992, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'Direct', 'sid_1788635498041_ttwtjb290', '2026-09-05 19:11:38'),
(993, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 19:12:40'),
(994, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 19:13:10'),
(995, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-05 19:13:38'),
(996, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 19:22:10'),
(997, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 19:22:40'),
(998, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-05 19:25:20'),
(999, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-05 19:36:57'),
(1000, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 19:54:30'),
(1001, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-05 19:56:35'),
(1002, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 20:00:45'),
(1003, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 20:02:53'),
(1004, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-05 20:05:25'),
(1005, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 20:05:31'),
(1006, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 20:10:18'),
(1007, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 20:20:11'),
(1008, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 20:24:26'),
(1009, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 20:38:23'),
(1010, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/parent.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 20:41:32'),
(1011, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-05 20:44:44'),
(1012, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 20:45:37'),
(1013, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/admin.html?', 'sid_1787125872443_gz92cnjkl', '2026-09-05 20:47:01'),
(1014, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1787125872443_gz92cnjkl', '2026-09-05 20:48:02'),
(1015, '', '', 'Safari', 'macOS', 'Mobile', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1787125872443_gz92cnjkl', '2026-09-05 20:50:57'),
(1016, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1787125872443_gz92cnjkl', '2026-09-05 20:54:35'),
(1017, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 20:54:58'),
(1018, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/admin.html?', 'sid_1787125872443_gz92cnjkl', '2026-09-05 20:55:26'),
(1019, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'about.html', 'http://localhost/noah/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 20:56:04'),
(1020, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/dashboard/parent.html?', 'sid_1787125872443_gz92cnjkl', '2026-09-05 20:56:28'),
(1021, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/admin.html?', 'sid_1787125872443_gz92cnjkl', '2026-09-05 20:57:50'),
(1022, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/about.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 20:57:57'),
(1023, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 21:05:42'),
(1024, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1787125872443_gz92cnjkl', '2026-09-05 21:06:17'),
(1025, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/admin.html?', 'sid_1787125872443_gz92cnjkl', '2026-09-05 21:30:06'),
(1026, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-05 21:30:33'),
(1027, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/dashboard/parent.html?', 'sid_1787125872443_gz92cnjkl', '2026-09-05 21:32:12'),
(1028, '', '', 'Safari', 'macOS', 'Mobile', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-05 21:32:30'),
(1029, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/admin.html?', 'sid_1787125872443_gz92cnjkl', '2026-09-05 21:32:34'),
(1030, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-05 21:32:47'),
(1031, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/admin.html?', 'sid_1787125872443_gz92cnjkl', '2026-09-05 21:35:45'),
(1032, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/admin.html?', 'sid_1787125872443_gz92cnjkl', '2026-09-06 04:55:09'),
(1033, '', '', 'Safari', 'macOS', 'Mobile', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1787125872443_gz92cnjkl', '2026-09-06 04:59:21'),
(1034, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1787125872443_gz92cnjkl', '2026-09-06 05:09:38'),
(1035, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1787125872443_gz92cnjkl', '2026-09-06 05:10:38'),
(1036, '', '', 'Safari', 'macOS', 'Mobile', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1787125872443_gz92cnjkl', '2026-09-06 05:29:49'),
(1037, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'Direct', 'sid_1788672634800_5hepom8l1', '2026-09-06 05:30:34'),
(1038, '', '', 'Safari', 'macOS', 'Mobile', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1788672634800_5hepom8l1', '2026-09-06 05:33:02'),
(1039, '', '', 'Safari', 'macOS', 'Mobile', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1787125872443_gz92cnjkl', '2026-09-06 05:34:31'),
(1040, '', '', 'Safari', 'macOS', 'Mobile', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1787125872443_gz92cnjkl', '2026-09-06 05:39:36'),
(1041, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-06 05:42:44'),
(1042, '', '', 'Safari', 'macOS', 'Mobile', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-06 05:43:42'),
(1043, '', '', 'Safari', 'macOS', 'Mobile', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1787125872443_gz92cnjkl', '2026-09-06 05:45:16'),
(1044, '', '', 'Safari', 'macOS', 'Mobile', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1787125872443_gz92cnjkl', '2026-09-06 05:53:16'),
(1045, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1787125872443_gz92cnjkl', '2026-09-06 05:55:44'),
(1046, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-06 05:55:54'),
(1047, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1787125872443_gz92cnjkl', '2026-09-06 06:19:28'),
(1048, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1787125872443_gz92cnjkl', '2026-09-06 06:21:47'),
(1049, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-06 06:23:15'),
(1050, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-06 06:23:17'),
(1051, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-06 06:23:20'),
(1052, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-06 06:24:01'),
(1053, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-06 06:38:39'),
(1054, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1787125872443_gz92cnjkl', '2026-09-06 06:38:40'),
(1055, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-06 06:40:15'),
(1056, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-06 06:40:21'),
(1057, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-06 06:40:25'),
(1058, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-06 06:41:25'),
(1059, '', '', 'Safari', 'macOS', 'Mobile', 'teacher.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-06 06:50:05'),
(1060, '', '', 'Safari', 'macOS', 'Mobile', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html', 'sid_1787125872443_gz92cnjkl', '2026-09-06 06:53:11'),
(1061, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-06 06:56:52'),
(1062, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-06 06:56:54'),
(1063, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-06 06:57:17'),
(1064, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1787125872443_gz92cnjkl', '2026-09-06 07:08:04'),
(1065, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-06 07:10:00'),
(1066, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-06 07:22:36'),
(1067, '', '', 'Safari', 'macOS', 'Mobile', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1787125872443_gz92cnjkl', '2026-09-06 07:22:55'),
(1068, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-06 07:23:40'),
(1069, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-06 07:23:52'),
(1070, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-06 07:23:55'),
(1071, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1787125872443_gz92cnjkl', '2026-09-06 07:26:05');
INSERT INTO `visitor_logs` (`id`, `ip_address`, `location`, `browser`, `os`, `device`, `page`, `referrer`, `session_id`, `created_at`) VALUES
(1072, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-06 07:26:37'),
(1073, '', '', 'Safari', 'macOS', 'Mobile', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1787125872443_gz92cnjkl', '2026-09-06 08:14:24'),
(1074, '', '', 'Safari', 'macOS', 'Mobile', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1787125872443_gz92cnjkl', '2026-09-06 08:23:53'),
(1075, '', '', 'Safari', 'macOS', 'Mobile', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1787125872443_gz92cnjkl', '2026-09-06 08:25:02'),
(1076, '', '', 'Safari', 'macOS', 'Mobile', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1787125872443_gz92cnjkl', '2026-09-06 08:28:04'),
(1077, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1787125872443_gz92cnjkl', '2026-09-06 08:31:14'),
(1078, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1787125872443_gz92cnjkl', '2026-09-06 08:31:18'),
(1079, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'about.html', 'http://localhost/noah/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-06 08:31:55'),
(1080, '', '', 'Safari', 'macOS', 'Mobile', 'about.html', 'http://localhost/noah/index.html', 'sid_1787125872443_gz92cnjkl', '2026-09-06 08:43:06'),
(1081, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-06 08:43:24'),
(1082, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1787125872443_gz92cnjkl', '2026-09-06 08:43:33'),
(1083, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-06 08:43:37'),
(1084, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1787125872443_gz92cnjkl', '2026-09-06 08:50:15'),
(1085, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1787125872443_gz92cnjkl', '2026-09-06 08:51:42'),
(1086, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1788684794643_shg0utrs1', '2026-09-06 08:53:16'),
(1087, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'about.html', 'http://localhost/noah/index.html', 'sid_1788684794643_shg0utrs1', '2026-09-06 08:53:37'),
(1088, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/index.html', 'sid_1788684794643_shg0utrs1', '2026-09-06 08:54:56'),
(1089, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1788684794643_shg0utrs1', '2026-09-06 08:54:58'),
(1090, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1788684794643_shg0utrs1', '2026-09-06 09:04:39'),
(1091, '', '', 'Safari', 'macOS', 'Mobile', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1788684794643_shg0utrs1', '2026-09-06 09:07:48'),
(1092, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1788684794643_shg0utrs1', '2026-09-06 09:09:22'),
(1093, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'Direct', 'sid_1788684794643_shg0utrs1', '2026-09-06 09:14:11'),
(1094, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'Direct', 'sid_1788684794643_shg0utrs1', '2026-09-06 09:59:57'),
(1095, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'Direct', 'sid_1788684794643_shg0utrs1', '2026-09-06 10:05:37'),
(1096, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1788684794643_shg0utrs1', '2026-09-06 10:14:39'),
(1097, '', '', 'Safari', 'macOS', 'Mobile', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1788684794643_shg0utrs1', '2026-09-06 10:21:55'),
(1098, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1788684794643_shg0utrs1', '2026-09-06 10:23:28'),
(1099, '', '', 'Safari', 'macOS', 'Mobile', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1788684794643_shg0utrs1', '2026-09-06 10:36:23'),
(1100, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1788684794643_shg0utrs1', '2026-09-06 10:37:33'),
(1101, '', '', 'Safari', 'macOS', 'Mobile', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1788684794643_shg0utrs1', '2026-09-06 10:40:57'),
(1102, '', '', 'Chrome', 'Windows 10/11', 'Desktop', 'teacher.html', 'Direct', 'sid_1788186483527_rriel2597', '2026-09-06 10:41:51'),
(1103, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1788684794643_shg0utrs1', '2026-09-06 12:08:16'),
(1104, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1788684794643_shg0utrs1', '2026-09-06 12:13:22'),
(1105, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1788684794643_shg0utrs1', '2026-09-06 12:23:07'),
(1106, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1788684794643_shg0utrs1', '2026-09-06 12:26:35'),
(1107, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'Direct', 'sid_1788701478445_f3xan35rz', '2026-09-06 13:31:18'),
(1108, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/dashboard/teacher.html?username=gumbo%40gmail.com&password=p88312%4027', 'sid_1788701478445_f3xan35rz', '2026-09-06 13:31:51'),
(1109, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/index.html', 'sid_1788701478445_f3xan35rz', '2026-09-06 13:32:07'),
(1110, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1788701478445_f3xan35rz', '2026-09-06 13:35:54'),
(1111, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1788701478445_f3xan35rz', '2026-09-06 13:44:53'),
(1112, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1788701478445_f3xan35rz', '2026-09-06 14:01:09'),
(1113, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1788701478445_f3xan35rz', '2026-09-06 14:14:34'),
(1114, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1788701478445_f3xan35rz', '2026-09-06 15:23:37'),
(1115, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1788701478445_f3xan35rz', '2026-09-06 15:31:19'),
(1116, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1788701478445_f3xan35rz', '2026-09-06 15:32:51'),
(1117, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1788701478445_f3xan35rz', '2026-09-06 15:37:14'),
(1118, '', '', 'Safari', 'Android', 'Mobile', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1788701478445_f3xan35rz', '2026-09-06 15:52:36'),
(1119, '', '', 'Safari', 'Android', 'Mobile', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1788701478445_f3xan35rz', '2026-09-06 16:04:48'),
(1120, '', '', 'Safari', 'Android', 'Mobile', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1788701478445_f3xan35rz', '2026-09-06 16:32:22'),
(1121, '', '', 'Safari', 'Android', 'Mobile', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1788701478445_f3xan35rz', '2026-09-06 16:33:52'),
(1122, '', '', 'Safari', 'Android', 'Mobile', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1788701478445_f3xan35rz', '2026-09-06 16:36:36'),
(1123, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1788701478445_f3xan35rz', '2026-09-06 16:37:03'),
(1124, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1788701478445_f3xan35rz', '2026-09-06 17:01:50'),
(1125, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1788701478445_f3xan35rz', '2026-09-06 18:13:04'),
(1126, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1788701478445_f3xan35rz', '2026-09-06 18:14:26'),
(1127, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1788701478445_f3xan35rz', '2026-09-06 18:18:52'),
(1128, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1788701478445_f3xan35rz', '2026-09-06 18:20:44'),
(1129, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1788701478445_f3xan35rz', '2026-09-06 18:27:12'),
(1130, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1788701478445_f3xan35rz', '2026-09-06 18:31:34'),
(1131, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1788701478445_f3xan35rz', '2026-09-06 18:33:28'),
(1132, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1788701478445_f3xan35rz', '2026-09-06 18:40:40'),
(1133, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1788701478445_f3xan35rz', '2026-09-06 18:40:57'),
(1134, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1788701478445_f3xan35rz', '2026-09-06 18:43:19'),
(1135, '', '', 'Chrome', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1788720557350_ablr32g9w', '2026-09-06 18:49:17'),
(1136, '', '', 'Chrome', 'Windows 10/11', 'Desktop', 'index.html', 'http://127.0.0.1:58463/', 'sid_1788720557350_ablr32g9w', '2026-09-06 18:50:31'),
(1137, '', '', 'Chrome', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://127.0.0.1:58463/dashboard/index.html', 'sid_1788720557350_ablr32g9w', '2026-09-06 18:50:34'),
(1138, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1788701478445_f3xan35rz', '2026-09-06 18:51:05'),
(1139, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'Direct', 'sid_1788701478445_f3xan35rz', '2026-09-06 19:01:49'),
(1140, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1788701478445_f3xan35rz', '2026-09-06 19:14:00'),
(1141, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1788701478445_f3xan35rz', '2026-09-06 19:15:38'),
(1142, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1788701478445_f3xan35rz', '2026-09-06 19:23:14'),
(1143, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1788701478445_f3xan35rz', '2026-09-06 19:25:04'),
(1144, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1788701478445_f3xan35rz', '2026-09-06 19:36:33'),
(1145, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1788701478445_f3xan35rz', '2026-09-06 19:42:49'),
(1146, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1788701478445_f3xan35rz', '2026-09-06 19:48:43'),
(1147, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1788701478445_f3xan35rz', '2026-09-06 20:54:52'),
(1148, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/index.html', 'sid_1788701478445_f3xan35rz', '2026-09-06 20:54:55'),
(1149, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1788701478445_f3xan35rz', '2026-09-06 20:55:06'),
(1150, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1788701478445_f3xan35rz', '2026-09-06 20:56:52'),
(1151, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1788701478445_f3xan35rz', '2026-09-06 20:57:44'),
(1152, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1788701478445_f3xan35rz', '2026-09-06 21:01:19'),
(1153, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1788701478445_f3xan35rz', '2026-09-06 21:09:38'),
(1154, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/index.html', 'sid_1788701478445_f3xan35rz', '2026-09-06 21:21:54'),
(1155, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1788701478445_f3xan35rz', '2026-09-06 21:22:22'),
(1156, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1788701478445_f3xan35rz', '2026-09-06 21:25:24'),
(1157, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1788701478445_f3xan35rz', '2026-09-06 21:26:16'),
(1158, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1788701478445_f3xan35rz', '2026-09-06 21:38:42'),
(1159, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1788701478445_f3xan35rz', '2026-09-06 21:47:49'),
(1160, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1788701478445_f3xan35rz', '2026-09-06 21:49:04'),
(1161, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1788701478445_f3xan35rz', '2026-09-06 21:52:10'),
(1162, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1788701478445_f3xan35rz', '2026-09-06 22:01:21'),
(1163, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1788701478445_f3xan35rz', '2026-09-06 22:03:00'),
(1164, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1788701478445_f3xan35rz', '2026-09-06 22:06:05'),
(1165, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1788701478445_f3xan35rz', '2026-09-06 22:07:29'),
(1166, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1788701478445_f3xan35rz', '2026-09-06 22:13:26'),
(1167, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1788701478445_f3xan35rz', '2026-09-06 22:14:29'),
(1168, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1788701478445_f3xan35rz', '2026-09-06 22:16:07'),
(1169, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1788701478445_f3xan35rz', '2026-09-06 22:23:13'),
(1170, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1788701478445_f3xan35rz', '2026-09-06 22:26:13'),
(1171, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1788701478445_f3xan35rz', '2026-09-06 22:28:18'),
(1172, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1788701478445_f3xan35rz', '2026-09-06 22:29:34'),
(1173, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html?', 'sid_1788701478445_f3xan35rz', '2026-09-06 22:31:45'),
(1174, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1788701478445_f3xan35rz', '2026-09-06 22:39:02'),
(1175, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1788701478445_f3xan35rz', '2026-09-06 22:40:15'),
(1176, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1788701478445_f3xan35rz', '2026-09-06 22:41:29'),
(1177, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1788701478445_f3xan35rz', '2026-09-06 22:54:50'),
(1178, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1788701478445_f3xan35rz', '2026-09-06 22:55:39'),
(1179, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'Direct', 'sid_1788701478445_f3xan35rz', '2026-09-06 22:58:49'),
(1180, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1788701478445_f3xan35rz', '2026-09-06 22:58:53'),
(1181, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/index.html', 'sid_1788701478445_f3xan35rz', '2026-09-06 22:58:58'),
(1182, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/index.html', 'sid_1788701478445_f3xan35rz', '2026-09-06 23:09:45'),
(1183, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/index.html', 'sid_1788701478445_f3xan35rz', '2026-09-06 23:12:59'),
(1184, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/index.html', 'sid_1788701478445_f3xan35rz', '2026-09-06 23:17:53'),
(1185, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1788701478445_f3xan35rz', '2026-09-06 23:18:39'),
(1186, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'teacher.html', 'http://localhost/noah/dashboard/teacher.html?', 'sid_1788701478445_f3xan35rz', '2026-09-06 23:20:34'),
(1187, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'Direct', 'sid_1788701478445_f3xan35rz', '2026-09-06 23:21:55'),
(1188, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'about.html', 'http://localhost/noah/', 'sid_1788701478445_f3xan35rz', '2026-09-06 23:22:22'),
(1189, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'team.html', 'http://localhost/noah/html/about.html', 'sid_1788701478445_f3xan35rz', '2026-09-06 23:22:24'),
(1190, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'gallery.html', 'http://localhost/noah/html/team.html', 'sid_1788701478445_f3xan35rz', '2026-09-06 23:22:27'),
(1191, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'features.html', 'http://localhost/noah/index.html', 'sid_1788701478445_f3xan35rz', '2026-09-06 23:22:49'),
(1192, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admissions.html', 'http://localhost/noah/html/features.html', 'sid_1788701478445_f3xan35rz', '2026-09-06 23:22:58'),
(1193, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admissions.html', 'http://localhost/noah/html/features.html', 'sid_1788701478445_f3xan35rz', '2026-09-06 23:26:11'),
(1194, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admissions.html', 'http://localhost/noah/html/features.html', 'sid_1788701478445_f3xan35rz', '2026-09-06 23:27:06'),
(1195, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'index.html', 'http://localhost/noah/html/admissions.html', 'sid_1788701478445_f3xan35rz', '2026-09-06 23:27:27'),
(1196, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'parent.html', 'http://localhost/noah/dashboard/index.html', 'sid_1788701478445_f3xan35rz', '2026-09-06 23:29:17');
INSERT INTO `visitor_logs` (`id`, `ip_address`, `location`, `browser`, `os`, `device`, `page`, `referrer`, `session_id`, `created_at`) VALUES
(1197, '', '', 'Edge', 'Windows 10/11', 'Desktop', 'admin.html', 'http://localhost/noah/dashboard/admin.html', 'sid_1788701478445_f3xan35rz', '2026-09-06 23:36:03');

-- --------------------------------------------------------

--
-- Table structure for table `visitor_page_history`
--

CREATE TABLE `visitor_page_history` (
  `id` int(11) NOT NULL,
  `session_id` varchar(100) NOT NULL,
  `url` varchar(500) DEFAULT NULL,
  `path` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `referrer` varchar(500) DEFAULT NULL,
  `visited_at` datetime NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `visitor_tracking`
--

CREATE TABLE `visitor_tracking` (
  `id` int(11) NOT NULL,
  `session_id` varchar(100) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `region` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `country_code` varchar(10) DEFAULT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `postal_code` varchar(20) DEFAULT NULL,
  `isp` varchar(255) DEFAULT NULL,
  `timezone` varchar(50) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `referrer` varchar(500) DEFAULT NULL,
  `current_page` varchar(500) DEFAULT NULL,
  `first_visit` datetime NOT NULL,
  `last_activity` datetime NOT NULL,
  `page_views` int(11) DEFAULT 0,
  `last_action` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account_deletion_requests`
--
ALTER TABLE `account_deletion_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user` (`user_type`,`user_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_scheduled` (`scheduled_deletion_at`);

--
-- Indexes for table `visitor_tracking`
--
ALTER TABLE `visitor_tracking`
  ADD KEY `idx_location_coords` (`latitude`,`longitude`),
  ADD KEY `idx_country_city` (`country`,`city`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
