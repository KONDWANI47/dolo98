-- Fix AUTO_INCREMENT for all tables
-- This script adds PRIMARY KEY and AUTO_INCREMENT to ID columns that are missing it
-- Run this in phpMyAdmin or MySQL CLI to fix the ID 0 issue

-- First, remove the problematic SQL mode
SET SQL_MODE = "";

-- Fix admins table
ALTER TABLE `admins` ADD PRIMARY KEY (`id`);
ALTER TABLE `admins` MODIFY COLUMN `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT = 1;

-- Fix activity_log table
ALTER TABLE `activity_log` ADD PRIMARY KEY (`id`);
ALTER TABLE `activity_log` MODIFY COLUMN `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT = 1;

-- Fix account_deletion_requests table
ALTER TABLE `account_deletion_requests` ADD PRIMARY KEY (`id`);
ALTER TABLE `account_deletion_requests` MODIFY COLUMN `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT = 1;

-- Fix admin_report_review table
ALTER TABLE `admin_report_review` ADD PRIMARY KEY (`id`);
ALTER TABLE `admin_report_review` MODIFY COLUMN `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT = 1;

-- Fix admin_sessions table
ALTER TABLE `admin_sessions` ADD PRIMARY KEY (`id`);
ALTER TABLE `admin_sessions` MODIFY COLUMN `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT = 1;

-- Fix announcements table
ALTER TABLE `announcements` ADD PRIMARY KEY (`id`);
ALTER TABLE `announcements` MODIFY COLUMN `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT = 1;

-- Fix apis table
ALTER TABLE `apis` ADD PRIMARY KEY (`id`);
ALTER TABLE `apis` MODIFY COLUMN `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT = 1;

-- Fix application_documents table
ALTER TABLE `application_documents` ADD PRIMARY KEY (`id`);
ALTER TABLE `application_documents` MODIFY COLUMN `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT = 1;

-- Fix assessments table
ALTER TABLE `assessments` ADD PRIMARY KEY (`id`);
ALTER TABLE `assessments` MODIFY COLUMN `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT = 1;

-- Fix class_teachers table
ALTER TABLE `class_teachers` ADD PRIMARY KEY (`id`);
ALTER TABLE `class_teachers` MODIFY COLUMN `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT = 1;

-- Fix collaboration_logs table
ALTER TABLE `collaboration_logs` ADD PRIMARY KEY (`id`);
ALTER TABLE `collaboration_logs` MODIFY COLUMN `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT = 1;

-- Fix collaboration_sessions table
ALTER TABLE `collaboration_sessions` ADD PRIMARY KEY (`id`);
ALTER TABLE `collaboration_sessions` MODIFY COLUMN `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT = 1;

-- Fix complaints table
ALTER TABLE `complaints` ADD PRIMARY KEY (`id`);
ALTER TABLE `complaints` MODIFY COLUMN `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT = 1;

-- Fix courses table
ALTER TABLE `courses` ADD PRIMARY KEY (`id`);
ALTER TABLE `courses` MODIFY COLUMN `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT = 1;

-- Fix events table
ALTER TABLE `events` ADD PRIMARY KEY (`id`);
ALTER TABLE `events` MODIFY COLUMN `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT = 1;

-- Fix gallery table
ALTER TABLE `gallery` ADD PRIMARY KEY (`id`);
ALTER TABLE `gallery` MODIFY COLUMN `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT = 1;

-- Fix messages table
ALTER TABLE `messages` ADD PRIMARY KEY (`id`);
ALTER TABLE `messages` MODIFY COLUMN `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT = 1;

-- Fix notifications table
ALTER TABLE `notifications` ADD PRIMARY KEY (`id`);
ALTER TABLE `notifications` MODIFY COLUMN `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT = 1;

-- Fix oauth_login_tokens table
ALTER TABLE `oauth_login_tokens` ADD PRIMARY KEY (`id`);
ALTER TABLE `oauth_login_tokens` MODIFY COLUMN `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT = 1;

-- Fix parent_authorized_emails table
ALTER TABLE `parent_authorized_emails` ADD PRIMARY KEY (`id`);
ALTER TABLE `parent_authorized_emails` MODIFY COLUMN `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT = 1;

-- Fix parent_authorized_ips table
ALTER TABLE `parent_authorized_ips` ADD PRIMARY KEY (`id`);
ALTER TABLE `parent_authorized_ips` MODIFY COLUMN `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT = 1;

-- Fix parent_login_logs table
ALTER TABLE `parent_login_logs` ADD PRIMARY KEY (`id`);
ALTER TABLE `parent_login_logs` MODIFY COLUMN `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT = 1;

-- Fix parent_report_access table
ALTER TABLE `parent_report_access` ADD PRIMARY KEY (`id`);
ALTER TABLE `parent_report_access` MODIFY COLUMN `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT = 1;

-- Fix parents table
ALTER TABLE `parents` ADD PRIMARY KEY (`id`);
ALTER TABLE `parents` MODIFY COLUMN `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT = 1;

-- Fix payments table
ALTER TABLE `payments` ADD PRIMARY KEY (`id`);
ALTER TABLE `payments` MODIFY COLUMN `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT = 1;

-- Fix registrations table
ALTER TABLE `registrations` ADD PRIMARY KEY (`id`);
ALTER TABLE `registrations` MODIFY COLUMN `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT = 1;

-- Fix services table
ALTER TABLE `services` ADD PRIMARY KEY (`id`);
ALTER TABLE `services` MODIFY COLUMN `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT = 1;

-- Fix settings table
ALTER TABLE `settings` ADD PRIMARY KEY (`id`);
ALTER TABLE `settings` MODIFY COLUMN `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT = 1;

-- Fix shared_report_drafts table
ALTER TABLE `shared_report_drafts` ADD PRIMARY KEY (`id`);
ALTER TABLE `shared_report_drafts` MODIFY COLUMN `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT = 1;

-- Fix shared_resources table
ALTER TABLE `shared_resources` ADD PRIMARY KEY (`id`);
ALTER TABLE `shared_resources` MODIFY COLUMN `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT = 1;

-- Fix site_content table
ALTER TABLE `site_content` ADD PRIMARY KEY (`id`);
ALTER TABLE `site_content` MODIFY COLUMN `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT = 1;

-- Fix students table
ALTER TABLE `students` ADD PRIMARY KEY (`id`);
ALTER TABLE `students` MODIFY COLUMN `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT = 1;

-- Fix teachers table
ALTER TABLE `teachers` ADD PRIMARY KEY (`id`);
ALTER TABLE `teachers` MODIFY COLUMN `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT = 1;

-- Fix testimonials table
ALTER TABLE `testimonials` ADD PRIMARY KEY (`id`);
ALTER TABLE `testimonials` MODIFY COLUMN `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT = 1;
