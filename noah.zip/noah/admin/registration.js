/**
 * Registration Management - Admin Dashboard
 * 
 * Manages registrations from the JSON-based registration API.
 * Registration is the CENTRAL POINT — approving a registration
 * auto-creates a student record linked via registration_id.
 */

// ============================================================
// Safe Fetch Helper
// ============================================================
async function safeFetch(response) {
    if (!response.ok) {
        const text = await response.text();
        try {
            return JSON.parse(text);
        } catch {
            return { success: false, message: `HTTP ${response.status}: ${text || 'No response body'}` };
        }
    }
    
    const text = await response.text();
    if (!text.trim()) {
        return { success: false, message: 'Empty response from server' };
    }
    
    try {
        return JSON.parse(text);
    } catch (parseErr) {
        return { success: false, message: 'Invalid JSON response from server' };
    }
}

// ============================================================
// API Helper
// ============================================================
async function apiReg(action, data = null, method = 'GET') {
    const url = '../api/registration.php' + (action ? '?' + action : '');
    const options = {
        method: method,
        headers: { 'Content-Type': 'application/json' }
    };
    if (data && method !== 'GET') {
        options.body = JSON.stringify(data);
    }
    try {
        const response = await fetch(url, options);
        return await safeFetch(response);
    } catch (err) {
        return { success: false, message: 'Network error: ' + err.message };
    }
}

// ============================================================
// Load and render registrations
// ============================================================
let allRegistrations = [];
let currentRegFilter = '';
let currentRegSearch = '';

async function loadRegistrations() {
    const res = await apiReg('status=' + encodeURIComponent(currentRegFilter));
    if (res.success && res.data) {
        allRegistrations = res.data.items || [];
        renderRegistrationsCustom();
    }
}

function renderRegistrationsCustom() {
    const tbody = document.getElementById('registrationsTableBody');
    if (!tbody) return;

    let filtered = allRegistrations;

    // Apply search filter
    if (currentRegSearch) {
        const search = currentRegSearch.toLowerCase();
        filtered = filtered.filter(r =>
            (r.studentName || '').toLowerCase().includes(search) ||
            (r.parentName || '').toLowerCase().includes(search) ||
            (r.email || '').toLowerCase().includes(search) ||
            (r.phone || '').toLowerCase().includes(search)
        );
    }

    if (filtered.length === 0) {
        tbody.innerHTML = '<tr><td colspan="9" class="text-center text-muted">No registrations found.</td></tr>';
        return;
    }

    tbody.innerHTML = filtered.map((reg, i) => {
        const status = reg.status || 'Pending';
        const statusClass = status === 'Approved' ? 'status-approved' :
                           status === 'Rejected' ? 'status-rejected' : 'status-pending';
        const created = new Date(reg.createdAt || '').toLocaleDateString('en-GB');
        return `
            <tr>
                <td>${i + 1}</td>
                <td><strong>${reg.studentName || ''}</strong></td>
                <td>${reg.grade || ''}</td>
                <td>${reg.parentName || ''}</td>
                <td>${reg.phone || ''}</td>
                <td>${reg.email || ''}</td>
                <td>${created}</td>
                <td><span class="status-badge ${statusClass}">${status}</span></td>
                <td>
                    <button class="admin-btn admin-btn-sm admin-btn-info" onclick="viewRegistration(${reg.id})" title="View"><i class="fas fa-eye"></i></button>
                    ${status !== 'Approved' ? `<button class="admin-btn admin-btn-sm admin-btn-success" onclick="approveRegistration(${reg.id})" title="Approve"><i class="fas fa-check"></i></button>` : ''}
                    ${status !== 'Rejected' ? `<button class="admin-btn admin-btn-sm admin-btn-danger" onclick="rejectRegistration(${reg.id})" title="Reject"><i class="fas fa-times"></i></button>` : ''}
                    <button class="admin-btn admin-btn-sm admin-btn-danger" onclick="deleteRegistration(${reg.id})" title="Delete"><i class="fas fa-trash"></i></button>
                </td>
            </tr>
        `;
    }).join('');

    updateRegBadge();
}

function updateRegBadge() {
    const badge = document.getElementById('regBadge');
    if (badge) {
        badge.textContent = allRegistrations.filter(r => (r.status || '') === 'Pending').length;
        badge.style.display = allRegistrations.length > 0 ? 'inline-block' : 'none';
    }
}

// ============================================================
// Registration actions
// ============================================================
async function approveRegistration(id) {
    if (!confirm('Approve this registration? This will auto-create a student record.')) return;
    const res = await apiReg('', { id: id, status: 'Approved' }, 'PUT');
    if (res.success) {
        alert('Registration approved! Student record auto-created.');
        loadRegistrations();
        loadOverviewStats();
    } else {
        alert('Error: ' + (res.message || 'Failed to approve'));
    }
}

async function rejectRegistration(id) {
    if (!confirm('Reject this registration?')) return;
    const res = await apiReg('', { id: id, status: 'Rejected' }, 'PUT');
    if (res.success) {
        alert('Registration rejected.');
        loadRegistrations();
        loadOverviewStats();
    } else {
        alert('Error: ' + (res.message || 'Failed to reject'));
    }
}

async function deleteRegistration(id) {
    if (!confirm('Delete this registration? This cannot be undone.')) return;
    const res = await fetch('../api/registration.php?id=' + id, { method: 'DELETE' });
    const result = await res.json();
    if (result.success) {
        alert('Registration deleted.');
        loadRegistrations();
        loadOverviewStats();
    } else {
        alert('Error: ' + (result.message || 'Failed to delete'));
    }
}

function viewRegistration(id) {
    const reg = allRegistrations.find(r => r.id === id);
    if (!reg) return;
    
    // Create modal content with photo display
    let modalContent = `
        <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
            <h3 style="color: #085636; margin-bottom: 20px;">Registration #${reg.id}</h3>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 20px;">
                <div>
                    <strong>Student:</strong><br>${reg.studentName || ''}
                </div>
                <div>
                    <strong>Grade:</strong><br>${reg.grade || ''}
                </div>
                <div>
                    <strong>Parent:</strong><br>${reg.parentName || ''}
                </div>
                <div>
                    <strong>Phone:</strong><br>${reg.phone || ''}
                </div>
                <div>
                    <strong>Email:</strong><br>${reg.email || ''}
                </div>
                <div>
                    <strong>Address:</strong><br>${reg.address || ''}
                </div>
                <div>
                    <strong>DOB:</strong><br>${reg.dateOfBirth || ''}
                </div>
                <div>
                    <strong>Status:</strong><br><span style="padding: 4px 8px; border-radius: 4px; background: ${reg.status === 'Approved' ? '#2ecc71' : reg.status === 'Rejected' ? '#e74c3c' : '#f39c12'}; color: white;">${reg.status || 'Pending'}</span>
                </div>
            </div>
            ${reg.idPhoto ? `
                <div style="margin-bottom: 20px;">
                    <strong>ID Photo:</strong><br>
                    <img src="../${reg.idPhoto}" alt="ID Photo" style="max-width: 200px; max-height: 200px; border: 2px solid #085636; border-radius: 8px; margin-top: 10px;">
                </div>
            ` : ''}
            <div style="margin-bottom: 15px;">
                <strong>Created:</strong><br>${new Date(reg.createdAt || '').toLocaleString()}
            </div>
            ${reg.studentId ? `<div style="margin-bottom: 10px;"><strong>Student ID:</strong> ${reg.studentId}</div>` : ''}
            ${reg.paymentId ? `<div style="margin-bottom: 10px;"><strong>Payment ID:</strong> ${reg.paymentId}</div>` : ''}
            <div style="margin-top: 15px; padding: 15px; background: #f5f5f5; border-radius: 8px;">
                <strong>Notes:</strong><br>${reg.notes || 'None'}
            </div>
        </div>
    `;
    
    // Create and show modal
    const modal = document.createElement('div');
    modal.style.cssText = 'position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 10000;';
    modal.innerHTML = `
        <div style="background: white; border-radius: 12px; max-width: 90%; max-height: 90%; overflow-y: auto; position: relative;">
            <button onclick="this.closest('div[style*=\'position: fixed\']').remove()" style="position: absolute; top: 10px; right: 10px; background: #e74c3c; color: white; border: none; width: 30px; height: 30px; border-radius: 50%; cursor: pointer; font-size: 18px;">&times;</button>
            ${modalContent}
        </div>
    `;
    document.body.appendChild(modal);
}

// ============================================================
// Search and filter
// ============================================================
function filterRegistrations() {
    const statusFilter = document.getElementById('regStatusFilter');
    currentRegFilter = statusFilter ? statusFilter.value : '';
    loadRegistrations();
}

function searchRegistrations() {
    const searchInput = document.getElementById('regSearch');
    currentRegSearch = searchInput ? searchInput.value : '';
    renderRegistrationsCustom();
}

// ============================================================
// Overview statistics
// ============================================================
async function loadOverviewStats() {
    try {
        const res = await fetch('../api/registration.php?action=stats');
        const data = await res.json();
        if (data.success && data.data) {
            const stats = data.data;
            const statReg = document.getElementById('statRegistrations');
            if (statReg) statReg.textContent = stats.pending;

            // Update badge
            const badge = document.querySelector('#sidebar .sidebar-link.active .admin-badge');
            if (badge) badge.textContent = stats.total;
        }
    } catch (e) {
        // Silently fail
    }
}

// ============================================================
// Export registrations
// ============================================================
function exportRegistrations() {
    if (allRegistrations.length === 0) {
        alert('No registrations to export.');
        return;
    }
    const csv = [
        ['ID', 'Student Name', 'Grade', 'Parent', 'Phone', 'Email', 'Address', 'DOB', 'Status', 'Created'],
        ...allRegistrations.map(r => [
            r.id, r.studentName, r.grade, r.parentName, r.phone, r.email,
            r.address, r.dateOfBirth, r.status, r.createdAt
        ])
    ].map(row => row.map(cell => `"${cell || ''}"`).join(',')).join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'registrations_' + new Date().toISOString().slice(0, 10) + '.csv';
    a.click();
    URL.revokeObjectURL(url);
}

// ============================================================
// Initialize
// ============================================================
function initRegistrationManagement() {
    loadRegistrations();
    loadOverviewStats();
}

// Auto-initialize when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    // Only initialize if we're on the registrations section or overview
    if (document.getElementById('registrationsTableBody') || document.getElementById('statRegistrations')) {
        initRegistrationManagement();
    }
});

