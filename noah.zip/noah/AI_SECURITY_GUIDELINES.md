# AI Assistant Security Guidelines

## Overview

This document outlines the security measures implemented in the NCA AI Assistant and provides guidelines for maintaining a secure deployment.

## Implemented Security Measures

### 1. SQL Injection Prevention

**Implementation:**
- All database queries use MySQLi prepared statements
- Parameterized queries with type binding
- No direct SQL execution from user input

**Files:**
- `api/db.php` - Database connection and query functions
- `api/ai_tools.php` - All database operations

**Example:**
```php
$stmt = $conn->prepare("SELECT * FROM students WHERE id = ?");
$stmt->bind_param('i', $studentId);
$stmt->execute();
```

### 2. Role-Based Access Control (RBAC)

**Implementation:**
- User roles validated on every request
- Teachers restricted to assigned class data
- Administrators have school-wide access
- Permission checks before each database operation

**Files:**
- `api/ai_tools.php` - Permission checks in each tool method
- `api/ai.php` - Role validation in API endpoints

**Access Matrix:**

| Feature | Teacher | Admin | Parent |
|---------|---------|-------|--------|
| View own students | ✓ | ✓ | ✓ (own children) |
| View class students | ✓ (assigned class) | ✓ | ✗ |
| View all students | ✗ | ✓ | ✗ |
| View fees | ✗ | ✓ | ✗ (own children) |
| View teachers | ✗ | ✓ | ✗ |
| Generate reports | ✓ (own class) | ✓ | ✗ |
| Save lesson plans | ✓ | ✓ | ✗ |

### 3. API Key Security

**Implementation:**
- API keys stored in environment variables (`.env`)
- Never exposed to frontend JavaScript
- Backend-only API calls
- `.env.example` provided without real keys

**Files:**
- `.env` - Environment configuration (not in git)
- `.env.example` - Template (in git)
- `api/ai_service.php` - Reads from environment

**Best Practices:**
- Never commit `.env` to version control
- Rotate API keys regularly
- Use separate keys for development/production
- Monitor API usage for anomalies

### 4. Input Validation & Sanitization

**Implementation:**
- All user inputs validated before processing
- File upload restrictions (type, size)
- XSS prevention in output
- Content Security Policy headers

**Files:**
- `api/ai.php` - Input validation
- `api/ai_tools.php` - Parameter validation
- Frontend - CSP headers in HTML

**File Upload Restrictions:**
- Allowed types: PDF, DOCX, XLSX, CSV, TXT
- Maximum size: 10MB (configurable)
- Virus scanning recommended (not implemented)

### 5. Audit Logging

**Implementation:**
- All AI usage logged to `ai_usage_log` table
- Activity logging for important actions
- Timestamp, user ID, role, token usage tracked

**Files:**
- `api/ai.php` - Usage logging function
- `api/db.php` - Activity log function

**Logged Data:**
- User ID and role
- Request message (truncated to 500 chars)
- Token usage (prompt, completion, total)
- Timestamp
- Tools used

### 6. Confirmation Workflows

**Implementation:**
- Destructive actions require confirmation
- Clear warning messages
- Two-step process for important operations

**Files:**
- `script/ai-chat.js` - Confirmation UI
- `api/ai.php` - Confirmation endpoint

**Actions Requiring Confirmation:**
- Save lesson plans
- Delete data
- Send bulk messages
- Generate certificates

### 7. Prompt Injection Prevention

**Implementation:**
- System prompt with clear guidelines
- Tool-based architecture (no direct SQL)
- AI instructed to refuse sensitive requests
- Output sanitization

**System Prompt Guidelines:**
- Never reveal passwords, API keys, or secrets
- Respect user permissions
- Don't invent or hallucinate data
- Refuse requests outside scope

## Security Checklist

### Before Deployment

- [ ] Set strong API keys (minimum 32 characters)
- [ ] Configure `.env` with production credentials
- [ ] Ensure `.env` is not in version control
- [ ] Test with sample data
- [ ] Verify permission system works correctly
- [ ] Check audit logging is functioning
- [ ] Test file upload restrictions
- [ ] Verify SSL/TLS is enabled

### Ongoing Maintenance

- [ ] Monitor API usage daily (check for anomalies)
- [ ] Review audit logs weekly
- [ ] Rotate API keys monthly
- [ ] Update dependencies regularly
- [ ] Review permission assignments
- [ ] Backup database regularly
- [ ] Monitor for security vulnerabilities

### After Security Incident

- [ ] Rotate all API keys immediately
- [ ] Review audit logs for suspicious activity
- [ ] Check for unauthorized data access
- [ ] Update passwords for affected users
- [ ] Document the incident
- [ ] Implement additional safeguards

## Known Limitations

1. **File Upload Security**
   - Virus scanning not implemented
   - Recommendation: Integrate ClamAV or similar

2. **Rate Limiting**
   - No rate limiting on API endpoints
   - Recommendation: Implement rate limiting middleware

3. **Session Security**
   - Uses existing session system
   - Recommendation: Implement session timeout

4. **Encryption at Rest**
   - Database not encrypted
   - Recommendation: Enable MySQL encryption for sensitive data

## Recommendations

### For Production Deployment

1. **HTTPS Only**
   - Enforce HTTPS for all connections
   - Use HSTS headers
   - Valid SSL certificate

2. **Database Security**
   - Use strong database passwords
   - Restrict database user permissions
   - Enable database query logging
   - Regular database backups

3. **API Security**
   - Implement rate limiting
   - Use API gateway if available
   - Monitor for abuse patterns
   - Set spending limits on OpenAI account

4. **Network Security**
   - Firewall rules to restrict access
   - VPN for admin access
   - Regular security audits
   - Penetration testing

### For Development

1. **Development Environment**
   - Use separate API keys
   - Test with dummy data
   - Enable detailed error logging
   - Use development database

2. **Testing**
   - Unit tests for security functions
   - Integration tests for API endpoints
   - Penetration testing before deployment
   - Code review for security issues

## Incident Response

If a security incident is suspected:

1. **Immediate Actions**
   - Disable AI assistant (remove API key)
   - Review audit logs
   - Identify affected data
   - Notify stakeholders

2. **Investigation**
   - Determine root cause
   - Assess impact scope
   - Document findings
   - Preserve evidence

3. **Recovery**
   - Restore from backups if needed
   - Patch vulnerabilities
   - Update security measures
   - Communicate with users

4. **Post-Incident**
   - Conduct post-mortem
   - Update security policies
   - Implement lessons learned
   - Schedule follow-up audits

## Compliance Considerations

### Data Privacy

- Student data is sensitive educational records
- Follow local data protection laws
- Implement data retention policies
- Provide data export on request

### Educational Records

- Comply with FERPA or equivalent
- Restrict access to authorized personnel
- Log all data access
- Implement data minimization

## Contact

For security concerns or to report vulnerabilities:
- Email: security@nca.edu
- Internal security team

---

**Version**: 1.0.0
**Last Updated**: 2026-10-06
**Review Date**: 2026-12-06
