<?php
/**
 * Google OAuth start endpoint.
* Usage: /auth.php?role=teacher|parent|admin
 */
session_start();
require_once __DIR__ . '/api/db.php';

if (!is_file(__DIR__ . '/vendor/autoload.php')) {
    http_response_code(503);
    exit('Google login is not installed yet. Run "composer install" in the website root.');
}
require_once __DIR__ . '/vendor/autoload.php';
$dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
$dotenv->safeLoad();

// Check if this is an OAuth callback (has code and state)
$code = $_GET['code'] ?? '';
$stateRaw = $_GET['state'] ?? '';

if ($code && $stateRaw) {
    // This is a callback - redirect to callback.php to handle it
    $basePath = dirname($_SERVER['SCRIPT_NAME'] ?? '/noah');
    $callbackUrl = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https://' : 'http://') . ($_SERVER['HTTP_HOST'] ?? 'localhost')) . $basePath . '/callback.php';
    $queryString = http_build_query($_GET);
    header('Location: ' . $callbackUrl . '?' . $queryString);
    exit;
}

// Otherwise, initiate OAuth flow
$role = strtolower(trim($_GET['role'] ?? ''));
if (!in_array($role, ['admin','teacher','parent'], true)) {
    http_response_code(400);
    exit('Invalid login role.');
}
$_SESSION['oauth_role'] = $role;

$client = new Google\Client();
$client->setClientId($_ENV['GOOGLE_CLIENT_ID'] ?? '');
$client->setClientSecret($_ENV['GOOGLE_CLIENT_SECRET'] ?? '');
$basePath = dirname($_SERVER['SCRIPT_NAME'] ?? '/noah');
$client->setRedirectUri($_ENV['GOOGLE_REDIRECT_URI'] ?? ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https://' : 'http://') . ($_SERVER['HTTP_HOST'] ?? 'localhost') . $basePath . '/callback.php'));
$client->addScope('openid');
$client->addScope('email');
$client->addScope('profile');
$client->setPrompt('select_account');
$client->setState(base64_encode(json_encode(['role'=>$role,'nonce'=>bin2hex(random_bytes(16))])));

if (!$client->getClientId() || !$client->getClientSecret()) {
    http_response_code(503);
    exit('Google OAuth is not configured. Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET.');
}

header('Location: ' . $client->createAuthUrl());
exit;
?>
