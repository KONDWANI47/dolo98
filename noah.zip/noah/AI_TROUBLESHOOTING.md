# AI Assistant Troubleshooting

## Issue: AI Assistant Not Responding

### Problem
The AI assistant button appears but doesn't respond when you send a message.

### Solution

The most common cause is that the **OpenAI API key is not configured**.

#### Step 1: Get an OpenAI API Key

1. Go to https://platform.openai.com/api-keys
2. Sign up or log in to your OpenAI account
3. Click "Create new secret key"
4. Copy the API key (starts with `sk-...`)

#### Step 2: Configure the API Key

1. Open the `.env` file in your project root: `C:\xampp\htdocs\noah\.env`
2. Find this line:
   ```
   AI_API_KEY=your_openai_api_key_here
   ```
3. Replace `your_openai_api_key_here` with your actual API key:
   ```
   AI_API_KEY=sk-your-actual-api-key-here
   ```
4. Save the file

#### Step 3: Test the AI Assistant

1. Refresh your browser
2. Log in to the Teacher or Admin portal
3. Click the AI assistant button (left side of screen)
4. Try sending a message: "Hello"

The AI should now respond.

---

## Other Issues

### AI Button Not Showing

**Check browser console:**
1. Press F12 to open developer tools
2. Click on Console tab
3. Look for red error messages

**Common causes:**
- JavaScript file not loading
- CSS file not loading
- User not logged in

**Solution:**
- Verify `script/ai-chat.js` exists
- Verify `css/ai-chat.css` exists
- Make sure you're logged in to the portal

### "Permission Denied" Error

**Cause:** User doesn't have permission to access the requested data.

**Solution:**
- Teachers can only access their assigned class
- Admins have full access
- Check that your user role is correct

### "Network Error" Message

**Cause:** API endpoint not reachable.

**Solution:**
- Check that `api/ai.php` exists
- Verify PHP is running
- Check internet connection (AI needs internet to work)

### API Key Working But No Response

**Check OpenAI Dashboard:**
1. Go to https://platform.openai.com/usage
2. Verify you have available credits
3. Check if API key is active

**Common issues:**
- No credits in OpenAI account
- API key was revoked
- Spending limit reached

---

## Debug Mode

To see detailed error messages:

1. Open browser console (F12)
2. Look for console.log messages
3. Check for:
   - "AI Chat Init:" - Shows if initialization happened
   - "Sending message to AI:" - Shows what was sent
   - "Response data:" - Shows API response
   - Red error messages - Shows errors

---

## Quick Fix Checklist

- [ ] OpenAI API key added to `.env` file
- [ ] API key is valid (starts with `sk-`)
- [ ] OpenAI account has credits
- [ ] User is logged in to portal
- [ ] JavaScript files are loading (check console)
- [ ] PHP is running (test other features)
- [ ] Internet connection is working

---

## Still Not Working?

1. Check the PHP error log
2. Verify `api/ai.php` is accessible
3. Test the API directly:
   ```bash
   curl -X POST http://localhost/noah/api/ai.php \
   -H "Content-Type: application/json" \
   -d '{"action":"chat","message":"test","user_id":1,"user_role":"admin"}'
   ```

---

## Need Help?

Refer to:
- **AI_ASSISTANT_SETUP.md** - Full setup guide
- **AI_SECURITY_GUIDELINES.md** - Security information
